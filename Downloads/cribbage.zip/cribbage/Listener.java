/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

import java.util.Scanner;

public class Listener {

	private Scanner scan;
	private InputChecker check;

	public Listener(Scanner scan) {
		this.scan = scan;
		check = new InputChecker();
	}
	
	public void pause() {
		scan.nextLine();
	}
	
	public void pause(String text) {
		System.out.println(text);
		scan.nextLine();
	}

	public String getString(String text) {
		while(true) {
			System.out.print(text);
			String s = scan.nextLine();
			if(check.isString(s)) {
				return s;
			}
		}
	}
	
	public String getString(String text, int opt) {
		while(true) {
			System.out.print(text);
			String s = scan.nextLine();
			if(!check.isString(s)) {
				continue;
			}
			switch(opt) {
			case 0:
				return s;
			case 1:
				return s.toUpperCase().charAt(0) + s.toLowerCase().substring(1);
			case 2:
				return s.toUpperCase();
			case 3:
				return s.toLowerCase();
			}
		}
	}

	public char getChar(String text) {
		while(true) {
			System.out.print(text);
			String input = scan.nextLine();
			if(check.isString(input)) {
				return input.charAt(0);
			}
		}
	}
	
	public char getChar(String text, int opt) {
		while(true) {
			System.out.print(text);
			String input = scan.nextLine();
			if(!check.isString(input)) {
				continue;
			}
			switch(opt) {
			case 0:
				return input.charAt(0);
			case 1:
				input = input.toUpperCase();
				return input.charAt(0);
			case 2:
				input = input.toLowerCase();
				return input.charAt(0);
			}
		}
	}

	public int getInt(String text) {
		while(true) {
			System.out.print(text);
			String input = scan.nextLine();
			if(check.inputMatches(input, "int")) {
				return Integer.parseInt(input);
			}
		}
	}

	public int getInt(String text, int min) {
		while(true) {
			System.out.print(text);
			String input = scan.nextLine();
			if(check.inputMatches(input, "int")) {
				int inputInt = Integer.parseInt(input);
				if(check.isInRange(inputInt, min)) {
					return inputInt;
				}
			}
		}
	}

	public int getInt(String text, int min, int max) {
		while(true) {
			System.out.print(text);
			String input = scan.nextLine();
			if(check.inputMatches(input, "int")) {
				int inputInt = Integer.parseInt(input);
				if(check.isInRange(inputInt, min, max)) {
					return inputInt;
				}
			}
		}
	}

	public float getFloat(String text) {
		while(true) {
			System.out.print(text);
			String input = scan.nextLine();
			if(check.inputMatches(input, "float")) {
				return Float.parseFloat(input);
			}
		}
	}

	public float getFloat(String text, float min) {
		while(true) {
			System.out.print(text);
			String input = scan.nextLine();
			if(check.inputMatches(input, "float")) {
				Float inputFloat = Float.parseFloat(input);
				if(check.isInRange(inputFloat, min)) {
					return inputFloat;
				}
			}
		}
	}

	public float getFloat(String text, float min, float max) {
		while(true) {
			System.out.print(text);
			String input = scan.nextLine();
			if(check.inputMatches(input, "float")) {
				Float inputFloat = Float.parseFloat(input);
				if(check.isInRange(inputFloat, min, max)) {
					return inputFloat;
				}
			}
		}
	}

	public double getDouble(String text) {
		while(true) {
			System.out.print(text);
			String input = scan.nextLine();
			if(check.inputMatches(input, "double")) {
				return Double.parseDouble(input);
			}
		}
	}

	public double getDouble(String text, double min) {
		while(true) {
			System.out.print(text);
			String input = scan.nextLine();
			if(check.inputMatches(input, "double")) {
				double inputDouble = Double.parseDouble(input);
				if(check.isInRange(inputDouble, min)) {
					return inputDouble;
				}
			}
		}
	}

	public double getDouble(String text, double min, double max) {
		while(true) {
			System.out.print(text);
			String input = scan.nextLine();
			if(check.inputMatches(input, "double")) {
				double inputDouble = Double.parseDouble(input);
				if(check.isInRange(inputDouble, min, max)) {
					return inputDouble;
				}
			}
		}
	}

}
