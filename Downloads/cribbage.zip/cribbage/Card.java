/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Card {

	private String rank;
	private String suit;
	private String abv;
	private int value;
	private int order;

	public Card(String rank, String suit, String abv, int value, int order) {
		this.rank = rank;
		this.suit = suit;
		this.abv = abv;
		this.value = value;
		this.order = order;
	}

	public Card(String rank, String suit) {
		this.rank = rank;
		this.suit = suit;
		try {
			initVars();
		} catch(CardException ex) {
			ex.printStackTrace();
			System.exit(0);
		}
	}

	public Card(String abv) {
		try {
			this.abv = abv;
			initVars(abv);
		} catch(CardException ex) {
			ex.printStackTrace();
			System.exit(0);
		}
	}

	private void initVars() throws CardException {
		abv = "";
		switch(rank) {
		case "Ace":
			abv += "A";
			value = 1;
			order = 1;
			break;
		case "Two":
			abv += "2";
			value = 2;
			order = 2;
			break;
		case "Three":
			abv += "3";
			value = 3;
			order = 3;
			break;
		case "Four":
			abv += "4";
			value = 4;
			order = 4;
			break;
		case "Five":
			abv += "5";
			value = 5;
			order = 5;
			break;
		case "Six":
			abv += "6";
			value = 6;
			order = 6;
			break;
		case "Seven":
			abv += "7";
			value = 7;
			order = 7;
			break;
		case "Eight":
			abv += "8";
			value = 8;
			order = 8;
			break;
		case "Nine":
			abv += "9";
			value = 9;
			order = 9;
			break;
		case "Ten":
			abv += "10";
			value = 10;
			order = 10;
			break;
		case "Jack":
			abv += "J";
			value = 10;
			order = 11;
			break;
		case "Queen":
			abv += "Q";
			value = 10;
			order = 12;
			break;
		case "King":
			abv += "K";
			value = 10;
			order = 13;
			break;
		default:
			throw new CardException("Invalid Rank");
		}

		switch(suit) {
		case "Diamonds":
			abv += "d";
			break;
		case "Clubs":
			abv += "c";
			break;
		case "Hearts":
			abv += "h";
			break;
		case "Spades":
			abv += "s";
			break;
		default:
			throw new CardException("Invalid Suit");
		}
	}

	private void initVars(String abv) throws CardException {
		try {
			String[] arr = abv.split("");
			String rankAbv = arr[0];
			String suitAbv;
			if(arr[0].equals("1") && arr[1].equals("0")) {
				rankAbv += arr[1];
				suitAbv = arr[2];
			} else {
				suitAbv = arr[1];
			}
			switch(rankAbv) {
			case "A":
				rank = "Ace";
				value = 1;
				order = 1;
				break;
			case "2":
				rank = "Two";
				value = 2;
				order = 2;
				break;
			case "3":
				rank = "Three";
				value = 3;
				order = 3;
				break;
			case "4":
				rank = "Four";
				value = 4;
				order = 4;
				break;
			case "5":
				rank = "Five";
				value = 5;
				order = 5;
				break;
			case "6":
				rank = "Six";
				value = 6;
				order = 6;
				break;
			case "7":
				rank = "Seven";
				value = 7;
				order = 7;
				break;
			case "8":
				rank = "Eight";
				value = 8;
				order = 8;
				break;
			case "9":
				rank = "Nine";
				value = 9;
				order = 9;
				break;
			case "10":
				rank = "Ten";
				value = 10;
				order = 10;
				break;
			case "J":
				rank = "Jack";
				value = 10;
				order = 11;
				break;
			case "Q":
				rank = "Queen";
				value = 10;
				order = 12;
				break;
			case "K":
				rank = "King";
				value = 10;
				order = 13;
				break;
			default:
				throw new CardException("Invalid Rank");
			}

			switch(suitAbv) {
			case "d":
				suit = "Diamonds";
				break;
			case "c":
				suit = "Clubs";
				break;
			case "h":
				suit = "Hearts";
				break;
			case "s":
				suit = "Spades";
				break;
			default:
				throw new CardException("Invalid Suit");
			}
		} catch(IndexOutOfBoundsException ex) {
			throw new CardException("Invalid Card Input");
		}
	}

	public String getRank() {
		return rank;
	}
	public void setRank(String set) {
		rank = set;
	}

	public String getSuit() {
		return suit;
	}
	public void setSuit(String set) {
		suit = set;
	}

	public String getAbv() {
		return abv;
	}
	public void setAbv(String set) {
		abv = set;
	}

	public int getValue() {
		return value;
	}
	public void setValue(int set) {
		value = set;
	}

	public int getOrder() {
		return order;
	}
	public void setOrder(int set) {
		order = set;
	}

	public void printSelf() {
		System.out.println(abv);
	}

}