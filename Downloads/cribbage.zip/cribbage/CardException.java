/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

SuppressWarnings("serial")
public class CardException extends Exception {
	
	public CardException(String text) {
		super(text);
	}

}
