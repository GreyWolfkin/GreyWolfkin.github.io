/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Calculator {
	
	Builder build = new Builder();
	Scanner scan = new Scanner(System.in);

	private ArrayList<Card> combine(ArrayList<Card> hand, Card flip) {
		ArrayList<Card> sortedHand = new ArrayList<Card>();
		ArrayList<Card> unsortedHand = new ArrayList<Card>();
		for(Card card:hand) {
			unsortedHand.add(card);
		}

		unsortedHand.add(flip);

		int lowestOrder;
		Card lowestOrderCard;
		for(int i = 0; i < 5; i++) {
			lowestOrder = 14;
			lowestOrderCard = null;
			for(Card card:unsortedHand) {
				if(card.getOrder() < lowestOrder) {
					lowestOrderCard = card;
					lowestOrder = card.getOrder();
				}
			}
			sortedHand.add(lowestOrderCard);
			unsortedHand.remove(lowestOrderCard);
		}

		return sortedHand;
	}

	public int getScore(ArrayList<Card> hand, Card flip, boolean crib) {
		int score = 0;
		int fifteens = getFifteens(combine(hand, flip));
//		System.out.println("Fifteens: " + fifteens);
		score += fifteens;
		int pairs = getPairs(combine(hand, flip));
//		System.out.println("Pairs: " + pairs);
		score += pairs;
		int runs = getRuns(combine(hand, flip));
//		System.out.println("Runs: " + runs);
		score += runs;
		int flush = getFlush(hand, flip, crib);
//		System.out.println("Flush: " + flush);
		score += flush;
		int nibs = getNibs(hand, flip);
//		System.out.println("Nibs: " + nibs);
		score += nibs;
		return score;
	}
	
	public double getPossibleScore(ArrayList<Card> hand, Card throw0, Card throw1) {
		double score = 0;
		
		ArrayList<Card> deck = build.getDeck();
		ArrayList<Card> tempHand = hand;
		
		
		Card deckCard;
		for(Card handCard:tempHand) {
			Iterator<Card> it = deck.iterator();
			while(it.hasNext()) {
				deckCard = (Card) it.next();
//				System.out.println("HandCard abv: " + handCard.getAbv());
//				System.out.println("DeckCard abv: " + deckCard.getAbv());
				if(handCard.getAbv().equals(deckCard.getAbv()) || throw0.getAbv().equals(deckCard.getAbv()) || throw1.getAbv().equals(deckCard.getAbv())) {
					it.remove();
				}
			}
		}
		
		for(Card possFlip:deck) {
//			System.out.println("If flip is " + possFlip.getAbv());
			score += (getScore(tempHand, possFlip, false) / 46.0);
//			scan.nextLine();
		}
//		System.out.println("Weighted score is " + score);
		return score;
	}
	
	public double getPossibleCrib(ArrayList<Card> hand, Card throw0, Card throw1) {
		double score = 0;
		
		ArrayList<Card> deck = build.getDeck();
		ArrayList<Card> tempHand = hand;
		ArrayList<Card> tempCrib = new ArrayList<Card>();
		
		
		Card deckCard;
		for(Card handCard:tempHand) {
			Iterator<Card> it = deck.iterator();
			while(it.hasNext()) {
				deckCard = (Card) it.next();
//				System.out.println("HandCard abv: " + handCard.getAbv());
//				System.out.println("DeckCard abv: " + deckCard.getAbv());
				if(handCard.getAbv().equals(deckCard.getAbv()) || throw0.getAbv().equals(deckCard.getAbv()) || throw1.getAbv().equals(deckCard.getAbv())) {
					it.remove();
				}
			}
		}
		
//		for(int i = 0; i < 44; i++) {
//			tempCrib.clear();
//			tempCrib.add(throw0);
//			tempCrib.add(throw1);
//			tempCrib.add(deck.get(i));
//			for(int j = i + 1; j < 45; j++) {
//				tempCrib.add(deck.get(j));
//				for(int k = j + 1; k < 46; k++) {
//					Card possFlip = deck.get(k);
//					score += (getScore(tempCrib, possFlip, true) / 91080.0);
//				}
//			}
//		}
		
//		for(Card possFlip:deck) {
////			System.out.println("If flip is " + possFlip.getAbv());
//			score += (getScore(tempHand, possFlip, false) / 46.0);
////			scan.nextLine();
//		}
//		System.out.println("Weighted score is " + score);
		if(throw0.getValue() + throw1.getValue() == 15) {
			score += 2;
		}
		if(throw0.getOrder() == throw1.getOrder()) {
			score += 2;
		}
		int numOf10s = 16;
		for(Card card:tempHand) {
			if(card.getValue() == 10) {
				numOf10s--;
			}
		}
		if(throw0.getValue() == 10) {
			numOf10s--;
		}
		if(throw1.getValue() == 10) {
			numOf10s--;
		}
		if(throw0.getValue() == 5) {
			score += 2 / (46.0 / numOf10s);
		}
		if(throw1.getValue() == 5) {
			score += 2 / (46.0 / numOf10s);
		}
		System.out.println("Weighted Crib score is " + score);
		return score;
	}

	private int getFifteens(ArrayList<Card> hand) {
		int score = 0;

		int value0;
		int value1;
		int value2;
		int value3;
		int value4;
		for(int i = 0; i < 5; i++) {
			Card card0 = hand.get(i);
			value0 = card0.getValue();
			for(int j = i + 1; j < 5; j++) {
				Card card1 = hand.get(j);
				value1 = card1.getValue();
				if(value0 + value1 == 15) {
					score += 2;
				}
				for(int k = j + 1; k < 5; k++) {
					Card card2 = hand.get(k);
					value2 = card2.getValue();
					if(value0 + value1 + value2 == 15) {
						score += 2;
					}
					for(int l = k + 1; l < 5; l++) {
						Card card3 = hand.get(l);
						value3 = card3.getValue();
						if(value0 + value1 + value2 + value3 == 15) {
							score += 2;
						}
						for(int m = l + 1; m < 5; m++) {
							Card card4 = hand.get(m);
							value4 = card4.getValue();
							if(value0 + value1 + value2 + value3 + value4 == 15) {
								score += 2;
							}
						}
					}
				}
			}
		}

		return score;
	}

	private int getPairs(ArrayList<Card> hand) {
		int score = 0;
		for(int i = 0; i < 5; i++) {
			Card card0 = hand.get(i);
			int order0 = card0.getOrder();
			for(int j = i + 1; j < 5; j++) {
				Card card1 = hand.get(j);
				int order1 = card1.getOrder();
				if(order0 == order1) {
					score += 2;
				}
			}
		}
		return score;
	}

	private int getRuns(ArrayList<Card> hand) {
		int score = 0;

		for(int i = 0; i < 5; i++) {
			Card card0 = hand.get(i);
			int order0 = card0.getOrder();
			for(int j = i + 1; j < 5; j++) {
				Card card1 = hand.get(j);
				int order1 = card1.getOrder();
				for(int k = j + 1; k < 5; k++) {
					Card card2 = hand.get(k);
					int order2 = card2.getOrder();
					if(order2 == order1 + 1 && order1 == order0 + 1) {
						score += 3;
						Card card3 = null;
						Card card4 = null;
						int order3 = 0;
						int order4 = 0;
						try {
							card3 = hand.get(k + 1);
							order3 = card3.getOrder();
							card4 = hand.get(k + 2);
							order4 = card4.getOrder();
						} catch(IndexOutOfBoundsException ex) {}
						if(order3 == order2 + 1) {
							score += 1;
							if(order4 == order3 + 1) {
								score += 1;
								return score;
							}
							return score;
						}
						if(order4 == order2 + 1) {
							score += 1;
							return score;
						}
					}
				}
			}
		}
		return score;
	}

	private int getFlush(ArrayList<Card> hand, Card flip, boolean crib) {
		int score = 0;

		String suit = hand.get(0).getSuit();
		if(hand.get(1).getSuit().equals(suit) && hand.get(2).getSuit().equals(suit) && hand.get(3).getSuit().equals(suit)) {
			if(!crib) {
				score += 4;
				if(flip.getSuit().equals(suit)) {
					score += 1;
				}
			} else {
				if(flip.getSuit().equals(suit)) {
					score += 5;
				}
			}
		}

		return score;
	}

	private int getNibs(ArrayList<Card> hand, Card flip) {
		int score = 0;

		for(Card card:hand) {
			if(card.getRank().equals("Jack") && card.getSuit().equals(flip.getSuit())) {
				score += 1;
			}
		}

		return score;
	}

}
