/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

/*****
 * WORK IN PROGRESS
 * MULTIPLE BUGS STILL PRESENT
 *****/

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Cribbage {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Random rand = new Random();
		Listener l = new Listener(scan);
		Calculator calc = new Calculator();
		ArrayList<Card> hand0 = new ArrayList<Card>();
		ArrayList<Card> hand1 = new ArrayList<Card>();
		ArrayList<Card> crib = new ArrayList<Card>();
		Builder build = new Builder();
		ArrayList<Card> deck = build.getDeck();
		
		boolean compCrib = true;
		
		while(true) {
			
			hand0.clear();
			
			deck = build.shufDeck(deck);
			
			for(int i = 0; i < 12; i++) {
				if(i % 2 == 0) {
					hand0.add(deck.get(i));
				}
			}
			
			System.out.println("Hand0");
			for(Card card:hand0) {
				card.printSelf();
			}
			
			if(compCrib) {
				System.out.println("\nMy Crib");
			} else {
				System.out.println("\nYour Crib");
			}
			
			l.pause();
			
			double highestPossibleScore = 0;
			
			Card possibleCard0 = null;
			Card possibleCard1 = null;
			ArrayList<Card> tempHand = new ArrayList<Card>();
			double tempScore;
			Card tempCard0;
			Card tempCard1;
			for(int card0Index = 0; card0Index < 6; card0Index++) {
				for(int card1Index = card0Index + 1; card1Index < 6; card1Index++) {
					tempCard0 = hand0.get(card0Index);
					tempCard1 = hand0.get(card1Index);
					System.out.println("Removing " + tempCard0.getAbv() + " and " + tempCard1.getAbv());
					tempHand.clear();
					for(Card card:hand0) {
						tempHand.add(card);
					}
					tempHand.remove(tempCard0);
					tempHand.remove(tempCard1);
//					tempScore = calc.getScore(tempHand, flip, false);
					tempScore = calc.getPossibleScore(tempHand, tempCard0, tempCard1);
					if(compCrib) {
						tempScore += calc.getPossibleCrib(tempHand, tempCard0, tempCard1);
					} else {
						tempScore -= calc.getPossibleCrib(tempHand, tempCard0, tempCard1);
					}
					System.out.println("Possible Score: " + tempScore);
					if(tempScore > highestPossibleScore) {
						highestPossibleScore = tempScore;
						possibleCard0 = tempCard0;
						possibleCard1 = tempCard1;
					}
//					l.pause();
				}
			}
			hand0.remove(possibleCard0);
			hand0.remove(possibleCard1);
			
			System.out.println("Hand0");
			for(Card card:hand0) {
				card.printSelf();
			}
		
			int flipIndex = rand.nextInt(40) + 11;
			Card flip = deck.get(flipIndex);
			
			System.out.println("\nFlip");
			flip.printSelf();
			
			System.out.println("\n\nScore: " + calc.getScore(hand0, flip, false));
			
//			hand0.clear();
//			hand1.clear();
//			crib.clear();
//			
//			deck = build.shufDeck(deck);
//			
//			for(int i = 0; i < 12; i++) {
//				Card card = deck.get(i);
//				if(i % 2 == 0) {
//					hand0.add(card);
//				} else {
//					hand1.add(card);
//				}
//			}
//			
//			System.out.println("Hand0");
//			for(Card card:hand0) {
//				card.printSelf();
//			}
//			System.out.println("\n\nHand1");
//			for(Card card:hand1) {
//				card.printSelf();
//			}
//			System.out.println("\n");
//			
//			int index;
//			for(int i = 0; i < 4; i++) {
//				if(i % 2 == 0) {
//					index = rand.nextInt(hand0.size());
//					crib.add(hand0.get(index));
//					hand0.remove(index);
//				} else {
//					index = rand.nextInt(hand1.size());
//					crib.add(hand1.get(index));
//					hand1.remove(index);
//				}
//			}
//			
//			System.out.println("Crib");
//			for(Card card:crib) {
//				card.printSelf();
//			}
//			
//			int flipIndex = rand.nextInt(40) + 11;
//			Card flip = deck.get(flipIndex);
//			System.out.println("\nFlip");
//			flip.printSelf();
//			
//			
//			System.out.println("\n\nHand0");
//			for(Card card:hand0) {
//				card.printSelf();
//			}
//			flip.printSelf();
//			System.out.println("\nScore: " + calc.getScore(hand0, flip, false));
//			
//			System.out.println("\n\nHand1");
//			for(Card card:hand1) {
//				card.printSelf();
//			}
//			flip.printSelf();
//			System.out.println("\nScore: " + calc.getScore(hand1, flip, false));
//			
//			System.out.println("\n\nCrib");
//			for(Card card:crib) {
//				card.printSelf();
//			}
//			flip.printSelf();
//			System.out.println("\nScore: " + calc.getScore(crib, flip, true));
			
			if(l.getString("END?\n", 2).equals("END")) {
				System.exit(0);
			}
			compCrib = !compCrib;
		}
	}
}
