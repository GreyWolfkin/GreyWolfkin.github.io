/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

import java.util.ArrayList;
import java.util.Random;

public class Builder {
	
	Random rand = new Random();
	
	public ArrayList<Card> getDeck() {
		ArrayList<Card> deck = new ArrayList<Card>();
		
		String[] ranks = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
		
		String[] suits = {"d", "c", "h", "s"};
		
		String abv;
		for(String rank:ranks) {
			for(String suit:suits) {
				abv = rank + suit;
				Card newCard = new Card(abv);
				deck.add(newCard);
			}
		}
		
		return deck;
	}
	
	public ArrayList<Card> shufDeck(ArrayList<Card> deck) {
		ArrayList<Card> shufDeck = new ArrayList<Card>();
		
		ArrayList<Card> newDeck = new ArrayList<Card>();
		
		for(Card card:deck) {
			newDeck.add(card);
		}
		
		int index;
		for(int i = 0; i < 51; i++) {
			index = rand.nextInt(newDeck.size());
			shufDeck.add(newDeck.get(index));
			newDeck.remove(index);
		}
		shufDeck.add(newDeck.get(0));
		newDeck.remove(0);
		
		return shufDeck;
	}

}
