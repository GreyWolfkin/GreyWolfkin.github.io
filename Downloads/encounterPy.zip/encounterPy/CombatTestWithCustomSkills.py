# TODO:
#   Multiple Enemies
#       e1, e2, e3
#       All the same type vs Multiple Types
#       If multiple types, how to prioritize who to attack?
#   Mana Conservation
#       Mana Strategy = 'Careful', 'Balanced', or 'Generous'
#       Run simulated combats using NO mana (x10)
#       Based on Mana Strategy, 1 HP is worth x Mana
#       Do not use more Mana than allowed
#   Generate Enemies
#       Enter desired hp lost and number of turns
#       Generates ballpark numbers, runs 100 simulations
#       If hp lost > estimated * 1.2 or
#           number of turns > estimated + 2 then reduce
#           Enemy stats by ~.5, rerun. If
#           hp lost < estimated *.8 or
#           number of turns < estimated - 2 or number
#           of turns = 1 then increase Enemy stats by
#           ~.5, repeat until finished, then print
#           enemy stats
#   Add mAtk and mDef
#       Set mAtk, mDef at construction
#       Allow skills to modify mAtk or mDef, or use
#           mAtk for damage calculations
#   Add turn counter for persisting buffs/debuffs
#   Add evasion / to-hit modifiers
#       Base 95% chance to hit, skills increase
#           or decrease chance to hit, increase
#           or decrease evasion
#   Add classes (Fighter, Mage, Rogue, Cleric)
#       ?
#       Is this necessary? If we include mAtk and mDef
#           as well as skills which can use mAtk/mDef
#           this will simulate classes?

from random import *
from math import *

run = True
skills = []
skill1 = None
skill2 = None
skill3 = None

class Player:
    def __init__(self, maxHP, maxPAtk, maxPDef, maxMana, skill1 = None, skill2 = None, skill3 = None, strategy = 'Balanced'):
        self.maxHP = maxHP
        self.hp = maxHP
        self.maxPAtk = maxPAtk
        self.pAtk = maxPAtk
        self.maxPDef = maxPDef
        self.pDef = maxPDef
        self.maxMana = maxMana
        self.mana = maxMana
        self.skill1 = skill1
        self.skill2 = skill2
        self.skill3 = skill3
        self.strategy = strategy

    def fullHeal(self):
        self.hp = self.maxHP
        self.mana = self.maxMana

    def reset(self):
        self.pAtk = self.maxPAtk
        self.pDef = self.maxPDef

class Skill:
    def __init__(self, name, type, cost, pAtk, pDef, heal):
        self.name = name
        self.type = type
        self.cost = cost
        self.pAtk = pAtk
        self.pDef = pDef
        self.heal = heal

    def use(self):
        global p
        p.mana -= self.cost
        p.pAtk = p.pAtk*self.pAtk
        if p.pDef*self.pDef <= 100:
            p.pDef = p.pDef*self.pDef
        else:
            p.pDef = 100
        if p.hp + p.maxHP*self.heal < p.maxHP:
            p.hp += p.maxHP*self.heal
        else:
            p.hp = p.maxHP

    def print(self):
        print(self.name + "\n\tType: " + self.type + "\n\tMana: " + str(self.cost) + "\n\tAttack: " + str(self.pAtk) + "\n\tDefense: " + str(self.pDef) + "\n\tHeal: " + str(self.heal))

class Enemy:
    def __init__(self, maxHP = 40, pAtk = 6, pDef = 0):
        self.maxHP = maxHP
        self.hp = self.maxHP
        self.pAtk = pAtk
        self.pDef = pDef

    def fullHeal(self):
        self.hp = self.maxHP

def getInput(str):
    userIn = input(str)
    userIn = userIn.capitalize()
    return userIn

def buildPlayer():
    validHP = False
    while not validHP:
        pHP = getInput("Player HP: ")
        try:
            pHP = int(pHP)
            validHP = True
        except ValueError:
            print("Unrecognized Input")
    validAtk = False
    while not validAtk:
        pAtk = getInput("Player Attack: ")
        try:
            pAtk = int(pAtk)
            validAtk = True
        except ValueError:
            print("Unrecognized Input")
    validDef = False
    while not validDef:
        pDef = getInput("Player Defense: ")
        try:
            pDef = int(pDef)
            if int(pDef) < 100:
                validDef = True
            else:
                print("Defense must be less than 100")
        except ValueError:
            print("Unrecognized Input")
    validMana = False
    while not validMana:
        pMana = getInput("Player Mana: ")
        try:
            pMana = int(pMana)
            validMana = True
        except ValueError:
            print("Unrecognized Input")
    validStrat = False
    while not validStrat:
        pStrat = getInput("Strategy:\nDefensive\nBalanced\nAggressive\n")
        if pStrat == 'Defensive':
            validStrat = True
        elif pStrat == 'Balanced':
            validStrat = True
        elif pStrat == 'Aggressive':
            validStrat = True
        else:
            print("Unrecognized Input")
    p = Player(pHP, pAtk, pDef, pMana)
    p.strategy = pStrat
    return p

def buildSkills():
    global skill1
    global skill2
    global skill3
    global p
    global skills
    skill0 = Skill('None', 'None', 0, 0, 0, 0)
    skill1 = None
    skill2 = None
    skill3 = None
    skills.clear()
    skills.append(skill0)
    validSkill1 = False
    while not validSkill1:
        chooseSkill1 = getInput("Add Skill 1?\nYes\nNo\n")
        if chooseSkill1 == 'Yes':
            validSkill1 = True
            pSkill1 = getInput("Name of Skill 1: ")
            validSkill1Type = False
            while not validSkill1Type:
                pSkill1Type = getInput("Type of Skill 1:\nAttack\nDefense\nHealing\nCombo\n")
                if pSkill1Type == 'Attack':
                    validSkill1Type = True
                elif pSkill1Type == 'Defense':
                    validSkill1Type = True
                elif pSkill1Type == 'Healing':
                    validSkill1Type = True
                elif pSkill1Type == 'Combo':
                    validSkill1Type = True
                else:
                    print("Unrecognized Input")
            validSkill1Cost = False
            while not validSkill1Cost:
                pSkill1Cost = getInput("Mana Cost of Skill 1: ")
                try:
                    pSkill1Cost = int(pSkill1Cost)
                    if pSkill1Cost > 0:
                        validSkill1Cost = True
                    else:
                        print("Mana Cost must be greater than 0")
                except ValueError:
                    print("Unrecognized Input")
            validModifier = False
            while not validModifier:
                if pSkill1Type == 'Attack':
                    validAtkModifier = False
                    while not validAtkModifier:
                        atkModifier = getInput("Multiply Attack by: ")
                        try:
                            atkModifier = float(atkModifier)
                            if atkModifier > 1.0:
                                validAtkModifier = True
                                pSkill1Atk = atkModifier
                            else:
                                print("Modifier must be greater than 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validDefModifier = False
                    while not validDefModifier:
                        defModifier = getInput("Multiply Defense by: ")
                        try:
                            defModifier = float(defModifier)
                            if defModifier >= 0.0:
                                validDefModifier = True
                                pSkill1Def = defModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validHealModifier = False
                    while not validHealModifier:
                        healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                        try:
                            healModifier = float(healModifier)
                            if 1.0 >= healModifier and healModifier > -1.0:
                                validHealModifier = True
                                pSkill1Heal = healModifier
                                validModifier = True
                            else:
                                print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                elif pSkill1Type == 'Defense':
                    validAtkModifier = False
                    while not validAtkModifier:
                        atkModifier = getInput("Multiply Attack by: ")
                        try:
                            atkModifier = float(atkModifier)
                            if atkModifier >= 0.0:
                                validAtkModifier = True
                                pSkill1Atk = atkModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validDefModifier = False
                    while not validDefModifier:
                        defModifier = getInput("Multiply Defense by: ")
                        try:
                            defModifier = float(defModifier)
                            if defModifier > 1.0:
                                validDefModifier = True
                                pSkill1Def = defModifier
                            else:
                                print("Modifier must be greater than 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validHealModifier = False
                    while not validHealModifier:
                        healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                        try:
                            healModifier = float(healModifier)
                            if 1.0 >= healModifier and healModifier > -1.0:
                                validHealModifier = True
                                pSkill1Heal = healModifier
                                validModifier = True
                            else:
                                print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                elif pSkill1Type == 'Healing':
                    validAtkModifier = False
                    while not validAtkModifier:
                        atkModifier = getInput("Multiply Attack by: ")
                        try:
                            atkModifier = float(atkModifier)
                            if atkModifier >= 0.0:
                                validAtkModifier = True
                                pSkill1Atk = atkModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validDefModifier = False
                    while not validDefModifier:
                        defModifier = getInput("Multiply Defense by: ")
                        try:
                            defModifier = float(defModifier)
                            if defModifier >= 0.0:
                                validDefModifier = True
                                pSkill1Def = defModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validHealModifier = False
                    while not validHealModifier:
                        healModifier = getInput("(0.1 - 1.0) Heal what percentage? ")
                        try:
                            healModifier = float(healModifier)
                            if 1.0 >= healModifier and healModifier > 0.0:
                                validHealModifier = True
                                pSkill1Heal = healModifier
                                validModifier = True
                            else:
                                print("Modifier must be greater than 0.0 and less than or equal to 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                elif pSkill1Type == 'Combo':
                    validAtkModifier = False
                    while not validAtkModifier:
                        atkModifier = getInput("Multiply Attack by: ")
                        try:
                            atkModifier = float(atkModifier)
                            if atkModifier >= 0.0:
                                validAtkModifier = True
                                pSkill1Atk = atkModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validDefModifier = False
                    while not validDefModifier:
                        defModifier = getInput("Multiply Defense by: ")
                        try:
                            defModifier = float(defModifier)
                            if defModifier >= 0.0:
                                validDefModifier = True
                                pSkill1Def = defModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validHealModifier = False
                    while not validHealModifier:
                        healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                        try:
                            healModifier = float(healModifier)
                            if 1.0 >= healModifier and healModifier > -1.0:
                                validHealModifier = True
                                pSkill1Heal = healModifier
                                validModifier = True
                            else:
                                print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                        except ValueError:
                            print("Unrecognized Input")
            skill1 = Skill(pSkill1, pSkill1Type, pSkill1Cost, pSkill1Atk, pSkill1Def, pSkill1Heal)
            skills.append(skill1)
        elif chooseSkill1 == 'No':
            validSkill1 = True
            skill1 = None
            skill2 = None
            skill3 = None
        else:
            print("Unrecognized Input")
    if skill1 != None:
        validSkill2 = False
        while not validSkill2:
            chooseSkill2 = getInput("Add Skill 2?\nYes\nNo\n")
            if chooseSkill2 == 'Yes':
                validSkill2 = True
                pSkill2 = getInput("Name of Skill 2: ")
                validSkill2Type = False
                while not validSkill2Type:
                    pSkill2Type = getInput("Type of Skill 2:\nAttack\nDefense\nHealing\nCombo\n")
                    if pSkill2Type == 'Attack':
                        validSkill2Type = True
                    elif pSkill2Type == 'Defense':
                        validSkill2Type = True
                    elif pSkill2Type == 'Healing':
                        validSkill2Type = True
                    elif pSkill2Type == 'Combo':
                        validSkill2Type = True
                    else:
                        print("Unrecognized Input")
                validSkill2Cost = False
                while not validSkill2Cost:
                    pSkill2Cost = getInput("Mana Cost of Skill 2: ")
                    try:
                        pSkill2Cost = int(pSkill2Cost)
                        if pSkill2Cost > 0:
                            validSkill2Cost = True
                        else:
                            print("Mana Cost must be greater than 0")
                    except ValueError:
                        print("Unrecognized Input")
                validModifier = False
                while not validModifier:
                    if pSkill2Type == 'Attack':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier > 1.0:
                                    validAtkModifier = True
                                    pSkill2Atk = atkModifier
                                else:
                                    print("Modifier must be greater than 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill2Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill2Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill2Type == 'Defense':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill2Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier > 1.0:
                                    validDefModifier = True
                                    pSkill2Def = defModifier
                                else:
                                    print("Modifier must be greater than 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill2Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill2Type == 'Healing':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill2Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill2Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(0.1 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > 0.0:
                                    validHealModifier = True
                                    pSkill2Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than 0.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill2Type == 'Combo':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill2Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill2Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill2Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                skill2 = Skill(pSkill2, pSkill2Type, pSkill2Cost, pSkill2Atk, pSkill2Def, pSkill2Heal)
                skills.append(skill2)
            elif chooseSkill2 == 'No':
                validSkill2 = True
                skill2 = None
                skill3 = None
            else:
                print("Unrecognized Input")
    if skill2 != None:
        validSkill3 = False
        while not validSkill3:
            chooseSkill3 = getInput("Add Skill 3?\nYes\nNo\n")
            if chooseSkill3 == 'Yes':
                validSkill3 = True
                pSkill3 = getInput("Name of Skill 3: ")
                validSkill3Type = False
                while not validSkill3Type:
                    pSkill3Type = getInput("Type of Skill 3:\nAttack\nDefense\nHealing\nCombo\n")
                    if pSkill3Type == 'Attack':
                        validSkill3Type = True
                    elif pSkill3Type == 'Defense':
                        validSkill3Type = True
                    elif pSkill3Type == 'Healing':
                        validSkill3Type = True
                    elif pSkill3Type == 'Combo':
                        validSkill3Type = True
                    else:
                        print("Unrecognized Input")
                validSkill3Cost = False
                while not validSkill3Cost:
                    pSkill3Cost = getInput("Mana Cost of Skill 3: ")
                    try:
                        pSkill3Cost = int(pSkill3Cost)
                        if pSkill3Cost > 0:
                            validSkill3Cost = True
                        else:
                            print("Mana Cost must be greater than 0")
                    except ValueError:
                        print("Unrecognized Input")
                validModifier = False
                while not validModifier:
                    if pSkill3Type == 'Attack':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier > 1.0:
                                    validAtkModifier = True
                                    pSkill3Atk = atkModifier
                                else:
                                    print("Modifier must be greater than 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill3Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill3Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill3Type == 'Defense':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill3Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier > 1.0:
                                    validDefModifier = True
                                    pSkill3Def = defModifier
                                else:
                                    print("Modifier must be greater than 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill3Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill3Type == 'Healing':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill3Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill3Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(0.1 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > 0.0:
                                    validHealModifier = True
                                    pSkill3Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than 0.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill3Type == 'Combo':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill3Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill3Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill3Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                skill3 = Skill(pSkill3, pSkill3Type, pSkill3Cost, pSkill3Atk, pSkill3Def, pSkill3Heal)
                skills.append(skill3)
            elif chooseSkill3 == 'No':
                validSkill3 = True
                skill3 = None
            else:
                print("Unrecognized Input")
    p.skill1 = skill1
    p.skill2 = skill2
    p.skill3 = skill3

def buildEnemy():
    validHP = False
    while not validHP:
        eHP = getInput("Enemy HP: ")
        try:
            int(eHP)
            validHP = True
        except ValueError:
            print("Unrecognized Input")
    validAtk = False
    while not validAtk:
        eAtk = getInput("Enemy Attack: ")
        try:
            int(eAtk)
            validAtk = True
        except ValueError:
            print("Unrecognized Input")
    validDef = False
    while not validDef:
        eDef = getInput("Enemy Defense: ")
        try:
            int(eDef)
            if int(eDef) < 100:
                validDef = True
            else:
                print("Defense must be less than 100")
        except ValueError:
            print("Unrecognized Input")
    e = Enemy(int(eHP), int(eAtk), int(eDef))
    return e

hpLostList = []
def getHPLost():
    global hpLostList
    totalLost = 0
    for i in hpLostList:
        totalLost += i
    avgLost = totalLost/100
    hpLostList.clear()
    return avgLost

turnsList = []
def getTurns():
    global turnsList
    totalTurns = 0
    for i in turnsList:
        totalTurns += i
    avgTurns = totalTurns/100
    turnsList.clear()
    return avgTurns

usedMana = []
def getUsedMana():
    global usedMana
    totalUsed = 0
    for i in usedMana:
        totalUsed += i
    avgUsed = totalUsed/100
    usedMana.clear()
    return avgUsed

usedSkill1 = 0
def getUsedSkill1():
    global usedSkill1
    avgUsed = usedSkill1/100
    usedSkill1 = 0
    return avgUsed

usedSkill2 = 0
def getUsedSkill2():
    global usedSkill2
    avgUsed = usedSkill2/100
    usedSkill2 = 0
    return avgUsed

usedSkill3 = 0
def getUsedSkill3():
    global usedSkill3
    avgUsed = usedSkill3/100
    usedSkill3 = 0
    return avgUsed

def usedSkill(skill):
    global usedSkill1
    global usedSkill2
    global usedSkill3
    if skill == skill1:
        usedSkill1 += 1
    elif skill == skill2:
        usedSkill2 += 1
    elif skill == skill3:
        usedSkill3 += 1

winsList = []
def getWins():
    global winsList
    totalWins = 0
    for i in winsList:
        totalWins += i
    winsList.clear()
    return totalWins

def atkAdj(pAtk, pDef):
    multiplier = (12 - randint(0,4))/10
    adjAtk = pAtk * multiplier
    defPerc = (100 - pDef)/100
    dam = ceil(adjAtk * defPerc)
    if dam < 0:
        dam = 0
    return dam

def turn():
    i = randint(0,3)
    if i == 0:
        turnInt = 0
    else:
        turnInt = 1
    return turnInt

def combat():
    global p
    global e
    global winsList
    global hpLostList
    global turnsList
    global usedMana
    global skills
    p.fullHeal()
    e.fullHeal()
    turnInt = turn()
    numTurns = 0
    while p.hp > 0 and e.hp > 0:
        if turnInt == 0:
            dam = atkAdj(e.pAtk, p.pDef)
            p.hp -= dam
            p.reset()
            turnInt = 1
        elif turnInt == 1:
            if p.strategy == 'Defensive':
                bestSkill = skills[0]
                bestAction = 'None'
                if p.hp < p.maxHP:
                    for i in skills:
                        if i.heal > 0:
                            if i.cost <= p.mana:
                                if p.hp + i.heal*p.maxHP <= p.maxHP:
                                    bestAction = 'HealSkill'
                if bestAction == 'None' and p.mana > p.maxMana*.5 and (atkAdj(e.pAtk, p.pDef) >= p.hp*.5 or atkAdj(e.pAtk, p.pDef) >= p.maxHP*.2):
                    for i in skills:
                        if i.pDef > 1:
                            if i.cost <= p.mana:
                                bestAction = 'DefenseSkill'
                if bestAction == 'HealSkill':
                    for i in skills:
                        if i.heal > 0:
                            if i.cost <= p.mana:
                                if p.hp + i.heal*p.maxHP <= p.maxHP:
                                    if i.heal > bestSkill.heal:
                                        bestSkill = i
                                    elif i.heal == bestSkill.heal and i.pDef > bestSkill.pDef:
                                        bestSkill = i
                                    elif i.heal == bestSkill.heal and i.pDef == bestSkill.pDef and i.pAtk > bestSkill.pAtk:
                                        bestSkill = i
                if bestAction == 'DefenseSkill':
                    for i in skills:
                        if i.pDef > 1:
                            if i.cost <= p.mana:
                                #if i.heal*p.maxHP*-1 <= p.hp*.25:
                                if i.pDef > bestSkill.pDef:
                                    bestSkill = i
                                elif i.pDef == bestSkill.pDef and i.heal > bestSkill.heal and p.hp < p.maxHP:
                                    bestSkill = i
                                elif i.pDef == bestSkill.pDef and i.pAtk > bestSkill.pAtk:
                                    bestSkill = i
                if bestSkill != skills[0]:
                    bestSkill.use()
                    usedSkill(bestSkill)
                dam = atkAdj(p.pAtk, e.pDef)
                e.hp -= dam
                numTurns += 1
                turnInt = 0
            elif p.strategy == 'Balanced':
                bestSkill = skills[0]
                bestAction = 'None'
                if p.hp <= p.maxHP*.5:
                    for i in skills:
                        if i.heal > 0:
                            if i.cost <= p.mana:
                                bestAction = 'HealSkill'
                if bestAction == 'None':
                    if p.mana > p.maxMana*.25:
                        if atkAdj(e.pAtk, p.pDef) >= p.hp*.66 or atkAdj(e.pAtk, p.pDef) >= p.maxHP*.33:
                            for i in skills:
                                if i.pDef > 1:
                                    if i.cost <= p.mana:
                                        bestAction = 'DefenseSkill'
                if bestAction == 'None':
                    if p.mana > p.maxMana*.25:
                        if atkAdj(p.pAtk, e.pDef) >= e.hp*.5:
                            for i in skills:
                                if i.pAtk > 1:
                                    if i.cost <= p.mana:
                                        bestAction = 'AttackSkill'
                if bestAction == 'HealSkill':
                    for i in skills:
                        if i.heal > 0:
                            if i.cost <= p.mana:
                                if p.hp + i.heal*p.maxHP <= p.maxHP:
                                    if i.heal > bestSkill.heal:
                                        bestSkill = i
                                    elif i.heal == bestSkill.heal and i.pDef > bestSkill.pDef:
                                        bestSkill = i
                                    elif i.heal == bestSkill.heal and i.pDef == bestSkill.pDef and i.pAtk > bestSkill.pAtk:
                                        bestSkill = i
                if bestAction == 'DefenseSkill':
                    for i in skills:
                        if i.pDef > 1:
                            if i.cost <= p.mana:
                                #if i.heal*p.maxHP*-1 <= p.hp*.3:
                                if i.pDef > bestSkill.pDef:
                                    bestSkill = i
                                elif i.pDef == bestSkill.pDef and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal*p.maxHP <= p.maxHP:
                                    bestSkill = i
                                elif i.pDef == bestSkill.pDef and i.pAtk > bestSkill.pAtk:
                                    bestSkill = i
                if bestAction == 'AttackSkill':
                    for i in skills:
                        if i.pAtk > 1:
                            if i.cost <= p.mana:
                                #if i.heal*p.maxHP*-1 <= p.hp*.3:
                                if i.pAtk > bestSkill.pAtk and atkAdj(p.pAtk*i.pAtk, e.pDef) <= e.hp:
                                    bestSkill = i
                                elif i.pAtk == bestSkill.pAtk and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal*p.maxHP <= p.maxHP:
                                    bestSkill = i
                                elif i.pAtk == bestSkill.pAtk and i.pDef > bestSkill.pDef:
                                    bestSkill = i
                if bestSkill != skills[0]:
                    bestSkill.use()
                    usedSkill(bestSkill)
                dam = atkAdj(p.pAtk, e.pDef)
                e.hp -= dam
                numTurns += 1
                turnInt = 0
            elif p.strategy == 'Aggressive':
                bestSkill = skills[0]
                bestAction = 'None'
                if atkAdj(e.pAtk, p.pDef) >= p.hp*.8:
                    for i in skills:
                        if i.heal > 0:
                            if i.cost <= p.mana:
                                bestAction = 'HealSkill'
                if bestAction == 'None' and atkAdj(p.pAtk, e.pDef) <= e.hp*.5:
                    for i in skills:
                        if i.pAtk > 1:
                            if i.cost <= p.mana:
                                bestAction = 'AttackSkill'
                if bestAction == 'HealSkill':
                    for i in skills:
                        if i.heal > 0:
                            if i.cost <= p.mana:
                                if i.heal > bestSkill.heal and p.hp + i.heal*p.maxHP <= p.maxHP:
                                    bestSkill = i
                                elif i.heal == bestSkill.heal and i.pAtk > bestSkill.pAtk:
                                    bestSkill = i
                                elif i.heal == bestSkill.heal and i.pAtk == bestSkill.pAtk and i.pDef > bestSkill.pDef:
                                    bestSkill = i
                elif bestAction == 'AttackSkill':
                    for i in skills:
                        if i.pAtk > 1:
                            if i.cost <= p.mana:
                                #if i.heal*p.maxHP*-1 <= p.hp * .5:
                                if i.pAtk > bestSkill.pAtk and atkAdj(p.pAtk*i.pAtk, e.pDef) <= e.hp:
                                    bestSkill = i
                                elif i.pAtk == bestSkill.pAtk and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal*p.maxHP <= p.maxHP:
                                    bestSkill = i
                                elif i.pAtk == bestSkill.pAtk and i.pDef > bestSkill.pDef:
                                    bestSkill = i
                if bestSkill != skills[0]:
                    bestSkill.use()
                    usedSkill(bestSkill)
                dam = atkAdj(p.pAtk, e.pDef)
                e.hp -= dam
                numTurns += 1
                turnInt = 0
    if e.hp <= 0:
        winsList.append(1)
    elif p.hp <= 0:
        winsList.append(0)
    hpLost = p.maxHP - p.hp
    hpLostList.append(hpLost)
    manaUsed = p.maxMana - p.mana
    usedMana.append(manaUsed)
    turnsList.append(numTurns)

p = buildPlayer()
buildSkills()
e = buildEnemy()

while run:
    hpLostList.clear()
    turnsList.clear()
    winsList.clear()
    repeat = 100
    print("Beginning iterations.")
    while repeat > 0:
        combat()
        repeat -= 1
    print("Iterations complete")
    print("Player HP: " + str(p.maxHP) + "\nPlayer Attack: " + str(p.maxPAtk) + "\nPlayer Defense: " + str(p.maxPDef) + "\nPlayer Mana: " + str(p.maxMana) + "\nStrategy: " + p.strategy)
    if skill1 != None:
        skill1.print()
    if skill2 != None:
        skill2.print()
    if skill3 != None:
        skill3.print()
    print("Enemy HP: " + str(e.maxHP) + "\nEnemy Attack: " + str(e.pAtk) + "\nEnemy Defense: " + str(e.pDef))
    print("Average HP lost: " + str(getHPLost()))
    print("Average Mana used: " + str(getUsedMana()))
    if skill1 != None:
        print("Used Skill 1: " + str(getUsedSkill1()))
    if skill2 != None:
        print("Used Skill 2: " + str(getUsedSkill2()))
    if skill3 != None:
        print("Used Skill 3: " + str(getUsedSkill3()))
    print("Average number of turns: " + str(getTurns()))
    print("Number of wins: " + str(getWins()))

    print()

    validRunAgain = False
    while not validRunAgain:
        runAgainInput = getInput("Run again?\nYes\nNo\n")
        if runAgainInput == 'Yes':
            validRunAgain = True
            validChangeStats = False
            while not validChangeStats:
                changeStatsInput = getInput("Change Player Stats?\nYes\nNo\n")
                if changeStatsInput == 'Yes':
                    validChangeStats = True
                    p = buildPlayer()
                    validChangeSkills = False
                    while not validChangeSkills:
                        changeSkillsInput = getInput("Change Skills?\nYes\nNo\n")
                        if changeSkillsInput == 'Yes':
                            validChangeSkills = True
                            buildSkills()
                        elif changeSkillsInput == 'No':
                            validChangeSkills = True
                        else:
                            print("Unrecognized Input")
                elif changeStatsInput == 'No':
                    validChangeStats = True
                    validChangeStrategy = False
                    while not validChangeStrategy:
                        changeStrategyInput = getInput("Change Strategy?\nYes\nNo\n")
                        if changeStrategyInput == 'Yes':
                            validChangeStrategy = True
                            validStrategy = False
                            while not validStrategy:
                                strategyInput = getInput("Strategy:\nDefensive\nBalanced\nAggressive\n")
                                if strategyInput == 'Defensive':
                                    validStrategy = True
                                    p.strategy = 'Defensive'
                                elif strategyInput == 'Balanced':
                                    validStrategy = True
                                    p.strategy = 'Balanced'
                                elif strategyInput == 'Aggressive':
                                    validStrategy = True
                                    p.strategy = 'Aggressive'
                                else:
                                    print("Unrecognized Input")
                            validChangeSkills = False
                            while not validChangeSkills:
                                changeSkillsInput = getInput("Change Skills?\nYes\nNo\n")
                                if changeSkillsInput == 'Yes':
                                    validChangeSkills = True
                                    buildSkills()
                                elif changeSkillsInput == 'No':
                                    validChangeSkills = True
                                else:
                                    print("Unrecognized Input")
                        elif changeStrategyInput == 'No':
                            validChangeStrategy = True
                            validChangeSkills = False
                            while not validChangeSkills:
                                changeSkillsInput = getInput("Change Skills?\nYes\nNo\n")
                                if changeSkillsInput == 'Yes':
                                    validChangeSkills = True
                                    buildSkills()
                                elif changeSkillsInput == 'No':
                                    validChangeSkills = True
                                else:
                                    print("Unrecognized Input")
                        else:
                            print("Unrecognized Input")
                else:
                    print("Unrecognized Input")
            validChangeEnemy = False
            while not validChangeEnemy:
                changeEnemyInput = getInput("Change Enemy Stats?\nYes\nNo\n")
                if changeEnemyInput == 'Yes':
                    validChangeEnemy = True
                    e = buildEnemy()
                elif changeEnemyInput == 'No':
                    validChangeEnemy = True
                else:
                    print("Unrecognized Input")
        elif runAgainInput == 'No':
            validRunAgain = True
            run = False
        else:
            print("Unrecognized Input")