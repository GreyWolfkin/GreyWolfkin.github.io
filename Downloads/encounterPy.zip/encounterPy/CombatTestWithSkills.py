from random import *
from math import *

run = True

class Player:
    def __init__(self, maxHP = 100, maxPAtk = 20, maxPDef = 20, maxMana = 100, strategy = 'Balanced'):
        self.maxHP = maxHP
        self.hp = self.maxHP
        self.maxPAtk = maxPAtk
        self.pAtk = self.maxPAtk
        self.maxPDef = maxPDef
        self.pDef = self.maxPDef
        self.maxMana = maxMana
        self.mana = self.maxMana
        self.strategy = strategy

    def fullHeal(self):
        self.hp = self.maxHP
        self.mana = self.maxMana

    def secondWind(self):
        self.hp += 40
        self.mana -= 50

    def slash(self):
        self.mana -= 25

    def reset(self):
        self.pAtk = self.maxPAtk
        self.pDef = self.maxPDef

class Enemy:
    def __init__(self, maxHP = 40, pAtk = 6, pDef = 0):
        self.maxHP = maxHP
        self.hp = self.maxHP
        self.pAtk = pAtk
        self.pDef = pDef

    def fullHeal(self):
        self.hp = self.maxHP

def getInput(str):
    userIn = input(str)
    userIn = userIn.capitalize()
    return userIn

def buildPlayer():
    validHP = False
    while not validHP:
        pHP = getInput("Player HP: ")
        try:
            int(pHP)
            validHP = True
        except ValueError:
            print("Unrecognized Input")
    validAtk = False
    while not validAtk:
        pAtk = getInput("Player Attack: ")
        try:
            int(pAtk)
            validAtk = True
        except ValueError:
            print("Unrecognized Input")
    validDef = False
    while not validDef:
        pDef = getInput("Player Defense: ")
        try:
            int(pDef)
            if int(pDef) < 100:
                validDef = True
            else:
                print("Defense must be less than 100")
        except ValueError:
            print("Unrecognized Input")
    validMana = False
    while not validMana:
        pMana = getInput("Player Mana: ")
        try:
            int(pMana)
            validMana = True
        except ValueError:
            print("Unrecognized Input")
    validStrat = False
    while not validStrat:
        pStrat = getInput("Strategy:\nDefensive\nBalanced\nAggressive\n")
        if pStrat == 'Defensive':
            validStrat = True
        elif pStrat == 'Balanced':
            validStrat = True
        elif pStrat == 'Aggressive':
            validStrat = True
        else:
            print("Unrecognized Input")

    p = Player(int(pHP), int(pAtk), int(pDef), int(pMana), pStrat)
    return p

def buildEnemy():
    validHP = False
    while not validHP:
        eHP = getInput("Enemy HP: ")
        try:
            int(eHP)
            validHP = True
        except ValueError:
            print("Unrecognized Input")
    validAtk = False
    while not validAtk:
        eAtk = getInput("Enemy Attack: ")
        try:
            int(eAtk)
            validAtk = True
        except ValueError:
            print("Unrecognized Input")
    validDef = False
    while not validDef:
        eDef = getInput("Enemy Defense: ")
        try:
            int(eDef)
            if int(eDef) < 100:
                validDef = True
            else:
                print("Defense must be less than 100")
        except ValueError:
            print("Unrecognized Input")
    e = Enemy(int(eHP), int(eAtk), int(eDef))
    return e

hpLostList = []
def getHPLost():
    global hpLostList
    totalLost = 0
    for i in hpLostList:
        totalLost += i
    avgLost = totalLost/len(hpLostList)
    return avgLost

turnsList = []
def getTurns():
    global turnsList
    totalTurns = 0
    for i in turnsList:
        totalTurns += i
    avgTurns = totalTurns/len(turnsList)
    return avgTurns

usedSecondWind = []
def getSecondWind():
    global usedSecondWind
    totalUsed = 0
    for i in usedSecondWind:
        totalUsed += i
    avgUsed = totalUsed/len(usedSecondWind)
    return avgUsed

usedSlash = []
def getSlash():
    global usedSlash
    totalUsed = 0
    for i in usedSlash:
        totalUsed += i
    avgUsed = totalUsed/len(usedSlash)
    return avgUsed

usedMana = []
def getUsedMana():
    global usedMana
    totalUsed = 0
    for i in usedMana:
        totalUsed += i
    avgUsed = totalUsed/len(usedMana)
    return avgUsed

winsList = []
def getWins():
    global winsList
    totalWins = 0
    for i in winsList:
        totalWins += i
    return totalWins

def atkAdj(pAtk, pDef):
    multiplier = (12 - randint(0,4))/10
    adjAtk = pAtk * multiplier
    defPerc = (100 - pDef)/100
    dam = ceil(adjAtk * defPerc)
    return dam

def turn():
    i = randint(0,3)
    if i == 0:
        turnInt = 0
    else:
        turnInt = 1
    return turnInt

def combat():
    global p
    global e
    global winsList
    global hpLostList
    global usedMana
    global usedSecondWind
    global usedSlash
    p.fullHeal()
    e.fullHeal()
    turnInt = turn()
    numTurns = 0
    manaUsed = 0
    secondWindUsed = 0
    slashUsed = 0
    while p.hp > 0 and e.hp > 0:
        if turnInt == 0:
            dam = atkAdj(e.pAtk, p.pDef)
            p.hp -= dam
            turnInt = 1
        elif turnInt == 1:
            if p.strategy == 'Defensive':
                if p.hp <= 60 and p.mana >= 50:
                    p.secondWind()
                    manaUsed += 50
                    secondWindUsed += 1
                    numTurns += 1
                    turnInt = 0
                else:
                    dam = atkAdj(p.pAtk, e.pDef)
                    e.hp -= dam
                    numTurns += 1
                    turnInt = 0
            elif p.strategy == 'Balanced':
                if p.hp > 40 and p.mana > 50 and e.hp >= p.pAtk*2.5:
                    p.slash()
                    manaUsed += 25
                    slashUsed += 1
                    dam = atkAdj(p.pAtk*2, e.pDef)
                    e.hp -= dam
                    numTurns += 1
                    turnInt = 0
                elif p.hp <= 40 and p.mana >= 50:
                    p.secondWind()
                    manaUsed += 50
                    secondWindUsed += 1
                    numTurns += 1
                    turnInt = 0
                else:
                    dam = atkAdj(p.pAtk, e.pDef)
                    e.hp -= dam
                    numTurns += 1
                    turnInt = 0
            elif p.strategy == 'Aggressive':
                if p.mana >= 25 and e.hp >= p.pAtk*2.5:
                    p.slash()
                    manaUsed += 25
                    slashUsed += 1
                    dam = atkAdj(p.pAtk * 2, e.pDef)
                    e.hp -= dam
                    numTurns += 1
                    turnInt = 0
                else:
                    dam = atkAdj(p.pAtk, e.pDef)
                    e.hp -= dam
                    numTurns += 1
                    turnInt = 0
    if e.hp <= 0:
        winsList.append(1)
    elif p.hp <= 0:
        winsList.append(0)
    hpLost = p.maxHP - p.hp
    hpLostList.append(hpLost)
    manaUsed = p.maxMana - p.mana
    usedMana.append(manaUsed)
    usedSecondWind.append(secondWindUsed)
    usedSlash.append(slashUsed)
    turnsList.append(numTurns)

p = buildPlayer()
e = buildEnemy()

while run:
    hpLostList.clear()
    turnsList.clear()
    usedSecondWind.clear()
    usedSlash.clear()
    usedMana.clear()
    winsList.clear()
    repeat = 100
    print("Beginning iterations.")
    while repeat > 0:
        combat()
        repeat -= 1
    print("Iterations complete")
    print("Player HP: " + str(p.maxHP) + "\nPlayer Attack: " + str(p.pAtk) + "\nPlayer Defense: " + str(p.pDef) + "\nStrategy: " + p.strategy)
    print("Enemy HP: " + str(e.maxHP) + "\nEnemy Attack: " + str(e.pAtk) + "\nEnemy Defense: " + str(e.pDef))
    print("Average HP lost: " + str(getHPLost()))
    print("Average Mana used: " + str(getUsedMana()))
    print("Average number of turns: " + str(getTurns()))
    print("Average uses of Second Wind: " + str(getSecondWind()))
    print("Average uses of Slash: " + str(getSlash()))
    print("Number of wins: " + str(getWins()))
    print()

    validRunAgain = False
    while not validRunAgain:
        runAgainInput = getInput("Run again?\nYes\nNo\n")
        if runAgainInput == 'Yes':
            validRunAgain = True
            validChangeStats = False
            while not validChangeStats:
                changeStatsInput = getInput("Change Player Stats?\nYes\nNo\n")
                if changeStatsInput == 'Yes':
                    validChangeStats = True
                    p = buildPlayer()
                elif changeStatsInput == 'No':
                    validChangeStats = True
                    validChangeStrategy = False
                    while not validChangeStrategy:
                        changeStrategyInput = getInput("Change Strategy?\nYes\nNo\n")
                        if changeStrategyInput == 'Yes':
                            validChangeStrategy = True
                            validStrategy = False
                            while not validStrategy:
                                strategyInput = getInput("Strategy:\nDefensive\nBalanced\nAggressive\n")
                                if strategyInput == 'Defensive':
                                    validStrategy = True
                                    p.strategy = 'Defensive'
                                elif strategyInput == 'Balanced':
                                    validStrategy = True
                                    p.strategy = 'Balanced'
                                elif strategyInput == 'Aggressive':
                                    validStrategy = True
                                    p.strategy = 'Aggressive'
                                else:
                                    print("Unrecognized Input")
                        elif changeStrategyInput == 'No':
                            validChangeStrategy = True
                        else:
                            print("Unrecognized Input")
                else:
                    print("Unrecognized Input")
            validChangeEnemy = False
            while not validChangeEnemy:
                changeEnemyInput = getInput("Change Enemy Stats?\nYes\nNo\n")
                if changeEnemyInput == 'Yes':
                    validChangeEnemy = True
                    e = buildEnemy()
                elif changeEnemyInput == 'No':
                    validChangeEnemy = True
                else:
                    print("Unrecognized Input")
        elif runAgainInput == 'No':
            validRunAgain = True
            run = False
        else:
            print("Unrecognized Input")