#TODO:
#   Mana
#   Skills
#   Skill costs
#   Health Skills
#   Attack Skills
#   Defense Skills

run = True

class Player:
    def __init__(self, maxHP = 100, maxPAtk = 20, maxPDef = 20, maxMana = 100, skill1 = None, skill1Type = None, skill1Cost = None, skill1Atk = 0, skill1Def = 0, skill1Heal = 0, skill2 = None, skill2Type = None, skill2Cost = None, skill2Atk = 0, skill2Def = 0, skill2Heal = 0, skill3 = None, skill3Type = None, skill3Cost = None, skill3Atk = 0, skill3Def = 0, skill3Heal = 0, strategy = 'Balanced'):
        self.maxHP = maxHP
        self.hp = self.maxHP
        self.maxPAtk = maxPAtk
        self.pAtk = self.maxPAtk
        self.maxPDef = maxPDef
        self.pDef = self.maxPDef
        self.maxMana = maxMana
        self.mana = self.maxMana
        self.skill1 = skill1
        self.skill1Type = skill1Type
        self.skill1Cost = skill1Cost
        self.skill1Atk = skill1Atk
        self.skill1Def = skill1Def
        self.skill1Heal = skill1Heal
        self.skill2 = skill2
        self.skill2Type = skill2Type
        self.skill2Cost = skill2Cost
        self.skill2Atk = skill2Atk
        self.skill2Def = skill2Def
        self.skill2Heal = skill2Heal
        self.skill3 = skill3
        self.skill3Type = skill3Type
        self.skill3Cost = skill3Cost
        self.skill3Atk = skill3Atk
        self.skill3Def = skill3Def
        self.skill3Heal = skill3Heal
        self.strategy = strategy

    def print(self):
        print("HP: " + str(self.hp) + "\tAtk: " + str(self.pAtk) + "\tDef: " + str(self.pDef) + "\tMana: " + str(self.mana))
        print("Strategy: " + self.strategy)
        if self.skill1 != None:
            print("Skill 1 Name: " + self.skill1 + "\nSkill 1 Type: " + self.skill1Type + "\nSkill 1 Cost: " + str(self.skill1Cost))
            print("Skill 1 Attack: " + str(self.skill1Atk) + "\tSkill 1 Defense: " + str(self.skill1Def) + "\tSkill 1 Healing: " + str(self.skill1Heal))
        if self.skill2 != None:
            print("Skill 2 Name: " + self.skill2 + "\nSkill 2 Type: " + self.skill2Type + "\nSkill 2 Cost: " + str(self.skill2Cost))
            print("Skill 2 Attack: " + str(self.skill2Atk) + "\tSkill 2 Defense: " + str(self.skill2Def) + "\tSkill 2 Healing: " + str(self.skill2Heal))
        if self.skill3 != None:
            print("Skill 3 Name: " + self.skill3 + "\nSkill 3 Type: " + self.skill3Type + "\nSkill 3 Cost: " + str(self.skill3Cost))
            print("Skill 3 Attack: " + str(self.skill3Atk) + "\tSkill 3 Defense: " + str(self.skill3Def) + "\tSkill 3 Healing: " + str(self.skill3Heal))

def getInput(str):
    userIn = input(str)
    userIn = userIn.capitalize()
    return userIn

def buildPlayer():
    validHP = False
    while not validHP:
        pHP = getInput("Player HP: ")
        try:
            int(pHP)
            validHP = True
        except ValueError:
            print("Unrecognized Input")
    validAtk = False
    while not validAtk:
        pAtk = getInput("Player Attack: ")
        try:
            int(pAtk)
            validAtk = True
        except ValueError:
            print("Unrecognized Input")
    validDef = False
    while not validDef:
        pDef = getInput("Player Defense: ")
        try:
            int(pDef)
            if int(pDef) < 100:
                validDef = True
            else:
                print("Defense must be less than 100")
        except ValueError:
            print("Unrecognized Input")
    validMana = False
    while not validMana:
        pMana = getInput("Player Mana: ")
        try:
            int(pMana)
            validMana = True
        except ValueError:
            print("Unrecognized Input")
    validSkill1 = False
    while not validSkill1:
        chooseSkill1 = getInput("Add Skill 1?\nYes\nNo\n")
        if chooseSkill1 == 'Yes':
           validSkill1 = True
           pSkill1 = getInput("Name of Skill 1: ")
           validSkill1Type = False
           while not validSkill1Type:
               pSkill1Type = getInput("Type of Skill 1:\nAttack\nDefense\nHealing\nCombo\n")
               if pSkill1Type == 'Attack':
                   validSkill1Type = True
               elif pSkill1Type == 'Defense':
                   validSkill1Type = True
               elif pSkill1Type == 'Healing':
                   validSkill1Type = True
               elif pSkill1Type == 'Combo':
                   validSkill1Type = True
               else:
                   print("Unrecognized Input")
           validSkill1Cost = False
           while not validSkill1Cost:
               pSkill1Cost = getInput("Mana Cost of Skill 1: ")
               try:
                   int(pSkill1Cost)
                   if int(pSkill1Cost) > 0:
                       validSkill1Cost = True
                   else:
                       print("Mana Cost must be greater than 0")
               except ValueError:
                   print("Unrecognized Input")
           validModifier = False
           while not validModifier:
               if pSkill1Type == 'Attack':
                   atkModifier = getInput("Multiply Attack by: ")
                   try:
                       atkModifier = float(atkModifier)
                       if atkModifier > 1.0:
                           validModifier = True
                           pSkill1Atk = atkModifier
                           pSkill1Def = 1.0
                           pSkill1Heal = 0
                       else:
                           print("Modifier must be greater than 1.0")
                   except ValueError:
                       print("Unrecognized Input")
               elif pSkill1Type == 'Defense':
                   defModifier = getInput("Multiply Defense by: ")
                   try:
                       defModifier = float(defModifier)
                       if defModifier > 1.0:
                           validModifier = True
                           pSkill1Atk = 1.0
                           pSkill1Def = defModifier
                           pSkill1Heal = 0
                       else:
                           print("Modifier must be greater than 1.0")
                   except ValueError:
                       print("Unrecognized Input")
               elif pSkill1Type == 'Healing':
                   healModifier = getInput("(0.1 - 1.0) Heal what percentage: ")
                   try:
                       healModifier = float(healModifier)
                       if 1.0 >= healModifier >= 0.1:
                           validModifier = True
                           pSkill1Atk = 1.0
                           pSkill1Def = 1.0
                           pSkill1Heal = healModifier
                       else:
                           print("Percentage must be between 0.1 and 1.0")
                   except ValueError:
                       print("Unrecognized Input")
               elif pSkill1Type == 'Combo':
                   validAtkModifier = False
                   while not validAtkModifier:
                       atkModifier = getInput("Multiply Attack by: ")
                       try:
                           atkModifier = float(atkModifier)
                           if atkModifier > 1.0:
                               validAtkModifier = True
                               pSkill1Atk = atkModifier
                           else:
                               print("Modifier must be greater than 1.0")
                       except ValueError:
                           print("Unrecognized Input")
                   validDefModifier = False
                   while not validDefModifier:
                       defModifier = getInput("Multiply Def by: ")
                       try:
                           defModifier = float(defModifier)
                           if defModifier > 1.0:
                               validDefModifier = True
                               pSkill1Def = defModifier
                           else:
                               print("Modifier must be greater than 1.0")
                       except ValueError:
                           print("Unrecognized Input")
                   validHealModifier = False
                   while not validHealModifier:
                       healModifier = getInput("(0.1-1.0) Heal what percentage: ")
                       try:
                           healModifier = float(healModifier)
                           if 1.0 >= healModifier >= 0.1:
                               validModifier = True
                               validHealModifier = True
                               pSkill1Heal = healModifier
                           else:
                               print("Percentage must be between 0.1 and 1.0")
                       except ValueError:
                           print("Unrecognized Input")
           validSkill2 = False
           while not validSkill2:
               chooseSkill2 = getInput("Add Skill 2?\nYes\nNo\n")
               if chooseSkill2 == 'Yes':
                   validSkill2 = True
                   pSkill2 = getInput("Name of Skill 2: ")
                   validSkill2Type = False
                   while not validSkill2Type:
                       pSkill2Type = getInput("Type of Skill 2:\nAttack\nDefense\nHealing\nCombo\n")
                       if pSkill2Type == 'Attack':
                           validSkill2Type = True
                       elif pSkill2Type == 'Defense':
                           validSkill2Type = True
                       elif pSkill2Type == 'Healing':
                           validSkill2Type = True
                       elif pSkill2Type == 'Combo':
                           validSkill2Type = True
                       else:
                           print("Unrecognized Input")
                   validSkill2Cost = False
                   while not validSkill2Cost:
                       pSkill2Cost = getInput("Mana Cost of Skill 2: ")
                       try:
                           int(pSkill2Cost)
                           if int(pSkill2Cost) > 0:
                               validSkill2Cost = True
                           else:
                               print("Mana Cost must be greater than 0")
                       except ValueError:
                           print("Unrecognized Input")
                   validModifier = False
                   while not validModifier:
                       if pSkill2Type == 'Attack':
                           atkModifier = getInput("Multiply Attack by: ")
                           try:
                               atkModifier = float(atkModifier)
                               if atkModifier > 1.0:
                                   validModifier = True
                                   pSkill2Atk = atkModifier
                                   pSkill2Def = 1.0
                                   pSkill2Heal = 0
                               else:
                                   print("Modifier must be greater than 1.0")
                           except ValueError:
                               print("Unrecognized Input")
                       elif pSkill2Type == 'Defense':
                           defModifier = getInput("Multiply Defense by: ")
                           try:
                               defModifier = float(defModifier)
                               if defModifier > 1.0:
                                   validModifier = True
                                   pSkill2Atk = 1.0
                                   pSkill2Def = defModifier
                                   pSkill2Heal = 0
                               else:
                                   print("Modifier must be greater than 1.0")
                           except ValueError:
                               print("Unrecognized Input")
                       elif pSkill2Type == 'Healing':
                           healModifier = getInput("(0.1 - 1.0) Heal what percentage: ")
                           try:
                               healModifier = float(healModifier)
                               if 1.0 >= healModifier >= 0.1:
                                   validModifier = True
                                   pSkill2Atk = 1.0
                                   pSkill2Def = 1.0
                                   pSkill2Heal = healModifier
                               else:
                                   print("Percentage must be between 0.1 and 1.0")
                           except ValueError:
                               print("Unrecognized Input")
                       elif pSkill2Type == 'Combo':
                           validAtkModifier = False
                           while not validAtkModifier:
                               atkModifier = getInput("Multiply Attack by: ")
                               try:
                                   atkModifier = float(atkModifier)
                                   if atkModifier > 1.0:
                                       validAtkModifier = True
                                       pSkill2Atk = atkModifier
                                   else:
                                       print("Modifier must be greater than 1.0")
                               except ValueError:
                                   print("Unrecognized Input")
                           validDefModifier = False
                           while not validDefModifier:
                               defModifier = getInput("Multiply Def by: ")
                               try:
                                   defModifier = float(defModifier)
                                   if defModifier > 1.0:
                                       validDefModifier = True
                                       pSkill2Def = defModifier
                                   else:
                                       print("Modifier must be greater than 1.0")
                               except ValueError:
                                   print("Unrecognized Input")
                           validHealModifier = False
                           while not validHealModifier:
                               healModifier = getInput("(0.1-1.0) Heal what percentage: ")
                               try:
                                   healModifier = float(healModifier)
                                   if 1.0 >= healModifier >= 0.1:
                                       validModifier = True
                                       validHealModifier = True
                                       pSkill2Heal = healModifier
                                   else:
                                       print("Percentage must be between 0.1 and 1.0")
                               except ValueError:
                                   print("Unrecognized Input")
                   validSkill3 = False
                   while not validSkill3:
                       chooseSkill3 = getInput("Add Skill 3?\nYes\nNo\n")
                       if chooseSkill3 == 'Yes':
                           validSkill3 = True
                           pSkill3 = getInput("Name of Skill 3: ")
                           validSkill3Type = False
                           while not validSkill3Type:
                               pSkill3Type = getInput("Type of Skill 3:\nAttack\nDefense\nHealing\nCombo\n")
                               if pSkill3Type == 'Attack':
                                   validSkill3Type = True
                               elif pSkill3Type == 'Defense':
                                   validSkill3Type = True
                               elif pSkill3Type == 'Healing':
                                   validSkill3Type = True
                               elif pSkill3Type == 'Combo':
                                   validSkill3Type = True
                               else:
                                   print("Unrecognized Input")
                           validSkill3Cost = False
                           while not validSkill3Cost:
                               pSkill3Cost = getInput("Mana Cost of Skill 3: ")
                               try:
                                   int(pSkill3Cost)
                                   if int(pSkill3Cost) > 0:
                                       validSkill3Cost = True
                                   else:
                                       print("Mana Cost must be greater than 0")
                               except ValueError:
                                   print("Unrecognized Input")
                           validModifier = False
                           while not validModifier:
                               if pSkill3Type == 'Attack':
                                   atkModifier = getInput("Multiply Attack by: ")
                                   try:
                                       atkModifier = float(atkModifier)
                                       if atkModifier > 1.0:
                                           validModifier = True
                                           pSkill3Atk = atkModifier
                                           pSkill3Def = 1.0
                                           pSkill3Heal = 0
                                       else:
                                           print("Modifier must be greater than 1.0")
                                   except ValueError:
                                       print("Unrecognized Input")
                               elif pSkill3Type == 'Defense':
                                   defModifier = getInput("Multiply Defense by: ")
                                   try:
                                       defModifier = float(defModifier)
                                       if defModifier > 1.0:
                                           validModifier = True
                                           pSkill3Atk = 1.0
                                           pSkill3Def = defModifier
                                           pSkill3Heal = 0
                                       else:
                                           print("Modifier must be greater than 1.0")
                                   except ValueError:
                                       print("Unrecognized Input")
                               elif pSkill3Type == 'Healing':
                                   healModifier = getInput("(0.1 - 1.0) Heal what percentage: ")
                                   try:
                                       healModifier = float(healModifier)
                                       if 1.0 >= healModifier >= 0.1:
                                           validModifier = True
                                           pSkill3Atk = 1.0
                                           pSkill3Def = 1.0
                                           pSkill3Heal = healModifier
                                       else:
                                           print("Percentage must be between 0.1 and 1.0")
                                   except ValueError:
                                       print("Unrecognized Input")
                               elif pSkill3Type == 'Combo':
                                   validAtkModifier = False
                                   while not validAtkModifier:
                                       atkModifier = getInput("Multiply Attack by: ")
                                       try:
                                           atkModifier = float(atkModifier)
                                           if atkModifier > 1.0:
                                               validAtkModifier = True
                                               pSkill3Atk = atkModifier
                                           else:
                                               print("Modifier must be greater than 1.0")
                                       except ValueError:
                                           print("Unrecognized Input")
                                   validDefModifier = False
                                   while not validDefModifier:
                                       defModifier = getInput("Multiply Def by: ")
                                       try:
                                           defModifier = float(defModifier)
                                           if defModifier > 1.0:
                                               validDefModifier = True
                                               pSkill3Def = defModifier
                                           else:
                                               print("Modifier must be greater than 1.0")
                                       except ValueError:
                                           print("Unrecognized Input")
                                   validHealModifier = False
                                   while not validHealModifier:
                                       healModifier = getInput("(0.1-1.0) Heal what percentage: ")
                                       try:
                                           healModifier = float(healModifier)
                                           if 1.0 >= healModifier >= 0.1:
                                               validModifier = True
                                               validHealModifier = True
                                               pSkill3Heal = healModifier
                                           else:
                                               print("Percentage must be between 0.1 and 1.0")
                                       except ValueError:
                                           print("Unrecognized Input")
                       elif chooseSkill3 == 'No':
                           validSkill3 = True
                           pSkill3 = None
                           pSkill3Type = None
                           pSkill3Cost = 0
                           pSkill3Atk = 0
                           pSkill3Def = 0
                           pSkill3Heal = 0
                       else:
                           print("Unrecognized Input")
               elif chooseSkill2 == 'No':
                   validSkill2 = True
                   pSkill2 = None
                   pSkill2Type = None
                   pSkill2Cost = 0
                   pSkill2Atk = 0
                   pSkill2Def = 0
                   pSkill2Heal = 0
                   pSkill3 = None
                   pSkill3Type = None
                   pSkill3Cost = 0
                   pSkill3Atk = 0
                   pSkill3Def = 0
                   pSkill3Heal = 0
               else:
                   print("Unrecognized Input")
        elif chooseSkill1 == 'No':
            validSkill1 = True
            pSkill1 = None
            pSkill1Type = None
            pSkill1Cost = 0
            pSkill1Atk = 0
            pSkill1Def = 0
            pSkill1Heal = 0
            pSkill2 = None
            pSkill2Type = None
            pSkill2Cost = 0
            pSkill2Atk = 0
            pSkill2Def = 0
            pSkill2Heal = 0
            pSkill3 = None
            pSkill3Type = None
            pSkill3Cost = 0
            pSkill3Atk = 0
            pSkill3Def = 0
            pSkill3Heal = 0
        else:
            print("Unrecognized Input")
    validStrat = False
    while not validStrat:
        pStrat = getInput("Strategy:\nDefensive\nBalanced\nAggressive\n")
        if pStrat == 'Defensive':
            validStrat = True
        elif pStrat == 'Balanced':
            validStrat = True
        elif pStrat == 'Aggressive':
            validStrat = True
        else:
            print("Unrecognized Input")
    p = Player(int(pHP), int(pAtk), int(pDef), int(pMana), pSkill1, pSkill1Type, int(pSkill1Cost), pSkill1Atk, pSkill1Def, pSkill1Heal, pSkill2, pSkill2Type, int(pSkill2Cost), pSkill2Atk, pSkill2Def, pSkill2Heal, pSkill3, pSkill3Type, int(pSkill3Cost), pSkill3Atk, pSkill3Def, pSkill3Heal, pStrat)
    return p

p = buildPlayer()
p.print()
while run:
    valid = False
    while not valid:
        userIn = getInput("Build Again?\nYes\nNo\n")
        if userIn == 'Yes':
            valid = True
            p = buildPlayer()
            p.print()
        elif userIn == 'No':
            valid = True
            run = False
        else:
            print("Unrecognized Input")