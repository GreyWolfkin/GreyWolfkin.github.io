# TODO:
#   Multiple Enemies
#       e1, e2, e3
#       All the same type vs Multiple Types
#       If multiple types, how to prioritize who to attack?
#   Mana Conservation
#       Mana Strategy = 'Careful', 'Balanced', or 'Generous'
#       Run simulated combats using NO mana (x10)
#       Based on Mana Strategy, 1 HP is worth x Mana
#       Do not use more Mana than allowed
#   Generate Enemies
#       Enter desired hp lost and number of turns
#       Generates ballpark numbers, runs 100 simulations
#       If hp lost > estimated * 1.2 or
#           number of turns > estimated + 2 then reduce
#           Enemy stats by ~.5, rerun. If
#           hp lost < estimated *.8 or
#           number of turns < estimated - 2 or number
#           of turns = 1 then increase Enemy stats by
#           ~.5, repeat until finished, then print
#           enemy stats
#   Add mAtk and mDef
#       Set mAtk, mDef at construction
#       Allow skills to modify mAtk or mDef, or use
#           mAtk for damage calculations
#   Add turn counter for persisting buffs/debuffs
#   Add evasion / to-hit modifiers
#       Base 95% chance to hit, skills increase
#           or decrease chance to hit, increase
#           or decrease evasion
#   Add classes (Fighter, Mage, Rogue, Cleric)
#       ?
#       Is this necessary? If we include mAtk and mDef
#           as well as skills which can use mAtk/mDef
#           this will simulate classes?

from random import *
from math import *

run = True
skills = []
skill1 = None
skill2 = None
skill3 = None

class Player:
    def __init__(self, maxHP, maxPAtk, maxPDef, maxMana, skill1 = None, skill2 = None, skill3 = None, strategy = 'Balanced'):
        self.maxHP = maxHP
        self.hp = maxHP
        self.maxPAtk = maxPAtk
        self.pAtk = maxPAtk
        self.maxPDef = maxPDef
        self.pDef = maxPDef
        self.maxMana = maxMana
        self.mana = maxMana
        self.skill1 = skill1
        self.skill2 = skill2
        self.skill3 = skill3
        self.strategy = strategy
        print("Player Built")

    def fullHeal(self):
        self.hp = self.maxHP
        self.mana = self.maxMana
        print("Player Full Healed")

    def reset(self):
        self.pAtk = self.maxPAtk
        self.pDef = self.maxPDef
        print("Player stats Reset")

class Skill:
    def __init__(self, name, type, cost, pAtk, pDef, heal):
        self.name = name
        self.type = type
        self.cost = cost
        self.pAtk = pAtk
        self.pDef = pDef
        self.heal = heal
        print("Skill Built")

    def use(self):
        print(self.name + " used")
        global p
        p.mana -= self.cost
        print(str(self.cost) + " spent. " + str(p.mana) + " mana remaining")
        p.pAtk = p.pAtk*self.pAtk
        print("Player attack now " + str(p.pAtk))
        if p.pDef*self.pDef <= 100:
            p.pDef = p.pDef*self.pDef
        else:
            p.pDef = 100
        print("Player defense now " + str(p.pDef))
        if p.hp + p.maxHP*self.heal < p.maxHP:
            p.hp += p.maxHP*self.heal
        else:
            p.hp = p.maxHP
        print("Player hp now " + str(p.hp))

    def print(self):
        print(self.name + "\n\tType: " + self.type + "\n\tMana: " + str(self.cost) + "\n\tAttack: " + str(self.pAtk) + "\n\tDefense: " + str(self.pDef) + "\n\tHeal: " + str(self.heal))

class Enemy:
    def __init__(self, maxHP = 40, pAtk = 6, pDef = 0):
        self.maxHP = maxHP
        self.hp = self.maxHP
        self.pAtk = pAtk
        self.pDef = pDef
        print("Enemy built")

    def fullHeal(self):
        self.hp = self.maxHP
        print("Enemy full heal")

def getInput(str):
    userIn = input(str)
    userIn = userIn.capitalize()
    return userIn

def buildPlayer():
    validHP = False
    while not validHP:
        pHP = getInput("Player HP: ")
        try:
            pHP = int(pHP)
            validHP = True
        except ValueError:
            print("Unrecognized Input")
    validAtk = False
    while not validAtk:
        pAtk = getInput("Player Attack: ")
        try:
            pAtk = int(pAtk)
            validAtk = True
        except ValueError:
            print("Unrecognized Input")
    validDef = False
    while not validDef:
        pDef = getInput("Player Defense: ")
        try:
            pDef = int(pDef)
            if int(pDef) < 100:
                validDef = True
            else:
                print("Defense must be less than 100")
        except ValueError:
            print("Unrecognized Input")
    validMana = False
    while not validMana:
        pMana = getInput("Player Mana: ")
        try:
            pMana = int(pMana)
            validMana = True
        except ValueError:
            print("Unrecognized Input")
    validStrat = False
    while not validStrat:
        pStrat = getInput("Strategy:\nDefensive\nBalanced\nAggressive\n")
        if pStrat == 'Defensive':
            validStrat = True
        elif pStrat == 'Balanced':
            validStrat = True
        elif pStrat == 'Aggressive':
            validStrat = True
        else:
            print("Unrecognized Input")
    p = Player(pHP, pAtk, pDef, pMana)
    p.strategy = pStrat
    return p

def buildSkills():
    global skill1
    global skill2
    global skill3
    global p
    global skills
    skill0 = Skill('None', 'None', 0, 0, 0, 0)
    skill1 = None
    skill2 = None
    skill3 = None
    skills.clear()
    skills.append(skill0)
    validSkill1 = False
    while not validSkill1:
        chooseSkill1 = getInput("Add Skill 1?\nYes\nNo\n")
        if chooseSkill1 == 'Yes':
            validSkill1 = True
            pSkill1 = getInput("Name of Skill 1: ")
            validSkill1Type = False
            while not validSkill1Type:
                pSkill1Type = getInput("Type of Skill 1:\nAttack\nDefense\nHealing\nCombo\n")
                if pSkill1Type == 'Attack':
                    validSkill1Type = True
                elif pSkill1Type == 'Defense':
                    validSkill1Type = True
                elif pSkill1Type == 'Healing':
                    validSkill1Type = True
                elif pSkill1Type == 'Combo':
                    validSkill1Type = True
                else:
                    print("Unrecognized Input")
            validSkill1Cost = False
            while not validSkill1Cost:
                pSkill1Cost = getInput("Mana Cost of Skill 1: ")
                try:
                    pSkill1Cost = int(pSkill1Cost)
                    if pSkill1Cost > 0:
                        validSkill1Cost = True
                    else:
                        print("Mana Cost must be greater than 0")
                except ValueError:
                    print("Unrecognized Input")
            validModifier = False
            while not validModifier:
                if pSkill1Type == 'Attack':
                    validAtkModifier = False
                    while not validAtkModifier:
                        atkModifier = getInput("Multiply Attack by: ")
                        try:
                            atkModifier = float(atkModifier)
                            if atkModifier > 1.0:
                                validAtkModifier = True
                                pSkill1Atk = atkModifier
                            else:
                                print("Modifier must be greater than 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validDefModifier = False
                    while not validDefModifier:
                        defModifier = getInput("Multiply Defense by: ")
                        try:
                            defModifier = float(defModifier)
                            if defModifier >= 0.0:
                                validDefModifier = True
                                pSkill1Def = defModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validHealModifier = False
                    while not validHealModifier:
                        healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                        try:
                            healModifier = float(healModifier)
                            if 1.0 >= healModifier and healModifier > -1.0:
                                validHealModifier = True
                                pSkill1Heal = healModifier
                                validModifier = True
                            else:
                                print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                elif pSkill1Type == 'Defense':
                    validAtkModifier = False
                    while not validAtkModifier:
                        atkModifier = getInput("Multiply Attack by: ")
                        try:
                            atkModifier = float(atkModifier)
                            if atkModifier >= 0.0:
                                validAtkModifier = True
                                pSkill1Atk = atkModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validDefModifier = False
                    while not validDefModifier:
                        defModifier = getInput("Multiply Defense by: ")
                        try:
                            defModifier = float(defModifier)
                            if defModifier > 1.0:
                                validDefModifier = True
                                pSkill1Def = defModifier
                            else:
                                print("Modifier must be greater than 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validHealModifier = False
                    while not validHealModifier:
                        healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                        try:
                            healModifier = float(healModifier)
                            if 1.0 >= healModifier and healModifier > -1.0:
                                validHealModifier = True
                                pSkill1Heal = healModifier
                                validModifier = True
                            else:
                                print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                elif pSkill1Type == 'Healing':
                    validAtkModifier = False
                    while not validAtkModifier:
                        atkModifier = getInput("Multiply Attack by: ")
                        try:
                            atkModifier = float(atkModifier)
                            if atkModifier >= 0.0:
                                validAtkModifier = True
                                pSkill1Atk = atkModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validDefModifier = False
                    while not validDefModifier:
                        defModifier = getInput("Multiply Defense by: ")
                        try:
                            defModifier = float(defModifier)
                            if defModifier >= 0.0:
                                validDefModifier = True
                                pSkill1Def = defModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validHealModifier = False
                    while not validHealModifier:
                        healModifier = getInput("(0.1 - 1.0) Heal what percentage? ")
                        try:
                            healModifier = float(healModifier)
                            if 1.0 >= healModifier and healModifier > 0.0:
                                validHealModifier = True
                                pSkill1Heal = healModifier
                                validModifier = True
                            else:
                                print("Modifier must be greater than 0.0 and less than or equal to 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                elif pSkill1Type == 'Combo':
                    validAtkModifier = False
                    while not validAtkModifier:
                        atkModifier = getInput("Multiply Attack by: ")
                        try:
                            atkModifier = float(atkModifier)
                            if atkModifier >= 0.0:
                                validAtkModifier = True
                                pSkill1Atk = atkModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validDefModifier = False
                    while not validDefModifier:
                        defModifier = getInput("Multiply Defense by: ")
                        try:
                            defModifier = float(defModifier)
                            if defModifier >= 0.0:
                                validDefModifier = True
                                pSkill1Def = defModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validHealModifier = False
                    while not validHealModifier:
                        healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                        try:
                            healModifier = float(healModifier)
                            if 1.0 >= healModifier and healModifier > -1.0:
                                validHealModifier = True
                                pSkill1Heal = healModifier
                                validModifier = True
                            else:
                                print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                        except ValueError:
                            print("Unrecognized Input")
            skill1 = Skill(pSkill1, pSkill1Type, pSkill1Cost, pSkill1Atk, pSkill1Def, pSkill1Heal)
            skills.append(skill1)
        elif chooseSkill1 == 'No':
            validSkill1 = True
            skill1 = None
            skill2 = None
            skill3 = None
        else:
            print("Unrecognized Input")
    if skill1 != None:
        validSkill2 = False
        while not validSkill2:
            chooseSkill2 = getInput("Add Skill 2?\nYes\nNo\n")
            if chooseSkill2 == 'Yes':
                validSkill2 = True
                pSkill2 = getInput("Name of Skill 2: ")
                validSkill2Type = False
                while not validSkill2Type:
                    pSkill2Type = getInput("Type of Skill 2:\nAttack\nDefense\nHealing\nCombo\n")
                    if pSkill2Type == 'Attack':
                        validSkill2Type = True
                    elif pSkill2Type == 'Defense':
                        validSkill2Type = True
                    elif pSkill2Type == 'Healing':
                        validSkill2Type = True
                    elif pSkill2Type == 'Combo':
                        validSkill2Type = True
                    else:
                        print("Unrecognized Input")
                validSkill2Cost = False
                while not validSkill2Cost:
                    pSkill2Cost = getInput("Mana Cost of Skill 2: ")
                    try:
                        pSkill2Cost = int(pSkill2Cost)
                        if pSkill2Cost > 0:
                            validSkill2Cost = True
                        else:
                            print("Mana Cost must be greater than 0")
                    except ValueError:
                        print("Unrecognized Input")
                validModifier = False
                while not validModifier:
                    if pSkill2Type == 'Attack':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier > 1.0:
                                    validAtkModifier = True
                                    pSkill2Atk = atkModifier
                                else:
                                    print("Modifier must be greater than 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill2Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill2Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill2Type == 'Defense':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill2Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier > 1.0:
                                    validDefModifier = True
                                    pSkill2Def = defModifier
                                else:
                                    print("Modifier must be greater than 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill2Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill2Type == 'Healing':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill2Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill2Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(0.1 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > 0.0:
                                    validHealModifier = True
                                    pSkill2Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than 0.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill2Type == 'Combo':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill2Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill2Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill2Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                skill2 = Skill(pSkill2, pSkill2Type, pSkill2Cost, pSkill2Atk, pSkill2Def, pSkill2Heal)
                skills.append(skill2)
            elif chooseSkill2 == 'No':
                validSkill2 = True
                skill2 = None
                skill3 = None
            else:
                print("Unrecognized Input")
    if skill2 != None:
        validSkill3 = False
        while not validSkill3:
            chooseSkill3 = getInput("Add Skill 3?\nYes\nNo\n")
            if chooseSkill3 == 'Yes':
                validSkill3 = True
                pSkill3 = getInput("Name of Skill 3: ")
                validSkill3Type = False
                while not validSkill3Type:
                    pSkill3Type = getInput("Type of Skill 3:\nAttack\nDefense\nHealing\nCombo\n")
                    if pSkill3Type == 'Attack':
                        validSkill3Type = True
                    elif pSkill3Type == 'Defense':
                        validSkill3Type = True
                    elif pSkill3Type == 'Healing':
                        validSkill3Type = True
                    elif pSkill3Type == 'Combo':
                        validSkill3Type = True
                    else:
                        print("Unrecognized Input")
                validSkill3Cost = False
                while not validSkill3Cost:
                    pSkill3Cost = getInput("Mana Cost of Skill 3: ")
                    try:
                        pSkill3Cost = int(pSkill3Cost)
                        if pSkill3Cost > 0:
                            validSkill3Cost = True
                        else:
                            print("Mana Cost must be greater than 0")
                    except ValueError:
                        print("Unrecognized Input")
                validModifier = False
                while not validModifier:
                    if pSkill3Type == 'Attack':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier > 1.0:
                                    validAtkModifier = True
                                    pSkill3Atk = atkModifier
                                else:
                                    print("Modifier must be greater than 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill3Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill3Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill3Type == 'Defense':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill3Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier > 1.0:
                                    validDefModifier = True
                                    pSkill3Def = defModifier
                                else:
                                    print("Modifier must be greater than 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill3Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill3Type == 'Healing':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill3Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill3Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(0.1 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > 0.0:
                                    validHealModifier = True
                                    pSkill3Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than 0.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                    elif pSkill3Type == 'Combo':
                        validAtkModifier = False
                        while not validAtkModifier:
                            atkModifier = getInput("Multiply Attack by: ")
                            try:
                                atkModifier = float(atkModifier)
                                if atkModifier >= 0.0:
                                    validAtkModifier = True
                                    pSkill3Atk = atkModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validDefModifier = False
                        while not validDefModifier:
                            defModifier = getInput("Multiply Defense by: ")
                            try:
                                defModifier = float(defModifier)
                                if defModifier >= 0.0:
                                    validDefModifier = True
                                    pSkill3Def = defModifier
                                else:
                                    print("Modifier must be greater than or equal to 0.0")
                            except ValueError:
                                print("Unrecognized Input")
                        validHealModifier = False
                        while not validHealModifier:
                            healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                            try:
                                healModifier = float(healModifier)
                                if 1.0 >= healModifier and healModifier > -1.0:
                                    validHealModifier = True
                                    pSkill3Heal = healModifier
                                    validModifier = True
                                else:
                                    print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                            except ValueError:
                                print("Unrecognized Input")
                skill3 = Skill(pSkill3, pSkill3Type, pSkill3Cost, pSkill3Atk, pSkill3Def, pSkill3Heal)
                skills.append(skill3)
            elif chooseSkill3 == 'No':
                validSkill3 = True
                skill3 = None
            else:
                print("Unrecognized Input")
    p.skill1 = skill1
    p.skill2 = skill2
    p.skill3 = skill3

def buildEnemy():
    validHP = False
    while not validHP:
        eHP = getInput("Enemy HP: ")
        try:
            int(eHP)
            validHP = True
        except ValueError:
            print("Unrecognized Input")
    validAtk = False
    while not validAtk:
        eAtk = getInput("Enemy Attack: ")
        try:
            int(eAtk)
            validAtk = True
        except ValueError:
            print("Unrecognized Input")
    validDef = False
    while not validDef:
        eDef = getInput("Enemy Defense: ")
        try:
            int(eDef)
            if int(eDef) < 100:
                validDef = True
            else:
                print("Defense must be less than 100")
        except ValueError:
            print("Unrecognized Input")
    e = Enemy(int(eHP), int(eAtk), int(eDef))
    return e

hpLostList = []
def getHPLost():
    global hpLostList
    totalLost = 0
    for i in hpLostList:
        totalLost += i
    avgLost = totalLost
    hpLostList.clear()
    return avgLost

turnsList = []
def getTurns():
    global turnsList
    totalTurns = 0
    for i in turnsList:
        totalTurns += i
    avgTurns = totalTurns
    turnsList.clear()
    return avgTurns

usedMana = []
def getUsedMana():
    global usedMana
    totalUsed = 0
    for i in usedMana:
        totalUsed += i
    avgUsed = totalUsed
    usedMana.clear()
    return avgUsed

usedSkill1 = 0
def getUsedSkill1():
    global usedSkill1
    avgUsed = usedSkill1
    usedSkill1 = 0
    return avgUsed

usedSkill2 = 0
def getUsedSkill2():
    global usedSkill2
    avgUsed = usedSkill2
    usedSkill2 = 0
    return avgUsed

usedSkill3 = 0
def getUsedSkill3():
    global usedSkill3
    avgUsed = usedSkill3
    usedSkill3 = 0
    return avgUsed

def usedSkill(skill):
    global usedSkill1
    global usedSkill2
    global usedSkill3
    if skill == skill1:
        usedSkill1 += 1
    elif skill == skill2:
        usedSkill2 += 1
    elif skill == skill3:
        usedSkill3 += 1

winsList = []
def getWins():
    global winsList
    totalWins = 0
    for i in winsList:
        totalWins += i
    winsList.clear()
    return totalWins

def atkAdj(pAtk, pDef):
    multiplier = (12 - randint(0,4))/10
    adjAtk = pAtk * multiplier
    defPerc = (100 - pDef)/100
    dam = ceil(adjAtk * defPerc)
    if dam < 0:
        dam = 0
    return dam

def turn():
    i = randint(0,3)
    if i == 0:
        turnInt = 0
    else:
        turnInt = 1
    return turnInt

def combat():
    global p
    global e
    global winsList
    global hpLostList
    global turnsList
    global usedMana
    global skills
    print("Combat beginning.")
    print("Available skills: ")
    if skill1 != None:
        skill1.print()
    if skill2 != None:
        skill2.print()
    if skill3 != None:
        skill3.print()
    p.fullHeal()
    e.fullHeal()
    turnInt = turn()
    numTurns = 0
    while p.hp > 0 and e.hp > 0:
        if turnInt == 0:
            print("Enemy turn")
            dam = atkAdj(e.pAtk, p.pDef)
            print("Enemy hits for " + str(dam) + " damage")
            p.hp -= dam
            print("Player HP now " + str(p.hp))
            p.reset()
            turnInt = 1
        elif turnInt == 1:
            print("Player turn")
            print("HP: " + str(p.hp) + "\nMana: " + str(p.mana))
            if p.strategy == 'Defensive':
                print("Player strategy Defensive")
                print("Defensive strategies prioritize healing whenever they are below maximum")
                print("unless doing so would overheal. If a healing skill is not used,")
                print("a defensive skill will be considered")
                print("Defensive skills are not used when mana is at or below 50% max")
                bestSkill = skills[0]
                bestAction = 'None'
                print("Looking for best action")
                if p.hp < p.maxHP:
                    print("Player hp less than max. Now looking for heal skill")
                    for i in skills:
                        if i.heal > 0:
                            print(i.name + " has a healing modifier")
                            print(i.name + " costs " + str(i.cost) + " mana")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                print("p.hp = " + str(p.hp))
                                print("i.heal = " + str(i.heal))
                                print("p.maxHP = " + str(p.maxHP))
                                print("p.hp + i.heal*p.maxHP = " + str(p.hp+i.heal*p.maxHP))
                                if p.hp + i.heal*p.maxHP <= p.maxHP:
                                    print(i.name + " would not overheal")
                                    print("bestAction is now HealSkill")
                                    bestAction = 'HealSkill'
                                    print("Other actions will not be considered")
                                else:
                                    print(i.name + " would overheal. " + i.name + " would be a waste of mana")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " has no healing modifier")
                else:
                    print("Player health is at maximum. No need for a healing skill.")
                if bestAction == 'None':
                    print("Other actions are being considered")
                    if p.mana > p.maxMana*5:
                        print("Mana is above half maximum. Considering a Defensive skill")
                        if atkAdj(e.pAtk, p.pDef) >= p.hp*.5:
                            print("Incoming attack is estimated to be greater than or equal to 50% current health.")
                            print("Looking for defense skill.")
                        elif atkAdj(e.pAtk, p.pDef) >= p.maxHP*.2:
                            print("Incoming attack is estimated to be greater than or equal to 20% max health.")
                            print("Looking for defense skill.")
                        else:
                            print("Incoming attack is estimated to be less than twice current health and less than 20% max health.")
                            print("A defensive skill will not be considered.")
                if bestAction == 'None' and p.mana > p.maxMana*.5 and (atkAdj(e.pAtk, p.pDef) >= p.hp*.5 or atkAdj(e.pAtk, p.pDef) >= p.maxHP*.2):
                    for i in skills:
                        if i.pDef > 1:
                            print(i.name + " has a defensive modifier")
                            print(i.name + " costs " + str(i.cost))
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                print("Best Action is now DefenseSkill")
                                bestAction = 'DefenseSkill'
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have a defensive modifier")
                if bestAction == 'HealSkill':
                    print("Best action is HealSkill. Looking for a healing skill.")
                    for i in skills:
                        if bestSkill != skills[0]:
                           print("Best Skill is currently " + bestSkill.name)
                        else:
                            print("Best Skill is currently skill0")
                        print("Considering " + i.name)
                        if i.heal > 0:
                            print(i.name + " has a healing modifier")
                            print(i.name + " costs " + str(i.cost))
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                print("p.hp = " + str(p.hp))
                                print("i.heal = " + str(i.heal))
                                print("p.maxHP = " + str(p.maxHP))
                                print("p.hp + i.heal*p.maxHP = " + str(p.hp + i.heal*p.maxHP))
                                if p.hp + i.heal*p.maxHP <= p.maxHP:
                                    print(i.name + " would not overheal")
                                    if i.heal > bestSkill.heal:
                                        print(i.name + " is a better heal than current bestSkill")
                                        print(i.name + " is new bestSkill")
                                        bestSkill = i
                                    elif i.heal == bestSkill.heal and i.pDef > bestSkill.pDef:
                                        print(i.name + " heals the same amount as current bestSkill, but has a better defense modifier than current bestSkill.")
                                        print(i.name + " is new bestSkill")
                                        bestSkill = i
                                    elif i.heal == bestSkill.heal and i.pDef == bestSkill.pDef and i.pAtk > bestSkill.pAtk:
                                        print(i.name + " heals the same amount as current bestSkill and has the same defense modifier as current bestSkill, but has a better attack modifier than current bestSkill.")
                                        print(i.name + " is new bestSkill")
                                        bestSkill = i
                                    else:
                                        print(i.name + " does not meet criteria to be new bestSkill")
                                else:
                                    print(i.name + " would overheal. " + i.name + " would be a waste of mana.")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have a healing modifier")
                if bestAction == 'DefenseSkill':
                    print("Best action is DefenseSkill. Looking for a defense skill.")
                    for i in skills:
                        if bestSkill != skills[0]:
                            print("Best Skill is currently " + bestSkill.name)
                        else:
                            print("Best Skill is currently skill0")
                        print("Considering " + i.name)
                        if i.pDef > 1:
                            print(i.name + " has a defensive modifier")
                            print(i.name + " costs " + str(i.cost) + " mana")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                #if i.heal*p.maxHP*-1 <= p.hp*.25:
                                if i.pDef > bestSkill.pDef:
                                    print(i.name + " has a better defensive modifier than current bestSkill.")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.pDef == bestSkill.pDef and i.heal > bestSkill.heal and p.hp < p.maxHP:
                                    print(i.name + " has the same defensive modifier as current bestSkill, but current health is below max, and " + i.name + " has a better healing modifier than current bestSkill")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.pDef == bestSkill.pDef and i.pAtk > bestSkill.pAtk:
                                    print(i.name + " has the same defensive modifier as current bestSkill, but has better attack modifier than current bestSkill.")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                else:
                                    print(i.name + " does not meet criteria to be new bestSkill")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have a defensive modifier")
                if bestSkill != skills[0]:
                    print("Best Skill is " + bestSkill.name)
                    print("Using " + bestSkill.name)
                    bestSkill.use()
                    print("Adding " + bestSkill.name + " to list of uses")
                    usedSkill(bestSkill)
                else:
                    print("Best Skill is skills[0]. Performing standard attack.")
                dam = atkAdj(p.pAtk, e.pDef)
                print("Player dealt " + str(dam) + " damage.")
                e.hp -= dam
                print("Enemy current hp is "+ str(e.hp))
                print("Increasing number of turns by 1")
                numTurns += 1
                turnInt = 0
            elif p.strategy == 'Balanced':
                print("Player strategy Balanced")
                print("Balanced strategies will heal when at or below half health")
                print("If a healing skill is not used, a defensive skill will be used if incoming damage is estimated")
                print("to be 66% of current health or 33% of maximum health.")
                print("If neither a healing skill nor a defensive skill are used, an attack skill will be considered")
                print("Defensive and Attack skills are not used when mana is at or below 25% max")
                bestSkill = skills[0]
                bestAction = 'None'
                print("Looking for best action")
                if p.hp <= p.maxHP*.5:
                    print("Player hp less than or equal to half max. Looking for heal skill.")
                    for i in skills:
                        if i.heal > 0:
                            print(i.name + " has a healing modifier")
                            print(i.name + " costs " + str(i.cost) + " mana")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                print("p.hp = " + str(p.hp))
                                print("i.heal = " + str(i.heal))
                                print("p.maxHP = " + str(p.maxHP))
                                print("p.hp + i.heal*p.maxHP = " + str(p.hp + i.heal*p.maxHP))
                                if p.hp + i.heal*p.maxHP <= p.maxHP:
                                    print(i.name + " would not overheal")
                                    print("bestAction is now HealSkill")
                                    bestAction = 'HealSkill'
                                    print("Other actions will not be considered")
                                else:
                                    print(i.name + " would overheal. " + i.name + " would be a waste of mana.")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " has no healing modifier")
                else:
                    print("Player hp greater than half max. No need for a heal skill.")
                if bestAction == 'None':
                    print("Other actions are being considered")
                    if p.mana > p.maxMana*.25:
                        print("Current mana is greater than 25% maximum")
                        if atkAdj(e.pAtk, p.pDef) >= p.hp*.66:
                            print("Incoming attack estimated to be greater than or equal to 66% of current health")
                            print("Looking for a defense skill")
                        elif atkAdj(e.pAtk, p.pDef) >= p.maxHP*.33:
                            print("Incoming attack estimated to be greater than or equal to 33% of maximum health")
                            print("Looking for a defense skill")
                        else:
                            print("Incoming attack is estimated to be less than 66% of current health and less than 33% of maximum health")
                            print("A defensive skill will not be considered")
                        if atkAdj(e.pAtk, p.pDef) >= p.hp*.66 or atkAdj(e.pAtk, p.pDef) >= p.maxHP*.33:
                            for i in skills:
                                if i.pDef > 1:
                                    print(i.name + " has a defensive modifier")
                                    print(i.name + " costs " + str(i.cost))
                                    if i.cost <= p.mana:
                                        print("Can afford " + i.name)
                                        print("Best Action is now DefenseSkill")
                                        bestAction = 'DefenseSkill'
                                        print("Other actions will not be considered")
                                    else:
                                        print("Cannot afford " + i.name)
                                else:
                                    print(i.name + " does not have a defensive modifier")
                    else:
                        print("Current mana is less than or equal to 25% maximum")
                if bestAction == 'None':
                    print("Other actions are being considered")
                    if p.mana > p.maxMana*.25:
                        print("Mana is above 25% maximum")
                        if atkAdj(p.pAtk, e.pDef) < e.hp*.5:
                            print("Basic attack is estimated to be less than 50% enemy health")
                            print("An Attack skill will be considered")
                            for i in skills:
                                if i.pAtk > 1:
                                    print(i.name + " has an attack modifier")
                                    print(i.name + " costs " + str(i.cost) + " mana")
                                    if i.cost <= p.mana:
                                        print("Can afford " + i.name)
                                        print("Best Action is now AttackSkill")
                                        bestAction = 'AttackSkill'
                                    else:
                                        print("Cannot afford " + i.name)
                                else:
                                    print(i.name + " does not have an attack modifier")
                        else:
                            print("Basic attack is estimated to be greater than or equal to 50% enemy health")
                            print("An Attack skill is not required")
                    else:
                        print("Mana is less than or equal to 25% maximum")
                if bestAction == 'HealSkill':
                    print("Best action is HealSkill. Looking for a healing skill")
                    for i in skills:
                        if bestSkill != skills[0]:
                            print("Best Skill is currently " + bestSkill.name)
                        else:
                            print("Best Skill is currently skill0")
                        print("Considering " + i.name)
                        if i.heal > 0:
                            print(i.name + " has a healing modifier")
                            print(i.name + " costs " + str(i.cost) + " mana")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                print("p.hp = " + str(p.hp))
                                print("i.heal = " + str(i.heal))
                                print("p.maxHP = " + str(p.maxHP))
                                print("p.hp + i.heal*p.maxHP = " + str(p.hp + i.heal*p.maxHP))
                                if p.hp + i.heal*p.maxHP <= p.maxHP:
                                    print(i.name + " would no overheal")
                                    if i.heal > bestSkill.heal:
                                        print(i.name + " is a better heal than current bestSkill")
                                        print(i.name + " is new bestSkill")
                                        bestSkill = i
                                    elif i.heal == bestSkill.heal and i.pDef > bestSkill.pDef:
                                        print(i.name + " heals the same amount as current bestSkill, but has a better defensive modifier than current bestSkill")
                                        print(i.name + " is new bestSkill")
                                        bestSkill = i
                                    elif i.heal == bestSkill.heal and i.pDef == bestSkill.pDef and i.pAtk > bestSkill.pAtk:
                                        print(i.name + " heals the same amount as current bestSkill, and has the same defensive modifier as current bestSkill, but has a better attack modifier than current bestSkill")
                                        print(i.name + " is new bestSkill")
                                        bestSkill = i
                                    else:
                                        print(i.name + " does not meet criteria to be new bestSkill")
                                else:
                                    print(i.name + " would overheal")
                                    print(i.name + " would be a waste of mana")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have a healing modifier")
                if bestAction == 'DefenseSkill':
                    print("Best action is DefenseSkill. Looking for a defense skill")
                    for i in skills:
                        if bestSkill != skills[0]:
                            print("Best skill is currently " + bestSkill.name)
                        else:
                            print("Best skill is currently skills[0]")
                        if i.pDef > 1:
                            print(i.name + " has a defensive modifier")
                            print(i.name + " costs " + str(i.cost) + " mana")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                #if i.heal*p.maxHP*-1 <= p.hp*.3:
                                if i.pDef > bestSkill.pDef:
                                    print(i.name + " has a better defensive modifier than current bestSkill")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.pDef == bestSkill.pDef and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal*p.maxHP <= p.maxHP:
                                    print(i.name + " has the same defensive modifier as current bestSkill, current health is less than max, " + i.name + " has a better healing modifier than current bestSkill, and " + i.name + " will not overheal")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.pDef == bestSkill.pDef and i.pAtk > bestSkill.pAtk:
                                    print(i.name + " has the same defensive modifier as current bestSkill, but has a better attack modifier than current bestSkill")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                else:
                                    print(i.name + " does not meet criteria to be new bestSkill")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have a defensive modifier")
                if bestAction == 'AttackSkill':
                    print("Best action is AttackSkill. Looking for an attack skill")
                    for i in skills:
                        if bestSkill != skills[0]:
                            print("Best Skill is currently " + bestSkill.name)
                        else:
                            print("Best Skill is currently skills[0]")
                        if i.pAtk > 1:
                            print(i.name + " has an attack modifier")
                            print(i.name + " costs " + str(i.cost) + " mana")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                #if i.heal*p.maxHP*-1 <= p.hp*.3:
                                if i.pAtk > bestSkill.pAtk and atkAdj(p.pAtk*i.pAtk, e.pDef) <= e.hp:
                                    print(i.name + " has a better attack modifier than current bestSkill, and will not overkill enemy")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.pAtk == bestSkill.pAtk and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal*p.maxHP <= p.maxHP:
                                    print(i.name + " has the same attack modifier as current bestSkill, current health is less than maximum, " + i.name + " has a better healing modifier than current bestSkill, and " + i.name + " will not overheal")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.pAtk == bestSkill.pAtk and i.pDef > bestSkill.pDef:
                                    print(i.name + " has the same attack modifier as current bestSkill, but has a better defensive modifier than current bestSkill")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                else:
                                    print(i.name + " does not meet criteria to be new bestSkill")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have an attack modifier")
                if bestSkill != skills[0]:
                    print("Best Skill is " + bestSkill.name)
                    print("Using " + bestSkill.name)
                    bestSkill.use()
                    print("Adding " + bestSkill.name + " to list of uses")
                    usedSkill(bestSkill)
                else:
                    print("Best Skill is skills[0]. Performing standard attack.")
                dam = atkAdj(p.pAtk, e.pDef)
                print("Player dealt " + str(dam) + " damage")
                e.hp -= dam
                print("Enemy current hp is " + str(e.hp))
                print("Increasing number of turns by 1")
                numTurns += 1
                turnInt = 0
            elif p.strategy == 'Aggressive':
                print("Player strategy Aggressive")
                print("Aggressive strategies will heal when the incoming attack is expected to be 80% or more of current health")
                print("If a healing skill is not used, an attack skill will be considered")
                print("An attack skill will be used if a standard attack would be less than or equal to half enemy health")
                print("Aggressive strategies do not reserve any mana")
                bestSkill = skills[0]
                bestAction = 'None'
                print("Looking for best action")
                if atkAdj(e.pAtk, p.pDef) >= p.hp*.8:
                    print("Incoming attack is expected to be greater than or equal to 80% of current health. Looking for a heal skill")
                    for i in skills:
                        if i.heal > 0:
                            print(i.name + " has a healing modifier")
                            print(i.name + " costs " + str(i.cost) + " mana")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                print("Best action is HealSkill")
                                bestAction = 'HealSkill'
                                print("Other actions will not be considered")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have a healing modifier")
                if bestAction == 'None':
                    print("Other actions are being considered")
                    if atkAdj(p.pAtk, e.pDef) <= e.hp*.5:
                        print("Standard attack expected to be less than or equal to half enemy health")
                        print("Looking for attack skill")
                if bestAction == 'None' and atkAdj(p.pAtk, e.pDef) <= e.hp*.5:
                    for i in skills:
                        if i.pAtk > 1:
                            print(i.name + " has an attack modifier")
                            print(i.name + " costs " + str(i.cost) + " mana")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                print("Best Action is AttackSkill")
                                bestAction = 'AttackSkill'
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have an attack modifier")
                if bestAction == 'HealSkill':
                    print("Best Action is HealSkill. Looking for a healing skill")
                    for i in skills:
                        if bestSkill != skills[0]:
                            print("Best Skill is currently " + bestSkill.name)
                        else:
                            print("Best Skill is currently skills[0]")
                        if i.heal > 0:
                            print(i.name + " has a healing modifier")
                            print(i.name + " costs " + str(i.cost) + " mana")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                if i.heal > bestSkill.heal and p.hp + i.heal*p.maxHP <= p.maxHP:
                                    print(i.name + " has a better healing modifier than current bestSkill, and will not overheal")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.heal == bestSkill.heal and i.pAtk > bestSkill.pAtk:
                                    print(i.name + " has the same healing modifier as current bestSkill, but has a better attack modifier than current bestSkill")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.heal == bestSkill.heal and i.pAtk == bestSkill.pAtk and i.pDef > bestSkill.pDef:
                                    print(i.name + " has the same healing modifier as current bestSkill and the same attack modifier as current bestSkill, but has a better defensive modifier than current bestSkill")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                else:
                                    print(i.name + " does not meet criteria to be bestSkill")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have a healing modifier")
                elif bestAction == 'AttackSkill':
                    print("Best Action is AttackSkill. Looking for attack skill")
                    for i in skills:
                        if bestSkill != skills[0]:
                            print("Current Best Skill is " + bestSkill.name)
                        else:
                            print("Current Best Skill is skills[0]")
                        if i.pAtk > 1:
                            print(i.name + " has an attack modifier")
                            print(i.name + " costs " + str(i.cost) + " mana")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                #if i.heal*p.maxHP*-1 <= p.hp * .5:
                                if i.pAtk > bestSkill.pAtk and atkAdj(p.pAtk*i.pAtk, e.pDef) <= e.hp:
                                    print(i.name + " has a better attack modifier than current bestSkill, and will not overkill enemy")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.pAtk == bestSkill.pAtk and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal*p.maxHP <= p.maxHP:
                                    print(i.name + " has the same attack modifier as current bestSkill, player health is less than maximum, " + i.name + " has a better healing modifier than current bestSkill, and " + i.name + " will not overheal")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.pAtk == bestSkill.pAtk and i.pDef > bestSkill.pDef:
                                    print(i.name + " has the same attack modifier as current bestSkill, but has a better defense modifier than current bestSkill")
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                else:
                                    print(i.name + " does not meet criteria to be new bestSkill")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have an attack modifier")
                if bestSkill != skills[0]:
                    print("Best Skill is " + bestSkill.name)
                    print("Using " + bestSkill.name)
                    bestSkill.use()
                    print("Adding " + bestSkill.name + " to list of uses")
                    usedSkill(bestSkill)
                else:
                    print("Best Skill is skills[0]. Performing standard attack")
                dam = atkAdj(p.pAtk, e.pDef)
                print("Player dealt " + str(dam) + " damage")
                e.hp -= dam
                print("Enemy current hp is " + str(e.hp))
                print("Increasing number of turns by 1")
                numTurns += 1
                turnInt = 0
    if e.hp <= 0:
        print("Enemy hp is less than or equal to 0. Player wins!")
        winsList.append(1)
    elif p.hp <= 0:
        print("Player hp is less than or equal to 0. Player loses")
        winsList.append(0)
    hpLost = p.maxHP - p.hp
    print("Lost " + str(hpLost) + " hp")
    hpLostList.append(hpLost)
    manaUsed = p.maxMana - p.mana
    print("Used " + str(manaUsed) + " mana")
    usedMana.append(manaUsed)
    print("Took " + str(numTurns) + " turns")
    turnsList.append(numTurns)

p = buildPlayer()
buildSkills()
e = buildEnemy()

while run:
    hpLostList.clear()
    turnsList.clear()
    winsList.clear()
    combat()
    print("Player HP: " + str(p.maxHP) + "\nPlayer Attack: " + str(p.maxPAtk) + "\nPlayer Defense: " + str(p.maxPDef) + "\nPlayer Mana: " + str(p.maxMana) + "\nStrategy: " + p.strategy)
    if skill1 != None:
        skill1.print()
    if skill2 != None:
        skill2.print()
    if skill3 != None:
        skill3.print()
    print("Enemy HP: " + str(e.maxHP) + "\nEnemy Attack: " + str(e.pAtk) + "\nEnemy Defense: " + str(e.pDef))
    print("Average HP lost: " + str(getHPLost()))
    print("Average Mana used: " + str(getUsedMana()))
    if skill1 != None:
        print("Used Skill 1: " + str(getUsedSkill1()))
    if skill2 != None:
        print("Used Skill 2: " + str(getUsedSkill2()))
    if skill3 != None:
        print("Used Skill 3: " + str(getUsedSkill3()))
    print("Average number of turns: " + str(getTurns()))
    print("Number of wins: " + str(getWins()))

    print()

    validRunAgain = False
    while not validRunAgain:
        runAgainInput = getInput("Run again?\nYes\nNo\n")
        if runAgainInput == 'Yes':
            validRunAgain = True
            validChangeStats = False
            while not validChangeStats:
                changeStatsInput = getInput("Change Player Stats?\nYes\nNo\n")
                if changeStatsInput == 'Yes':
                    validChangeStats = True
                    p = buildPlayer()
                    validChangeSkills = False
                    while not validChangeSkills:
                        changeSkillsInput = getInput("Change Skills?\nYes\nNo\n")
                        if changeSkillsInput == 'Yes':
                            validChangeSkills = True
                            buildSkills()
                        elif changeSkillsInput == 'No':
                            validChangeSkills = True
                        else:
                            print("Unrecognized Input")
                elif changeStatsInput == 'No':
                    validChangeStats = True
                    validChangeStrategy = False
                    while not validChangeStrategy:
                        changeStrategyInput = getInput("Change Strategy?\nYes\nNo\n")
                        if changeStrategyInput == 'Yes':
                            validChangeStrategy = True
                            validStrategy = False
                            while not validStrategy:
                                strategyInput = getInput("Strategy:\nDefensive\nBalanced\nAggressive\n")
                                if strategyInput == 'Defensive':
                                    validStrategy = True
                                    p.strategy = 'Defensive'
                                elif strategyInput == 'Balanced':
                                    validStrategy = True
                                    p.strategy = 'Balanced'
                                elif strategyInput == 'Aggressive':
                                    validStrategy = True
                                    p.strategy = 'Aggressive'
                                else:
                                    print("Unrecognized Input")
                            validChangeSkills = False
                            while not validChangeSkills:
                                changeSkillsInput = getInput("Change Skills?\nYes\nNo\n")
                                if changeSkillsInput == 'Yes':
                                    validChangeSkills = True
                                    buildSkills()
                                elif changeSkillsInput == 'No':
                                    validChangeSkills = True
                                else:
                                    print("Unrecognized Input")
                        elif changeStrategyInput == 'No':
                            validChangeStrategy = True
                            validChangeSkills = False
                            while not validChangeSkills:
                                changeSkillsInput = getInput("Change Skills?\nYes\nNo\n")
                                if changeSkillsInput == 'Yes':
                                    validChangeSkills = True
                                    buildSkills()
                                elif changeSkillsInput == 'No':
                                    validChangeSkills = True
                                else:
                                    print("Unrecognized Input")
                        else:
                            print("Unrecognized Input")
                else:
                    print("Unrecognized Input")
            validChangeEnemy = False
            while not validChangeEnemy:
                changeEnemyInput = getInput("Change Enemy Stats?\nYes\nNo\n")
                if changeEnemyInput == 'Yes':
                    validChangeEnemy = True
                    e = buildEnemy()
                elif changeEnemyInput == 'No':
                    validChangeEnemy = True
                else:
                    print("Unrecognized Input")
        elif runAgainInput == 'No':
            validRunAgain = True
            run = False
        else:
            print("Unrecognized Input")