#TODO:
#   class Player
#   class Enemy
#   def combat
#   def atkMult
#   repeat 10x?
#   repeat 100x?
#   get average hp loss
#   get average mana use

from random import *
from math import *

class Player:
    def __init__(self, maxHP = 100, pAtk = 20, pDef = 20):
        self.maxHP = maxHP
        self.hp = self.maxHP
        self.pAtk = pAtk
        self.pDef = pDef

    def fullHeal(self):
        self.hp = self.maxHP

class Enemy:
    def __init__(self, maxHP = 40, pAtk = 6, pDef = 0):
        self.maxHP = maxHP
        self.hp = self.maxHP
        self.pAtk = pAtk
        self.pDef = pDef

    def fullHeal(self):
        self.hp = self.maxHP

hpLostList = []
def getHPLost():
    global hpLostList
    totalLost = 0
    for i in hpLostList:
        totalLost += i
    avgLost = totalLost/len(hpLostList)
    return avgLost

turnsList = []
def getTurns():
    global turnsList
    totalTurns = 0
    for i in turnsList:
        totalTurns += i
    avgTurns = totalTurns/len(turnsList)
    return avgTurns

winsList = []
def getWins():
    global winsList
    totalWins = 0
    for i in winsList:
        totalWins += i
    return totalWins

def atkAdj(pAtk, pDef):
    multiplier = (12 - randint(0,4))/10
    adjAtk = pAtk * multiplier
    defPerc = (100 - pDef)/100
    dam = ceil(adjAtk * defPerc)
    return dam

def turn():
    i = randint(0,3)
    if i == 0:
        turnInt = 0
    else:
        turnInt = 1
    return turnInt

def combat():
    global p
    global e
    global winsList
    global hpLostList
    p.fullHeal()
    e.fullHeal()
    turnInt = turn()
    numTurns = 0
    while p.hp > 0 and e.hp > 0:
        if turnInt == 0:
            dam = atkAdj(e.pAtk, p.pDef)
            p.hp -= dam
            turnInt = 1
        elif turnInt == 1:
            dam = atkAdj(p.pAtk, e.pDef)
            e.hp -= dam
            numTurns += 1
            turnInt = 0
    if e.hp <= 0:
        winsList.append(1)
    elif p.hp >= 0:
        winsList.append(0)
    hpLost = p.maxHP - p.hp
    hpLostList.append(hpLost)
    turnsList.append(numTurns)

pHP = input("Player HP: ")
pAtk = input("Player Attack: ")
pDef = input("Player Defense: ")

p = Player(int(pHP), int(pAtk), int(pDef))

eHP = input("Enemy HP: ")
eAtk = input("Enemy Attack: ")
eDef = input("Enemy Defense: ")

e = Enemy(int(eHP), int(eAtk), int(eDef))

repeat = 100
print("Beginning iterations.")
while repeat > 0:
    combat()
    repeat -= 1
print("Iterations complete")
print("Player HP: " + pHP + "\nPlayer Attack: " + pAtk + "\nPlayer Defense: " + pDef)
print("Enemy HP: " + eHP + "\nEnemy Attack: " + eAtk + "\nEnemy Defense: " + eDef)
print("Average HP lost: " + str(getHPLost()))
print("Average number of turns: " + str(getTurns()))
print("Number of wins: " + str(getWins()))