# TODO:
#   Multiple Enemies
#       e1, e2, e3
#       All the same type vs Multiple Types
#       If multiple types, how to prioritize who to attack?
#   Mana Conservation
#       Mana Strategy = 'Careful', 'Balanced', or 'Generous'
#       Run simulated combats using NO mana (x10)
#       Based on Mana Strategy, 1 HP is worth x Mana
#       Do not use more Mana than allowed
#   Add turn counter for persisting buffs/debuffs
#   Add evasion / to-hit modifiers
#       Base 95% chance to hit, skills increase
#           or decrease chance to hit, increase
#           or decrease evasion
#   Add options for skills which cost health to use
#       Add if - then for how much health to sacrifice

from random import *
from math import *

run = True
skills = []
skill1 = None
skill2 = None
skill3 = None


class Player:
    def __init__(self, maxHP, maxPAtk, maxPDef, maxMAtk, maxMDef, maxMana, skill1=None, skill2=None, skill3=None,
                 strategy='Balanced'):
        self.maxHP = maxHP
        self.hp = maxHP
        self.maxPAtk = maxPAtk
        self.pAtk = maxPAtk
        self.maxPDef = maxPDef
        self.pDef = maxPDef
        self.maxMAtk = maxMAtk
        self.mAtk = maxMAtk
        self.maxMDef = maxMDef
        self.mDef = maxMDef
        self.maxMana = maxMana
        self.mana = maxMana
        self.skill1 = skill1
        self.skill2 = skill2
        self.skill3 = skill3
        self.strategy = strategy

    def fullHeal(self):
        self.hp = self.maxHP
        self.mana = self.maxMana

    def reset(self):
        self.pAtk = self.maxPAtk
        self.pDef = self.maxPDef
        self.mAtk = self.maxMAtk
        self.mDef = self.maxMDef


class Skill:
    def __init__(self, name, cost, pAtk, pDef, mAtk, mDef, heal):
        self.name = name
        self.cost = cost
        self.pAtk = pAtk
        self.pDef = pDef
        self.mAtk = mAtk
        self.mDef = mDef
        self.heal = heal

    def use(self):
        global p
        p.mana -= self.cost
        p.pAtk = p.pAtk * self.pAtk
        if p.pDef * self.pDef <= 100:
            p.pDef = p.pDef * self.pDef
        else:
            p.pDef = 100
        p.mAtk = p.mAtk * self.mAtk
        if p.mDef * self.mDef <= 100:
            p.mDef = p.mDef * self.mDef
        else:
            p.mDef = 100
        if p.hp + p.maxHP * self.heal < p.maxHP:
            p.hp += p.maxHP * self.heal
        else:
            p.hp = p.maxHP

    def print(self):
        print(self.name + "\n\tMana: " + str(self.cost) + "\n\tAttack: " + str(self.pAtk) + "\n\tDefense: " + str(
            self.pDef) + "\n\tMAttack: " + str(self.mAtk) + "\n\tMDefense: " + str(self.mDef) + "\n\tHeal: " + str(
            self.heal) + "\n")


class Enemy:
    def __init__(self, maxHP, pAtk, pDef, mAtk, mDef):
        self.maxHP = maxHP
        self.hp = self.maxHP
        self.pAtk = pAtk
        self.pDef = pDef
        self.mAtk = mAtk
        self.mDef = mDef

    def fullHeal(self):
        self.hp = self.maxHP


def getInput(str):
    userIn = input(str)
    userIn = userIn.capitalize()
    return userIn


def buildPlayer():
    validHP = False
    while not validHP:
        pHP = getInput("Player HP: ")
        try:
            pHP = int(pHP)
            validHP = True
        except ValueError:
            print("Unrecognized Input")
    validAtk = False
    while not validAtk:
        pAtk = getInput("Player Physical Attack: ")
        try:
            pAtk = int(pAtk)
            validAtk = True
        except ValueError:
            print("Unrecognized Input")
    validDef = False
    while not validDef:
        pDef = getInput("Player Physical Defense: ")
        try:
            pDef = int(pDef)
            if pDef < 100:
                validDef = True
            else:
                print("Defense must be less than 100")
        except ValueError:
            print("Unrecognized Input")
    validMAtk = False
    while not validMAtk:
        mAtk = getInput("Player Magic Attack: ")
        try:
            mAtk = int(mAtk)
            validMAtk = True
        except ValueError:
            print("Unrecognized Input")
    validMDef = False
    while not validMDef:
        mDef = getInput("Player Magic Defense: ")
        try:
            mDef = int(mDef)
            if mDef < 100:
                validMDef = True
            else:
                print("Magic Defense must be less than 100")
        except:
            print("Unrecognized Input")
    validMana = False
    while not validMana:
        pMana = getInput("Player Mana: ")
        try:
            pMana = int(pMana)
            validMana = True
        except ValueError:
            print("Unrecognized Input")
    p = Player(pHP, pAtk, pDef, mAtk, mDef, pMana)
    return p


def buildStrat():
    validStrat = False
    while not validStrat:
        stratChoice = getInput("Strategy:\n1 - Defensive\n2 - Balanced\n3 - Aggressive\n")
        if stratChoice == '1':
            validStrat = True
            pStrat = 'Defensive'
        elif stratChoice == '2':
            validStrat = True
            pStrat = 'Balanced'
        elif stratChoice == '3':
            validStrat = True
            pStrat = 'Aggressive'
        else:
            print("Unrecognized Input")
    p.strategy = pStrat


def buildSkills():
    global skill1
    global skill2
    global skill3
    global p
    global skills
    skill0 = Skill('None', 0, 0, 0, 0, 0, 0)
    skill1 = None
    skill2 = None
    skill3 = None
    skills.clear()
    skills.append(skill0)
    validSkill1 = False
    while not validSkill1:
        chooseSkill1 = getInput("Add Skill 1?\nYes\nNo\n")
        if chooseSkill1 == 'Yes':
            validSkill1 = True
            pSkill1 = getInput("Name of Skill 1: ")
            validSkill1Cost = False
            while not validSkill1Cost:
                pSkill1Cost = getInput("Mana Cost of Skill 1: ")
                try:
                    pSkill1Cost = int(pSkill1Cost)
                    if pSkill1Cost > 0:
                        validSkill1Cost = True
                    else:
                        print("Mana Cost must be greater than 0")
                except ValueError:
                    print("Unrecognized Input")
            validModifier = False
            while not validModifier:
                validAtkModifier = False
                while not validAtkModifier:
                    atkModifier = getInput("Multiply Attack by: ")
                    try:
                        atkModifier = float(atkModifier)
                        if atkModifier >= 0:
                            validAtkModifier = True
                            pSkill1Atk = atkModifier
                        else:
                            print("Modifier must be greater than or equal to 0.0")
                    except ValueError:
                        print("Unrecognized Input")
                validDefModifier = False
                while not validDefModifier:
                    defModifier = getInput("Multiply Defense by: ")
                    try:
                        defModifier = float(defModifier)
                        if defModifier >= 0:
                            validDefModifier = True
                            pSkill1Def = defModifier
                        else:
                            print("Modifier must be greater than or equal to 0.0")
                    except ValueError:
                        print("Unrecognized Input")
                validMAtkModifier = False
                while not validMAtkModifier:
                    mAtkModifier = getInput("Multiply Magic Attack by: ")
                    try:
                        mAtkModifier = float(mAtkModifier)
                        if mAtkModifier >= 0:
                            validMAtkModifier = True
                            pSkill1MAtk = mAtkModifier
                        else:
                            print("Modifier must be greater than or equal to 0.0")
                    except ValueError:
                        print("Unrecognized Input")
                validMDefModifier = False
                while not validMDefModifier:
                    mDefModifier = getInput("Multiply Magic Defense by: ")
                    try:
                        mDefModifier = float(mDefModifier)
                        if mDefModifier >= 0:
                            validMDefModifier = True
                            pSkill1MDef = mDefModifier
                        else:
                            print("Modifier must be greater than or equal to 0.0")
                    except ValueError:
                        print("Unrecognized Input")
                validHealModifier = False
                while not validHealModifier:
                    healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                    try:
                        healModifier = float(healModifier)
                        if 1.0 >= healModifier > -1.0:
                            validHealModifier = True
                            pSkill1Heal = healModifier
                            validModifier = True
                        else:
                            print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                    except ValueError:
                        print("Unrecognized Input")
            skill1 = Skill(pSkill1, pSkill1Cost, pSkill1Atk, pSkill1Def, pSkill1MAtk, pSkill1MDef, pSkill1Heal)
            skills.append(skill1)
        elif chooseSkill1 == 'No':
            validSkill1 = True
        else:
            print("Unrecognized Input")
    if skill1 is not None:
        validSkill2 = False
        while not validSkill2:
            chooseSkill2 = getInput("Add Skill 2?\nYes\nNo\n")
            if chooseSkill2 == 'Yes':
                validSkill2 = True
                pSkill2 = getInput("Name of Skill 2: ")
                validSkill2Cost = False
                while not validSkill2Cost:
                    pSkill2Cost = getInput("Mana Cost of Skill 2: ")
                    try:
                        pSkill2Cost = int(pSkill2Cost)
                        if pSkill2Cost > 0:
                            validSkill2Cost = True
                        else:
                            print("Mana Cost must be greater than 0")
                    except ValueError:
                        print("Unrecognized Input")
                validModifier = False
                while not validModifier:
                    validAtkModifier = False
                    while not validAtkModifier:
                        atkModifier = getInput("Multiply Attack by: ")
                        try:
                            atkModifier = float(atkModifier)
                            if atkModifier >= 0:
                                validAtkModifier = True
                                pSkill2Atk = atkModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validDefModifier = False
                    while not validDefModifier:
                        defModifier = getInput("Multiply Defense by: ")
                        try:
                            defModifier = float(defModifier)
                            if defModifier >= 0:
                                validDefModifier = True
                                pSkill2Def = defModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validMAtkModifier = False
                    while not validMAtkModifier:
                        mAtkModifier = getInput("Multiply Magic Attack by: ")
                        try:
                            mAtkModifier = float(mAtkModifier)
                            if mAtkModifier >= 0:
                                validMAtkModifier = True
                                pSkill2MAtk = mAtkModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validMDefModifier = False
                    while not validMDefModifier:
                        mDefModifier = getInput("Multiply Magic Defense by: ")
                        try:
                            mDefModifier = float(mDefModifier)
                            if mDefModifier >= 0:
                                validMDefModifier = True
                                pSkill2MDef = mDefModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validHealModifier = False
                    while not validHealModifier:
                        healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                        try:
                            healModifier = float(healModifier)
                            if 1.0 >= healModifier > -1.0:
                                validHealModifier = True
                                pSkill2Heal = healModifier
                                validModifier = True
                            else:
                                print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                skill2 = Skill(pSkill2, pSkill2Cost, pSkill2Atk, pSkill2Def, pSkill2MAtk, pSkill2MDef, pSkill2Heal)
                skills.append(skill2)
            elif chooseSkill2 == 'No':
                validSkill2 = True
            else:
                print("Unrecognized Input")
    if skill2 is not None:
        validSkill3 = False
        while not validSkill3:
            chooseSkill3 = getInput("Add Skill 3?\nYes\nNo\n")
            if chooseSkill3 == 'Yes':
                validSkill3 = True
                pSkill3 = getInput("Name of Skill 3: ")
                validSkill3Cost = False
                while not validSkill3Cost:
                    pSkill3Cost = getInput("Mana Cost of Skill 3: ")
                    try:
                        pSkill3Cost = int(pSkill3Cost)
                        if pSkill3Cost > 0:
                            validSkill3Cost = True
                        else:
                            print("Mana Cost must be greater than 0")
                    except ValueError:
                        print("Unrecognized Input")
                validModifier = False
                while not validModifier:
                    validAtkModifier = False
                    while not validAtkModifier:
                        atkModifier = getInput("Multiply Attack by: ")
                        try:
                            atkModifier = float(atkModifier)
                            if atkModifier >= 0:
                                validAtkModifier = True
                                pSkill3Atk = atkModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validDefModifier = False
                    while not validDefModifier:
                        defModifier = getInput("Multiply Defense by: ")
                        try:
                            defModifier = float(defModifier)
                            if defModifier >= 0:
                                validDefModifier = True
                                pSkill3Def = defModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validMAtkModifier = False
                    while not validMAtkModifier:
                        mAtkModifier = getInput("Multiply Magic Attack by: ")
                        try:
                            mAtkModifier = float(mAtkModifier)
                            if mAtkModifier >= 0:
                                validMAtkModifier = True
                                pSkill3MAtk = mAtkModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validMDefModifier = False
                    while not validMDefModifier:
                        mDefModifier = getInput("Multiply Magic Defense by: ")
                        try:
                            mDefModifier = float(mDefModifier)
                            if mDefModifier >= 0:
                                validMDefModifier = True
                                pSkill3MDef = mDefModifier
                            else:
                                print("Modifier must be greater than or equal to 0.0")
                        except ValueError:
                            print("Unrecognized Input")
                    validHealModifier = False
                    while not validHealModifier:
                        healModifier = getInput("(-0.99 - 1.0) Heal what percentage? ")
                        try:
                            healModifier = float(healModifier)
                            if 1.0 >= healModifier and healModifier > -1.0:
                                validHealModifier = True
                                pSkill3Heal = healModifier
                                validModifier = True
                            else:
                                print("Modifier must be greater than -1.0 and less than or equal to 1.0")
                        except ValueError:
                            print("Unrecognized Input")
                skill3 = Skill(pSkill3, pSkill3Cost, pSkill3Atk, pSkill3Def, pSkill3MAtk, pSkill3MDef, pSkill3Heal)
                skills.append(skill3)
            elif chooseSkill3 == 'No':
                validSkill3 = True
            else:
                print("Unrecognized Input")
    p.skill1 = skill1
    p.skill2 = skill2
    p.skill3 = skill3


def buildEnemy():
    validHP = False
    while not validHP:
        eHP = getInput("Enemy HP: ")
        try:
            eHP = int(eHP)
            validHP = True
        except ValueError:
            print("Unrecognized Input")
    validAtk = False
    while not validAtk:
        eAtk = getInput("Enemy Attack: ")
        try:
            eAtk = int(eAtk)
            validAtk = True
        except ValueError:
            print("Unrecognized Input")
    validDef = False
    while not validDef:
        eDef = getInput("Enemy Defense: ")
        try:
            eDef = int(eDef)
            if eDef < 100:
                validDef = True
            else:
                print("Defense must be less than 100")
        except ValueError:
            print("Unrecognized Input")
    validMAtk = False
    while not validMAtk:
        eMAtk = getInput("Enemy Magic Attack: ")
        try:
            eMAtk = int(eMAtk)
            validMAtk = True
        except ValueError:
            print("Unrecognized Input")
    validMDef = False
    while not validMDef:
        eMDef = getInput("Enemy Magic Defense: ")
        try:
            eMDef = int(eMDef)
            if eMDef < 100:
                validMDef = True
            else:
                print("Magic Defense must be less than 100")
        except ValueError:
            print("Unrecognized Input")
    e = Enemy(eHP, eAtk, eDef, eMAtk, eMDef)
    return e


hpLostList = []


def getHPLost():
    global hpLostList
    totalLost = 0
    for i in hpLostList:
        totalLost += i
    avgLost = totalLost / len(hpLostList)
    hpLostList.clear()
    return avgLost


turnsList = []


def getTurns():
    global turnsList
    totalTurns = 0
    for i in turnsList:
        totalTurns += i
    avgTurns = totalTurns / len(turnsList)
    turnsList.clear()
    return avgTurns


usedMana = []


def getUsedMana():
    global usedMana
    totalUsed = 0
    for i in usedMana:
        totalUsed += i
    avgUsed = totalUsed / len(usedMana)
    usedMana.clear()
    return avgUsed


usedSkill1 = 0


def getUsedSkill1():
    global usedSkill1
    avgUsed = usedSkill1 / 100
    usedSkill1 = 0
    return avgUsed


usedSkill2 = 0


def getUsedSkill2():
    global usedSkill2
    avgUsed = usedSkill2 / 100
    usedSkill2 = 0
    return avgUsed


usedSkill3 = 0


def getUsedSkill3():
    global usedSkill3
    avgUsed = usedSkill3 / 100
    usedSkill3 = 0
    return avgUsed


def usedSkill(skill):
    global usedSkill1
    global usedSkill2
    global usedSkill3
    if skill == skill1:
        usedSkill1 += 1
    elif skill == skill2:
        usedSkill2 += 1
    elif skill == skill3:
        usedSkill3 += 1


winsList = []


def getWins():
    global winsList
    totalWins = 0
    for i in winsList:
        totalWins += i
    winsList.clear()
    return totalWins


def atkAdj(pAtk, pDef):
    multiplier = (12 - randint(0, 4)) / 10
    adjAtk = pAtk * multiplier
    defPerc = (100 - pDef) / 100
    dam = ceil(adjAtk * defPerc)
    if dam < 0:
        dam = 0
    return dam


def turn():
    i = randint(0, 3)
    if i == 0:
        turnInt = 0
    else:
        turnInt = 1
    return turnInt


def combatDebug():
    global p
    global e
    global skills
    print("Combat beginning\n")
    if skill1 is not None:
        print("Available skills:")
        skill1.print()
    if skill2 is not None:
        skill2.print()
    if skill3 is not None:
        skill3.print()
    p.fullHeal()
    e.fullHeal()
    turnInt = turn()
    numTurns = 0
    if p.strategy == 'Defensive':
        print("Player strategy Defensive\n")
        print("Defensive strategies prioritize healing whenever they are at or below 50% maximum,")
        print("or when incoming damage is estimated to be 50% of current health,")
        print("unless doing so would overheal. If a healing skill is not used,")
        print("a defensive skill will be considered")
        print("Defensive skills are not used when mana is at or below 50% max\n")
    elif p.strategy == 'Balanced':
        print("Player strategy Balanced")
        print("Balanced strategies will heal when at or below 50% maximum and incoming damage is estimated")
        print("to be at least 50% of current hp, unless an attack skill could kill the enemy outright, at")
        print("which point an attack skill will be used.")
        print("If a healing skill is not used, a defensive skill will be used if incoming damage is estimated")
        print("to be 66% of current health or 33% of maximum health.")
        print("If neither a healing skill nor a defensive skill are used, an attack skill will be considered")
        print("Defensive and Attack skills are not used when mana is at or below 25% max\n")
    elif p.strategy == 'Aggressive':
        print("Player strategy Aggressive")
        print("Aggressive strategies will heal when the incoming attack is expected to be 80% or more of ")
        print("current health, unless an attack skill could kill the enemy outright, at which point an attack")
        print("skill will be used.")
        print("If a healing skill is not used, an attack skill will be considered")
        print("An attack skill will be used if a standard attack would be less than or equal to half enemy health")
        print("Aggressive strategies do not reserve any mana\n")
    while p.hp > 0 and e.hp > 0:
        if turnInt == 0:
            print("Enemy turn\n")
            pDam = atkAdj(e.pAtk, p.pDef)
            print("Enemy hits for " + str(pDam) + " physical damage")
            mDam = atkAdj(e.mAtk, p.mDef)
            print("Enemy hits for " + str(mDam) + " magic damage\n")
            p.hp -= pDam
            p.hp -= mDam
            print("Player HP now " + str(p.hp) + "\n")
            p.reset()
            turnInt = 1
        elif turnInt == 1:
            print("Player turn")
            print("HP: " + str(p.hp) + "\tMana: " + str(p.mana) + "\n")
            print("Analyzing enemy strengths and weaknesses\n")
            pStrongestAttack = 'Physical'
            eStrongestAttack = 'Physical'
            expectedPAttack = atkAdj(p.pAtk, e.pDef)
            expectedMAttack = atkAdj(p.mAtk, e.mDef)
            if expectedPAttack > expectedMAttack:
                print("Strongest outgoing attack is physical")
                pStrongestAttack = 'Physical'
            elif expectedPAttack < expectedMAttack:
                print("Strongest outgoing attack is magic")
                pStrongestAttack = 'Magic'
            expectedPIncoming = atkAdj(e.pAtk, p.pDef)
            expectedMIncoming = atkAdj(e.mAtk, p.mDef)
            if expectedPIncoming > expectedMIncoming:
                print("Strongest incoming attack is physical\n")
                eStrongestAttack = 'Physical'
            elif expectedPIncoming < expectedMIncoming:
                print("Strongest incoming attack is magic\n")
                eStrongestAttack = 'Magic'
            incomingAttack = atkAdj(e.pAtk, p.pDef) + atkAdj(e.mAtk, p.mDef)
            print("Estimated incoming damage is " + str(incomingAttack))
            outgoingAttack = atkAdj(p.pAtk, e.pDef) + atkAdj(p.mAtk, e.mDef)
            print("Estimated outgoing damage is " + str(outgoingAttack) + "\n")
            bestSkill = skills[0]
            bestAction = 'None'

            if p.strategy == 'Defensive':
                if p.hp <= p.maxHP * .5:
                    print("HP is less than or equal to 50% max. Looking for heal skill.")
                    bestAction = 'HealSkill'
                elif incomingAttack >= p.hp * .5:
                    print("Incoming attack is estimated to be greater than or equal to 50% hp. Looking for heal skill.")
                    bestAction = 'HealSkill'
                else:
                    print("Heal skill will not be necessary")
            elif p.strategy == 'Balanced':
                if p.hp <= p.maxHP * .5 and incomingAttack >= p.hp * .5:
                    print(
                        "HP is less than or equal to 50% and incoming attack is estimated to be greater than or equal to 50% hp.")
                    if outgoingAttack >= e.hp:
                        print("A basic attack could kill the enemy outright.")
                        bestAction = 'BasicAttack'
                    else:
                        print("A basic attack will not kill the enemy outright.")
                        for i in skills:
                            if i.cost <= p.mana:
                                estimatedDamage = atkAdj(p.pAtk * i.pAtk, e.pDef) + atkAdj(p.mAtk * i.mAtk, e.mDef)
                                if estimatedDamage >= e.hp:
                                    print("An attack skill could kill the enemy outright. Looking for attack skill.")
                                    bestAction = 'QuickKill'
                    if bestAction == 'None':
                        print("No attack skills could kill the enemy outright. Looking for heal skill.")
                        bestAction = 'HealSkill'
                else:
                    print("Heal skill will not be necessary")
            elif p.strategy == 'Aggressive':
                if incomingAttack >= p.hp * .75:
                    print("Incoming attack is estimated to be greater than or equal to 75% hp.")
                    if outgoingAttack >= e.hp:
                        print("A basic attack could kill the enemy outright.")
                        bestAction = 'BasicAttack'
                    else:
                        print("A basic attack will not kill the enemy outright.")
                        for i in skills:
                            if i.cost <= p.mana:
                                estimatedDamage = atkAdj(p.pAtk * i.pAtk, e.pDef) + atkAdj(p.mAtk * i.mAtk, e.mDef)
                                if estimatedDamage >= e.hp:
                                    print("An attack skill could kill the enemy outright. Looking for attack skill.")
                                    bestAction = 'QuickKill'
                    if bestAction == 'None':
                        print("No attack skills could kill the enemy outright. Looking for heal skill.")
                        bestAction = 'HealSkill'
                else:
                    print("Heal skill will not be necessary")
            if bestAction == 'None':
                print("Considering other options")
                if p.strategy == 'Defensive':
                    if p.mana > p.maxMana * .5:
                        print("Mana is greater than 50% max")
                        if incomingAttack >= p.maxHP * .2:
                            print(
                                "Incoming attack is estimated to be greater than or equal to 20% max hp. Looking for defense skill.")
                            bestAction = 'DefenseSkill'
                        else:
                            print("Defense skill will not be necessary")
                    else:
                        print("Mana is less than or equal to 50% max. Defense skill will not be considered.")
                elif p.strategy == 'Balanced':
                    if p.mana > p.maxMana * .5:
                        print("Mana is greater than 50% max")
                        if incomingAttack >= p.hp * .66:
                            print("Incoming attack is estimated to be greater than or equal to 66% hp")
                            if outgoingAttack >= e.hp:
                                print("A basic attack could kill the enemy outright.")
                                bestAction = 'BasicAttack'
                            else:
                                print("A basic attack will not kill the enemy outright.")
                                for i in skills:
                                    if i.cost <= p.mana:
                                        estimatedDamage = atkAdj(p.pAtk * i.pAtk, e.pDef) + atkAdj(p.mAtk * i.mAtk,
                                                                                                   e.mDef)
                                        if estimatedDamage >= e.hp:
                                            print(
                                                "An attack skill could kill the enemy outright. Looking for attack skill.")
                                            bestAction = 'QuickKill'
                            if bestAction == 'None':
                                print("No attack skill could kill the enemy outright. Looking for defense skill.")
                                bestAction = 'DefenseSkill'
                        elif incomingAttack >= p.maxHP * .33:
                            print("Incoming attack is estimated to be greater than or equal to 33% max hp")
                            if outgoingAttack >= e.hp:
                                print("A basic attack could kill the enemy outright.")
                                bestAction = 'BasicAttack'
                            else:
                                print("A basic attack will not kill the enemy outright.")
                                for i in skills:
                                    if i.cost <= p.mana:
                                        estimatedDamage = atkAdj(p.pAtk * i.pAtk, e.pDef) + atkAdj(p.mAtk * i.mAtk,
                                                                                                   e.mDef)
                                        if estimatedDamage >= e.hp:
                                            print(
                                                "An attack skill could kill the enemy outright. Looking for attack skill.")
                                            bestAction = 'QuickKill'
                            if bestAction == 'None':
                                print("No attack skill could kill the enemy outright. Looking for defense skill.")
                                bestAction = 'DefenseSkill'
            if bestAction == 'None':
                if p.strategy == 'Balanced' and p.mana > p.maxMana * .25:
                    print("Mana is greater than 25% max")
                    if outgoingAttack < e.hp * .5:
                        print(
                            "Standard attack would be less than 50% enemy remaining health. Looking for attack skill.")
                        bestAction = 'AttackSkill'
                elif p.strategy == 'Aggressive' and outgoingAttack < e.hp * .5:
                    print("Standard attack would be less than 50% enemy remaining health. Looking for attack skill.")
                    bestAction = 'AttackSkill'
            if bestAction == 'HealSkill':
                for i in skills:
                    print("Current bestSkill is " + bestSkill.name)
                    print("Considering " + i.name)
                    if i.heal > 0:
                        print(i.name + " has a healing modifier")
                        if i.cost <= p.mana:
                            print("Can afford " + i.name)
                            estimatedHeal = p.hp + i.heal * p.maxHP
                            if estimatedHeal <= p.maxHP:
                                print(i.name + " would not overheal")
                                if i.heal > bestSkill.heal:
                                    print(i.name + " has a better healing modifier than " + bestSkill.name)
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.heal == bestSkill.heal:
                                    print(i.name + " has the same healing modifier as " + bestSkill.name)
                                    if p.strategy == 'Defensive' or p.strategy == 'Balanced':
                                        if eStrongestAttack == 'Physical' and i.pDef > bestSkill.pDef:
                                            print(
                                                i.name + " has a better physical defense modifier than " + bestSkill.name)
                                            print(i.name + " is new bestSkill")
                                            bestSkill = i
                                        elif eStrongestAttack == 'Magic' and i.mDef > bestSkill.mDef:
                                            print(
                                                i.name + " has a better magic defense modifier than " + bestSkill.name)
                                            print(i.name + " is new bestSkill")
                                            bestSkill = i
                                        else:
                                            print(i.name + " does not meet criteria for bestSkill")
                                    elif p.strategy == 'Aggressive':
                                        if pStrongestAttack == 'Physical' and i.pAtk > bestSkill.pAtk:
                                            print(
                                                i.name + " has a better physical attack modifier than " + bestSkill.name)
                                            print(i.name + " is new bestSkill")
                                            bestSkill = i
                                        elif pStrongestAttack == 'Magic' and i.mAtk > bestSkill.mAtk:
                                            print(i.name + " has a better magic attack modifier than " + bestSkill.name)
                                            print(i.name + " is new bestSkill")
                                            bestSkill = i
                                        else:
                                            print(i.name + " does not meet criteria for bestSkill")
                                else:
                                    print(i.name + " does not meet criteria for bestSkill")
                            else:
                                print(i.name + " would overheal")
                        else:
                            print("Cannot afford " + i.name)
                    else:
                        print(i.name + " does not have a healing modifier")
            elif bestAction == 'QuickKill':
                for i in skills:
                    print("Current best skill is " + bestSkill.name)
                    print("Considering " + i.name)
                    if i.cost <= p.mana:
                        print("Can afford " + i.name)
                        estimatedDamageI = atkAdj(p.pAtk * i.pAtk, e.pDef) + atkAdj(p.mAtk * i.mAtk, e.mDef)
                        estimatedDamageBest = atkAdj(p.pAtk * bestSkill.pAtk, e.pDef) + atkAdj(p.mAtk * bestSkill.mAtk,
                                                                                               e.mDef)
                        if estimatedDamageBest >= e.hp:
                            print(bestSkill.name + " would kill enemy")
                            if estimatedDamageI >= e.hp:
                                print(i.name + " would also kill enemy")
                                if i.cost < bestSkill.cost:
                                    print(i.name + " costs less than " + bestSkill.name)
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                else:
                                    print(i.name + " does not meet criteria to be bestSkill")
                            else:
                                print(i.name + " would not kill enemy outright")
                        else:
                            print(bestSkill.name + " would not kill enemy")
                            if estimatedDamageI >= e.hp:
                                print(i.name + " would kill enemy")
                                print(i.name + " is new bestSkill")
                                bestSkill = i
                    else:
                        print("Cannot afford " + i.name)
            elif bestAction == 'DefenseSkill':
                for i in skills:
                    print("Current bestSkill is " + bestSkill.name)
                    print("Considering " + i.name)
                    if eStrongestAttack == 'Physical':
                        if i.pDef > 1:
                            print(i.name + " has a physical defense modifier")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                if i.pDef > bestSkill.pDef:
                                    print(i.name + " has a better physical defense modifier than " + bestSkill.name)
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.pDef == bestSkill.pDef:
                                    print(i.name + " has the same physical defense modifier as " + bestSkill.name)
                                    if (
                                            p.strategy == 'Defensive' or p.strategy == 'Balanced') and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal * p.maxHP <= p.maxHP:
                                        print(i.name + " has a better healing modifier than " + bestSkill.name)
                                        print(i.name + " is new bestSkill")
                                        bestSkill = i
                                    elif p.strategy == 'Aggressive':
                                        if pStrongestAttack == 'Physical':
                                            if i.pAtk > bestSkill.pAtk:
                                                print(
                                                    i.name + " has a better physical attack modifier than " + bestSkill.name)
                                                print(i.name + " is new bestSkill")
                                                bestSkill = i
                                            else:
                                                print(i.name + " does not meet criteria for bestSkill")
                                        elif pStrongestAttack == 'Magic':
                                            if i.mAtk > bestSkill.mAtk:
                                                print(
                                                    i.name + " has a better magic attack modifier than " + bestSkill.name)
                                                print(i.name + " is new bestSkill")
                                                bestSkill = i
                                            else:
                                                print(i.name + " does not meet criteria for bestSkill")
                                    else:
                                        print(i.name + " does not meet criteria for new bestSkill")
                                else:
                                    print(i.name + " does not meet criteria for new bestSkill")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have a physical defense modifier")
                    elif eStrongestAttack == 'Magic':
                        if i.mDef > 1:
                            print(i.name + " has a magic defense modifier")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                if i.mDef > bestSkill.mDef:
                                    print(i.name + " has a better magic defense modifier than " + bestSkill.name)
                                    print(i.name + " is new bestSkill")
                                    bestSkill = i
                                elif i.mDef == bestSkill.mDef:
                                    print(i.name + " has the same magic defense modifier as " + bestSkill.name)
                                    if (
                                            p.strategy == 'Defensive' or p.strategy == 'Balanced') and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal * p.maxHP <= p.maxHP:
                                        print(i.name + " has a better healing modifier than " + bestSkill.name)
                                        print(i.name + " is new bestSkill")
                                        bestSkill = i
                                    elif p.strategy == 'Aggressive':
                                        if pStrongestAttack == 'Physical':
                                            if i.pAtk > bestSkill.pAtk:
                                                print(
                                                    i.name + " has a better physical attack modifier than " + bestSkill.name)
                                                print(i.name + " is new bestSkill")
                                                bestSkill = i
                                            else:
                                                print(i.name + " does not meet criteria for bestSkill")
                                        elif pStrongestAttack == 'Magic':
                                            if i.mAtk > bestSkill.mAtk:
                                                print(
                                                    i.name + " has a better magic attack modifier than " + bestSkill.name)
                                                print(i.name + " is new bestSkill")
                                                bestSkill = i
                                            else:
                                                print(i.name + " does not meet criteria for bestSkill")
                                else:
                                    print(i.name + " does not meet criteria for bestSkill")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have a magic defense modifier")
            elif bestAction == 'AttackSkill':
                for i in skills:
                    print("Current bestSkill is " + bestSkill.name)
                    print("Considering " + i.name)
                    if pStrongestAttack == 'Physical':
                        if i.pAtk > 1:
                            print(i.name + " has a physical attack modifier")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                if i.pAtk > bestSkill.pAtk:
                                    print(i.name + " has a better physical attack modifier than " + bestSkill.name)
                                    estimatedDamage = atkAdj(p.pAtk * i.pAtk, e.pDef)
                                    if estimatedDamage <= e.hp:
                                        print(i.name + " will not overkill")
                                        print(i.name + " is new bestSkill")
                                        bestSkill = i
                                    else:
                                        print(i.name + " will overkill")
                                elif i.pAtk == bestSkill.pAtk:
                                    if eStrongestAttack == 'Physical':
                                        if i.pDef > bestSkill.pDef:
                                            print(
                                                i.name + " has a better physical defense modifier than " + bestSkill.name)
                                            print(i.name + " is new bestSkill")
                                            bestSkill = i
                                        else:
                                            print(i.name + " does not meet criteria for bestSkill")
                                    elif eStrongestAttack == 'Magic':
                                        if i.mDef > bestSkill.mDef:
                                            print(
                                                i.name + " has a better magic defense modifier than " + bestSkill.name)
                                            print(i.name + " is new bestSkill")
                                            bestSkill = i
                                        else:
                                            print(i.name + " does not meet criteria for bestSkill")
                                else:
                                    print(i.name + " does not meet criteria for bestSkill")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have a physical attack modifier")
                    elif pStrongestAttack == 'Magic':
                        if i.mAtk > 1:
                            print(i.name + " has a magic attack modifier")
                            if i.cost <= p.mana:
                                print("Can afford " + i.name)
                                if i.mAtk > bestSkill.mAtk:
                                    print(i.name + " has a better magic attack modifier than " + bestSkill.name)
                                    estimatedDamage = atkAdj(p.mAtk * i.mAtk, e.mDef)
                                    if estimatedDamage <= e.hp:
                                        print(i.name + " will not overkill")
                                        print(i.name + " is new bestSkill")
                                        bestSkill = i
                                    else:
                                        print(i.name + " will overkill")
                                elif i.mAtk == bestSkill.mAtk:
                                    if eStrongestAttack == 'Physical':
                                        if i.pDef > bestSkill.pDef:
                                            print(
                                                i.name + " has a better physical defense modifier than " + bestSkill.name)
                                            print(i.name + " is new bestSkill")
                                            bestSkill = i
                                        else:
                                            print(i.name + " does not meet criteria for bestSkill")
                                    elif eStrongestAttack == 'Magic':
                                        if i.mDef > bestSkill.mDef:
                                            print(
                                                i.name + " has a better magic defense modifier than " + bestSkill.name)
                                            print(i.name + " is new bestSkill")
                                            bestSkill = i
                                        else:
                                            print(i.name + " does not meet criteria for bestSkill")
                                else:
                                    print(i.name + " does not meet criteria for bestSkill")
                            else:
                                print("Cannot afford " + i.name)
                        else:
                            print(i.name + " does not have a physical attack modifier")
            if bestSkill != skills[0]:
                print("bestSkill is " + bestSkill.name)
                print("Using " + bestSkill.name)
                bestSkill.use()
                print(str(bestSkill.cost) + " mana spent. " + str(p.mana) + " mana remaining.")
                print("Player physical attack now " + str(p.pAtk))
                print("Player physical defense now " + str(p.pDef))
                print("Player magic attack now " + str(p.mAtk))
                print("Player magic defense now " + str(p.mDef))
                print("Player hp now " + str(p.hp))
                print("Adding " + bestSkill.name + " to list of uses\n")
                usedSkill(bestSkill)
            else:
                print("No bestSkill found. Performing standard attack.\n")
            dam = atkAdj(p.pAtk, e.pDef) + atkAdj(p.mAtk, e.mDef)
            print("Player dealt " + str(dam) + " damage")
            e.hp -= dam
            print("Enemy hp is now " + str(e.hp) + "\n")
            print("Increasing number of turns\n")
            numTurns += 1
            turnInt = 0
    if e.hp <= 0:
        print("Player wins!\n")
    elif p.hp <= 0:
        print("Player loses.\n")
    hpLost = p.maxHP - p.hp
    print("Lost " + str(hpLost) + " hp\n")
    manaUsed = p.maxMana - p.mana
    print("Used " + str(manaUsed) + " mana\n")
    print("Took " + str(numTurns) + " turns\n")


def combatReport():
    global p
    global e
    global winsList
    global hpLostList
    global turnsList
    global usedMana
    global skills
    p.fullHeal()
    e.fullHeal()
    turnInt = turn()
    numTurns = 0
    while p.hp > 0 and e.hp > 0:
        print("Player HP: " + str(p.hp) + "\nEnemy HP: " + str(e.hp))
        if turnInt == 0:
            dam = atkAdj(e.pAtk, p.pDef) + atkAdj(e.mAtk, p.mDef)
            p.hp -= dam
            print("Enemy deals " + str(dam) + " damage")
            p.reset()
            turnInt = 1
        elif turnInt == 1:
            pStrongestAttack = 'Physical'
            eStrongestAttack = 'Physical'
            expectedPAttack = atkAdj(p.pAtk, e.pDef)
            expectedMAttack = atkAdj(p.mAtk, e.mDef)
            if expectedPAttack > expectedMAttack:
                pStrongestAttack = 'Physical'
            elif expectedPAttack < expectedMAttack:
                pStrongestAttack = 'Magic'
            expectedPIncoming = atkAdj(e.pAtk, p.pDef)
            expectedMIncoming = atkAdj(e.mAtk, p.mDef)
            if expectedPIncoming > expectedMIncoming:
                eStrongestAttack = 'Physical'
            elif expectedPIncoming < expectedMIncoming:
                eStrongestAttack = 'Magic'
            incomingAttack = atkAdj(e.pAtk, p.pDef) + atkAdj(e.mAtk, p.mDef)
            outgoingAttack = atkAdj(p.pAtk, e.pDef) + atkAdj(p.mAtk, e.mDef)
            bestSkill = skills[0]
            if (p.strategy == 'Defensive' and p.hp < p.maxHP) or (
                    p.strategy == 'Balanced' and p.hp <= p.maxHP * .5) or (
                    p.strategy == 'Aggressive' and incomingAttack >= p.hp * .8):
                for i in skills:
                    if i.heal > 0 and i.cost <= p.mana and p.hp + i.heal * p.maxHP <= p.maxHP:
                        if i.heal > bestSkill.heal:
                            bestSkill = i
                        elif i.heal == bestSkill.heal:
                            if (p.strategy == 'Defensive' or p.strategy == 'Balanced') and (
                                    (eStrongestAttack == 'Physical' and i.pDef > bestSkill.pDef) or (
                                    eStrongestAttack == 'Magic' and i.mDef > bestSkill.mDef)):
                                bestSkill = i
                            elif p.strategy == 'Aggressive' and (
                                    (pStrongestAttack == 'Physical' and i.pAtk > bestSkill.pAtk) or (
                                    pStrongestAttack == 'Magic' and i.mAtk > bestSkill.mAtk)):
                                bestSkill = i
            if bestSkill == skills[0] and ((p.strategy == 'Defensive' and p.mana > p.maxMana * .5 and (
                    incomingAttack >= p.hp * .5 or incomingAttack >= p.maxHP * .2)) or (
                                                   p.strategy == 'Balanced' and p.mana > p.maxMana * .25 and (
                                                   incomingAttack >= p.hp * .66 or incomingAttack >= p.maxHP * .33))):
                for i in skills:
                    if eStrongestAttack == 'Physical':
                        if i.pDef > 1 and i.cost <= p.mana:
                            if i.pDef > bestSkill.pDef:
                                bestSkill = i
                            elif i.pDef == bestSkill.pDef:
                                if (
                                        p.strategy == 'Defensive' or p.strategy == 'Balanced') and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal * p.maxHP <= p.maxHP:
                                    bestSkill = i
                    elif eStrongestAttack == 'Magic':
                        if i.mDef > 1 and i.cost <= p.mana:
                            if i.mDef > bestSkill.mDef:
                                bestSkill = i
                            elif i.mDef == bestSkill.mDef:
                                if (
                                        p.strategy == 'Defensive' or p.strategy == 'Balanced') and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal * p.maxHP <= p.maxHP:
                                    bestSkill = i
            if bestSkill == skills[0] and ((
                                                   p.strategy == 'Balanced' and p.mana > p.maxMana * .25) or p.strategy == 'Aggressive') and outgoingAttack < e.hp * .5:
                for i in skills:
                    if pStrongestAttack == 'Physical':
                        if i.pAtk > 1 and i.cost <= p.mana:
                            if i.pAtk > bestSkill.pAtk and atkAdj(p.pAtk * i.pAtk, e.pDef) <= e.hp:
                                bestSkill = i
                            elif i.pAtk == bestSkill.pAtk and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal * p.maxHP <= p.maxHP:
                                bestSkill = i
                    elif pStrongestAttack == 'Magic':
                        if i.mAtk > 1 and i.cost <= p.mana:
                            if i.mAtk > bestSkill.mAtk and atkAdj(p.mAtk * i.mAtk, e.mDef) <= e.hp:
                                bestSkill = i
                            elif i.mAtk == bestSkill.mAtk and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal * p.maxHP <= p.maxHP:
                                bestSkill = i
            if bestSkill != skills[0]:
                bestSkill.use()
                usedSkill(bestSkill)
            dam = atkAdj(p.pAtk, e.pDef) + atkAdj(p.mAtk, e.mDef)
            e.hp -= dam
            print("Player deals " + str(dam) + " damage")
            numTurns += 1
            turnInt = 0
    if e.hp <= 0:
        print("Player wins\n")
        winsList.append(1)
    elif p.hp <= 0:
        print("Player loses\n")
        winsList.append(0)
    hpLost = p.maxHP - p.hp
    hpLostList.append(hpLost)
    manaUsed = p.maxMana - p.mana
    usedMana.append(manaUsed)
    turnsList.append(numTurns)


def combat():
    global p
    global e
    global winsList
    global hpLostList
    global turnsList
    global usedMana
    global skills
    p.fullHeal()
    e.fullHeal()
    turnInt = turn()
    numTurns = 0
    while p.hp > 0 and e.hp > 0:
        if turnInt == 0:
            p.hp -= atkAdj(e.pAtk, p.pDef) + atkAdj(e.mAtk, p.mDef)
            p.reset()
            turnInt = 1
        elif turnInt == 1:
            pStrongestAttack = 'Physical'
            eStrongestAttack = 'Physical'
            expectedPAttack = atkAdj(p.pAtk, e.pDef)
            expectedMAttack = atkAdj(p.mAtk, e.mDef)
            if expectedPAttack > expectedMAttack:
                pStrongestAttack = 'Physical'
            elif expectedPAttack < expectedMAttack:
                pStrongestAttack = 'Magic'
            expectedPIncoming = atkAdj(e.pAtk, p.pDef)
            expectedMIncoming = atkAdj(e.mAtk, p.mDef)
            if expectedPIncoming > expectedMIncoming:
                eStrongestAttack = 'Physical'
            elif expectedPIncoming < expectedMIncoming:
                eStrongestAttack = 'Magic'
            incomingAttack = atkAdj(e.pAtk, p.pDef) + atkAdj(e.mAtk, p.mDef)
            outgoingAttack = atkAdj(p.pAtk, e.pDef) + atkAdj(p.mAtk, e.mDef)
            bestSkill = skills[0]
            bestAction = 'None'
            if p.strategy == 'Defensive' and (p.hp <= p.maxHP * .5 or incomingAttack >= p.hp * .5):
                bestAction = 'HealSkill'
            elif (p.strategy == 'Balanced' and p.hp <= p.maxHP * .5 and incomingAttack >= p.hp * .5) or (
                    p.strategy == 'Aggressive' and incomingAttack >= p.hp * .75):
                if outgoingAttack >= e.hp:
                    bestAction = 'BasicAttack'
                else:
                    for i in skills:
                        if i.cost <= p.mana:
                            estimatedDamage = atkAdj(p.pAtk * i.pAtk, e.pDef) + atkAdj(p.mAtk * i.mAtk, e.mDef)
                            if estimatedDamage >= e.hp:
                                bestAction = 'QuickKill'
                if bestAction == 'None':
                    bestAction = 'HealSkill'
            if bestAction == 'None':
                if (p.strategy == 'Defensive' and p.mana > p.maxMana * .5 and incomingAttack >= p.maxHP * .2):
                    bestAction = 'DefenseSkill'
                elif (p.strategy == 'Balanced' and p.mana > p.maxMana * .5 and (
                        incomingAttack >= p.hp * .66 or incomingAttack >= p.maxHP * .33)):
                    if outgoingAttack >= e.hp:
                        bestAction = 'BasicAttack'
                    else:
                        for i in skills:
                            if i.cost <= p.mana:
                                estimatedDamage = atkAdj(p.pAtk * i.pAtk, e.pDef) + atkAdj(p.mAtk * i.mAtk, e.mDef)
                                if estimatedDamage >= e.hp:
                                    bestAction = 'QuickKill'
                    if bestAction == 'None':
                        bestAction = 'DefenseSkill'
            if bestAction == 'None':
                if ((
                            p.strategy == 'Balanced' and p.mana > p.maxMana * .25) or p.strategy == 'Aggressive') and outgoingAttack < e.hp * .5:
                    bestAction = 'AttackSkill'
            if bestAction == 'HealSkill':
                for i in skills:
                    if i.heal > 0 and i.cost <= p.mana:
                        estimatedHeal = p.hp + i.heal * p.maxHP
                        if estimatedHeal <= p.maxHP:
                            if i.heal > bestSkill.heal:
                                bestSkill = i
                            elif i.heal == bestSkill.heal:
                                if (p.strategy == 'Defensive' or p.strategy == 'Balanced') and (
                                        (eStrongestAttack == 'Physical' and i.pDef > bestSkill.pDef) or (
                                        eStrongestAttack == 'Magic' and i.mDef > bestSkill.mDef)):
                                    bestSkill = i
                                elif p.strategy == 'Aggressive' and (
                                        (pStrongestAttack == 'Physical' and i.pAtk > bestSkill.pAtk) or (
                                        pStrongestAttack == 'Magic' and i.mAtk > bestSkill.mAtk)):
                                    bestSkill = i
            elif bestAction == 'QuickKill':
                estimatedDamage = atkAdj(p.pAtk, e.pDef) + atkAdj(p.mAtk, e.mDef)
                if estimatedDamage < e.hp:
                    for i in skills:
                        if i.cost <= p.mana:
                            estimatedDamageI = atkAdj(p.pAtk * i.pAtk, e.pDef) + atkAdj(p.mAtk * i.mAtk, e.mDef)
                            estimatedDamageBest = atkAdj(p.pAtk * bestSkill.pAtk, e.pDef) + atkAdj(
                                p.mAtk * bestSkill.mAtk, e.mDef)
                            if estimatedDamageBest >= e.hp and estimatedDamageI >= e.hp and i.cost < bestSkill.cost:
                                bestSkill = i
                            elif estimatedDamageI >= e.hp:
                                bestSkill = i
            elif bestAction == 'DefenseSkill':
                for i in skills:
                    if eStrongestAttack == 'Physical' and i.cost <= p.mana:
                        if p.pDef * bestSkill.pDef >= 100 and p.pDef * i.pDef >= 100 and i.cost < bestSkill.cost:
                            bestSkill = i
                        elif i.pDef > bestSkill.pDef and i.pDef * p.pDef <= 100:
                            bestSkill = i
                        elif i.pDef == bestSkill.pDef and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal * p.maxHP <= p.maxHP:
                            bestSkill = i
                    elif eStrongestAttack == 'Magic' and i.cost <= p.mana:
                        if p.mDef * bestSkill.mDef >= 100 and p.mDef * i.mDef >= 100 and i.cost < bestSkill.cost:
                            bestSkill = i
                        elif i.mDef > bestSkill.mDef and i.mDef * p.mDef <= 100:
                            bestSkill = i
                        elif i.mDef == bestSkill.mDef and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal * p.maxHP <= p.maxHP:
                            bestSkill = i
            elif bestAction == 'AttackSkill':
                for i in skills:
                    if pStrongestAttack == 'Physical' and i.cost <= p.mana:
                        estimatedDamage = atkAdj(p.pAtk * i.pAtk, e.pDef)
                        if i.pAtk > bestSkill.pAtk and estimatedDamage <= e.hp:
                            bestSkill = i
                        elif i.pAtk == bestSkill.pAtk and i.heal > bestSkill.heal and p.hp < p.maxHP and p.hp + i.heal * p.maxHP <= p.maxHP:
                            bestSkill = i
                    elif pStrongestAttack == 'Magic' and i.cost <= p.mana:
                        estimatedDamage = atkAdj(p.mAtk * i.mAtk, e.mDef)
                        if i.mAtk > bestSkill.mAtk and estimatedDamage <= e.hp:
                            bestSkill = i
                        elif i.mAtk == bestSkill.mAtk and i.heal > bestSkill.heal and p.hp < p.maxHP and p.hp + i.heal * p.maxHP <= p.maxHP:
                            bestSkill = i
            if bestAction != 'None':
                bestSkill.use()
                usedSkill(bestSkill)
            dam = atkAdj(p.pAtk, e.pDef) + atkAdj(p.mAtk, e.mDef)
            e.hp -= dam
            numTurns += 1
            turnInt = 0
    if e.hp <= 0:
        winsList.append(1)
    elif p.hp <= 0:
        winsList.append(0)
    hpLost = p.maxHP - p.hp
    hpLostList.append(hpLost)
    manaUsed = p.maxMana - p.mana
    usedMana.append(manaUsed)
    turnsList.append(numTurns)


def encounterGenerator():
    global p
    global e
    # bp will stand for "ballpark estimate"
    validBPHP = False
    while not validBPHP:
        bpHPLost = getInput("(0.0-0.99) Average hp loss as percentage: ")
        try:
            bpHPLost = float(bpHPLost)
            if 1.0 > bpHPLost and bpHPLost >= 0.0:
                bpHPLost = p.maxHP * bpHPLost
                validBPHP = True
            else:
                print("Percentage lost must be greater than or equal to 0.0 and less than 1.0")
        except ValueError:
            print("Unrecognized Input")
    validBPTurns = False
    while not validBPTurns:
        bpTurns = getInput("Average number of turns: ")
        try:
            bpTurns = int(bpTurns)
            if bpTurns >= 1:
                validBPTurns = True
            else:
                print("Average number of turns must be greater than or equal to 1")
        except ValueError:
            print("Unrecognized Input")
    validEnemyType = False
    while not validEnemyType:
        enemyType = getInput("Enemy Type:\nPhysical\nMagic\n")
        if enemyType == 'Physical':
            validEnemyType = True
        elif enemyType == 'Magic':
            validEnemyType = True
        else:
            print("Unrecognized Input")
    randHP = randint(40, 80)
    if enemyType == 'Physical':
        randPAtk = randint(20, 40)
        randMAtk = round(randPAtk / 3)
        randPDef = randint(10, 20)
        randMDef = round(randPDef / 4)
    elif enemyType == 'Magic':
        randMAtk = randint(20, 40)
        randPAtk = round(randMAtk / 3)
        randMDef = randint(10, 20)
        randPDef = round(randMDef / 4)
    e = Enemy(randHP, randPAtk, randPDef, randMAtk, randMDef)
    print("Starting stats:\nHP: " + str(e.hp) + "\nPAtk: " + str(e.pAtk) + "\nPDef: " + str(e.pDef)
          + "\nMAtk: " + str(e.mAtk) + "\nMDef: " + str(e.mDef) + "\n")
    print("Beginning calculations")
    successful = False
    while not successful:
        repeat = 100
        while repeat > 0:
            combat()
            repeat -= 1
        hpLost = getHPLost()
        turns = getTurns()
        if bpHPLost * 1.2 >= hpLost >= bpHPLost * .8 and bpTurns + 1 >= turns >= bpTurns - 1:
            successful = True
            print("Calculations complete!\n")
            print("Average HP Loss: " + str(hpLost) + "\nAverage Turns: " + str(turns) + "\n")
            print("Ideal enemy stats:")
            print("Enemy Type: " + enemyType)
            print("HP: " + str(e.maxHP) + "\nPAtk: " + str(e.pAtk) + "\nPDef: " + str(e.pDef)
                  + "\nMAtk: " + str(e.mAtk) + "\nMDef: " + str(e.mDef) + "\n")
        else:
            print("Recalculating")
            if hpLost > bpHPLost * 1.2:
                e.pAtk = round(e.pAtk - e.pAtk * .25)
                e.mAtk = round(e.mAtk - e.mAtk * .25)
            elif bpHPLost * .8 > hpLost:
                e.pAtk = round(e.pAtk + e.pAtk * .25)
                e.mAtk = round(e.mAtk + e.mAtk * .25)
            if turns > bpTurns + 1:
                e.maxHP = round(e.maxHP - e.maxHP * .25)
                e.pDef = round(e.pDef - e.pDef * .2)
                e.mDef = round(e.mDef - e.mDef * .2)
            elif bpTurns - 1 > turns:
                e.maxHP = round(e.maxHP + e.maxHP * .25)
                e.pDef = round(e.pDef + e.pDef * .2)
                e.mDef = round(e.mDef + e.mDef * .2)


def runCombat():
    global winsList
    global hpLostList
    global usedMana
    global turnsList
    winsList.clear()
    hpLostList.clear()
    usedMana.clear()
    turnsList.clear()
    repeat = 100
    while repeat > 0:
        combat()
        repeat -= 1
    print("Player HP: " + str(p.maxHP) + "\nPlayer Physical Attack: " + str(
        p.maxPAtk) + "\nPlayer Physical Defense: " + str(
        p.maxPDef) + "\nPlayer Magic Attack: " + str(p.maxMAtk) + "\nPlayer Magic Defense: " + str(
        p.maxMDef) + "\nPlayer Mana: " + str(p.maxMana) + "\nStrategy: " + p.strategy + "\n")
    if skill1 is not None:
        skill1.print()
    if skill2 is not None:
        skill2.print()
    if skill3 is not None:
        skill3.print()
    print("Enemy HP: " + str(e.maxHP) + "\nEnemy Physical Attack: " + str(
        e.pAtk) + "\nEnemy Physical Defense: " + str(e.pDef) + "\nEnemy Magic Attack: " + str(
        e.mAtk) + "\nEnemy Magic Defense: " + str(e.mDef) + "\n")
    print("Average HP lost: " + str(getHPLost()))
    print("Average Mana used: " + str(getUsedMana()))
    if skill1 is not None:
        print("Used " + skill1.name + ": " + str(getUsedSkill1() / 100))
    if skill2 is not None:
        print("Used " + skill2.name + ": " + str(getUsedSkill2() / 100))
    if skill3 is not None:
        print("Used " + skill3.name + ": " + str(getUsedSkill3() / 100))
    print("Average number of turns: " + str(getTurns()))
    print("Number of wins: " + str(getWins()) + "\n")


# ***********************************************************************************************************************
# EXPERIMENTAL CODE
# ***********************************************************************************************************************

def multiCombat():
    global p
    global winsList
    global hpLostList
    global turnsList
    global usedMana
    global skills

    e1 = buildEnemy()
    e2 = buildEnemy()
    e3 = buildEnemy()
    enemies = [e1, e2, e3]
    e1.name = 'e1'
    e2.name = 'e2'
    e3.name = 'e3'
    validTarget = False
    while not validTarget:
        targetChoice = getInput("Target:\n1 - Weakest\n2 - Strongest\n")
        if targetChoice == '1':
            validTarget = True
            bestTarget = 'Weakest'
        elif targetChoice == '2':
            validTarget = True
            bestTarget = 'Strongest'
        else:
            print("Unrecognized Input")
    for e in enemies:
        e.fullHeal()
    p.fullHeal()
    turnInt = turn()
    numTurns = 0
    weakest = enemies[0]
    strongest = enemies[0]
    for e in enemies:
        if e.hp < weakest.hp:
            weakest = e
            print("Weakest is " + weakest.name)
        if atkAdj(e.pAtk, p.pDef) + atkAdj(e.mAtk, p.mDef) > atkAdj(strongest.pAtk, p.pDef) + atkAdj(strongest.mAtk,
                                                                                                     p.mDef):
            strongest = e
            print("Strongest is " + strongest.name)
    if bestTarget == 'Weakest':
        target = weakest
        print("Targeting weakest")
    elif bestTarget == 'Strongest':
        target = strongest
        print("Targeting strongest")
    while p.hp > 0 and len(enemies) > 0:
        if turnInt == 0:
            for e in enemies:
                print(e.name + " attacks")
                dam = atkAdj(e.pAtk, p.pDef) + atkAdj(e.mAtk, p.mDef)
                p.hp -= dam
                print(e.name + " deals " + str(dam) + " damage")
                print("HP: " + str(p.hp))
            p.reset()
            turnInt = 1
        elif turnInt == 1:
            pStrongestAttack = 'Physical'
            eStrongestAttack = 'Physical'
            expectedPAttack = atkAdj(p.pAtk, target.pDef)
            expectedMAttack = atkAdj(p.mAtk, target.mDef)
            if expectedPAttack > expectedMAttack:
                pStrongestAttack = 'Physical'
            elif expectedPAttack < expectedMAttack:
                pStrongestAttack = 'Magic'
            strongestPIncoming = atkAdj(strongest.pAtk, p.pDef)
            strongestMIncoming = atkAdj(strongest.mAtk, p.mDef)
            try:
                pIncoming2 = atkAdj(enemies[1].pAtk, p.pDef)
                mIncoming2 = atkAdj(enemies[1].mAtk, p.mDef)
            except IndexError:
                pIncoming2 = 0
                mIncoming2 = 0
            try:
                pIncoming3 = atkAdj(enemies[2].pAtk, p.pDef)
                mIncoming3 = atkAdj(enemies[2].mAtk, p.mDef)
            except IndexError:
                pIncoming3 = 0
                mIncoming3 = 0
            pIncoming = strongestPIncoming + pIncoming2 + pIncoming3
            mIncoming = strongestMIncoming + mIncoming2 + mIncoming3
            if pIncoming > mIncoming:
                eStrongestAttack = 'Physical'
            elif pIncoming < mIncoming:
                eStrongestAttack = 'Magic'
            incomingAttack = pIncoming + mIncoming
            outgoingAttack = atkAdj(p.pAtk, target.pDef) + atkAdj(p.mAtk, target.mDef)
            bestSkill = skills[0]
            bestAction = 'None'
            if p.strategy == 'Defensive' and (p.hp <= p.maxHP * .5 or incomingAttack >= p.hp * .5):
                bestAction = 'HealSkill'
            elif (p.strategy == 'Balanced' and p.hp <= p.maxHP * .5 and incomingAttack >= p.hp * .5) or (
                    p.strategy == 'Aggressive' and incomingAttack >= p.hp * .75):
                if len(enemies) == 1 and outgoingAttack >= target.hp:
                    bestAction = 'BasicAttack'
                else:
                    for i in skills:
                        if i.cost <= p.mana:
                            estimatedDamage = atkAdj(p.pAtk * i.pAtk, target.pDef) + atkAdj(p.mAtk * i.mAtk,
                                                                                            target.mDef)
                            if len(enemies) == 1 and estimatedDamage >= target.hp:
                                bestAction = 'QuickKill'
                if bestAction == 'None':
                    bestAction = 'HealSkill'
            if bestAction == 'None':
                if (p.strategy == 'Defensive' and p.mana > p.maxMana * .5 and incomingAttack >= p.maxHP * .2):
                    bestAction = 'DefenseSkill'
                elif (p.strategy == 'Balanced' and p.mana > p.maxMana * .5 and (
                        incomingAttack >= p.hp * .66 or incomingAttack >= p.maxHP * .33)):
                    if len(enemies) == 1 and outgoingAttack >= target.hp:
                        bestAction = 'BasicAttack'
                    else:
                        for i in skills:
                            if i.cost <= p.mana:
                                estimatedDamage = atkAdj(p.pAtk * i.pAtk, target.pDef) + atkAdj(p.mAtk * i.mAtk,
                                                                                                target.mDef)
                                if len(enemies) == 1 and estimatedDamage >= target.hp:
                                    bestAction = 'QuickKill'
                    if bestAction == 'None':
                        bestAction = 'DefenseSkill'
            if bestAction == 'None':
                if ((
                            p.strategy == 'Balanced' and p.mana > p.maxMana * .25) or p.strategy == 'Aggressive') and outgoingAttack < target.hp * .5:
                    bestAction = 'AttackSkill'
            if bestAction == 'HealSkill':
                for i in skills:
                    if i.heal > 0 and i.cost <= p.mana:
                        estimatedHeal = p.hp + i.heal * p.maxHP
                        if estimatedHeal <= p.maxHP:
                            if i.heal > bestSkill.heal:
                                bestSkill = i
                            elif i.heal == bestSkill.heal:
                                if (p.strategy == 'Defensive' or p.strategy == 'Balanced') and (
                                        (eStrongestAttack == 'Physical' and i.pDef > bestSkill.pDef) or (
                                        eStrongestAttack == 'Magic' and i.mDef > bestSkill.mDef)):
                                    bestSkill = i
                                elif p.strategy == 'Aggressive' and (
                                        (pStrongestAttack == 'Physical' and i.pAtk > bestSkill.pAtk) or (
                                        pStrongestAttack == 'Magic' and i.mAtk > bestSkill.mAtk)):
                                    bestSkill = i
            elif bestAction == 'QuickKill':
                estimatedDamage = atkAdj(p.pAtk, target.pDef) + atkAdj(p.mAtk, target.mDef)
                if estimatedDamage < target.hp:
                    for i in skills:
                        if i.cost <= p.mana:
                            estimatedDamageI = atkAdj(p.pAtk * i.pAtk, target.pDef) + atkAdj(p.mAtk * i.mAtk,
                                                                                             target.mDef)
                            estimatedDamageBest = atkAdj(p.pAtk * bestSkill.pAtk, target.pDef) + atkAdj(
                                p.mAtk * bestSkill.mAtk, target.mDef)
                            if estimatedDamageBest >= target.hp and estimatedDamageI >= target.hp and i.cost < bestSkill.cost:
                                bestSkill = i
                            elif estimatedDamageI >= target.hp:
                                bestSkill = i
            elif bestAction == 'DefenseSkill':
                for i in skills:
                    if eStrongestAttack == 'Physical' and i.cost <= p.mana:
                        if p.pDef * bestSkill.pDef >= 100 and p.pDef * i.pDef >= 100 and i.cost < bestSkill.cost:
                            bestSkill = i
                        elif i.pDef > bestSkill.pDef and i.pDef * p.pDef <= 100:
                            bestSkill = i
                        elif i.pDef == bestSkill.pDef and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal * p.maxHP <= p.maxHP:
                            bestSkill = i
                    elif eStrongestAttack == 'Magic' and i.cost <= p.mana:
                        if p.mDef * bestSkill.mDef >= 100 and p.mDef * i.mDef >= 100 and i.cost < bestSkill.cost:
                            bestSkill = i
                        elif i.mDef > bestSkill.mDef and i.mDef * p.mDef <= 100:
                            bestSkill = i
                        elif i.mDef == bestSkill.mDef and p.hp < p.maxHP and i.heal > bestSkill.heal and p.hp + i.heal * p.maxHP <= p.maxHP:
                            bestSkill = i
            elif bestAction == 'AttackSkill':
                for i in skills:
                    if pStrongestAttack == 'Physical' and i.cost <= p.mana:
                        estimatedDamage = atkAdj(p.pAtk * i.pAtk, target.pDef)
                        if i.pAtk > bestSkill.pAtk and estimatedDamage <= target.hp:
                            bestSkill = i
                        elif i.pAtk == bestSkill.pAtk and i.heal > bestSkill.heal and p.hp < p.maxHP and p.hp + i.heal * p.maxHP <= p.maxHP:
                            bestSkill = i
                    elif pStrongestAttack == 'Magic' and i.cost <= p.mana:
                        estimatedDamage = atkAdj(p.mAtk * i.mAtk, target.mDef)
                        if i.mAtk > bestSkill.mAtk and estimatedDamage <= target.hp:
                            bestSkill = i
                        elif i.mAtk == bestSkill.mAtk and i.heal > bestSkill.heal and p.hp < p.maxHP and p.hp + i.heal * p.maxHP <= p.maxHP:
                            bestSkill = i
            if bestAction != 'None':
                bestSkill.use()
                usedSkill(bestSkill)
            dam = atkAdj(p.pAtk, target.pDef) + atkAdj(p.mAtk, target.mDef)
            print("Dealt " + str(dam) + " damage to target")
            target.hp -= dam
            print("Target hp is " + str(target.hp))
            if target.hp <= 0:
                enemies.remove(target)
                print("Killed target")
            numTurns += 1
            turnInt = 0
    if len(enemies) == 0:
        winsList.append(1)
    elif p.hp <= 0:
        winsList.append(0)
    hpLost = p.maxHP - p.hp
    hpLostList.append(hpLost)
    manaUsed = p.maxMana - p.mana
    usedMana.append(manaUsed)
    turnsList.append(numTurns)


# ***********************************************************************************************************************
#
# ***********************************************************************************************************************


validChoice = False
while not validChoice:
    choice = getInput(
        "Run what?\n1 - Test Encounter\n2 - Debug Encounter\n3 - Build Encounter\n4 - BROKEN MultiCombat\n")
    if choice == '1':
        validChoice = True
        p = buildPlayer()
        buildStrat()
        buildSkills()
        e = buildEnemy()
        runCombat()
    elif choice == '2':
        validChoice = True
        p = buildPlayer()
        buildStrat()
        buildSkills()
        e = buildEnemy()
        combatDebug()
    elif choice == '3':
        validChoice = True
        p = buildPlayer()
        buildStrat()
        buildSkills()
        encounterGenerator()
    elif choice == '4':
        validChoice = True
        p = buildPlayer()
        buildStrat()
        buildSkills()
        multiCombat()
    else:
        print("Unrecognized Input")

while run:
    validRunAgain = False
    while not validRunAgain:
        runAgainInput = getInput("Run again?\nYes\nNo\n")
        if runAgainInput == 'Yes':
            validRunAgain = True
            validChoice = False
            while not validChoice:
                choice = getInput(
                    "Run what?\n1 - Test Encounter\n2 - Debug Encounter\n3 - Build Encounter\n4 - BROKEN MultiCombat\n")
                if choice == '1':
                    validChoice = True
                    validChangeStats = False
                    while not validChangeStats:
                        changeStatsInput = getInput("Change Player Stats?\nYes\nNo\n")
                        if changeStatsInput == 'Yes':
                            validChangeStats = True
                            p = buildPlayer()
                        elif changeStatsInput == 'No':
                            validChangeStats = True
                        else:
                            print("Unrecognized Input")
                    validChangeSkills = False
                    while not validChangeSkills:
                        changeSkillsInput = getInput("Change Skills?\nYes\nNo\n")
                        if changeSkillsInput == 'Yes':
                            validChangeSkills = True
                            buildSkills()
                        elif changeSkillsInput == 'No':
                            validChangeSkills = True
                        else:
                            print("Unrecognized Input")
                    validChangeStrat = False
                    while not validChangeStrat:
                        changeStratInput = getInput("Change Strategy?\nYes\nNo\n")
                        if changeStratInput == 'Yes':
                            validChangeStrat = True
                            buildStrat()
                        elif changeStratInput == 'No':
                            validChangeStrat = True
                        else:
                            print("Unrecognized Input")
                    validChangeEnemy = False
                    while not validChangeEnemy:
                        changeEnemyInput = getInput("Change Enemy?\nYes\nNo\n")
                        if changeEnemyInput == 'Yes':
                            validChangeEnemy = True
                            e = buildEnemy()
                        elif changeEnemyInput == 'No':
                            validChangeEnemy = True
                        else:
                            print("Unrecognized Input")
                    runCombat()
                elif choice == '2':
                    validChoice = True
                    validChangeStats = False
                    while not validChangeStats:
                        changeStatsInput = getInput("Change Player Stats?\nYes\nNo\n")
                        if changeStatsInput == 'Yes':
                            validChangeStats = True
                            p = buildPlayer()
                        elif changeStatsInput == 'No':
                            validChangeStats = True
                        else:
                            print("Unrecognized Input")
                    validChangeSkills = False
                    while not validChangeSkills:
                        changeSkillsInput = getInput("Change Skills?\nYes\nNo\n")
                        if changeSkillsInput == 'Yes':
                            validChangeSkills = True
                            buildSkills()
                        elif changeSkillsInput == 'No':
                            validChangeSkills = True
                        else:
                            print("Unrecognized Input")
                    validChangeStrat = False
                    while not validChangeStrat:
                        changeStratInput = getInput("Change Strategy?\nYes\nNo\n")
                        if changeStratInput == 'Yes':
                            validChangeStrat = True
                            buildStrat()
                        elif changeStratInput == 'No':
                            validChangeStrat = True
                        else:
                            print("Unrecognized Input")
                    validChangeEnemy = False
                    while not validChangeEnemy:
                        changeEnemyInput = getInput("Change Enemy?\nYes\nNo\n")
                        if changeEnemyInput == 'Yes':
                            validChangeEnemy = True
                            e = buildEnemy()
                        elif changeEnemyInput == 'No':
                            validChangeEnemy = True
                        else:
                            print("Unrecognized Input")
                    combatDebug()
                elif choice == '3':
                    validChoice = True
                    validChangeStats = False
                    while not validChangeStats:
                        changeStatsInput = getInput("Change Player Stats?\nYes\nNo\n")
                        if changeStatsInput == 'Yes':
                            validChangeStats = True
                            p = buildPlayer()
                        elif changeStatsInput == 'No':
                            validChangeStats = True
                        else:
                            print("Unrecognized Input")
                    validChangeSkills = False
                    while not validChangeSkills:
                        changeSkillsInput = getInput("Change Skills?\nYes\nNo\n")
                        if changeSkillsInput == 'Yes':
                            validChangeSkills = True
                            buildSkills()
                        elif changeSkillsInput == 'No':
                            validChangeSkills = True
                        else:
                            print("Unrecognized Input")
                    validChangeStrat = False
                    while not validChangeStrat:
                        changeStratInput = getInput("Change Strategy?\nYes\nNo\n")
                        if changeStratInput == 'Yes':
                            validChangeStrat = True
                            buildStrat()
                        elif changeStratInput == 'No':
                            validChangeStrat = True
                        else:
                            print("Unrecognized Input")
                    encounterGenerator()
                elif choice == '4':
                    validChoice = True
                    validChangeStats = False
                    while not validChangeStats:
                        changeStatsInput = getInput("Change Player Stats?\nYes\nNo\n")
                        if changeStatsInput == 'Yes':
                            validChangeStats = True
                            p = buildPlayer()
                        elif changeStatsInput == 'No':
                            validChangeStats = True
                        else:
                            print("Unrecognized Input")
                    validChangeSkills = False
                    while not validChangeSkills:
                        changeSkillsInput = getInput("Change Skills?\nYes\nNo\n")
                        if changeSkillsInput == 'Yes':
                            validChangeSkills = True
                            buildSkills()
                        elif changeSkillsInput == 'No':
                            validChangeSkills = True
                        else:
                            print("Unrecognized Input")
                    validChangeStrat = False
                    while not validChangeStrat:
                        changeStratInput = getInput("Change Strategy?\nYes\nNo\n")
                        if changeStratInput == 'Yes':
                            validChangeStrat = True
                            buildStrat()
                        elif changeStratInput == 'No':
                            validChangeStrat = True
                        else:
                            print("Unrecognized Input")
                    multiCombat()
                else:
                    print("Unrecognized Input")
        elif runAgainInput == 'No':
            validRunAgain = True
            run = False
        else:
            print("Unrecognized Input")
