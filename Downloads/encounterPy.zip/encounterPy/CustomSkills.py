#TODO:
#   Mana
#   Skills
#   Skill costs
#   Health Skills
#   Attack Skills
#   Defense Skills

run = True

class Player:
    def __init__(self, maxHP = 100, maxPAtk = 20, maxPDef = 20, maxMana = 100, skill1 = None, skill1Type = None, skill1Cost = None, skill2 = None, skill2Type = None, skill2Cost = None, skill3 = None, skill3Type = None, skill3Cost = None, strategy = 'Balanced'):
        self.maxHP = maxHP
        self.hp = self.maxHP
        self.maxPAtk = maxPAtk
        self.pAtk = self.maxPAtk
        self.maxPDef = maxPDef
        self.pDef = self.maxPDef
        self.maxMana = maxMana
        self.mana = self.maxMana
        self.skill1 = skill1
        self.skill1Type = skill1Type
        self.skill1Cost = skill1Cost
        self.skill2 = skill2
        self.skill2Type = skill2Type
        self.skill2Cost = skill2Cost
        self.skill3 = skill3
        self.skill3Type = skill3Type
        self.skill3Cost = skill3Cost
        self.strategy = strategy

    def print(self):
        print("HP: " + str(self.hp) + "\tAtk: " + str(self.pAtk) + "\tDef: " + str(self.pDef) + "\tMana: " + str(self.mana))
        print("Strategy: " + self.strategy)
        if self.skill1 != None:
            print("Skill 1 Name: " + self.skill1 + "\nSkill 1 Type: " + self.skill1Type + "\nSkill 1 Cost: " + str(self.skill1Cost))
        if self.skill2 != None:
            print("Skill 2 Name: " + self.skill2 + "\nSkill 2 Type: " + self.skill2Type + "\nSkill 2 Cost: " + str(self.skill2Cost))
        if self.skill3 != None:
            print("Skill 3 Name: " + self.skill3 + "\nSkill 3 Type: " + self.skill3Type + "\nSkill 3 Cost: " + str(self.skill3Cost))

def getInput(str):
    userIn = input(str)
    userIn = userIn.capitalize()
    return userIn

def buildPlayer():
    validHP = False
    while not validHP:
        pHP = getInput("Player HP: ")
        try:
            int(pHP)
            validHP = True
        except ValueError:
            print("Unrecognized Input")
    validAtk = False
    while not validAtk:
        pAtk = getInput("Player Attack: ")
        try:
            int(pAtk)
            validAtk = True
        except ValueError:
            print("Unrecognized Input")
    validDef = False
    while not validDef:
        pDef = getInput("Player Defense: ")
        try:
            int(pDef)
            if int(pDef) < 100:
                validDef = True
            else:
                print("Defense must be less than 100")
        except ValueError:
            print("Unrecognized Input")
    validMana = False
    while not validMana:
        pMana = getInput("Player Mana: ")
        try:
            int(pMana)
            validMana = True
        except ValueError:
            print("Unrecognized Input")
    validSkill1 = False
    while not validSkill1:
        chooseSkill1 = getInput("Add Skill 1?\nYes\nNo\n")
        if chooseSkill1 == 'Yes':
           validSkill1 = True
           pSkill1 = getInput("Name of Skill 1: ")
           validSkill1Type = False
           while not validSkill1Type:
               pSkill1Type = getInput("Type of Skill 1:\nAttack\nDefense\nHealing\n")
               if pSkill1Type == 'Attack':
                   validSkill1Type = True
               elif pSkill1Type == 'Defense':
                   validSkill1Type = True
               elif pSkill1Type == 'Healing':
                   validSkill1Type = True
               else:
                   print("Unrecognized Input")
           validSkill1Cost = False
           while not validSkill1Cost:
               pSkill1Cost = getInput("Mana Cost of Skill 1: ")
               try:
                   int(pSkill1Cost)
                   if int(pSkill1Cost) > 0:
                       validSkill1Cost = True
                   else:
                       print("Mana Cost must be greater than 0")
               except ValueError:
                   print("Unrecognized Input")
           validSkill2 = False
           while not validSkill2:
               chooseSkill2 = getInput("Add Skill 2?\nYes\nNo\n")
               if chooseSkill2 == 'Yes':
                   validSkill2 = True
                   pSkill2 = getInput("Name of Skill 2: ")
                   validSkill2Type = False
                   while not validSkill2Type:
                       pSkill2Type = getInput("Type of Skill 2:\nAttack\nDefense\nHealing\n")
                       if pSkill2Type == 'Attack':
                           validSkill2Type = True
                       elif pSkill2Type == 'Defense':
                           validSkill2Type = True
                       elif pSkill2Type == 'Healing':
                           validSkill2Type = True
                       else:
                           print("Unrecognized Input")
                   validSkill2Cost = False
                   while not validSkill2Cost:
                       pSkill2Cost = getInput("Mana Cost of Skill 2: ")
                       try:
                           int(pSkill2Cost)
                           if int(pSkill2Cost) > 0:
                               validSkill2Cost = True
                           else:
                               print("Mana Cost must be greater than 0")
                       except ValueError:
                           print("Unrecognized Input")
                   validSkill3 = False
                   while not validSkill3:
                       chooseSkill3 = getInput("Add Skill 3?\nYes\nNo\n")
                       if chooseSkill3 == 'Yes':
                           validSkill3 = True
                           pSkill3 = getInput("Name of Skill 3: ")
                           validSkill3Type = False
                           while not validSkill3Type:
                               pSkill3Type = getInput("Type of Skill 3:\nAttack\nDefense\nHealing\n")
                               if pSkill3Type == 'Attack':
                                   validSkill3Type = True
                               elif pSkill3Type == 'Defense':
                                   validSkill3Type = True
                               elif pSkill3Type == 'Healing':
                                   validSkill3Type = True
                               else:
                                   print("Unrecognized Input")
                           validSkill3Cost = False
                           while not validSkill3Cost:
                               pSkill3Cost = getInput("Mana Cost of Skill 3: ")
                               try:
                                   int(pSkill3Cost)
                                   if int(pSkill3Cost) > 0:
                                       validSkill3Cost = True
                                   else:
                                       print("Mana Cost must be greater than 0")
                               except ValueError:
                                   print("Unrecognized Input")
                       elif chooseSkill3 == 'No':
                           validSkill3 = True
                           pSkill3 = None
                           pSkill3Type = None
                           pSkill3Cost = 0
                       else:
                           print("Unrecognized Input")
               elif chooseSkill2 == 'No':
                   validSkill2 = True
                   pSkill2 = None
                   pSkill2Type = None
                   pSkill2Cost = 0
                   pSkill3 = None
                   pSkill3Type = None
                   pSkill3Cost = 0
               else:
                   print("Unrecognized Input")
        elif chooseSkill1 == 'No':
            validSkill1 = True
            pSkill1 = None
            pSkill1Type = None
            pSkill1Cost = 0
            pSkill2 = None
            pSkill2Type = None
            pSkill2Cost = 0
            pSkill3 = None
            pSkill3Type = None
            pSkill3Cost = 0
        else:
            print("Unrecognized Input")
    validStrat = False
    while not validStrat:
        pStrat = getInput("Strategy:\nDefensive\nBalanced\nAggressive\n")
        if pStrat == 'Defensive':
            validStrat = True
        elif pStrat == 'Balanced':
            validStrat = True
        elif pStrat == 'Aggressive':
            validStrat = True
        else:
            print("Unrecognized Input")
    p = Player(int(pHP), int(pAtk), int(pDef), int(pMana), pSkill1, pSkill1Type, int(pSkill1Cost), pSkill2, pSkill2Type, int(pSkill2Cost), pSkill3, pSkill3Type, int(pSkill3Cost))
    p.strategy = pStrat
    return p

p = buildPlayer()
p.print()
while run:
    valid = False
    while not valid:
        userIn = getInput("Build Again?\nYes\nNo\n")
        if userIn == 'Yes':
            valid = True
            p = buildPlayer()
            p.print()
        elif userIn == 'No':
            valid = True
            run = False
        else:
            print("Unrecognized Input")