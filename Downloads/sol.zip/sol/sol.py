#***********************************************************************************************************************
# COPYRIGHT Joshua Supelana-Mix 9/9/2019
# This product is for private use only
# This product may not be modified, redistributed, sold, or used for any commercial purpose except by the
#   copyright holder
#***********************************************************************************************************************
from random import *

run = True

class Card:
	def __init__(self, rank, suit, value, color, faceUp=False):
		self.rank = rank
		self.suit = suit
		self.value = value
		self.color = color
		self.faceUp = faceUp
		
ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
suits = ['D', 'C', 'H', 'S']
deck = []
columns = [[],[],[],[],[],[],[],[],[],[],[],[]]

def rankSuit(card):
	return card.rank + card.suit
	
def fullPrint(card):
	print(card.rank + card.suit + "\nValue: " + str(card.value) + "\tColor: " + card.color + "\tFaceUp: " + str(card.faceUp))

def buildDeck():
	for suit in suits:
		if suit == 'D' or suit == 'H':
			color = 'red'
		elif suit == 'C' or suit == 'S':
			color = 'black'
		i = 0
		while i < 13:
			rank = ranks[i]
			value = i + 1
			deck.append(Card(rank, suit, value, color))
			i += 1


def dealBoard():
	startCol = 0
	while startCol < 7:
		currCol = startCol
		while currCol < 7:
			if currCol == startCol:
				deck[0].faceUp = True
			columns[currCol].append(deck[0])
			deck.pop(0)
			currCol += 1
		startCol += 1
		
def printBoard():
	longestCol = 0
	for column in columns:
		if len(column) > longestCol:
			longestCol = len(column)
	print("1\t\t2\t\t3\t\t4\t\t5\t\t6\t\t7\t\tD\t\tC\t\tH\t\tS\t\tDeck (" + str(len(deck)) + ")\n")
	i = 0
	while i < longestCol:
		for column in columns:
			try:
				if column[i].faceUp == True:
					print(rankSuit(column[i]), end = "\t\t")
				else:
					print("?", end="\t\t")
			except IndexError:
				print("\t", end="\t")
		print()
		i += 1
	print()
	
def checkCommand(userIn):
	if userIn == 'QUIT' or userIn == 'NEW' or userIn == 'DRAW':
		command = True
	else:
		command = False
	return command
	
def getInput(string):
	userIn = input(string)
	userIn = userIn.upper()
	return userIn
		
def getInputList(string):
	userIn = input(string)
	userIn = userIn.upper()
	if checkCommand(userIn):
		return userIn
	userIn = list(userIn)
	if len(userIn) < 2:
		userIn = '00'
		userIn = list(userIn)
	if userIn[0] == '1' and userIn[1] == '0':
		userIn[0] = '10'
		userIn.pop(1)
	return userIn
	
def pickUp():
	global run
	userIn = getInputList("Pickup what?\n")
	if userIn == 'QUIT':
		run = False
	elif userIn == 'NEW':
		newGame()
	elif userIn == 'DRAW':
		if len(deck) >= 3:
			i = 0
			while i < 3:
				deck[0].faceUp = True
				columns[11].append(deck[0])
				deck.pop(0)
				i += 1
		elif 3 > len(deck) > 0:
			i = 0
			j = len(deck)
			while i < j:
				deck[0].faceUp = True
				columns[11].append(deck[0])
				deck.pop(0)
				i += 1
		elif len(deck) == 0:
			i = 0
			length = len(columns[11])
			while i < length:
				columns[11][0].faceUp = False
				deck.append(columns[11][0])
				columns[11].pop(0)
				i += 1
			i = 0
			while i < 3:
				deck[0].faceUp = True
				columns[11].append(deck[0])
				deck.pop(0)
				i += 1				
	else:
		rankIn = userIn[0]
		suitIn = userIn[1]
		validCard = False
		for tempColumn in columns:
			for tempCard in tempColumn:
				if tempCard.rank == rankIn and tempCard.suit == suitIn and tempCard.faceUp:
					if tempColumn != columns[11]:
						validCard = True
						column = tempColumn
						card = tempCard
					else:
						card = tempCard
						column = tempColumn
						if column.index(card) == len(column) - 1:
							validCard = True
		if validCard:
			i = place(card, column)
			if i == 1:
				indexOfCard = column.index(card)
				i = len(column)
				while i > indexOfCard:
					column.pop()
					i -= 1
				try:
					column[len(column) - 1].faceUp = True
				except IndexError:
					pass
			elif i == 0:
				print("Cannot place there!")
			elif i == -1:
				print("Unrecognized Input")					
		else:
			print("Cannot see " + rankIn + suitIn)
		
def place(pickedUp, pickedUpColumn):
	global run
	indexOfCard = pickedUpColumn.index(pickedUp)
	userIn = getInput("Place in which column?\n")
	columnIn = -1
	try:
		userIn = int(userIn)
		if 7 >= userIn >= 1:
			columnIn = userIn - 1
		else:
			return -1
	except ValueError:
		if userIn == 'D':
			columnIn = 7
		elif userIn == 'C':
			columnIn = 8
		elif userIn == 'H':
			columnIn = 9
		elif userIn == 'S':
			columnIn = 10
		else:
			return -1
	if 6 >= columnIn >= 0:
		if len(columns[columnIn]) == 0:
			if pickedUp.rank == 'K':
				i = indexOfCard
				while i < len(pickedUpColumn):
					columns[columnIn].append(pickedUpColumn[i])
					i += 1
				return 1
			else:
				return 0
		else:
			card = columns[columnIn][len(columns[columnIn]) - 1]
			if pickedUp.value == card.value - 1 and pickedUp.color != card.color:
				i = indexOfCard
				while i < len(pickedUpColumn):
					columns[columnIn].append(pickedUpColumn[i])
					i += 1
				return 1
			else:
				return 0
	elif 10 >= columnIn >= 7:
		validSuit = False
		if pickedUp.suit == 'D' and columnIn == 7:
			validSuit = True
		elif pickedUp.suit == 'C' and columnIn == 8:
			validSuit = True
		elif pickedUp.suit == 'H' and columnIn == 9:
			validSuit = True
		elif pickedUp.suit == 'S' and columnIn == 10:
			validSuit = True
		if validSuit:
			indexOfColumn = pickedUpColumn.index(pickedUp)
			if indexOfColumn == len(pickedUpColumn) - 1:
				if len(columns[columnIn]) == 0:
					if pickedUp.rank == 'A':
						columns[columnIn].append(pickedUp)
						return 1
					else:
						return 0
				else:
					card = columns[columnIn][len(columns[columnIn]) - 1]
					if pickedUp.value == card.value + 1:
						columns[columnIn].append(pickedUp)
						return 1
					else:
						return 0
			else:
				return 0
		else:
			return 0
	else:
		return -1
		
def newGame():
	for column in columns:
		column.clear()
	deck.clear()
	buildDeck()
	shuffle(deck)
	dealBoard()


print("Thank you for playing Sol.py\n\nTo pick up a card, input the rank and suit of the card as it appears.\nFor example, input 5C to pick up the Five of Clubs.")
print("To pick up multiple cards, input the topmost card to pick up. For example, to pick up the King of Clubs,")
print("the Queen of Hearts, and the Jack of Spades, input KC.")
print("Once you've picked up a card, you will be asked for a column\nin which to place the card or cards you have picked up.")
print("Input the number of the column, or D, C, H, or S to place it in the home row.")
print("Input DRAW to draw from the deck, NEW to start a new game, or QUIT to end the program")
print("Press ENTER to begin")
input()
print()
print()
newGame()
while run:
	print()
	printBoard()
	pickUp()
	