/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

/*
 * Skills the Player can use in combat. Lots of room for customization.
 * Skills can be created that attack, defend, heal, buff or debuff, or even cost HP instead of mana to use
 * See help text in Handler class for a more detailed description of skills and how they work
 */
 
public class Skill {

	private String name;
	private String job;
	private String desc;
	private int manaCost;
	private int acc;
	
	// These variables buff the player
	private float pAtk;
	private float pDef;
	private float mAtk;
	private float mDef;
	private float heal;
	private float eva;
	private float accMod;
	private int range;
	
	// These variables debuff (d) the enemy
	private float dPAtk;
	private float dPDef;
	private float dMAtk;
	private float dMDef;
	private float dAcc;
	private float dEva;
	
	// These variables store the value by which a buff changes a stat
	// When the skill resets, the stored values are retrieved and the stat changes by -1x that amount
	private int storedPAtk;
	private int storedPDef;
	private int storedMAtk;
	private int storedMDef;
	private int storedEva;
	private int storedAccMod;
	private int storedDPAtk;
	private int storedDPDef;
	private int storedDMAtk;
	private int storedDMDef;
	private int storedDAcc;
	private int storedDEva;
	
	private int duration;
	private int atkDuration;
	private boolean hitToBuff;
	private int goldCost;
	private int buffEnd;
	private int atkBuffEnd;

	public Skill(String name, String job, String desc, int manaCost, int acc, float pAtk, float pDef, float mAtk, float mDef, float heal, float eva, float accMod, int range, float dPAtk, float dPDef, float dMAtk, float dMDef, float dAcc, float dEva, int duration, int atkDuration, boolean hitToBuff, int goldCost) {
		this.name = name;
		this.job = job;
		this.desc = desc;
		this.manaCost = manaCost;
		this.acc = acc;
		this.pAtk = pAtk;
		this.pDef = pDef;
		this.mAtk = mAtk;
		this.mDef = mDef;
		this.heal = heal;
		this.eva = eva;
		this.accMod = accMod;
		this.range = range;
		this.dPAtk = dPAtk;
		this.dPDef = dPDef;
		this.dMAtk = dMAtk;
		this.dMDef = dMDef;
		this.dAcc = dAcc;
		this.dEva = dEva;
		this.storedPAtk = 0;
		this.storedPDef = 0;
		this.storedMAtk = 0;
		this.storedMDef = 0;
		this.storedEva = 0;
		this.storedAccMod = 0;
		this.storedDPAtk = 0;
		this.storedDPDef = 0;
		this.storedDMAtk = 0;
		this.storedDMDef = 0;
		this.storedDAcc = 0;
		this.storedDEva = 0;
		this.duration = duration;
		this.atkDuration = atkDuration;
		this.hitToBuff = hitToBuff;
		this.goldCost = goldCost;
		this.buffEnd = 0;
		this.atkBuffEnd = 0;
	}
	
	public Skill(String name, int manaCost, int acc, float pAtk, float pDef, float mAtk, float mDef, float heal, float eva, float accMod, int range, float dPAtk, float dPDef, float dMAtk, float dMDef, float dAcc, float dEva, int duration, int atkDuration, boolean hitToBuff) {
		this.name = name;
		this.job = "";
		this.desc = "";
		this.manaCost = manaCost;
		this.acc = acc;
		this.pAtk = pAtk;
		this.pDef = pDef;
		this.mAtk = mAtk;
		this.mDef = mDef;
		this.heal = heal;
		this.eva = eva;
		this.accMod = accMod;
		this.range = range;
		this.dPAtk = dPAtk;
		this.dPDef = dPDef;
		this.dMAtk = dMAtk;
		this.dMDef = dMDef;
		this.dAcc = dAcc;
		this.dEva = dEva;
		this.storedPAtk = 0;
		this.storedPDef = 0;
		this.storedMAtk = 0;
		this.storedMDef = 0;
		this.storedEva = 0;
		this.storedAccMod = 0;
		this.storedDPAtk = 0;
		this.storedDPDef = 0;
		this.storedDMAtk = 0;
		this.storedDMDef = 0;
		this.storedDAcc = 0;
		this.storedDEva = 0;
		this.duration = duration;
		this.atkDuration = atkDuration;
		this.hitToBuff = hitToBuff;
		this.goldCost = 0;
		this.buffEnd = 0;
		this.atkBuffEnd = 0;
	}

	public String getName() {
		return name;
	}
	public void setName(String set) {
		name = set;
	}

	public String getJob() {
		return job;
	}
	public void setJob(String set) {
		job = set;
	}

	public String getDesc() {
		return desc;
	}
	public void setDesc(String set) {
		desc = set;
	}

	public int getManaCost() {
		return manaCost;
	}
	public void setManaCost(int set) {
		manaCost = set;
	}
	public void adjManaCost(int adj) {
		manaCost += adj;
	}

	public int getAcc() {
		return acc;
	}
	public void setAcc(int set) {
		acc = set;
	}
	public void adjAcc(int adj) {
		acc += adj;
	}

	public float getPAtk() {
		return pAtk;
	}
	public void setPAtk(float set) {
		pAtk = set;
	}
	public void adjPAtk(float adj) {
		pAtk += adj;
	}

	public float getPDef() {
		return pDef;
	}
	public void setPDef(float set) {
		pDef = set;
	}
	public void adjPDef(float adj) {
		pDef += adj;
	}

	public float getMAtk() {
		return mAtk;
	}
	public void setMAtk(float set) {
		mAtk = set;
	}
	public void adjMAtk(float adj) {
		mAtk += adj;
	}

	public float getMDef() {
		return mDef;
	}
	public void setMDef(float set) {
		mDef = set;
	}
	public void adjMDef(float adj) {
		mDef += adj;
	}

	public float getHeal() {
		return heal;
	}
	public void setHeal(float set) {
		heal = set;
	}
	public void adjHeal(float adj) {
		heal += adj;
	}

	public float getEva() {
		return eva;
	}
	public void setEva(float set) {
		eva = set;
	}
	public void adjEva(float adj) {
		eva += adj;
	}

	public float getAccMod() {
		return accMod;
	}
	public void setAccMod(float set) {
		accMod = set;
	}
	public void adjAccMod(float adj) {
		accMod += adj;
	}

	public int getRange() {
		return range;
	}
	public void setRange(int set) {
		range = set;
	}
	public void adjRange(int adj) {
		range += adj;
	}

	public float getDPAtk() {
		return dPAtk;
	}
	public void setDPAtk(float set) {
		dPAtk = set;
	}
	public void adjDPAtk(float adj) {
		dPAtk += adj;
	}

	public float getDPDef() {
		return dPDef;
	}
	public void setDPDef(float set) {
		dPDef = set;
	}
	public void adjDPDef(float adj) {
		dPDef += adj;
	}

	public float getDMAtk() {
		return dMAtk;
	}
	public void setDMAtk(float set) {
		dMAtk = set;
	}
	public void adjDMAtk(float adj) {
		dMAtk += adj;
	}

	public float getDMDef() {
		return dMDef;
	}
	public void setDMDef(float set) {
		dMDef = set;
	}
	public void adjDMDef(float adj) {
		dMDef += adj;
	}

	public float getDAcc() {
		return dAcc;
	}
	public void setDAcc(float set) {
		dAcc = set;
	}
	public void adjDAcc(float adj) {
		dAcc += adj;
	}

	public float getDEva() {
		return dEva;
	}
	public void setDEva(float set) {
		dEva = set;
	}
	public void adjDEva(float adj) {
		dEva += adj;
	}

	public int getDuration() {
		return duration;
	}
	public void setDuration(int set) {
		duration = set;
	}
	public void adjDuration(int adj) {
		duration += adj;
	}

	public int getAtkDuration() {
		return atkDuration;
	}
	public void setAtkDuration(int set) {
		atkDuration = set;
	}
	public void adjAtkDuration(int adj) {
		atkDuration += adj;
	}

	public boolean getHitToBuff() {
		return hitToBuff;
	}
	public void setHitToBuff(boolean set) {
		hitToBuff = set;
	}

	public int getGoldCost() {
		return goldCost;
	}
	public void setGoldCost(int set) {
		goldCost = set;
	}
	public void adjGoldCost(int adj) {
		goldCost += adj;
	}

	public int getBuffEnd() {
		return buffEnd;
	}
	public void setBuffEnd(int set) {
		buffEnd = set;
	}
	public void adjBuffEnd(int adj) {
		buffEnd += adj;
	}

	public int getAtkBuffEnd() {
		return atkBuffEnd;
	}
	public void setAtkBuffEnd(int set) {
		atkBuffEnd = set;
	}
	public void adjAtkBuffEnd(int adj) {
		atkBuffEnd += adj;
	}
	
	// Instead of giving each stored value its own getter/setter, stored values can be accessed by requesting storeValue or getStoredValue and passing the desired value as a String
	public void storeValue(String type, int value) {
		switch(type) {
		case "pAtk":
			storedPAtk = value;
			break;
		case "pDef":
			storedPDef = value;
			break;
		case "mAtk":
			storedMAtk = value;
			break;
		case "mDef":
			storedMDef = value;
			break;
		case "eva":
			storedEva = value;
			break;
		case "accMod":
			storedAccMod = value;
			break;
		case "dPAtk":
			storedDPAtk = value;
			break;
		case "dPDef":
			storedDPDef = value;
			break;
		case "dMAtk":
			storedDMAtk = value;
			break;
		case "dMDef":
			storedDMDef = value;
			break;
		case "dAcc":
			storedDAcc = value;
			break;
		case "dEva":
			storedDEva = value;
			break;
		default:
			System.out.println("Bad type passed to Skill.setStoredValue.");
			System.out.println("Received " + type + " " + value);
		}
	}
	
	public int getStoredValue(String type) {
		switch(type) {
		case "pAtk":
			return storedPAtk;
		case "pDef":
			return storedPDef;
		case "mAtk":
			return storedMAtk;
		case "mDef":
			return storedMDef;
		case "eva":
			return storedEva;
		case "accMod":
			return storedAccMod;
		case "dPAtk":
			return storedDPAtk;
		case "dPDef":
			return storedDPDef;
		case "dMAtk":
			return storedDMAtk;
		case "dMDef":
			return storedDMDef;
		case "dAcc":
			return storedDAcc;
		case "dEva":
			return storedDEva;
		default:
			System.out.println("Bad type passed to Skill.getStoredValue.");
			System.out.println("Received " + type);
			return -1;
		}
	}
	
	// Returns the total amount that the skill buffs the player
	public float getBuffValue() {
		float buffValue = pDef + mDef + accMod + eva;
		if(atkDuration > 1) {
			// Only includes pAtk and mAtk in buff value if the attack buff lasts longer than one attack
			buffValue += pAtk + mAtk;
		}
		return buffValue;
	}
	
	// Returns the total amount that the skill debuffs the player
	public float getDebuffValue() {
		return dPAtk + dPDef + dMAtk + dMDef + dAcc + dEva;
	}
	
	public void turnReset() {
		buffEnd = 0;
		atkBuffEnd = 0;
	}
	
	public void printSelf() {
		System.out.println(name + "\t\t(" + manaCost + " mana)");
	}
	
	public void printSelfFull() {
		System.out.println("Name: " + name);
		System.out.println("Mana Cost: " + manaCost);
		System.out.println("Acc: " + acc);
		System.out.println("PAtk: " + pAtk);
		System.out.println("PDef: " + pDef);
		System.out.println("MAtk: " + mAtk);
		System.out.println("MDef: " + mDef);
		System.out.println("Heal: " + heal);
		System.out.println("Eva: " + eva);
		System.out.println("AccMod: " + accMod);
		System.out.println("Range: " + range);
		System.out.println("DPAtk: " + dPAtk);
		System.out.println("DPDef: " + dPDef);
		System.out.println("DMAtk: " + dMAtk);
		System.out.println("DMDef: " + dMDef);
		System.out.println("DAcc: " + dAcc);
		System.out.println("DEva: " + dEva);
		System.out.println("Duration: " + duration);
		System.out.println("Atk Duration: " + atkDuration);
		System.out.println("Hit To Buff: " + hitToBuff);
	}

}
