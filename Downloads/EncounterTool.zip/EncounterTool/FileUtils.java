/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

/*
 * Class for introducing "save" and "load" functionality via Base64 encrypted txt files
 * Currently only loadToolFileText is used, but variables exist to add save game or load data functionality when moved to a full project
 * Unlike save and data, tool data is not encrypted. This allows the user to manually adjust stats within the file as needed, before running the program.
 */

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;

public class FileUtils {
	
	private String current_working_directory;
	private String tool_directory_path;
	private String save_directory_path;
	private String data_directory_path;
	private String tool_file_path;
	private String save_file_path;
	private String[] toolFileTextArr;
	private String[] saveFileTextArr;
	private String[] dataFileTextArr;
	
	// Sets directory paths for tool, save, and data
	// Currently only tool_directory_path is used
	public FileUtils() {
		current_working_directory = System.getProperty("user.dir") + "\\bin";
		tool_directory_path = current_working_directory + "\\encountertool";
		save_directory_path = current_working_directory + "\\save";
		data_directory_path = current_working_directory + "\\data";
	}
	
	// This method must be called by main before other methods can be used
	// Sets the variable toolFileTextArr to be used in later methods
	public void loadToolFileText(String file_name) throws IOException {
		tool_file_path = tool_directory_path + "\\" + file_name + ".txt";
		FileReader fr = new FileReader(tool_file_path);
//		String str_enc = "";
		String str_dec = "";
		
		int c;
		while((c = fr.read()) != -1) {
//			str_enc += (char) c;
			str_dec += (char) c;
		}
		
		fr.close();
		
//		byte[] byte_dec = Base64.getDecoder().decode(str_enc);
//		String str_dec = new String(byte_dec);
		
		String[] split_str = str_dec.split("\\||\n");
		
		toolFileTextArr = split_str;
	}
	
	// NOT USED
	public void loadFileText(String file_name) throws IOException {
		save_file_path = save_directory_path + "\\" + file_name + ".txt";
		FileReader fr = new FileReader(save_file_path);
		String str_enc = "";
		
		int c;
		while((c = fr.read()) != -1) {
			str_enc += (char) c;
		}
		
		fr.close();
		
		byte[] byte_dec = Base64.getDecoder().decode(str_enc);
		String str_dec = new String(byte_dec);
		
		String[] split_str = str_dec.split("\\|");
		
		saveFileTextArr = split_str;
	}
	
	// NOT USED
	public void saveData(Player p, Enemy e) {
		save_file_path = save_directory_path + "\\save.txt";
		String str_dec = "Game|Exists";
		
		str_dec += "|PLAYER-START";
		str_dec += "|name|" + p.getName();
		str_dec += "|job|" + p.getJob();
		str_dec += "|maxHP|" + p.getMaxHP();
		str_dec += "|maxMana|" + p.getMaxMana();
		str_dec += "|basePAtk|" + p.getBasePAtk();
		str_dec += "|basePDef|" + p.getBasePDef();
		str_dec += "|baseMAtk|" + p.getBaseMAtk();
		str_dec += "|baseMDef|" + p.getBaseMDef();
		str_dec += "|baseAcc|" + p.getBaseAcc();
		str_dec += "|baseEva|" + p.getBaseEva();
		str_dec += "|range|" + p.getRange();
		str_dec += "|strategy|" + p.getStrategy();
		str_dec += "|gold|" + p.getGold();
		str_dec += "|pots|" + p.getPots();
		str_dec += "|weapon|" + p.getWeapon();
		str_dec += "|armor|" + p.getArmor();
		str_dec += "|PLAYER-END";
		str_dec += "|SKILLS-START";
		for(Skill s:p.getSkills()) {
			str_dec += "|START";
			str_dec += "|name|" + s.getName();
			str_dec += "|job|" + s.getJob();
			str_dec += "|desc|" + s.getDesc();
			str_dec += "|manaCost|" + s.getManaCost();
			str_dec += "|acc|" + s.getAcc();
			str_dec += "|pAtk|" + s.getPAtk();
			str_dec += "|pDef|" + s.getPDef();
			str_dec += "|mAtk|" + s.getMAtk();
			str_dec += "|mDef|" + s.getMDef();
			str_dec += "|heal|" + s.getHeal();
			str_dec += "|eva|" + s.getEva();
			str_dec += "|accMod|" + s.getAccMod();
			str_dec += "|range|" + s.getRange();
			str_dec += "|dPAtk|" + s.getDPAtk();
			str_dec += "|dPDef|" + s.getDPDef();
			str_dec += "|dMAtk|" + s.getDMAtk();
			str_dec += "|dMDef|" + s.getDMDef();
			str_dec += "|dAcc|" + s.getDAcc();
			str_dec += "|dEva|" + s.getDEva();
			str_dec += "|duration|" + s.getDuration();
			str_dec += "|atkDuration|" + s.getAtkDuration();
			str_dec += "|hitToBuff|" + s.getHitToBuff();
			str_dec += "|goldCost|" + s.getGoldCost();
			str_dec += "|END";
		}
		str_dec += "|SKILLS-END";
		str_dec += "|ENEMY-START";
		str_dec += "|name|" + e.getName();
		str_dec += "|maxHP|" + e.getMaxHP();
		str_dec += "|pAtk|" + e.getPAtk();
		str_dec += "|pDef|" + e.getPDef();
		str_dec += "|mAtk|" + e.getMAtk();
		str_dec += "|mDef|" + e.getMDef();
		str_dec += "|acc|" + e.getAcc();
		str_dec += "|eva|" + e.getEva();
		str_dec += "|range|" + e.getRange();
		str_dec += "|goldVal|" + e.getGoldVal();
		str_dec += "|ENEMY-END";
		
		String str_enc = encodeString(str_dec);
		
		try {
			File directory = new File(save_directory_path);
			if(!directory.isDirectory()) {
				directory.mkdirs();
			}
			FileWriter fw = new FileWriter(save_file_path);
			fw.write(str_enc);
			fw.flush();
			fw.close();
		} catch(IOException ex) {
			System.out.println("Error writing to file");
		}
		
		try {
			FileWriter fw = new FileWriter(save_directory_path + "\\raw.txt");
			fw.write(str_dec);
			fw.flush();
			fw.close();
		} catch(IOException ex) {
			ex.printStackTrace();
		}
	}
	
	// saveToolData saves with a slightly different delimiter, making it easier to modify the raw txt file as needed
	public void saveToolData(Player p, Enemy e) {
		tool_file_path = tool_directory_path + "\\data.txt";
		String str_dec = "PLAYER";
		
		str_dec += "\nname|" + p.getName();
		str_dec += "\njob|" + p.getJob();
		str_dec += "\nmaxHP|" + p.getMaxHP();
		str_dec += "\nmaxMana|" + p.getMaxMana();
		str_dec += "\nbasePAtk|" + p.getBasePAtk();
		str_dec += "\nbasePDef|" + p.getBasePDef();
		str_dec += "\nbaseMAtk|" + p.getBaseMAtk();
		str_dec += "\nbaseMDef|" + p.getBaseMDef();
		str_dec += "\nbaseAcc|" + p.getBaseAcc();
		str_dec += "\nbaseEva|" + p.getBaseEva();
		str_dec += "\nrange|" + p.getRange();
		str_dec += "\nstrategy|" + p.getStrategy();
		str_dec += "\ngold|" + p.getGold();
		str_dec += "\npots|" + p.getPots();
		str_dec += "\nweapon|" + p.getWeapon();
		str_dec += "\narmor|" + p.getArmor();
		str_dec += "\nSKILLS";
		for(Skill s:p.getSkills()) {
			str_dec += "\nSTART";
			str_dec += "\nname|" + s.getName();
			str_dec += "\njob|" + s.getJob();
			str_dec += "\ndesc|" + s.getDesc();
			str_dec += "\nmanaCost|" + s.getManaCost();
			str_dec += "\nacc|" + s.getAcc();
			str_dec += "\npAtk|" + s.getPAtk();
			str_dec += "\npDef|" + s.getPDef();
			str_dec += "\nmAtk|" + s.getMAtk();
			str_dec += "\nmDef|" + s.getMDef();
			str_dec += "\nheal|" + s.getHeal();
			str_dec += "\neva|" + s.getEva();
			str_dec += "\naccMod|" + s.getAccMod();
			str_dec += "\nrange|" + s.getRange();
			str_dec += "\ndPAtk|" + s.getDPAtk();
			str_dec += "\ndPDef|" + s.getDPDef();
			str_dec += "\ndMAtk|" + s.getDMAtk();
			str_dec += "\ndMDef|" + s.getDMDef();
			str_dec += "\ndAcc|" + s.getDAcc();
			str_dec += "\ndEva|" + s.getDEva();
			str_dec += "\nduration|" + s.getDuration();
			str_dec += "\natkDuration|" + s.getAtkDuration();
			str_dec += "\nhitToBuff|" + s.getHitToBuff();
			str_dec += "\ngoldCost|" + s.getGoldCost();
			str_dec += "\nEND";
		}
		str_dec += "\nENEMY";
		str_dec += "\nname|" + e.getName();
		str_dec += "\nmaxHP|" + e.getMaxHP();
		str_dec += "\npAtk|" + e.getPAtk();
		str_dec += "\npDef|" + e.getPDef();
		str_dec += "\nmAtk|" + e.getMAtk();
		str_dec += "\nmDef|" + e.getMDef();
		str_dec += "\nacc|" + e.getAcc();
		str_dec += "\neva|" + e.getEva();
		str_dec += "\nrange|" + e.getRange();
		str_dec += "\ngoldVal|" + e.getGoldVal();
		
//		String str_enc = encodeString(str_dec);
		
		try {
			File directory = new File(tool_directory_path);
			if(!directory.isDirectory()) {
				directory.mkdirs();
			}
			FileWriter fw = new FileWriter(tool_file_path);
//			fw.write(str_enc);
			fw.write(str_dec);
			fw.flush();
			fw.close();
		} catch(IOException ex) {
			System.out.println("Error writing to file");
		}
		
//		try {
//			FileWriter fw = new FileWriter(tool_directory_path + "\\raw.txt");
//			fw.write(str_dec);
//			fw.flush();
//			fw.close();
//		} catch(IOException ex) {
//			ex.printStackTrace();
//		}
	}
	
	// Returns a Player object generated from saved data
	public Player loadPlayer() throws IOException, LoadException {
		// Generates a split string out of a substring of toolFileTextArr
		// Saves memory and increases speed, as the smaller split string can be passed to getString and getInt methods, which will not have to iterate over the entire toolFileTextArr array
		String[] split_str = getSubstringTool("player");
		
		String name = getString("name", split_str);
		String job = getString("job", split_str);
		int maxHP = getInt("maxHP", split_str);
		int maxMana = getInt("maxMana", split_str);
		int basePAtk = getInt("basePAtk", split_str);
		int basePDef = getInt("basePDef", split_str);
		int baseMAtk = getInt("baseMAtk", split_str);
		int baseMDef = getInt("baseMDef", split_str);
		int baseAcc = getInt("baseAcc", split_str);
		int baseEva = getInt("baseEva", split_str);
		int range = getInt("range", split_str);
		String strategy = getString("strategy", split_str);
		int gold = getInt("gold", split_str);
		int pots = getInt("pots", split_str);
		String weapon = getString("weapon", split_str);
		String armor = getString("armor", split_str);
		
		return new Player(name, job, maxHP, maxMana, basePAtk, basePDef, baseMAtk, baseMDef, baseAcc, baseEva, range, strategy, gold, pots, weapon, armor);
	}
	
	// Returns an ArrayList of Skill objects which can be added to a Player object
	public ArrayList<Skill> loadSkills() throws IOException, LoadException {
		String name;
		String job;
		String desc;
		int manaCost;
		int acc;
		float pAtk;
		float pDef;
		float mAtk;
		float mDef;
		float heal;
		float eva;
		float accMod;
		int range;
		float dPAtk;
		float dPDef;
		float dMAtk;
		float dMDef;
		float dAcc;
		float dEva;
		int duration;
		int atkDuration;
		boolean hitToBuff;
		int goldCost;
		
		ArrayList<Skill> skills = new ArrayList<Skill>();
		
		// Generates a split string out of a substring of toolFileTextArr
		// Saves memory and increases speed, as the smaller split string can be passed to getString and getInt methods, which will not have to iterate over the entire toolFileTextArr array
		String[] split_str = getSubstringTool("skills");
		// Creates a new String array to hold only the substring relating to an individual Skill
		String[] skill_str;
		
		// Initializes the variables from and to which will be used to create a skill_str substring
		int from = 1;
		int to = 0;
		
		// Iterates until from is greater than split_str.length.
		// In each iteration, the variable <to> is being set to the index of the last variable which relates to a given skill. A substring is then created from variable <from> to variable <to>.
		// After the iteration, <from> is set to <to + 1> so that the substring starts at the index following the last variable of the previous skill
		for(from = 1; from < split_str.length; from = to + 1) {
			to = getSkillEndIndex(from, split_str);
			skill_str = Arrays.copyOfRange(split_str, from, to);
			
			name = getString("name", skill_str);
			job = getString("job", skill_str);
			desc = getString("desc", skill_str);
			manaCost = getInt("manaCost", skill_str);
			acc = getInt("acc", skill_str);
			pAtk = getFloat("pAtk", skill_str);
			pDef = getFloat("pDef", skill_str);
			mAtk = getFloat("mAtk", skill_str);
			mDef = getFloat("mDef", skill_str);
			heal = getFloat("heal", skill_str);
			eva = getFloat("eva", skill_str);
			accMod = getFloat("accMod", skill_str);
			range = getInt("range", skill_str);
			dPAtk = getFloat("dPAtk", skill_str);
			dPDef = getFloat("dPDef", skill_str);
			dMAtk = getFloat("dMAtk", skill_str);
			dMDef = getFloat("dMDef", skill_str);
			dAcc = getFloat("dAcc", skill_str);
			dEva = getFloat("dEva", skill_str);
			duration = getInt("duration", skill_str);
			atkDuration = getInt("atkDuration", skill_str);
			hitToBuff = getBool("hitToBuff", skill_str);
			goldCost = getInt("goldCost", skill_str);
			
			skills.add(new Skill(name, job, desc, manaCost, acc, pAtk, pDef, mAtk, mDef, heal, eva, accMod, range, dPAtk, dPDef, dMAtk, dMDef, dAcc, dEva, duration, atkDuration, hitToBuff, goldCost));
		}
		
		return skills;
	}
	
	public Enemy loadEnemy() throws IOException, LoadException {
		// Generates a split string out of a substring of toolFileTextArr
		// Saves memory and increases speed, as the smaller split string can be passed to getString and getInt methods, which will not have to iterate over the entire toolFileTextArr array
		String[] split_str = getSubstringTool("enemy");
		String name = getString("name", split_str);
		int maxHP = getInt("maxHP", split_str);
		int pAtk = getInt("pAtk", split_str);
		int pDef = getInt("pDef", split_str);
		int mAtk = getInt("mAtk", split_str);
		int mDef = getInt("mDef", split_str);
		int acc = getInt("acc", split_str);
		int eva = getInt("eva", split_str);
		int range = getInt("range", split_str);
		int goldVal = getInt("goldVal", split_str);
		
		return new Enemy(name, maxHP, pAtk, pDef, mAtk, mDef, acc, eva, range, goldVal);
	}
	
	// Returns a substring for each requested type
	// Improves speed by allowing each method to iterate over a smaller substring
	private String[] getSubstringTool(String type) {
		// <from> will be set to the index that marks the start of the desired section
		// <to> will be set to the index that marks the start of the next section
		int from = -1;
		int to = -1;
		for(int i = 0; i < toolFileTextArr.length; i++) {
			String s = toolFileTextArr[i];
			if(type.equals("player")) {
				if(s.equals("PLAYER")) {
					from = i;
				} else if(s.equals("SKILLS")) {
					to = i;
				}
			} else if(type.equals("skills")) {
				if(s.equals("SKILLS")) {
					from = i;
				} else if(s.equals("ENEMY")) {
					to = i;
				}
			} else if(type.equals("enemy")) {
				to = toolFileTextArr.length;
				if(s.equals("ENEMY")) {
					from = i;
				}
			}
		}
		
		String[] substring = Arrays.copyOfRange(toolFileTextArr, from, to);
		return substring;
	}
	
	// Provides a substring relating only to one skill
	// Receives a startIndex, which is related to the new <from> value in loadSkills
	private int getSkillEndIndex(int startIndex, String[] split_str) {
		// Each skill starts with the marker START
		// If the startIndex does not match the START marker, then a bad index was received
		if(!split_str[startIndex].equals("START")) {
			System.out.println("Bad startIndex passed to getSkillIndex\nReceived " + split_str[startIndex]);
			return -1;
		}
		for(int i = startIndex; i < split_str.length; i++) {
			if(split_str[i].equals("END")) {
				// Each skill ends with the marker END
				// Returns the index of END
				return i;
			}
		}
		System.out.println("Bad split_str passed to getSkillIndex\nCould not find END");
		return -1;
	}
	
	// Abstracts the Base64 encoding of a String
	private String encodeString(String str_dec) {
		return Base64.getEncoder().encodeToString(str_dec.getBytes());
	}
	
	// These methods return a String, int, float, double, or boolean from a String array, by searching for the term passed as an argument, and returning the value at the next index
	
	private String getString(String term, String[] split_str) throws LoadException {
		for(int i = 0; i < split_str.length; i++) {
			if(split_str[i].equals(term)) {
				return split_str[i + 1];
			}
		}
		throw new LoadException("Load Exception getString\nCould not find " + term);
	}
	
	private int getInt(String term, String[] split_str) throws NumberFormatException, LoadException {
		for(int i = 0; i < split_str.length; i++) {
			if(split_str[i].equals(term)) {
				int returnInt = Integer.parseInt(split_str[i + 1]);
				return returnInt;
			}
		}
		throw new LoadException("Load Exception getInt\nCould not find " + term);
	}
	
	private float getFloat(String term, String[] split_str) throws NumberFormatException, LoadException {
		for(int i = 0; i < split_str.length; i++) {
			if(split_str[i].equals(term)) {
				float returnFloat = Float.parseFloat(split_str[i + 1]);
				return returnFloat;
			}
		}
		throw new LoadException("Load Exception getFloat\nCould not find " + term);
	}
	
	private boolean getBool(String term, String[] split_str) throws LoadException {
		for(int i = 0; i < split_str.length; i++) {
			if(split_str[i].equals(term)) {
				if(split_str[i + 1].equals("true")) {
					return true;
				} else {
					return false;
				}
			}
		}
		throw new LoadException("Load Exception getBool\nCould not find " + term);
	}

}
