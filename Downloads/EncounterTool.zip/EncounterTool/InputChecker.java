/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

/*
 * Cleans up Listener class by handling some of the boolean logic
 */

public class InputChecker {

	// Checks that input is greater than 0
	protected boolean isString(String input) {
		if(input.length() > 0) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * Takes two Strings, one for input and one for desired return type
	 * Switch statement checks against inputType and tries to parse input into desired type
	 * If logic clears the try block, return true
	 * If NumberFormatException is caught, then input cannot be parsed into desired type
	 * If logic lands in catch block, print unique message and return false
	 */
	protected boolean inputMatches(String input, String inputType) {
		try { // try{}catch(NumberFormatException)
			switch(inputType) {
			case "int":
				Integer.parseInt(input);
				break;
			case "float":
				Float.parseFloat(input);
				break;
			case "double":
				Double.parseDouble(input);
				break;
			}
			return true;
		} catch(NumberFormatException ex) {
			switch(inputType) {
			case "int":
				System.out.println("Unexpected Input. Expected Integer.");
				break;
			case "float":
				System.out.println("Unexpected Input. Expected Float.");
				break;
			case "double":
				System.out.println("Unexpected Input. Expected Double.");
				break;
			}
			return false;
		}
	}

	// Checks that input int is greater than or equal to provided minimum
	protected boolean isInRange(int input, int min) {
		if(min <= input) {
			return true;
		} else {
			rangeError(Integer.toString(min)); // Prints a unique error message defined later
			return false;
		}
	}

	// Checks that input int is within min-max range, inclusive
	protected boolean isInRange(int input, int min, int max) {
		if(min <= input && input <= max) {
			return true;
		} else {
			rangeError(Integer.toString(min), Integer.toString(max)); // Prints a unique error message defined later
			return false;
		}
	}

	// Overloaded isInRange() methods with different signatures for accepting float and double values
	
	protected boolean isInRange(float input, float min) {
		if(min <= input) {
			return true;
		} else {
			rangeError(Float.toString(min));
			return false;
		}
	}

	protected boolean isInRange(float input, float min, float max) {
		if(min <= input && input <= max) {
			return true;
		} else {
			rangeError(Float.toString(min), Float.toString(max));
			return false;
		}
	}

	protected boolean isInRange(double input, double min) {
		if(min <= input) {
			return true;
		} else {
			rangeError(Double.toString(min));
			return false;
		}
	}

	protected boolean isInRange(double input, double min, double max) {
		if(min <= input && input <= max) {
			return true;
		} else {
			rangeError(Double.toString(min), Double.toString(max));
			return false;
		}
	}
	
	// rangeError methods produce unique error messages if passed minimum only or minimum and maximum values as Strings

	private void rangeError(String min) {
		System.out.println("Invalid Input. Input must be at least " + min + ".");
	}

	private void rangeError(String min, String max) {
		System.out.println("Invalid Input. Input must be between " + min + " and " + max + ".");
	}

}
