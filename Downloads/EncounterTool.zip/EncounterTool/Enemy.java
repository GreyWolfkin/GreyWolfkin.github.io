/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

/*
 * Extends Combatant superclass
 * Adds goldVal, stat to determine how much gold the player adds when defeating enemy
 */

public class Enemy extends Combatant {
	
	private int goldVal;
	
	public Enemy(String name, int maxHP, int pAtk, int pDef, int mAtk, int mDef, int acc, int eva, int range, int goldVal) {
		super(name, maxHP, pAtk, pDef, mAtk, mDef, acc, eva, range);
		this.goldVal = goldVal;
	}
	
	public Enemy(String name, int maxHP, int pAtk, int pDef, int mAtk, int mDef, int acc, int eva, int range) {
		super(name, maxHP, pAtk, pDef, mAtk, mDef, acc, eva, range);
		this.goldVal = 0;
	}
	
	public int getGoldVal() {
		return goldVal;
	}
	public void setGoldVal(int set) {
		goldVal = set;
		if(goldVal < 0) {
			goldVal = 0;
		}
	}
	public void adjGoldVal(int adj) {
		goldVal += adj;
		if(goldVal < 0) {
			goldVal = 0;
		}
	}

}
