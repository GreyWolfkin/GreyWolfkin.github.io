/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

/*
 * Player extends Combatant superclass
 * Adds several variables, including ArrayList of Skill objects
 */

import java.util.ArrayList;
import java.util.Arrays;

public class Player extends Combatant {

	private String job;
	private int maxMana;
	private int mana;
	private ArrayList<Skill> skills;
	private String strategy;
	private int gold;
	private int pots;
	private String weapon;
	private String armor;

	public Player(String name, String job, int maxHP, int maxMana, int pAtk, int pDef, int mAtk, int mDef, int acc, int eva, int range) {
		super(name, maxHP, pAtk, pDef, mAtk, mDef, acc, eva, range);
		this.job = job;
		this.maxMana = maxMana;
		this.mana = maxMana;
		this.skills = new ArrayList<Skill>();
		this.strategy = "Balanced";
		this.gold = 0;
		this.pots = 0;
		this.weapon = "";
		this.armor = "";
	}
	
	public Player(String name, String job, int maxHP, int maxMana, int pAtk, int pDef, int mAtk, int mDef, int acc, int eva, int range, String strategy, int gold, int pots, String weapon, String armor) {
		super(name, maxHP, pAtk, pDef, mAtk, mDef, acc, eva, range);
		this.job = job;
		this.maxMana = maxMana;
		this.mana = maxMana;
		this.skills = new ArrayList<Skill>();
		this.strategy = strategy;
		this.gold = gold;
		this.pots = pots;
		this.weapon = weapon;
		this.armor = armor;
	}
	
	public String getJob() {
		return job;
	}
	public void setJob(String set) {
		job = set;
	}

	public int getMaxMana() {
		return maxMana;
	}
	public void setMaxMana(int set) {
		maxMana = set;
	}
	public void adjMaxMana(int adj) {
		maxMana += adj;
	}

	public int getMana() {
		return mana;
	}
	public void setMana(int set) {
		mana = set;
		if(mana > maxMana) {
			mana = maxMana;
		}
	}
	public void adjMana(int adj) {
		mana += adj;
		if(mana > maxMana) {
			mana = maxMana;
		}
	}
	
	// These methods all work on ArrayList of Skill objects
	// Multiple methods to return Skill based on several types of search criteria, return index based on several types of search criteria, remove or replace Skills
	
	public ArrayList<Skill> getSkills() {
		// Get full ArrayList of Skill objects
		return skills;
	}
	public Skill getSkill(int index) {
		// Get Skill at given index
		return skills.get(index);
	}
	public Skill getSkill(String name) {
		// Get Skill of given name
		for(Skill skill:skills) {
			if(skill.getName().equals(name)) {
				return skill;
			}
		}
		return null;
	}
	public int getIndexOfSkill(Skill skill) {
		// Get index of Skill by Skill object
		for(int i = 0; i < skills.size(); i++) {
			if(skills.get(i) == skill) {
				return i;
			}
		}
		return -1;
	}
	public int getIndexOfSkill(String name) {
		// Get index of Skill by name
		for(int i = 0; i < skills.size(); i++) {
			if(skills.get(i).getName().equals(name)) {
				return i;
			}
		}
		return -1;
	}
	public void setSkills(ArrayList<Skill> set) {
		// Set full ArrayList of Skill objects from ArrayList
		skills = set;
	}
	public void setSkills(Skill[] set) {
		// Set full ArrayList of Skill objects from Array
		skills.clear();
		skills.addAll(Arrays.asList(set));
	}
	public void addSkill(Skill skill) {
		// Add Skill object to ArrayList
		skills.add(skill);
	}
	public void removeSkill(Skill skill) {
		// Remove Skill object from ArrayList
		skills.remove(skill);
	}
	public void removeSkill(String name) {
		// Remove Skill object with matching name
		int index = getIndexOfSkill(name);
		skills.remove(index);
	}
	public void removeSkill(int index) {
		// Remove Skill object at given index
		skills.remove(index);
	}
	public void replaceSkill(Skill oldSkill, Skill newSkill) {
		// Replaces oldSkill with newSkill at same index
		int index = getIndexOfSkill(oldSkill);
		skills.remove(index);
		skills.add(index, newSkill);
	}
	public void replaceSkill(String name, Skill skill) {
		// Replaces oldSkill with newSkill at same index
		// Finds oldSkill by name
		int index = getIndexOfSkill(name);
		skills.remove(index);
		skills.add(index, skill);
	}
	public void replaceSkill(int index, Skill skill) {
		// Replaces oldSkill with newSkill
		// Finds oldSkill by index
		skills.remove(index);
		skills.add(index, skill);
	}
	public void clearSkills() {
		// Empties ArrayList
		skills.clear();
	}

	public String getStrategy() {
		return strategy;
	}
	public void setStrategy(String set) {
		strategy = set;
	}

	public int getGold() {
		return gold;
	}
	public void setGold(int set) {
		gold = set;
	}
	public void adjGold(int adj) {
		gold += adj;
	}

	public int getPots() {
		return pots;
	}
	public void setPots(int set) {
		pots = set;
	}
	public void adjPots(int adj) {
		pots += adj;
	}

	public String getWeapon() {
		return weapon;
	}
	public void setWeapon(String set) {
		weapon = set;
	}

	public String getArmor() {
		return armor;
	}
	public void setArmor(String set) {
		armor = set;
	}
	
	public boolean canAffordSkill(Skill skill) {
		// Checks if player can afford to use skill
		if(mana - skill.getManaCost() >= 0) {
			return true;
		} else {
			return false;
		}
	}
	
	// This method overrides the fullHeal method of Combatant superclass
	// It uses super.fullHeal to invoke the superclass method, then also adds a reset of mana
	@Override
	public void fullHeal() {
		super.fullHeal();
		mana = maxMana;
	}
	
	@Override
	public void printBaseStats() {
		System.out.print(name);
		if(name.length() >= 8) {
			System.out.print("\t\t");
		} else {
			System.out.print("\t\t\t");
		}
		System.out.println(job);
		System.out.println("HP: " + hp + "\t\t\tMana: " + mana);
	}
	
	public void printStats() {
		printBaseStats();
		System.out.print("Gold: " + gold + "\t");
		if(gold < 10) {
			System.out.print("\t");
		}
		System.out.println("Potions: " + pots);
	}
	
	@Override
	public void printAllStats() {
		printBaseStats();
		super.printAdtlStats();
	}

}
