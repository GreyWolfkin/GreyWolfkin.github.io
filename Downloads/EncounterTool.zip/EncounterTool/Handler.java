/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

/*
 * Abstracts functionality to clean up main class
 * Builds Player and Enemy objects, modifies Player skills, handles combat simulation and playtesting
 * Generates Enemy encounters based on provided parameters
 */

import java.util.Random;

public class Handler {

	private Listener l;
	private CombatUtils combatUtils; // Runs combat encounters
	private Random rand;

	public Handler(Listener l) {
		this.l = l;
		this.combatUtils = new CombatUtils(l);
		this.rand = new Random();
	}

	// Returns a new Player object
	public Player buildPlayer() {
		String name;
		String job;
		int maxHP;
		int mana;
		int pAtk;
		int pDef;
		int mAtk;
		int mDef;
		int acc;
		int eva;
		int range;

		name = l.getString("Player Name: ", 1);
		job = l.getString("Player Job: ", 1);
		maxHP = l.getInt("HP: ", 1);
		mana = l.getInt("Mana: ", 0);
		pAtk = l.getInt("Physical Attack: ", 0);
		pDef = l.getInt("Physical Defense: ", 0);
		mAtk = l.getInt("Magic Attack: ", 0);
		mDef = l.getInt("Magic Defense: ", 0);
		while(pAtk + mAtk == 0) {
			// If user tries to create a player with 0 physical and magic attack
			// Asks user to confirm this selection
			int confirmZeroAttack = l.getInt("You have chosen 0 Physical and Magic attack.\nAre you sure you wish to create a character with 0 attack value?\n1 - YES\n2 - NO\n", 1, 2);
			if(confirmZeroAttack == 1) {
				break;
			} else if(confirmZeroAttack == 2) {
				pAtk = l.getInt("Physical Attack: ", 0);
				mAtk = l.getInt("Magic Attack: ", 0);
			}
		}
		acc = l.getInt("Accuracy: ", 1);
		eva = l.getInt("Evasion: ", 0);
		range = l.getInt("Range: ", 0);

		return new Player(name, job, maxHP, mana, pAtk, pDef, mAtk, mDef, acc, eva, range);
	}

	// Functionality to add, remove, or replace skills
	public void changeSkills(Player p) {
		String opts;
		int optNum;
		while(true) {
			if(p.getSkills().size() > 0) {
				// If there are any skills in p.getSkills ArrayList
				opts = "CURRENT SKILLS\nSelect a skill to replace or remove it.\n";
				optNum = 3;
				int i;
				for(i = 0; i < p.getSkills().size(); i++) {
					// Each skill appears with a sequential number
					opts += (i + 1) + " - " + p.getSkills().get(i).getName() + "\n";
					// Increases the maximum number of valid input integers
					optNum++;
				}
				opts += (i + 1) + " - Add Skill\n";
				opts += (i + 2) + " - Clear Skills\n";
				opts += (i + 3) + " - Quit\n";
			} else {
				// If no skills in p.getSkills ArrayList
				opts = "CURRENT SKILLS\n1 - Add Skill\n2 - Quit\n";
				optNum = 2;
			}
			// Prints the <opts> String, then accepts only integers between 1 and the maximum number of valid inputs
			int inputInt = l.getInt(opts, 1, optNum);
			if(p.getSkills().size() > 0) {
				// If there are any skills in p.getSkills ArrayList
				if(inputInt == p.getSkills().size() + 1) {
					// If inputInt is 1 more than number of skills in p.getSkills then user has selected Add Skill
					System.out.println();
					p.addSkill(createSkill());
				} else if(inputInt == p.getSkills().size() + 2) {
					// If inputInt is 2 more than number of skills in p.getSkills, then user has selected Clear Skills
					p.clearSkills();
				} else if(inputInt == p.getSkills().size() + 3) {
					// If inputInt is 3 more than number of skills in p.getSkills, then user has selected Quit
					return;
				} else {
					// If inputInt is within p.getSkills.size, then modify the skill at index <inputInt - 1>
					System.out.println();
					modifySkill(p, inputInt - 1);
				}
			} else {
				// If no skills in p.getSkills ArrayList
				if(inputInt == 1) {
					System.out.println();
					p.addSkill(createSkill());
				} else if(inputInt == 2) {
					return;
				}
			}
		}
	}
	
	// Returns a new Enemy object
	public Enemy buildEnemy() {
		String name;
		int maxHP;
		int pAtk;
		int pDef;
		int mAtk;
		int mDef;
		int acc;
		int eva;
		int range;

		name = l.getString("Enemy Name: ", 1);
		maxHP = l.getInt("HP: ", 1);
		pAtk = l.getInt("Physical Attack: ", 0);
		pDef = l.getInt("Physical Defense: ", 0);
		mAtk = l.getInt("Magic Attack: ", 0);
		mDef = l.getInt("Magic Defense: ", 0);
		while(pAtk + mAtk == 0) {
			int confirmZeroAttack = l.getInt("You have chosen 0 Physical and Magic attack.\nAre you sure you wish to create an enemy with 0 attack value?\n1 - YES\n2 - NO\n", 1, 2);
			if(confirmZeroAttack == 1) {
				break;
			} else if(confirmZeroAttack == 2) {
				pAtk = l.getInt("Physical Attack: ", 0);
				mAtk = l.getInt("Magic Attack: ", 0);
			}
		}
		acc = l.getInt("Accuracy: ", 1);
		eva = l.getInt("Evasion: ", 0);
		range = l.getInt("Range: ", 0);

		return new Enemy(name, maxHP, pAtk, pDef, mAtk, mDef, acc, eva, range);
	}
	
	// Playtest encounter
	public void playCombat(Player p, Enemy e) {
		combatUtils.combat(p, e);
	}
	
	// Run 1000 combats, pull win count, hp loss, mana usage, and turn count from CombatUtils
	public void testCombat(Player p, Enemy e) {
		int i;
		for(i = 1; i < 1001; i++) {
			combatUtils.combatAuto(p, e);
		}
		int wins = combatUtils.getWins();
		float hpLost = combatUtils.getHPLost();
		int manaUsed = combatUtils.getManaUsed();
		int turns = combatUtils.getTurns();
		System.out.println("Player wins: " + wins);
		System.out.println("Average HP Lost: " + hpLost);
		System.out.println("Percentage HP Lost: " + (hpLost / p.getMaxHP()));
		System.out.println("Average Mana Used: " + manaUsed);
		System.out.println("Average num turns: " + turns);
		for(int j = 0; j < p.getSkills().size(); j++) {
			System.out.println(p.getSkills().get(j).getName() + " used on average " + (combatUtils.getSkillUsed(j) / (float) i) + " per combat");
		}
		combatUtils.clearSkillUsedList();
	}
	
	// Run automated encounter with debug prints
	public void debugCombat(Player p, Enemy e) {
		combatUtils.combatDebug(p, e);
	}
	
	// Generate enemy stats from a random seed, and modify until user criteria are met
	// bp stands for Ballpark
	// Get bp criteria from user
	// Generate acceptable upper and lower ranges
	// Acceptable ranges are +/- 20% of desired percentage for hp, and +/- 1 turn for desired turns
	public Enemy buildEncounter(Player p) {
		Enemy e = new Enemy("ERROR", 1, 1, 1, 1, 1, 1, 1, 1); // Create base Enemy object
		// Get percentage of hp lost from user
		float bpHPLost = l.getFloat("(0.0 - 1.0) Average hp loss as percentage: ", 0.0f, 1.0f);
		// Assign upper range of hp loss
		float hpLostUpperRange = (bpHPLost * 1.2f) * p.getMaxHP();
		// If upper range is greater than player max hp, set upper range to player max hp
		if(hpLostUpperRange > p.getMaxHP()) {
			hpLostUpperRange = p.getMaxHP();
		}
		// Assign lower range of hp loss
		float hpLostLowerRange = (bpHPLost * 0.8f) * p.getMaxHP();
		// If lower range is less than 0, set lower range to 0
		if(hpLostLowerRange < 0) {
			hpLostLowerRange = 0;
		}
		// Get turns from user
		int bpTurns = l.getInt("Average number of turns: ", 1);
		int turnsUpperRange = bpTurns + 1; // Assign upper range of turns
		int turnsLowerRange = bpTurns - 1; // Assign lower range of turns
		// If lower range is less than 1, set lower range to 1
		if(turnsLowerRange < 1) {
			turnsLowerRange = 1;
		}
		String enemyName = l.getString("Enemy Name: ");
		String enemyType; // Whether Enemy is primarily a Physical or Magic combatant
		int enemyTypeInt = l.getInt("Enemy Type\n1 - Physical\n2 - Magic\n", 1, 2);
		if(enemyTypeInt == 2) {
			enemyType = "Magic";
		} else {
			enemyType = "Physical";
		}
		// Set seed HP to between 40 and 80 inclusive
		int randHP = (rand.nextInt(41) + 40);
		int randPAtk = -1;
		int randPDef = -1;
		int randMAtk = -1;
		int randMDef = -1;
		if(enemyType.equals("Physical")) {
			// Set PAtk to between 20 and 40 inclusive
			randPAtk = (rand.nextInt(21) + 20);
			// Set PDef to between 10 and 20 inclusive
			randPDef = (rand.nextInt(11) + 10);
			// Set MAtk to 1/3 PAtk
			randMAtk = (int) Math.round(randPAtk / 3f);
			// Set MDef to 1/4 PDef
			randMDef = (int) Math.round(randPDef / 4f);
		} else if(enemyType.equals("Magic")) {
			// Set MAtk to between 20 and 40 inclusive
			randMAtk = (rand.nextInt(21) + 20);
			// Set MDef to between 10 and 20 inclusive
			randMDef = (rand.nextInt(11) + 10);
			// Set PAtk to 1/3 MAtk
			randPAtk = (int) Math.round(randMAtk / 3f);
			// Set PDef to 1/4 MDef
			randPDef = (int) Math.round(randMDef / 4f);
		}
		// Create Enemy object with seed stats and base acc, eva, range
		e = new Enemy(enemyName, randHP, randPAtk, randPDef, randMAtk, randMDef, 95, 5, 2);
		System.out.println("Starting stats\nHP: " + e.getMaxHP() + "\nPAtk: " + e.getBasePAtk() + "\nPDef: " + e.getBasePDef() + "\nMAtk: " + e.getBaseMAtk() + "\nMDef: " + e.getBaseMDef() + "\nAcc: 95\nEva: 5\nRange: 2");
		System.out.println("Beginning calculations");
		
		while(true) {
			// Run 100 simulations of combat with existing stats
			for(int i = 0; i < 100; i++) {
				combatUtils.combatAuto(p, e);
			}
			// Get amount of HP lost and turns from CombatUtils
			int hpLost = combatUtils.getHPLost();
			int turns = combatUtils.getTurns();
			if(hpLostUpperRange >= hpLost && hpLost >= hpLostLowerRange && turnsUpperRange >= turns && turns >= turnsLowerRange) {
				// If hpLost is between hpLostUpperRange and hpLostLowerRange, and turns is between turnsUpperRange and turnsLowerRange
				System.out.println("Calculations complete");
				System.out.println("Average HP Loss: " + hpLost + "\nAverage Turns: " + turns + "\n");
				System.out.println("Ideal Enemy Stats");
				System.out.println("HP: " + e.getMaxHP() + "\nPAtk: " + e.getBasePAtk() + "\nPDef: " + e.getBasePDef() + " \nMAtk: " + e.getBaseMAtk() + "\nMDef: " + e.getBaseMDef());
				// Return Enemy object to main class, with option to save existing stats
				return e;
			} else {
				// Either hpLost or turns are not within acceptable range
				System.out.println("Recalculating");
				if(hpLost > hpLostUpperRange) {
					// If hpLost is greater than UpperRange, reduce PAtk and MAtk by 25%
					e.adjBasePAtk(-1 * (int) Math.round(e.getBasePAtk() * 0.25f));
					e.adjBaseMAtk(-1 * (int) Math.round(e.getBaseMAtk() * 0.25f));
				} else if(hpLost < hpLostLowerRange) {
					// If hpLost is less than LowerRange, increase PAtk and MAtk by 25%
					e.adjBasePAtk((int) Math.round(e.getBasePAtk() * 0.25f));
					e.adjBaseMAtk((int) Math.round(e.getBaseMAtk() * 0.25f));
				}
				if(turns > turnsUpperRange) {
					// If turns is greater than UpperRange, reduce hp by 25%, reduce PDef and MDef by 20%
					e.adjMaxHP(-1 * (int) Math.round(e.getMaxHP() * 0.25f));
					e.adjBasePDef(-1 * (int) Math.round(e.getBasePDef() * 0.2f));
					e.adjBaseMDef(-1 * (int) Math.round(e.getBaseMDef() * 0.2f));
				} else if(turns < turnsLowerRange) {
					// If turns is less than LowerRange, increase hp by 25%, increase PDef and MDef by 20%
					e.adjMaxHP((int) Math.round(e.getMaxHP() * 0.25f));
					e.adjBasePDef((int) Math.round(e.getBasePDef() * 0.2f));
					e.adjBaseMDef((int) Math.round(e.getBaseMDef() * 0.2f));
				}
				// If and stats are less than or equal to 0, set those stats to 1
				if(e.getMaxHP() <= 0) {
					e.setMaxHP(1);
				}
				if(e.getBasePAtk() <= 0) {
					e.setBasePAtk(1);
				}
				if(e.getBasePDef() <= 0) {
					e.setBasePDef(1);
				}
				if(e.getBaseMAtk() <= 0) {
					e.setBaseMAtk(1);
				}
				if(e.getBaseMDef() <= 0) {
					e.setBaseMDef(1);
				}
			}
		}
	}
	
	// Allow user to define Skill
	// See help text method for more information on Skill creation and usage
	private Skill createSkill() {
		String name;
		int manaCost;
		int acc;
		float pAtk;
		float pDef;
		float mAtk;
		float mDef;
		float heal;
		float eva;
		float accMod;
		int range;
		float dPAtk;
		float dPDef;
		float dMAtk;
		float dMDef;
		float dAcc;
		float dEva;
		int duration;
		int atkDuration;
		boolean hitToBuff;
		
		name = l.getString("Name: ");
		manaCost = l.getInt("Mana Cost: ");
		acc = l.getInt("Accuracy: ", -100, 100);
		pAtk = l.getFloat("Physical Attack Modifier: ", -1);
		pDef = l.getFloat("Physical Defense Modifier: ", -1);
		mAtk = l.getFloat("Magic Attack Modifier: ", -1);
		mDef = l.getFloat("Magic Defense Modifier: ", -1);
		heal = l.getFloat("HP Modifier: ", -0.99f, 1);
		eva = l.getFloat("Evasion Modifier: ", -1);
		accMod = l.getFloat("Accuracy Modifier: ", -1);
		range = l.getInt("Range: ", 0);
		dPAtk = l.getFloat("Enemy Physical Attack: ");
		dPDef = l.getFloat("Enemy Physical Defense: ");
		dMAtk = l.getFloat("Enemy Magic Attack: ");
		dMDef = l.getFloat("Enemy Magic Defense: ");
		dAcc = l.getFloat("Enemy Accuracy: ", -1);
		dEva = l.getFloat("Enemy Evasion: ", -1);
		duration = l.getInt("Buff Duration: ", 0);
		atkDuration = l.getInt("Attack Buff Duration: ", 0);
		int hitToBuffInt = l.getInt("Hit to Buff?\n1 - Yes\n2 - No\n", 1, 2);
		if(hitToBuffInt == 1) {
			hitToBuff = true;
		} else {
			hitToBuff = false;
		}
		
		return new Skill(name, manaCost, acc, pAtk, pDef, mAtk, mDef, heal, eva, accMod, range, dPAtk, dPDef, dMAtk, dMDef, dAcc, dEva, duration, atkDuration, hitToBuff);
	}
	
	// Option to remove or replace an existing skill
	// If removing, remove skill at that index from ArrayList
	// If replacing, build a new skill and replace the skill at that index
	private void modifySkill(Player p, int index) {
		String opts = "Skill: " + p.getSkills().get(index).getName() + "\n";
		opts += "1 - Remove Skill\n2 - Replace Skill\n";
		int inputInt = l.getInt(opts, 1, 2);
		if(inputInt == 1) {
			p.removeSkill(index);
		} else if(inputInt == 2) {
			Skill newSkill = createSkill();
			p.replaceSkill(index, newSkill);
		}
	}
	
	public void printHelpText(int helpChoiceInt) {
		System.out.println();
		if(helpChoiceInt == 1) {
			System.out.println("Encounter Tool Functions\n------------------------\nEncounter Play - Playtest your encounter with control over attacks and skills\nEncounter Test - Simulates 1000 runs of your encounter and prints how many wins, average HP lost, average skill use, etc\nEncounter Debug - Simulates 1 run of your encounter using the same logic as the Encounter Test, but with printouts of each step. Useful for debugging the logic if Encounter Test seems to be returning odd results\nEncounter Builder - Generates monster stats for an ideal encounter, based on how much HP you expect the player to lose, and how many turns you expect the encounter to take");
		} else if(helpChoiceInt == 2) {System.out.println("Player and Enemy stats\n----------------------\nP vs M - P stands for Physical, M stands for Magic. These each have an attack and defense stat. Physical defense reduces Physical damage taken, Magic defense reduces Magic damage taken.\nDefense - Reduces damage taken by that percentage. A defense value of 10 would reduce damage taken by 10%, a defense value of 50 would reduce damage taken by 50%, etc\nAcc - Accuracy is a percentage chance to hit. An accuracy stat of 80 would mean a base 80% chance to hit.\nEva - Evasion reduces enemy chance to hit by that percentage. An eva of 10 would make the enemy 10% less likely to hit.\nRange - The spread of possible damage output. A range of 2 means a +/- 20% spread in possible damage output, so an attack that deals 100 damage could deal anywhere from 80 - 120 damage, inclusive");
		} else if(helpChoiceInt == 3) {
			System.out.println("Player Strategies\n-----------------\nDefensive - Will conserve mana unless healing or defending. Is careful when estimating incoming damage and using heal or defense skills accordingly. Very rarely uses attack, buff, or debuff skills.\nBalanced - Uses heal or defense skills when in danger. Uses attack, buff, and debuff skills when appropriate. Conserves some mana.\nAggressive - Only uses heal or defense skills when absolutely necessary. Prefers attack, buff, or debuff skills. Only conserves a small amount of emergency reserve mana.");
		} else if(helpChoiceInt == 4) {
			System.out.println("Designing Skills\n----------------\nYou can design as many skills as you want, and the Encounter Tool will determine the best one to use at any given time.\nNote that most stats are additive, not multiplicative, so a value of 1 will double that stat. A value of 4 will produce a x5 result in that stat. A value of 0.25 will increase that stat by 25%. A value of -0.5 will decrease that stat by 50%, and a value of -1 will decrease that value to zero.\nAcc - The accuracy of this attack, the liklihood of the skill hitting the target. Only affects skills that are \"Hit To Buff\". This stat is additive to the player's accuracy stat\nPAtk - Physical attack modifier\nPDef - Physical defense modifier\nMAtk - Magic attack modifier\nMDef - Magic defense modifier\nHeal - Heals a percentage of player's maximum hp. A value of 0.5 would heal 50% hp. A value of 1 would heal 100% hp. A value of -0.3 would subtract 30% hp.\nEva - Evasion Modifier\nAccMod - Ongoing Accuracy modifier buff\nRange - Damage spread of skill. Standalone, not additive to player's base range\nD values - All D values are debuffs which affect the enemy's Physical Attack, Evasion, etc\nDuration - Duration of non-attack stat buffs in turns. A value of 1 will only affect this turn, and end at the start of the enemy's turn. A value of 2 will end at the start of your next turn, etc\nAtkDuration - Duration of attack stat buffs in turns. Example: A Frost Bolt only deals 50% the usual damage, but reduces enemy's Physical Attack for 3 turns. The Duration of the skill should be 4, but the Attack Duration should only be 1, as only this attack is affected by the -0.5 modifier\nHit To Buff - Determines if an attack has to hit the target to buff the player or debuff the enemy. Example: A Holy Strike deals 150% damage and heals the player for 30% their maximum hp. But they only get the heal if the attack hits. If the attack misses, they get no boost. This skill would be Hit To Buff");
		}
		System.out.println();
	}

}
