/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

/*****
 * EncounterTool v2.1
 * Tool for playtesting, balancing, and generating combat encounters for text-based RPGs.
 * Reads and writes to a Base64 encrypted file for "save" and "load" purposes.
 * Provides control over a wide range of variables, including Physical Attack and Defense, Magic Attack and Defense, accuracy, evasion, and damage spread.
 * Also allows for inclusion of an unlimited number of attack, defense, and support skills.
 * Functionality for Playtesting, Simulating, Debugging, and Generating combat encounters
 *****/

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class EncounterTool {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Listener l = new Listener(scan);
		Handler handle = new Handler(l); // Handles requests, abstracts combat utility
		FileUtils fileUtils = new FileUtils();
		Player p = null;
		Enemy e = null;
		int loadChoiceInt = l.getInt("Load data from a previous session?\n1 - Yes\n2 - No\n", 1, 2);
		if(loadChoiceInt == 1) {
			try { // try{}catch(IOException | LoadException | NullPointerException)
				fileUtils.loadToolFileText("data"); // Loads fileText for Player and Enemy data saved by the EncounterTool
				p = fileUtils.loadPlayer(); // Returns a player using loaded data
				p.setSkills(fileUtils.loadSkills()); // Adds skills to player based on loaded data
				e = fileUtils.loadEnemy(); // Returns an enemy using loaded data
			} catch(IOException | LoadException | NullPointerException ex) {
				// IOException - No file found
				// LoadException - Corruption in save file
				System.out.println("Error loading from file");
			}
		}
		while(true) {
			// Loops until Quit option is chosen
			int toolChoiceInt = l.getInt("1 - Encounter Play\n2 - Encounter Test\n3 - Encounter Debug\n4 - Encounter Builder\n5 - Print Combatants\n6 - Help\n7 - Quit\n", 1, 7);
			if(toolChoiceInt == 5) {
				// Only print stats if p and e are not null
				if(p != null && e != null) {
					System.out.println();
					System.out.println("PLAYER");
					p.printAllStats();
					System.out.println();
					System.out.println("SKILLS");
					for(Skill s:p.getSkills()) {
						s.printSelfFull();
						System.out.println();
					}
					System.out.println("ENEMY");
					e.printAllStats();
				} else {
					// If p or e are null
					System.out.println("No stats loaded");
				}
				continue;
			} else if(toolChoiceInt == 6) {
				int helpChoiceInt = l.getInt("What would you like help with?\n1 - Encounter Tool Functions\n2 - Player and Enemy Stats\n3 - Player Strategies\n4 - Designing Skills\n", 1, 4);
				handle.printHelpText(helpChoiceInt); // Abstracts large blocks of help text
				continue;
			} else if(toolChoiceInt == 7) {
				if(p != null && e != null) { // Option to save if p and e are not null
					int saveChoiceInt = l.getInt("Save Player and Enemy Data?\n1 - Yes\n2 - No\n", 1, 2);
					if(saveChoiceInt == 1) {
						fileUtils.saveToolData(p, e); // Saves player and enemy data 
						System.exit(0);
					} else {
						// If player does not want to save
						System.exit(0);
					}
				} else {
					// If p or e are null
					System.exit(0);
				}
			}
			// Any option chosen other than Help, Print, or Quit requires a player or enemy to be built or modified
			int skillChoiceInt;
			int stratChoiceInt;
			int changePlayerInt;
			int changeSkillInt;
			int changeStratInt;
			if(p == null) {
				// If no player was loaded, p will be null. New player must be built
				p = handle.buildPlayer(); // Returns a new player built by the user
				skillChoiceInt = l.getInt("Add skills?\n1 - Yes\n2 - No\n", 1, 2);
				if(skillChoiceInt == 1) {
					handle.changeSkills(p); // Adds skills
				}
				stratChoiceInt = l.getInt("Set Strategy\n1 - Defensive\n2 - Balanced\n3 - Aggressive\n", 1, 3);
				if(stratChoiceInt == 1) {
					p.setStrategy("Defensive");
				} else if(stratChoiceInt == 2) {
					p.setStrategy("Balanced");
				} else if(stratChoiceInt == 3) {
					p.setStrategy("Aggressive");
				}
			} else {
				// If p is not null, option to modify existing player stats if desired
				changePlayerInt = l.getInt("Change Player Stats?\n1 - Yes\n2 - No\n", 1, 2);
				if(changePlayerInt == 1) {
					// Creates player with new stats but existing skill set
					ArrayList<Skill> skills = p.getSkills();
					p = handle.buildPlayer();
					p.setSkills(skills);
				}
				changeSkillInt = l.getInt("Change Skills?\n1 - Yes\n2 - No\n", 1, 2);
				if(changeSkillInt == 1) {
					handle.changeSkills(p); // Add or modify skills
				}
				changeStratInt = l.getInt("Change Strategy?\n1 - Yes\n2 - No\n", 1, 2);
				if(changeStratInt == 1) {
					stratChoiceInt = l.getInt("Set Strategy\n1 - Defensive\n2 - Balanced\n3 - Aggressive\n", 1, 3);
					if(stratChoiceInt == 1) {
						p.setStrategy("Defensive");
					} else if(stratChoiceInt == 2) {
						p.setStrategy("Balanced");
					} else if(stratChoiceInt == 3) {
						p.setStrategy("Aggressive");
					}
				}
			}
			if(toolChoiceInt == 4) {
				Enemy newEnemy = handle.buildEncounter(p); // Calculates ideal enemy stats
				// Option to save enemy generated by handle.buildEncounter
				int saveEnemyChoice = l.getInt("Save Enemy Stats?\n1 - Yes\n2 - No\n", 1, 2);
				if(saveEnemyChoice == 1) {
					e = newEnemy;
				}
				continue;
			}
			int changeEnemyInt;
			if(e == null) {
				// If no enemy was loaded, e will be null. New enemy must be built
				e = handle.buildEnemy(); // Returns a new enemy built by the user
			} else {
				// If e is not null, option to modify existing enemy stats if desired
				changeEnemyInt = l.getInt("Change Enemy Stats?\n1 - Yes\n2 - No\n", 1, 2);
				if(changeEnemyInt == 1) {
					e = handle.buildEnemy(); // Rebuild enemy stats
				}
			}
			if(toolChoiceInt == 1) {
				handle.playCombat(p, e); // Playtest encounter
			} else if(toolChoiceInt == 2) {
				handle.testCombat(p, e); // Simulate encounter
			} else if(toolChoiceInt == 3) {
				handle.debugCombat(p, e); // Simulate encounter with visible logic
			}
		}
	}
}
