/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

/*
 * Handles all Combat related functionality, including playtesting, auto combat, and auto combat with debugging prints
 */

import java.util.ArrayList;
import java.util.Random;

public class CombatUtils {

	private Random rand = new Random();
	private Listener l;
	private ArrayList<Integer> turnsList; // Stores number of turns any number of encounters takes
	private ArrayList<Integer> winsList; // Stores wins
	private ArrayList<Integer> hpLostList; // Stores how much hp lost for any number of encounters
	private ArrayList<Integer> manaUsedList; // Stores how much mana used for any number of encounters
	// Creates an ArrayList<Integer> for each skill, then appends 1 to that skill's ArrayList every time that skill is used
	// Return skillUsedList.get(i).size() for number of uses of skill at index i
	private ArrayList<ArrayList<Integer>> skillUsedList;

	public CombatUtils(Listener l) {
		this.l = l;
		turnsList = new ArrayList<Integer>();
		winsList = new ArrayList<Integer>();
		hpLostList = new ArrayList<Integer>();
		manaUsedList = new ArrayList<Integer>();
		skillUsedList = new ArrayList<ArrayList<Integer>>();
	}

	// Determines who goes first in combat. Player has a 3/4 chance of going first
	// 1 means Enemy goes first
	// 2 means Player goes first
	private int getTurn() {
		int i = rand.nextInt(4);
		if(i == 0) {
			return 1;
		} else {
			return 2;
		}
	}

	// Playtest combat
	public void combat(Player p, Enemy e) {
		int turn = getTurn(); // Determines who goes first
		String choiceString; // String that prints options for player to choose from
		ArrayList<String> options = new ArrayList<String>(); // ArrayList of possible options
		int choiceInt; // How many choices are available to player
		int inputInt; // Integer value of player choice
		String inputChoice = ""; // Used to pull Skill used, if a skill was selected
		boolean choseSkill; // Returns true if player chose to use a skill
		Skill skillUsed; // Which skill the player chose to use
		boolean hit; // Whether or not the combatant hit with their attack
		int pDam; // Physical damage dealt
		int mDam; // Magic damage dealt
		int dam; // Total damage dealt
		boolean[] skillActive = new boolean[p.getSkills().size() + 1]; // Boolean array of size 1 + size of p.getSkills
		int potRecovered; // Amount healed by a potion
		// Heal both combatants to full
		p.fullHeal();
		e.fullHeal();
		while(p.getHP() > 0 && e.getHP() > 0) {
			// While both combatants have remaining hp
			hit = false; // Reset hit to false
			System.out.println();
			// For each skill, if its BuffEnd or AtkBuffEnd values equal the turn value, then those buffs reset
			for(Skill skill:p.getSkills()) {
				if(skill.getBuffEnd() == turn) {
					resetSkill(p, e, skill, true); // Reset the skill with printed text
				}
				if(skill.getAtkBuffEnd() == turn) {
					atkEnd(p, skill); // Reset the skills attack values
				}
			}
			// Set values in skillActive array.
			// If a skill's BuffEnd or AtkBuffEnd values are greater than current turn, that skill is active
			// Set the boolean at that index to true
			// Otherwise set it to false
			for(int i = 0; i < p.getSkills().size(); i++) {
				Skill s = p.getSkill(i);
				if(s.getBuffEnd() > turn || s.getAtkBuffEnd() > turn) {
					skillActive[i] = true;
				} else {
					skillActive[i] = false;
				}
			}
			if(turn % 2 == 0) {
				// If turn value is even, then it is Player's turn
				options.clear(); // Clear the ArrayList of Strings
				choseSkill = false; // Reset choseSkill
				skillUsed = null; // Reset skillUsed
				p.printStats(); // Print player HP and Mana
				while(true) {
					// Loop until the user has made a valid choice
					choiceString = "1 - Attack\n"; // Add the value to String that will be printed
					choiceInt = 1; // Set number of possible choices to 1
					options.add("Attack"); // Add the String to options at index 0
					for(Skill skill:p.getSkills()) {
						// For each skill in ArrayList of Skill objects
						choiceInt++; // Increase number of possible choices by 1
						choiceString += choiceInt + " - " + skill.getName() + " (" + skill.getManaCost() + " mana)\n"; // Add that skill and its mana cost to the String that will be printed
						options.add(skill.getName()); // Add the name of that skill to the options ArrayList
					}
					if(p.getPots() > 0) {
						// If player has any Potions remaining
						choiceInt++; // Increase number of possible choices by 1
						choiceString += choiceInt + " - Potion\n"; // Add the value to String that will be printed
		 				options.add("Potion"); // Add Potion to options ArrayList
					}
					// Print the players list of choices, then get input as an integer between 1 and the maximum number of possible choices
					inputInt = l.getInt(choiceString, 1, choiceInt);
					if(inputInt == 1) {
						// Input of 1 always means attack
						inputChoice = "Attack";
					} else {
						try {
							// If inputInt - 2 is within the bounds of the p.getSkills ArrayList, then inputChoice is equal to that skills name
							inputChoice = p.getSkill(inputInt - 2).getName();
							choseSkill = true; // Set boolean to true
						} catch(IndexOutOfBoundsException ex) {
							// If inputInt - 2 is outside the bounds of the ArrayList, then player must have selected Potion
							inputChoice = "Potion";
						}
					}
					if(!choseSkill) {
						// If player did not choose to use a skill
						if(inputChoice.equals("Attack")) {
							// If player selected the input option that equated to "Attack"
							System.out.println(p.getName() + " attacks!");
							hit = calcHit(p.getAcc(), e.getEva()); // Determine hit based on player accuracy and enemy evasion
							if(hit) {
								// If player attack hits
								// Determine pDam and mDam separately, based on attack and defense modifiers, as well as player range
								pDam = atkAdj(p.getPAtk(), e.getPDef(), p.getRange());
								mDam = atkAdj(p.getMAtk(), e.getMDef(), p.getRange());
								// dam is the total damage dealt
								dam = pDam + mDam;
								System.out.println(p.getName() + " deals " + dam + " damage!");
								e.adjHP(-1 * dam); // Reduce enemy hp by dam
								break; // break out of while loop
							} else {
								// If player attack misses
								System.out.println(p.getName() + " misses!");
								break; // break out of while loop
							}
						} else if(inputChoice.equals("Potion")) {
							// If player selected Potion
							if(p.getHP() < p.getMaxHP()) {
								// If player hp is less than maximum
								System.out.println("Drank a potion!");
								// Potion heals 1/3 maximum hp
								if(p.getHP() + (p.getMaxHP() * 0.33) >= p.getMaxHP()) {
									// If healing 1/3 maximum hp would put hp above maximum, set amount healed to difference between max and current
									potRecovered = p.getMaxHP() - p.getHP();
									p.setHP(p.getMaxHP()); // Set hp to max
								} else {
									// If healing 1/3 maximum hp would not put hp above maximum
									potRecovered = (int) Math.round(p.getMaxHP() * 0.33);
									p.adjHP(potRecovered); // Heal 1/3 maximum hp
								}
								System.out.println("Recovered " + potRecovered + " HP!");
								p.adjPots(-1); // Reduce number of potions by 1
								break; // break out of while loop
							} else {
								// If player hp is equal to maximum
								System.out.println("No need for a potion right now!");
								continue; // continue while loop
							}
						}
					} else {
						// If player chose to use a skill
						skillUsed = p.getSkill(inputChoice); // Get Skill object by name
						if(p.canAffordSkill(skillUsed)) {
							// If player can afford to use that skill
							// Get index of Skill object
							int index = p.getIndexOfSkill(skillUsed);
							if(!skillActive[index]) {
								// If boolean at that same index is false, then skill is not active
								useWText(p, e, skillUsed, turn); // Use the skill with printed text
								break; // break out of while loop
							} else {
								// If boolean at that same index is true, then skill is currently active
								System.out.println(skillUsed.getName() + " is already active!");
								continue; // continue while loop
							}
						} else {
							// If player cannot afford to use that skill
							System.out.println("Not enough mana!");
							continue; // continue while loop
						}
					}
				}
				// If broken out of while loop, then player made a valid choice
				turn++; // Increase turn value by 1
				l.pause(); // Wait for user input
			} else {
				// If turn value is odd, then it is enemy's turn
				System.out.println(e.getName() + " attacks!");
				hit = calcHit(e.getAcc(), p.getEva());
				if(hit) {
					pDam = atkAdj(e.getPAtk(), p.getPDef(), e.getRange());
					mDam = atkAdj(e.getMAtk(), p.getMDef(), e.getRange());
					dam = pDam + mDam;
					p.adjHP(-1 * dam);
					System.out.println(e.getName() + " deals " + dam + " damage!");
				} else {
					System.out.println(e.getName() + " misses!");
				}
				turn++;
				l.pause();
			}
		}
		if(p.getHP() <= 0) {
			System.out.println(p.getName() + " loses!");
		} else if(e.getHP() <= 0) {
			System.out.println(p.getName() + " wins!");
			System.out.println("Collected " + e.getGoldVal() + " gold!");
			p.adjGold(e.getGoldVal());
		}
	}

	// Returns average number of turns for set of encounters
	public int getTurns() {
		int avg = 0;
		// Set avg to total number of all turns taken
		for(int i:turnsList) {
			avg += i;
		}
		// Divide avg by size of turnsList for average number of turns taken
		avg = avg / turnsList.size();
		// Clear turnsList to be used again
		turnsList.clear();
		return avg;
	}

	// Returns number of wins for set of encounters
	// On a win, a 1 is added to the end of winsList, so winsList.size returns the number of wins
	public int getWins() {
		int total = winsList.size();
		// Clear winsList to be used again
		winsList.clear();
		return total;
	}

	// Returns average amount of hp lost for set of encounters
	public int getHPLost() {
		int avg = 0;
		// Set avg to total amount of hp lost for all encounters
		for(int i:hpLostList) {
			avg += i;
		}
		// Divide avg by size of hpLostList for average amount of hp lost
		avg = avg / hpLostList.size();
		// Clear hpLostList to be used again
		hpLostList.clear();
		return avg;
	}

	// Returns average amount of mana used for set of encounters
	public int getManaUsed() {
		int avg = 0;
		// Set avg to total amount of mana used for all encounters
		for(int i:manaUsedList) {
			avg += i;
		}
		// Divide avg by size of manaUsedList for average amount of mana used
		avg = avg / manaUsedList.size();
		// Clear manaUsedList to be used again
		manaUsedList.clear();
		return avg;
	}

	// Get number of uses of skill at index
	// skillUsedList is an ArrayList<ArrayList<Integer>>
	// Each skill gets its own ArrayList<Integer>, and that ArrayList gets appended 1 every time that skill is used
	// So returning skillUsedList.get(i).size() returns the number of times the skill at index i was used
	public int getSkillUsed(int index) {
		return skillUsedList.get(index).size();
	}

	// Clear skillUsedList to be used again
	public void clearSkillUsedList() {
		skillUsedList.clear();
	}
	
	// Simulates combat between player and enemy, using available skills and modified by player strategy
	public void combatAuto(Player p, Enemy e) {
		int turn = getTurn();
		boolean hit;
		int pDam;
		int mDam;
		int dam;
		String bestAction; // Action to look for
		Skill bestSkill; // Skill to use
		int expPhysOut; // Expected outgoing physical damage
		int expMagOut; // Expected outgoing magic damage
		String pStrongest; // Strongest outgoing damage between Physical and Magic
		int expPhysInc; // Expected incoming physical damage
		int expMagInc; // expected incoming magic damage
		String eStrongest; // Strongest incoming damage between Physical and Magic
		int expInc; // Expected total incoming damage
		int expOut; // Expected total outgoing damage
		boolean[] skillActive = new boolean[p.getSkills().size()]; // Whether skill at Player.getSkills().get(i) is active
		String strat = p.getStrategy();
		int skillDam; // Estimated total outgoing damage if skill is used
		int skillHeal; // Estimated amount healed by skill
		float skillDef; // Amount that evaluated skill will increase relevant defense stat
		int bestSkillHeal; // Estimated amount healed by currently selected bestSkill
		int bestSkillDam; // Estimated amount of damage dealt by currently selected bestSkill
		float bestSkillDef; // Amount that bestSkill will increase relevant defense stat
		int numTurns = 0; // How many turns the combat took
		for(int i = 0; i < p.getSkills().size(); i++) {
			// Add an ArrayList<Integer> for each skill in p.getSkills().
			// ArrayList<Integer> at this index of skillUsedList will be used to track uses of skill at this index of p.getSkills
			skillUsedList.add(new ArrayList<Integer>());
		}
		p.fullHeal();
		e.fullHeal();
		for(Skill skill:p.getSkills()) {
			// Set buffEnd and atkBuffEnd to 0 for all skills in p.getSkills
			skill.turnReset();
		}
		while(p.getHP() > 0 && e.getHP() > 0) {
			// Combat continues while both combatants have HP > 0
			hit = false;
			for(Skill skill:p.getSkills()) {
				if(turn == skill.getBuffEnd()) {
					resetSkill(p, e, skill, false);
				}
				if(turn == skill.getAtkBuffEnd()) {
					atkEnd(p, skill);
				}
			}
			for(int i = 0; i < p.getSkills().size(); i++) {
				Skill s = p.getSkill(i);
				if(s.getBuffEnd() > turn || s.getAtkBuffEnd() > turn) {
					// Skill at index i of p.getSkills is still active
					// Set boolean at index i of skillActive to true
					skillActive[i] = true;
				} else {
					// Skill at index i of p.getSkills is not active
					// Set boolean at index i of skillActive to false
					skillActive[i] = false;
				}
			}
			if(turn % 2 == 0) {
				// Player turn
				bestAction = "None"; // No bestAction found yet
				bestSkill = null; // No bestSkill found yet
				expPhysOut = atkAdj(p.getPAtk(), e.getPDef(), p.getRange());
				expMagOut = atkAdj(p.getMAtk(), e.getMDef(), p.getRange());
				expOut = expPhysOut + expMagOut;
				if(expPhysOut >= expMagOut) {
					pStrongest = "Physical";
				} else {
					pStrongest = "Magic";
				}
				expPhysInc = atkAdj(e.getPAtk(), p.getPDef(), e.getRange());
				expMagInc = atkAdj(e.getMAtk(), p.getMDef(), e.getRange());
				expInc = expPhysInc + expMagInc;
				if(expPhysInc >= expMagInc) {
					eStrongest = "Physical";
				} else {
					eStrongest = "Magic";
				}

				// Determine bestAction based on current hp and mana values, and incoming and outgoing damage

				if(expOut >= e.getHP()) {
					// Expected outgoing damage of a basic attack is greater than or equal to enemy current HP
					// Because a basic attack will likely kill the enemy, a skill does not need to be used
					bestAction = "BasicAttack";
				}
				if(bestAction.equals("None")) {
					if(strat.equals("Defensive") && 
							((p.getHP() <= p.getMaxHP() * 0.5f) ||
									(expInc >= p.getHP() * 0.5f))) {
						// Current HP is less than or equal to half of MaxHP
						// Or
						// Expected incoming damage is greater than or equal to current HP
						// Because strategy is Defensive, look for a HealSkill the player can afford
						for(Skill skill:p.getSkills()) {
							if(skill.getHeal() > 0 && p.canAffordSkill(skill)) {
								// There is at least one skill with a healing effect which the player can afford
								bestAction = "HealSkill";
							}
						}
					} else if((strat.equals("Balanced") && 
							(p.getHP() <= p.getMaxHP() * 0.5f &&
							expInc >= p.getHP() * 0.5f)) ||
							// Strategy is Balanced, HP is less than or equal to half of MaxHP, and incoming attack is greater than or equal to half of remaining HP
							(strat.equals("Aggressive") &&
									expInc >= p.getHP() * 0.75f)) {
						// Strategy is Aggressive and incoming attack is greater than or equal to 3/4ths of remaining HP
						for(Skill skill:p.getSkills()) {
							skillDam = atkAdj((int) Math.round(p.getPAtk() + p.getBasePAtk() * skill.getPAtk()), e.getPDef(), p.getRange()) + atkAdj((int) Math.round(p.getMAtk() + p.getBaseMAtk() * skill.getMAtk()), e.getMDef(), p.getRange());
							if(skillDam >= e.getHP() && p.canAffordSkill(skill) && 
									((strat.equals("Balanced") && (p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f)) ||
											(strat.equals("Aggressive") && (p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.25f)))) {
								// A skill has been found that will kill the enemy outright that the player can afford
								// If possible, Balanced or Aggressive strategies will prefer to kill the enemy rather than waste time and mana healing
								// Balanced strategies will not use a sacrifice spell that would reduce their hp to less than 50% max
								// Aggressive strategies will not use a sacrifice spell that would reduce their hp to less than 25% max
								bestAction = "QuickKill";
							}
						}
						if(bestAction.equals("None")) {
							// If bestAction is currently None, then no skill which could kill the enemy outright was found or could not be afforded
							// Given the current HP and expected incoming damage, look for a HealSkill
							for(Skill skill:p.getSkills()) {
								if(skill.getHeal() > 0 && p.canAffordSkill(skill)) {
									// There is at least one skill with a healing effect which the player can afford
									bestAction = "HealSkill";
								}
							}
						}
					}
				}
				if(bestAction.equals("None")) {
					// If bestAction is currently None, then hp is not so low that a HealSkill or QuickKill is necessary
					if(expOut >= e.getHP() * 0.5f) {
						// A basic attack would reduce enemy current HP to half or lower
						// Most efficient use of mana would be two basic attacks to defeat enemy, rather than looking for an attack, buff, or debuff
						bestAction = "BasicAttack";
					}
				}
				if(bestAction.equals("None")) {
					// If bestAction is currently None, then a basic attack would not reduce enemy to half or lower
					// It would be inefficient to hit the enemy with a basic attack
					// Checking whether or not a Defensive skill is necessary
					if(strat.equals("Defensive") && expInc >= p.getMaxHP() * 0.2f) {
						// Strategy is Defensive and incoming attack is at least 1/5 of maximum HP
						// Looking for a Defense skill
						for(Skill skill:p.getSkills()) {
							if(p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f && skill.getHeal() >= 0) {
								// Skill will not reduce mana below 50% and skill will not sacrifice hp
								if(eStrongest.equals("Physical") && skill.getPDef() > 0) {
									// Strongest incoming attack is Physical, and skill has a PDef buff
									bestAction = "DefenseSkill";
								} else if(eStrongest.equals("Magic") && skill.getMDef() > 0) {
									// Strongest incoming attack is Magic, and skill has a MDef buff
									bestAction = "DefenseSkill";
								}
							}
						}
					} else if(strat.equals("Balanced") &&
							(expInc >= p.getHP() * 0.66f || expInc >= p.getMaxHP() * 0.33f)) {
						// Strategy is Balanced and incoming attack is either at least 2/3 current HP, or at least 1/3 maximum HP
						for(Skill skill:p.getSkills()) {
							skillDam = atkAdj((int) Math.round(p.getPAtk() + p.getBasePAtk() * skill.getPAtk()), e.getPDef(), p.getRange()) + atkAdj((int) Math.round(p.getMAtk() + p.getBaseMAtk() * skill.getMAtk()), e.getMDef(), p.getRange());
							if(skillDam >= e.getHP() && p.canAffordSkill(skill) && 
									(p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f)) {
								// If possible, Balanced strategy prefers to kill the enemy rather than waste time and mana defending
								// A skill has been found that will kill the enemy outright that the player can afford and will not reduce hp below 50% max
								bestAction = "QuickKill";
							}
						}
						if(bestAction.equals("None")) {
							// If bestAction is currently None, then no skill was found that could kill the enemy outright
							for(Skill skill:p.getSkills()) {
								if(p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f && 
										(p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f)) {
									// Skill will not reduce mana below 50%
									// Skill will not reduce hp below 50% max
									if(eStrongest.equals("Physical") && skill.getPDef() > 0) {
										// Strongest incoming attack is Physical, and skill has a PDef buff
										bestAction = "DefenseSkill";
									} else if(eStrongest.equals("Magic") && skill.getMDef() > 0) {
										// Strongest incoming attack is Magic, and skill has a MDef buff
										bestAction = "DefenseSkill";
									}
								}
							}
						}
					}
				}
				if(bestAction.equals("None")) {
					// If bestAction is None, no Defense skill was found
					boolean foundBuff = false;
					boolean foundDebuff = false;
					Skill s;
					for(int i = 0; i < p.getSkills().size(); i++) {
						s = p.getSkills().get(i);
						if(!skillActive[i] &&
								((strat.equals("Defensive") &&
										p.getMana() - s.getManaCost() >= p.getMaxMana() * 0.5f &&
										s.getHeal() >= 0) ||
										(strat.equals("Balanced") &&
												p.getMana() - s.getManaCost() >= p.getMaxMana() * 0.5f &&
												p.getHP() + s.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f) ||
										(strat.equals("Aggressive") &&
												p.getMana() - s.getManaCost() >= p.getMaxMana() * 0.25f &&
												p.getHP() + s.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.25f))) {
							// Skill is not active
							// If strategy is Defensive, will not use a skill that will reduce mana below 50% or a skill which sacrifices hp
							// If strategy is Balanced, will not use a skill which will reduce mana or hp below 50%
							// If strategy is Aggressive, will not use a skill that will reduce mana or hp below 25%
							if(s.getBuffValue() > 0) {
								// Skill is a buff
								// Buffs are preferred over Debuffs, so breaking the loop
								foundBuff = true;
								break;
							} else if(s.getDebuffValue() > 0) {
								// Skill is a debuff
								// Continuing the loop to see if a Buff can be found
								foundDebuff = true;
								continue;
							}
						}
					}
					if(foundBuff) {
						bestAction = "BuffSkill";
					} else if(foundDebuff) {
						bestAction = "DebuffSkill";
					}
				}
				if(bestAction.equals("None")) {
					// If bestAction is currently None, then no buff or debuff skill was found
					for(Skill skill:p.getSkills()) {
						if((skill.getPAtk() > 0 || skill.getMAtk() > 0) &&
								((strat.equals("Balanced") && 
										p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.25f) &&
										p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f) ||
								(strat.equals("Aggressive") && 
										p.canAffordSkill(skill) &&
										p.getHP() + skill.getHeal() * p.getMaxHP() > 0)) {
							// Balanced strategies will only use an attack skill if it doesn't bring their mana below 25% max or hp below 50%
							// Aggressive strategies will use an attack skill as long as they can afford it and it will not reduce hp to 0
							bestAction = "AttackSkill";
						}
					}
				}

				// Handle skill selection based on bestAction

				if(bestAction.equals("HealSkill")) {
					// If bestAction is HealSkill, then the player needs to heal themselves
					// bestSkill must be affordable and provide the most healing possible out of all skills the player currently has
					bestSkillHeal = 0;
					for(Skill skill:p.getSkills()) {
						if(p.canAffordSkill(skill) && skill.getHeal() > 0) {
							// Skill has a heal value and player can afford it
							// Determine how much the skill would heal the player
							skillHeal = (int) Math.round(p.getHP() + p.getMaxHP() * skill.getHeal());
							if(p.getHP() + skillHeal > p.getMaxHP()) {
								// If the skill would overheal, then estimate only the amount the skill would heal
								// This way we can evaluate more than one healing skill
								// If both skills would "overheal" but one costs less than the other, then that skill is preferable, so that we're not wasting mana
								skillHeal = p.getMaxHP() - p.getHP();
							}
							if(bestSkill != null) {
								if(skillHeal > bestSkillHeal || 
										(skillHeal == bestSkillHeal && skill.getManaCost() < bestSkill.getManaCost())) {
									// Currently evaluated skill would heal more than bestSkill, or would heal the same amount and cost less
									// This is usually the case if both skills would overheal, in which case bestSkill will be the least expensive one
									// The skill currently being evaluated is the bestSkill so far
									bestSkill = skill;
									bestSkillHeal = skillHeal;
								}
							} else {
								// If bestSkill is null, then no bestSkill has been selected for comparison
								// The skill currently being evaluated is the bestSkill so far
								bestSkill = skill;
								// Set bestSkillHeal to the estimated amount healed by this skill
								bestSkillHeal = skillHeal;
							}
						}
					}
				} else if(bestAction.equals("QuickKill")) {
					// If bestAction is QuickKill, then the player is in danger, but one or more skills may be able to end combat
					// bestSkill must be the most affordable skill which will kill the enemy outright
					bestSkillDam = 0;
					for(Skill skill:p.getSkills()) {
						// Estimate how much damage player will do 
						skillDam = atkAdj((int) Math.round(p.getPAtk() + p.getBasePAtk() * skill.getPAtk()), e.getPDef(), p.getRange()) + atkAdj((int) Math.round(p.getMAtk() + p.getBaseMAtk() * skill.getMAtk()), e.getMDef(), p.getRange());
						if ((strat.equals("Balanced") &&
								(p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f) ||
								(strat.equals("Aggressive") &&
										(p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.25f)))) {
							// Balanced strategy will not use a skill which would reduce hp below 50%
							// Aggressive strategy will not use a skill which would reduce hp below 25%
							if(bestSkill != null) {
								if((bestSkillDam < e.getHP() && skillDam > bestSkillDam) ||
										(bestSkillDam >= e.getHP() && skillDam >= e.getHP() && skill.getManaCost() < bestSkill.getManaCost()) ||
										bestSkillDam >= e.getHP() && skillDam >= e.getHP() && skill.getManaCost() == bestSkill.getManaCost() && skill.getHeal() > bestSkill.getHeal()) {
									// If bestSkill would not kill enemy and skill would deal more damage than bestSkill
									// Or if both bestSkill and skill would kill enemy and skill costs less than bestSkill
									// Or if both bestSkill and skill would kill enemy, cost the same amount of mana, and skill would sacrifice less HP than bestSkill
									bestSkill = skill;
									bestSkillDam = skillDam;
								}
							} else {
								// If bestSkill is null, no bestSkill has been selected for comparison
								// The skill currently being evaluated is the bestSkill so far
								bestSkill = skill;
								// Set bestSkillDam to the estimated amount dealt by this skill
								bestSkillDam = skillDam;
							}
						}
					}
				} else if(bestAction.equals("DefenseSkill")) {
					bestSkillDef = 0;
					skillDef = 0;
					// If bestAction is DefenseSkill, the player needs to protect themselves from the incoming attack
					// bestSkill will be the skill with the greatest boost to whichever defense stat the player needs most
					for(Skill skill:p.getSkills()) {
						if(p.canAffordSkill(skill)) {
							// Player can afford skill
							if((strat.equals("Defensive") && skill.getHeal() >= 0) ||
									// Defensive strategies will not sacrifice HP for Defense
									(strat.equals("Balanced") &&
											(skill.getHeal() >= 0 || p.getHP() + p.getMaxHP() * skill.getHeal() >= p.getMaxHP() * 0.5f)) ||
									// Balanced strategies will not use a sacrifice spell which would reduce their HP to less than half maximum
									(strat.equals("Aggressive") &&
											(skill.getHeal() >= 0 || p.getHP() + p.getMaxHP() * skill.getHeal() >= p.getMaxHP() * 0.25f))) 
								// Aggressive strategies will not use a sacrifice spell which would reduce their HP to less than 1/4 maximum
							{
								if(eStrongest.equals("Physical")) {
									skillDef = p.getBasePDef() * skill.getPDef();
									if(p.getPDef() + skillDef > 100) {
										// If skill would raise PDef above 100, set skillDef to the difference between 100 and PDef
										skillDef = 100 - p.getPDef();
									}
								} else if(eStrongest.equals("Magic")) {
									skillDef = p.getBaseMDef() * skill.getMDef();
									if(p.getMDef() + skillDef > 100) {
										// If skill would raise MDef above 100, set skillDef to the difference between 100 and MDef
										skillDef = 100 - p.getMDef();
									}
								}
								if(bestSkill != null) {
									if(skillDef > bestSkillDef ||
											(skillDef == bestSkillDef && skill.getManaCost() < bestSkill.getManaCost()) ||
											(skillDef == bestSkillDef && skill.getManaCost() == bestSkill.getManaCost() && skill.getHeal() > bestSkill.getHeal())) {
										// If the evaluated skill has a better def buff than the current bestSkill, or the same def buff and costs less, or the same def buff, costs the same, and sacrifices less HP
										bestSkill = skill;
										bestSkillDef = skillDef;
									}
								} else {
									// If bestSkill is null, no bestSkill has been selected for comparison
									// If the current skill has a skillDef > 0, it is bestSkill so far
									if(skillDef > 0) {
										bestSkill = skill;
										bestSkillDef = skillDef;
									}
								}
							}
						}
					}
				} else if(bestAction.equals("BuffSkill")) {
					// If bestAction is BuffSkill, then the player wants to buff themselves
					// When selecting which buff to apply, the player will tend to apply the longest lasting buffs first
					// bestSkill will be the buff skill with the longest duration
					for(Skill skill:p.getSkills()) {
						if(skill.getBuffValue() > 0 &&
								((strat.equals("Devensive") &&
										p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f &&
										skill.getHeal() >= 0) ||
										(strat.equals("Balanced") &&
												p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f &&
												p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f) ||
										(strat.equals("Aggressive") &&
												p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.25f &&
												p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.25f))) {
							// Skill has a buff value
							// Defensive strategies will go below 50% mana, and will not sacrifice hp
							// Balanced strategies will not go below 50% mana or hp
							// Aggressive strategies will not go below 25% mana or hp
							if(bestSkill != null) {
								if(skill.getDuration() > bestSkill.getDuration() ||
										(skill.getDuration() == bestSkill.getDuration() &&
										skill.getBuffValue() > bestSkill.getBuffValue())) {
									// Skill being evaluated has a longer duration that bestSkill, or has the same duration but a better buff value
									bestSkill = skill;
								}
							} else {
								// If bestSkill is null, no bestSkill has been selected for comparison
								// The skill currently being evaluated is the bestSkill so far
								bestSkill = skill;
							}
						}
					}
				} else if(bestAction.equals("DebuffSkill")) {
					// If bestAction is DebuffSkill, then the player wants to debuff the enemy
					// When selecting which debuff to apply, the player will tend to apply the longest lasting debuffs first
					// bestSkill will be the debuff skill with the longest duration
					for(Skill skill:p.getSkills()) {
						if(skill.getDebuffValue() > 0 &&
								((strat.equals("Devensive") &&
										p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f &&
										skill.getHeal() >= 0) ||
										(strat.equals("Balanced") &&
												p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f &&
												p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f) ||
										(strat.equals("Aggressive") &&
												p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.25f &&
												p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.25f))) {
							// Skill has a debuff value
							// Defensive strategies will go below 50% mana, and will not sacrifice hp
							// Balanced strategies will not go below 50% mana or hp
							// Aggressive strategies will not go below 25% mana or hp
							if(bestSkill != null) {
								if(skill.getDuration() > bestSkill.getDuration() ||
										(skill.getDuration() == bestSkill.getDuration() &&
										skill.getDebuffValue() > bestSkill.getDebuffValue())) {
									// Skill being evaluated has a longer duration that bestSkill, or has the same duration but a better buff value
									bestSkill = skill;
								}
							} else {
								// If bestSkill is null, no bestSkill has been selected for comparison
								// The skill currently being evaluated is the bestSkill so far
								bestSkill = skill;
							}
						}
					}
				} else if(bestAction.equals("AttackSkill")) {
					skillDam = 0;
					bestSkillDam = 0;
					for(Skill skill:p.getSkills()) {
						if((strat.equals("Balanced") &&
								p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.25f &&
								p.getHP() + p.getMaxHP() * skill.getHeal() >= p.getMaxHP() * 0.5f) ||
								(strat.equals("Aggressive") &&
										p.getHP() + p.getMaxHP() * skill.getHeal() >= p.getMaxHP() * 0.25f)) {
							// Balanced strategies will not go below 25% mana or 50% hp
							// Aggressive strategies will not go below 25% hp

							if((pStrongest.equals("Physical") && skill.getPAtk() > 0) ||
									(pStrongest.equals("Magic") && skill.getMAtk() > 0)) {
								skillDam = atkAdj((int) Math.round(p.getPAtk() + p.getBasePAtk() * skill.getPAtk()), e.getPDef(), p.getRange()) + atkAdj((int) Math.round(p.getMAtk() + p.getBaseMAtk() * skill.getMAtk()), e.getMDef(), p.getRange());
								if(skillDam > e.getHP()) {
									// If skill would overkill enemy, set skillDam equal to enemy current HP
									skillDam = e.getHP();
								}
								if(bestSkill != null) {
									if(skillDam > bestSkillDam ||
											(skillDam == bestSkillDam && skill.getManaCost() < bestSkill.getManaCost()) ||
											(skillDam == bestSkillDam && skill.getManaCost() == bestSkill.getManaCost() && skill.getHeal() > bestSkill.getHeal())) {
										// If skill would deal more damage than bestSkill, or would deal the same amount of damage and cost less, or would deal the same amount of damage, cost the same, and sacrifice less HP
										bestSkill = skill;
										bestSkillDam = skillDam;
									}
								} else {
									// If bestSkill is null, no bestSkill has been selected for comparison
									bestSkill = skill;
									bestSkillDam = skillDam;
								}
							}
						}
					}
				}
				if(bestSkill != null) {
					// If bestSkill is not null, then a bestSkill was found
					int index = p.getIndexOfSkill(bestSkill);
					useSkill(p, e, bestSkill, turn);
					// Add 1 to list of uses for that skill
					skillUsedList.get(index).add(1);
				} else {
					// If bestSkill is null, use a basic attack
					hit = calcHit(p.getAcc(), e.getEva());
					if(hit) {
						pDam = atkAdj(p.getPAtk(), e.getPDef(), p.getRange());
						mDam = atkAdj(p.getMAtk(), e.getMDef(), p.getRange());
						dam = pDam + mDam;
						e.adjHP(-1 * dam);
					}
				}
				numTurns++;
				turn++;
			} else {
				// Enemy turn
				hit = calcHit(e.getAcc(), p.getEva());
				if(hit) {
					pDam = atkAdj(e.getPAtk(), p.getPDef(), e.getRange());
					mDam = atkAdj(e.getMAtk(), p.getMDef(), e.getRange());
					dam = pDam + mDam;
					p.adjHP(-1 * dam);
				}
				turn++;
			}
		}
		if(p.getHP() <= 0) {
			// Do not add to winsList
		} else if(e.getHP() <= 0) {
			winsList.add(1);
		}
		int hpLost = p.getMaxHP() - p.getHP();
		hpLostList.add(hpLost);
		int manaUsed = p.getMaxMana() - p.getMana();
		manaUsedList.add(manaUsed);
		turnsList.add(numTurns);
		p.fullHeal();
		e.fullHeal();
	}

	// Simulates combat with skill choices, printing the logic process for debugging purposes
	public void combatDebug(Player p, Enemy e) {
		int turn = getTurn();
		boolean hit;
		int pDam;
		int mDam;
		int dam;
		String bestAction; // Action to look for
		Skill bestSkill; // Skill to use
		int expPhysOut; // Expected outgoing physical damage
		int expMagOut; // Expected outgoing magic damage
		String pStrongest; // Strongest outgoing damage between Physical and Magic
		int expPhysInc; // Expected incoming physical damage
		int expMagInc; // expected incoming magic damage
		String eStrongest; // Strongest incoming damage between Physical and Magic
		int expInc; // Expected total incoming damage
		int expOut; // Expected total outgoing damage
		boolean[] skillActive = new boolean[p.getSkills().size()]; // Whether skill at Player.getSkills().get(i) is active
		String strat = p.getStrategy();
		int skillDam; // Estimated total outgoing damage if skill is used
		int skillHeal; // Estimated amount healed by skill
		float skillDef; // Amount that evaluated skill will increase relevant defense stat
		int bestSkillHeal; // Estimated amount healed by currently selected bestSkill
		int bestSkillDam; // Estimated amount of damage dealt by currently selected bestSkill
		float bestSkillDef; // Amount that bestSkill will increase relevant defense stat
		int numTurns = 0; // How many turns the combat took
		System.out.println("Healing both combatants");
		p.fullHeal();
		e.fullHeal();
		System.out.println();
		System.out.println("PLAYER");
		p.printAllStats();
		System.out.println();
		System.out.println("SKILLS");
		for(Skill skill:p.getSkills()) {
			skill.printSelf();
		}
		System.out.println();
		System.out.println("Strategy: " + p.getStrategy());
//		switch(p.getStrategy()) {
//		case "Defensive":
//			System.out.println("Defensive strategies prioritize healing whenever they are at or below 50% maximum,\nor when incoming damage is estimated to be 50% of current health,\nunless doing so would overheal. If a healing skill is not used,\na defensive skill will be considered.\nDefensive skills are not used when mana is at or below 50% max\n");
//		}
		System.out.println("Setting turn end for all skills");
		for(Skill skill:p.getSkills()) {
			// Set buffEnd and atkBuffEnd to 0 for all skills in p.getSkills
			skill.turnReset();
		}
		System.out.println();
		System.out.println("ENEMY");
		e.printAllStats();
		System.out.println();
		while(p.getHP() > 0 && e.getHP() > 0) {
			l.pause();
			p.printStats();
			e.printBaseStats();
			System.out.println("Player HP > 0 && Enemy HP > 0\nContinuing combat");
			// Combat continues while both combatants have HP > 0
			hit = false;
			System.out.println();
			System.out.println("Checking buff resets for skills");
			for(Skill skill:p.getSkills()) {
				System.out.println("Turn: " + turn);
				System.out.println(skill.getName() + " BuffEnd: " + skill.getBuffEnd());
				if(turn == skill.getBuffEnd()) {
					System.out.println("Resetting buff");
					resetSkill(p, e, skill, false);
				}
				System.out.println(skill.getName() + " AtkBuffEnd: " + skill.getAtkBuffEnd());
				if(turn == skill.getAtkBuffEnd()) {
					System.out.println("Resetting atk buff");
					atkEnd(p, skill);
				}
			}
			System.out.println("Checking active skills");
			for(int i = 0; i < p.getSkills().size(); i++) {
				Skill s = p.getSkill(i);
				if(s.getBuffEnd() > turn || s.getAtkBuffEnd() > turn) {
					System.out.println(s.getName() + " is active");
					// Skill at index i of p.getSkills is still active
					// Set boolean at index i of skillActive to true
					skillActive[i] = true;
				} else {
					System.out.println(s.getName() + " is not active");
					// Skill at index i of p.getSkills is not active
					// Set boolean at index i of skillActive to false
					skillActive[i] = false;
				}
			}
			System.out.print("skillActive Boolean Values: {");
			for(int i = 0; i < skillActive.length; i++) {
				if(skillActive[i]) {
					System.out.print("true");
				} else {
					System.out.print("false");
				}
				if(i < skillActive.length - 1) {
					System.out.print(", ");
				}
			}
			System.out.println("}");
			System.out.println();
			if(turn % 2 == 0) {
				System.out.println("Player Turn");
				// Player turn
				System.out.println("Resetting bestAction and bestSkill");
				bestAction = "None"; // No bestAction found yet
				bestSkill = null; // No bestSkill found yet
				System.out.println();
				expPhysOut = atkAdj(p.getPAtk(), e.getPDef(), p.getRange());
				expMagOut = atkAdj(p.getMAtk(), e.getMDef(), p.getRange());
				expOut = expPhysOut + expMagOut;
				System.out.println("expPhysOut: " + expPhysOut);
				System.out.println("expMagOut: " + expMagOut);
				System.out.println("expOut: " + expOut);
				if(expPhysOut >= expMagOut) {
					pStrongest = "Physical";
				} else {
					pStrongest = "Magic";
				}
				System.out.println("pStrongest: " + pStrongest);
				expPhysInc = atkAdj(e.getPAtk(), p.getPDef(), e.getRange());
				expMagInc = atkAdj(e.getMAtk(), p.getMDef(), e.getRange());
				expInc = expPhysInc + expMagInc;
				System.out.println();
				System.out.println("expPhysInc: " + expPhysInc);
				System.out.println("expMagInc: " + expMagInc);
				System.out.println("expInc: " + expInc);
				if(expPhysInc >= expMagInc) {
					eStrongest = "Physical";
				} else {
					eStrongest = "Magic";
				}
				System.out.println("eStrongest: " + eStrongest);

				// Determine bestAction based on current hp and mana values, and incoming and outgoing damage

				System.out.println();
				System.out.println("Determining bestAction.");
				System.out.println();
				if(expOut >= e.getHP()) {
					System.out.println("expOut >= enemy hp");
					System.out.println("bestAction is BasicAttack");
					// Expected outgoing damage of a basic attack is greater than or equal to enemy current HP
					// Because a basic attack will likely kill the enemy, a skill does not need to be used
					bestAction = "BasicAttack";
				} else {
					System.out.println("expOut < enemy hp.\nBasicAttack is not bestAction");
				}
				if(bestAction.equals("None")) {
					System.out.println();
					System.out.println("bestAction is None. Looking for HealSkill.");
					// If bestAction is currently None, then a basic attack is unlikely to kill the enemy
					if(strat.equals("Defensive") && 
							((p.getHP() <= p.getMaxHP() * 0.5f) ||
									(expInc >= p.getHP() * 0.5f))) {
						System.out.println("Strategy is Defensive and HP is less than 50% max or incoming attack is at least 50% current");
						// Current HP is less than or equal to half of MaxHP
						// Or
						// Expected incoming damage is greater than or equal to current HP
						// Because strategy is Defensive, look for a HealSkill the player can afford
						System.out.println();
						for(Skill skill:p.getSkills()) {
							System.out.println("Evaluating " + skill.getName());
							if(skill.getHeal() > 0 && p.canAffordSkill(skill)) {
								System.out.println(skill.getName() + " has a heal effect and can afford");
								System.out.println("bestAction is HealSkill");
								// There is at least one skill with a healing effect which the player can afford
								bestAction = "HealSkill";
							} else {
								System.out.println(skill.getName() + " does not have a heal effect or cannot afford");
							}
						}
					} else if((strat.equals("Balanced") && 
							(p.getHP() <= p.getMaxHP() * 0.5f &&
							expInc >= p.getHP() * 0.5f)) ||
							// Strategy is Balanced, HP is less than or equal to half of MaxHP, and incoming attack is greater than or equal to half of remaining HP
							(strat.equals("Aggressive") &&
									expInc >= p.getHP() * 0.75f)) {
						System.out.println("Strategy is Balanced and HP is less than 50% max and incoming attack is at least 50% current");
						System.out.println("OR");
						System.out.println("Strategy is Aggressive and incoming attack is at least 75% current");
						// Strategy is Aggressive and incoming attack is greater than or equal to 3/4ths of remaining HP
						for(Skill skill:p.getSkills()) {
							System.out.println("Evaluating " + skill.getName());
							skillDam = atkAdj((int) Math.round(p.getPAtk() + p.getBasePAtk() * skill.getPAtk()), e.getPDef(), p.getRange()) + atkAdj((int) Math.round(p.getMAtk() + p.getBaseMAtk() * skill.getMAtk()), e.getMDef(), p.getRange());
							System.out.println(skill.getName() + " damage: " + skillDam);
							if(skillDam >= e.getHP() && p.canAffordSkill(skill) && 
									((strat.equals("Balanced") && (p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f)) ||
											(strat.equals("Aggressive") && (p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.25f)))) {
								System.out.println(skill.getName() + " will kill outright, can afford, and will not sacrifice too much health");
								System.out.println("bestAction is QuickKill");
								// A skill has been found that will kill the enemy outright that the player can afford
								// If possible, Balanced or Aggressive strategies will prefer to kill the enemy rather than waste time and mana healing
								// Balanced strategies will not use a sacrifice spell that would reduce their hp to less than 50% max
								// Aggressive strategies will not use a sacrifice spell that would reduce their hp to less than 25% max
								bestAction = "QuickKill";
							} else {
								System.out.println(skill.getName() + " will not kill outright, cannot afford, or would sacrifice too much health");
							}
						}
						if(bestAction.equals("None")) {
							System.out.println("No QuickKill found. Looking for HealSkill");
							// If bestAction is currently None, then no skill which could kill the enemy outright was found or could not be afforded
							// Given the current HP and expected incoming damage, look for a HealSkill
							for(Skill skill:p.getSkills()) {
								System.out.println("Evaluating " + skill.getName());
								if(skill.getHeal() > 0 && p.canAffordSkill(skill)) {
									System.out.println(skill.getName() + " has heal and can afford.");
									// There is at least one skill with a healing effect which the player can afford
									System.out.println("bestAction is HealSkill");
									bestAction = "HealSkill";
								} else {
									System.out.println(skill.getName() + " does not have heal, or cannot afford.");
								}
							}
						}
					} else {
						System.out.println("HealSkill is not necessary.");
					}
				}
				if(bestAction.equals("None")) {
					System.out.println();
					System.out.println("bestAction is None. HealSkill or QuickKill are not necessary, or could not be found.");
					// If bestAction is currently None, then hp is not so low that a HealSkill or QuickKill is necessary
					System.out.println("Expected Out: " + expOut);
					System.out.println("Enemy HP: " + e.getHP());
					if(expOut >= e.getHP() * 0.5f) {
						System.out.println("expOut >= e.getHP() * 0.5f");
						System.out.println("bestAction is BasicAttack");
						// A basic attack would reduce enemy current HP to half or lower
						// Most efficient use of mana would be two basic attacks to defeat enemy, rather than looking for an attack, buff, or debuff
						bestAction = "BasicAttack";
					} else {
						System.out.println("expOut < e.getHP() * 0.5f");
						System.out.println("bestAction is not BasicAttack");
					}
				}
				if(bestAction.equals("None")) {
					System.out.println();
					System.out.println("bestAction is None. BasicAttack will not work.");
					// If bestAction is currently None, then a basic attack would not reduce enemy to half or lower
					// It would be inefficient to hit the enemy with a basic attack
					// Checking whether or not a Defensive skill is necessary
					if(strat.equals("Defensive") && expInc >= p.getMaxHP() * 0.2f) {
						System.out.println("Strategy is defensive and expected incoming attack is at least 20% max HP.");
						System.out.println("Looking for DefenseSkill");
						// Strategy is Defensive and incoming attack is at least 1/5 of maximum HP
						// Looking for a Defense skill
						for(Skill skill:p.getSkills()) {
							System.out.println("Evaluating " + skill.getName());
							if(p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f && skill.getHeal() >= 0) {
								System.out.println(skill.getName() + " will not reduce mana below 50% and will not sacrifice hp");
								// Skill will not reduce mana below 50% and skill will not sacrifice hp
								if(eStrongest.equals("Physical") && skill.getPDef() > 0) {
									System.out.println(skill.getName() + " will modify necessary defense stat.");
									System.out.println("bestAction is DefenseSkill.");
									// Strongest incoming attack is Physical, and skill has a PDef buff
									bestAction = "DefenseSkill";
								} else if(eStrongest.equals("Magic") && skill.getMDef() > 0) {
									System.out.println(skill.getName() + " will modify necessary defense stat.");
									System.out.println("bestAction is DefenseSkill.");
									// Strongest incoming attack is Magic, and skill has a MDef buff
									bestAction = "DefenseSkill";
								} else {
									System.out.println(skill.getName() + " will not modify necessary defense stat.");
								}
							}
						}
					} else if(strat.equals("Balanced") &&
							(expInc >= p.getHP() * 0.66f || expInc >= p.getMaxHP() * 0.33f)) {
						System.out.println("Strategy is Balanced and incoming attack is at least 66% current HP, or at least 33% max HP");
						System.out.println("Looking for QuickKill");
						// Strategy is Balanced and incoming attack is either at least 2/3 current HP, or at least 1/3 maximum HP
						for(Skill skill:p.getSkills()) {
							System.out.println("Evaluating " + skill.getName());
							skillDam = atkAdj((int) Math.round(p.getPAtk() + p.getBasePAtk() * skill.getPAtk()), e.getPDef(), p.getRange()) + atkAdj((int) Math.round(p.getMAtk() + p.getBaseMAtk() * skill.getMAtk()), e.getMDef(), p.getRange());
							System.out.println("skillDam: " + skillDam);
							if(skillDam >= e.getHP() && p.canAffordSkill(skill) && 
									(p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f)) {
								System.out.println(skill.getName() + " will kill enemy, can afford, and will not reduce hp below 50%");
								// If possible, Balanced strategy prefers to kill the enemy rather than waste time and mana defending
								// A skill has been found that will kill the enemy outright that the player can afford and will not reduce hp below 50% max
								System.out.println("Best action is QuickKill");
								bestAction = "QuickKill";
							}
						}
						if(bestAction.equals("None")) {
							System.out.println("bestAction is None. No QuickKill was found.");
							System.out.println("Looking for DefenseSkill");
							// If bestAction is currently None, then no skill was found that could kill the enemy outright
							for(Skill skill:p.getSkills()) {
								System.out.println("Evaluating " + skill.getName());
								if(p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f && 
										(p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f)) {
									System.out.println(skill.getName() + " will not reduce mana or hp below 50%");
									// Skill will not reduce mana below 50%
									// Skill will not reduce hp below 50% max
									if(eStrongest.equals("Physical") && skill.getPDef() > 0) {
										// Strongest incoming attack is Physical, and skill has a PDef buff
										System.out.println("Incoming attack is physical and skill has PDef");
										bestAction = "DefenseSkill";
									} else if(eStrongest.equals("Magic") && skill.getMDef() > 0) {
										// Strongest incoming attack is Magic, and skill has a MDef buff
										System.out.println("Incoming attack is Magic and skill has MDef");
										bestAction = "DefenseSkill";
									}
								}
							}
						}
					} else {
						System.out.println("DefenseSkill is not necessary.");
					}
				}
				if(bestAction.equals("None")) {
					System.out.println();
					System.out.println("bestAction is None. No DefenseSkill found.");
					System.out.println("Looking for Buff or Debuff skill");
					boolean foundBuff = false;
					boolean foundDebuff = false;
					Skill s;
					for(int i = 0; i < p.getSkills().size(); i++) {
						s = p.getSkills().get(i);
						System.out.println("Evaluating " + s.getName());
						if(!skillActive[i] &&
								((strat.equals("Defensive") &&
										p.getMana() - s.getManaCost() >= p.getMaxMana() * 0.5f &&
										s.getHeal() >= 0) ||
										(strat.equals("Balanced") &&
												p.getMana() - s.getManaCost() >= p.getMaxMana() * 0.5f &&
												p.getHP() + s.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f) ||
										(strat.equals("Aggressive") &&
												p.getMana() - s.getManaCost() >= p.getMaxMana() * 0.25f &&
												p.getHP() + s.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.25f))) {
							System.out.println(s.getName() + " is not active, and meets mana/hp requirements.");
							switch(strat) {
							case "Defensive":
								System.out.println("Strategy is Defensive. Skill will not reduce mana below 50% and will not sacrifice hp.");
								break;
							case "Balanced":
								System.out.println("Strategy is Balanced. Skill will not reduce mana or hp below 50%.");
								break;
							case "Aggressive":
								System.out.println("Strategy is Aggressive. Skill will not reduce mana or hp below 25%.");
								break;
							}
							// Skill is not active
							// If strategy is Defensive, will not use a skill that will reduce mana below 50% or a skill which sacrifices hp
							// If strategy is Balanced, will not use a skill which will reduce mana or hp below 50%
							// If strategy is Aggressive, will not use a skill that will reduce mana or hp below 25%
							if(s.getBuffValue() > 0) {
								// Skill is a buff
								// Buffs are preferred over Debuffs, so breaking the loop
								System.out.println(s.getName() + " has a Buff value. Breaking loop.");
								foundBuff = true;
								break;
							} else if(s.getDebuffValue() > 0) {
								// Skill is a debuff
								// Continuing the loop to see if a Buff can be found
								System.out.println(s.getName() + " has a Debuff value. Continuing loop.");
								foundDebuff = true;
								continue;
							} else {
								System.out.println(s.getName() + " does not have a Buff or Debuff value.");
							}
						} else {
							System.out.println(s.getName() + " does not meet mana/hp requirements.");
						}
					}
					if(foundBuff) {
						System.out.println("bestAction is BuffSkill.");
						bestAction = "BuffSkill";
					} else if(foundDebuff) {
						System.out.println("bestAction is DebuffSkill.");
						bestAction = "DebuffSkill";
					}
				}
				if(bestAction.equals("None")) {
					System.out.println();
					System.out.println("bestAction is None. No Buff or Debuff skill was found.");
					System.out.println("Looking for AttackSkill.");
					// If bestAction is currently None, then no buff or debuff skill was found
					for(Skill skill:p.getSkills()) {
						System.out.println("Evaluating " + skill.getName());
						if((skill.getPAtk() > 0 || skill.getMAtk() > 0) &&
								((strat.equals("Balanced") && 
										p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.25f) &&
										p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f) ||
								(strat.equals("Aggressive") && 
										p.canAffordSkill(skill) &&
										p.getHP() + skill.getHeal() * p.getMaxHP() > 0)) {
							System.out.println(skill.getName() + " has an attack buff and meets mana/hp requirements");
							if(strat.equals("Balanced")) {
								System.out.println("Strategy is Balanced. Skill will not reduce mana below 25% or hp below 50%.");
							} else if(strat.equals("Aggressive")) {
								System.out.println("Strategy is Aggressive. Skill will not reduce hp below 0.");
							}
							// Balanced strategies will only use an attack skill if it doesn't bring their mana below 25% max or hp below 50%
							// Aggressive strategies will use an attack skill as long as they can afford it and it will not reduce hp to 0
							System.out.println("bestAction is AttackSkill.");
							bestAction = "AttackSkill";
						} else {
							System.out.println(skill.getName() + " does not have an attack modifier, or does not meet mana/hp requirements.");
						}
					}
				}

				// Handle skill selection based on bestAction
				System.out.println();
				System.out.println("bestAction determined. Handling bestAction.");
				System.out.println();

				if(bestAction.equals("HealSkill")) {
					System.out.println("bestAction is HealSkill");
					// If bestAction is HealSkill, then the player needs to heal themselves
					// bestSkill must be affordable and provide the most healing possible out of all skills the player currently has
					bestSkillHeal = 0;
					for(Skill skill:p.getSkills()) {
						System.out.println("Evaluating " + skill.getName());
						if(p.canAffordSkill(skill) && skill.getHeal() > 0) {
							System.out.println("Can afford and has heal effect");
							// Skill has a heal value and player can afford it
							// Determine how much the skill would heal the player
							skillHeal = (int) Math.round(p.getHP() + p.getMaxHP() * skill.getHeal());
							if(p.getHP() + skillHeal > p.getMaxHP()) {
								// If the skill would overheal, then estimate only the amount the skill would heal
								// This way we can evaluate more than one healing skill
								// If both skills would "overheal" but one costs less than the other, then that skill is preferable, so that we're not wasting mana
								skillHeal = p.getMaxHP() - p.getHP();
							}
							System.out.println(skill.getName() + " would heal " + skillHeal + " hp.");
							if(bestSkill != null) {
								System.out.println("Current bestSkill is " + bestSkill.getName());
								System.out.println(bestSkill.getName() + " would heal " + bestSkillHeal);
								if(skillHeal > bestSkillHeal || 
										(skillHeal == bestSkillHeal && skill.getManaCost() < bestSkill.getManaCost())) {
									System.out.println(skill.getName() + " is better than " + bestSkill.getName());
									// Currently evaluated skill would heal more than bestSkill, or would heal the same amount and cost less
									// This is usually the case if both skills would overheal, in which case bestSkill will be the least expensive one
									// The skill currently being evaluated is the bestSkill so far
									bestSkill = skill;
									bestSkillHeal = skillHeal;
									System.out.println(bestSkill.getName() + " is new bestSkill.");
								} else {
									System.out.println(bestSkill.getName() + " is better than " + skill.getName());
								}
							} else {
								System.out.println("No bestSkill currently found.");
								// If bestSkill is null, then no bestSkill has been selected for comparison
								// The skill currently being evaluated is the bestSkill so far
								bestSkill = skill;
								// Set bestSkillHeal to the estimated amount healed by this skill
								bestSkillHeal = skillHeal;
								System.out.println(bestSkill.getName() + " is bestSkill.");
							}
						}
					}
				} else if(bestAction.equals("QuickKill")) {
					System.out.println("bestAction is QuickKill.");
					// If bestAction is QuickKill, then the player is in danger, but one or more skills may be able to end combat
					// bestSkill must be the most affordable skill which will kill the enemy outright
					bestSkillDam = 0;
					for(Skill skill:p.getSkills()) {
						System.out.println("Evaluating " + skill.getName());
						// Estimate how much damage player will do 
						skillDam = atkAdj((int) Math.round(p.getPAtk() + p.getBasePAtk() * skill.getPAtk()), e.getPDef(), p.getRange()) + atkAdj((int) Math.round(p.getMAtk() + p.getBaseMAtk() * skill.getMAtk()), e.getMDef(), p.getRange());
						System.out.println(skill.getName() + " would deal " + skillDam + " damage.");
						if ((strat.equals("Balanced") &&
								(p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f) ||
								(strat.equals("Aggressive") &&
										(p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.25f)))) {
							System.out.println(skill.getName() + " would not sacrifice too much hp.");
							// Balanced strategy will not use a skill which would reduce hp below 50%
							// Aggressive strategy will not use a skill which would reduce hp below 25%
							if(bestSkill != null) {
								System.out.println("Current bestSkill is " + bestSkill.getName());
								System.out.println(bestSkill.getName() + " would deal " + bestSkillDam + " damage.");
								if((bestSkillDam < e.getHP() && skillDam > bestSkillDam) ||
										(bestSkillDam >= e.getHP() && skillDam >= e.getHP() && skill.getManaCost() < bestSkill.getManaCost()) ||
										bestSkillDam >= e.getHP() && skillDam >= e.getHP() && skill.getManaCost() == bestSkill.getManaCost() && skill.getHeal() > bestSkill.getHeal()) {
									System.out.println(skill.getName() + " is better than " + bestSkill.getName());
									// If bestSkill would not kill enemy and skill would deal more damage than bestSkill
									// Or if both bestSkill and skill would kill enemy and skill costs less than bestSkill
									// Or if both bestSkill and skill would kill enemy, cost the same amount of mana, and skill would sacrifice less HP than bestSkill
									bestSkill = skill;
									bestSkillDam = skillDam;
									System.out.println(bestSkill.getName() + " is new bestSkill.");
								} else {
									System.out.println(bestSkill.getName() + " is better than " + skill.getName());
								}
							} else {
								System.out.println("No current bestSkill.");
								// If bestSkill is null, no bestSkill has been selected for comparison
								// The skill currently being evaluated is the bestSkill so far
								bestSkill = skill;
								// Set bestSkillDam to the estimated amount dealt by this skill
								bestSkillDam = skillDam;
								System.out.println(bestSkill.getName() + " is bestSkill.");
							}
						} else {
							System.out.println(skill.getName() + " would sacrifice too much hp.");
						}
					}
				} else if(bestAction.equals("DefenseSkill")) {
					System.out.println("bestAction is DefenseSkill.");
					bestSkillDef = 0;
					skillDef = 0;
					// If bestAction is DefenseSkill, the player needs to protect themselves from the incoming attack
					// bestSkill will be the skill with the greatest boost to whichever defense stat the player needs most
					for(Skill skill:p.getSkills()) {
						System.out.println("Evaluating " + skill.getName());
						if(p.canAffordSkill(skill)) {
							System.out.println("Can afford " + skill.getName());
							if((strat.equals("Defensive") && skill.getHeal() >= 0) ||
									// Defensive strategies will not sacrifice HP for Defense
									(strat.equals("Balanced") &&
											(skill.getHeal() >= 0 || p.getHP() + p.getMaxHP() * skill.getHeal() >= p.getMaxHP() * 0.5f)) ||
									// Balanced strategies will not use a sacrifice spell which would reduce their HP to less than half maximum
									(strat.equals("Aggressive") &&
											(skill.getHeal() >= 0 || p.getHP() + p.getMaxHP() * skill.getHeal() >= p.getMaxHP() * 0.25f))) 
								// Aggressive strategies will not use a sacrifice spell which would reduce their HP to less than 1/4 maximum
							{
								System.out.println(skill.getName() + " meets mana/hp requirements.");
								if(eStrongest.equals("Physical")) {
									skillDef = p.getBasePDef() * skill.getPDef();
									if(p.getPDef() + skillDef > 100) {
										// If skill would raise PDef above 100, set skillDef to the difference between 100 and PDef
										skillDef = 100 - p.getPDef();
									}
								} else if(eStrongest.equals("Magic")) {
									skillDef = p.getBaseMDef() * skill.getMDef();
									if(p.getMDef() + skillDef > 100) {
										// If skill would raise MDef above 100, set skillDef to the difference between 100 and MDef
										skillDef = 100 - p.getMDef();
									}
								}
								System.out.println("eStrongest is " + eStrongest);
								System.out.println(skill.getName() + " would add " + skillDef + " defense.");
								if(bestSkill != null) {
									System.out.println("Current bestSkill is " + bestSkill.getName());
									System.out.println(bestSkill.getName() + " would add " + bestSkillDef);
									if(skillDef > bestSkillDef ||
											(skillDef == bestSkillDef && skill.getManaCost() < bestSkill.getManaCost()) ||
											(skillDef == bestSkillDef && skill.getManaCost() == bestSkill.getManaCost() && skill.getHeal() > bestSkill.getHeal())) {
										System.out.println(skill.getName() + " is better than " + bestSkill.getName());
										// If the evaluated skill has a better def buff than the current bestSkill, or the same def buff and costs less, or the same def buff, costs the same, and sacrifices less HP
										bestSkill = skill;
										bestSkillDef = skillDef;
										System.out.println(bestSkill.getName() + " is new bestSkill.");
									} else {
										System.out.println(bestSkill.getName() + " is better than " + skill.getName());
									}
								} else {
									System.out.println("No current bestSkill.");
									// If bestSkill is null, no bestSkill has been selected for comparison
									// If the current skill has a skillDef > 0, it is bestSkill so far
									if(skillDef > 0) {
										bestSkill = skill;
										bestSkillDef = skillDef;
										System.out.println(bestSkill.getName() + " is new bestSkill.");
									} else {
										System.out.println(skill.getName() + " does not have defense modifier.");
									}
								}
							} else {
								System.out.println(skill.getName() + " does not meet mana/hp requirements.");
							}
						} else {
							System.out.println("Cannot afford " + skill.getName());
						}
					}
				} else if(bestAction.equals("BuffSkill")) {
					System.out.println("bestAction is BuffSkill.");
					// If bestAction is BuffSkill, then the player wants to buff themselves
					// When selecting which buff to apply, the player will tend to apply the longest lasting buffs first
					// bestSkill will be the buff skill with the longest duration
					for(Skill skill:p.getSkills()) {
						System.out.println("Evaluating " + skill.getName());
						if(skill.getBuffValue() > 0 &&
								((strat.equals("Devensive") &&
										p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f &&
										skill.getHeal() >= 0) ||
										(strat.equals("Balanced") &&
												p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f &&
												p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f) ||
										(strat.equals("Aggressive") &&
												p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.25f &&
												p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.25f))) {
							System.out.println(skill.getName() + " has buff value and meets mana/hp requirements.");
							// Skill has a buff value
							// Defensive strategies will go below 50% mana, and will not sacrifice hp
							// Balanced strategies will not go below 50% mana or hp
							// Aggressive strategies will not go below 25% mana or hp
							if(bestSkill != null) {
								System.out.println("Current bestSkill is " + bestSkill.getName());
								if(skill.getDuration() > bestSkill.getDuration() ||
										(skill.getDuration() == bestSkill.getDuration() &&
										skill.getBuffValue() > bestSkill.getBuffValue())) {
									System.out.println(skill.getName() + " is better than " + bestSkill.getName());
									// Skill being evaluated has a longer duration that bestSkill, or has the same duration but a better buff value
									bestSkill = skill;
									System.out.println(bestSkill.getName() + " is new bestSkill.");
								} else {
									System.out.println(bestSkill.getName() + " is better than " + skill.getName());
								}
							} else {
								System.out.println("No current bestSkill.");
								// If bestSkill is null, no bestSkill has been selected for comparison
								// The skill currently being evaluated is the bestSkill so far
								bestSkill = skill;
								System.out.println("bestSkill is " + bestSkill.getName());
							}
						} else {
							System.out.println(skill.getName() + " does not have buff value, or does not meet mana/hp requirements.");
						}
					}
				} else if(bestAction.equals("DebuffSkill")) {
					System.out.println("bestAction is DebuffSkill.");
					// If bestAction is DebuffSkill, then the player wants to debuff the enemy
					// When selecting which debuff to apply, the player will tend to apply the longest lasting debuffs first
					// bestSkill will be the debuff skill with the longest duration
					for(Skill skill:p.getSkills()) {
						System.out.println("Evaluating " + skill.getName());
						if(skill.getDebuffValue() > 0 &&
								((strat.equals("Devensive") &&
										p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f &&
										skill.getHeal() >= 0) ||
										(strat.equals("Balanced") &&
												p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.5f &&
												p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.5f) ||
										(strat.equals("Aggressive") &&
												p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.25f &&
												p.getHP() + skill.getHeal() * p.getMaxHP() >= p.getMaxHP() * 0.25f))) {
							System.out.println(skill.getName() + " has debuff value and meets mana/hp requirements.");
							// Skill has a debuff value
							// Defensive strategies will go below 50% mana, and will not sacrifice hp
							// Balanced strategies will not go below 50% mana or hp
							// Aggressive strategies will not go below 25% mana or hp
							if(bestSkill != null) {
								System.out.println("bestSkill is " + bestSkill.getName());
								if(skill.getDuration() > bestSkill.getDuration() ||
										(skill.getDuration() == bestSkill.getDuration() &&
										skill.getDebuffValue() > bestSkill.getDebuffValue())) {
									System.out.println(skill.getName() + " is better than " + bestSkill.getName());
									// Skill being evaluated has a longer duration that bestSkill, or has the same duration but a better buff value
									bestSkill = skill;
									System.out.println(bestSkill.getName() + " is bestSkill.");
								} else {
									System.out.println(bestSkill.getName() + " is better than " + skill.getName());
								}
							} else {
								System.out.println("No current bestSkill.");
								// If bestSkill is null, no bestSkill has been selected for comparison
								// The skill currently being evaluated is the bestSkill so far
								bestSkill = skill;
								System.out.println(bestSkill.getName() + " is bestSkill.");
							}
						} else {
							System.out.println(skill.getName() + " does not have debuff value, or does not meet mana/hp requirements.");
						}
					}
				} else if(bestAction.equals("AttackSkill")) {
					System.out.println("bestAction is AttackSkill.");
					skillDam = 0;
					bestSkillDam = 0;
					for(Skill skill:p.getSkills()) {
						System.out.println("Evaluating " + skill.getName());
						if((strat.equals("Balanced") &&
								p.getMana() - skill.getManaCost() >= p.getMaxMana() * 0.25f &&
								p.getHP() + p.getMaxHP() * skill.getHeal() >= p.getMaxHP() * 0.5f) ||
								(strat.equals("Aggressive") &&
										p.getHP() + p.getMaxHP() * skill.getHeal() >= p.getMaxHP() * 0.25f)) {
							System.out.println(skill.getName() + " meets mana/hp requirements.");
							// Balanced strategies will not go below 25% mana or 50% hp
							// Aggressive strategies will not go below 25% hp

							if((pStrongest.equals("Physical") && skill.getPAtk() > 0) ||
									(pStrongest.equals("Magic") && skill.getMAtk() > 0)) {
								System.out.println(skill.getName() + " would buff strongest attack.");
								skillDam = atkAdj((int) Math.round(p.getPAtk() + p.getBasePAtk() * skill.getPAtk()), e.getPDef(), p.getRange()) + atkAdj((int) Math.round(p.getMAtk() + p.getBaseMAtk() * skill.getMAtk()), e.getMDef(), p.getRange());
								if(skillDam > e.getHP()) {
									// If skill would overkill enemy, set skillDam equal to enemy current HP
									skillDam = e.getHP();
								}
								System.out.println(skill.getName() + " would deal " + skillDam + " damage.");
								if(bestSkill != null) {
									System.out.println("Current bestSkill is " + bestSkill.getName());
									System.out.println(bestSkill.getName() + " would deal " + bestSkillDam);
									if(skillDam > bestSkillDam ||
											(skillDam == bestSkillDam && skill.getManaCost() < bestSkill.getManaCost()) ||
											(skillDam == bestSkillDam && skill.getManaCost() == bestSkill.getManaCost() && skill.getHeal() > bestSkill.getHeal())) {
										System.out.println(skill.getName() + " is better than " + bestSkill.getName());
										// If skill would deal more damage than bestSkill, or would deal the same amount of damage and cost less, or would deal the same amount of damage, cost the same, and sacrifice less HP
										bestSkill = skill;
										bestSkillDam = skillDam;
										System.out.println(bestSkill.getName() + " is new bestSkill.");
									} else {
										System.out.println(bestSkill.getName() + " is better than " + skill.getName());
									}
								} else {
									System.out.println("No current bestSkill.");
									// If bestSkill is null, no bestSkill has been selected for comparison
									bestSkill = skill;
									bestSkillDam = skillDam;
									System.out.println(bestSkill.getName() + " is bestSkill.");
								}
							} else {
								System.out.println(skill.getName() + " would not buff strongest attack.");
							}
						} else {
							System.out.println(skill.getName() + " does not meet mana/hp requirements.");
						}
					}
				}
				System.out.println();
				if(bestSkill != null) {
					System.out.println(bestSkill.getName() + " is bestSkill.");
					System.out.println("Using " + bestSkill.getName());
					// If bestSkill is not null, then a bestSkill was found
					int index = p.getIndexOfSkill(bestSkill);
					useWText(p, e, bestSkill, turn);
					// Add 1 to list of uses for that skill
				} else {
					System.out.println("No bestSkill found.\nUsing basicAttack.");
					// If bestSkill is null, use a basic attack
					hit = calcHit(p.getAcc(), e.getEva());
					if(hit) {
						System.out.println("Hit.");
						pDam = atkAdj(p.getPAtk(), e.getPDef(), p.getRange());
						mDam = atkAdj(p.getMAtk(), e.getMDef(), p.getRange());
						dam = pDam + mDam;
						e.adjHP(-1 * dam);
						System.out.println("Dealt " + dam + " damage.");
					} else {
						System.out.println("Missed.");
					}
				}
				numTurns++;
				turn++;
			} else {
				System.out.println("Enemy turn.");
				// Enemy turn
				hit = calcHit(e.getAcc(), p.getEva());
				if(hit) {
					System.out.println("Hit.");
					pDam = atkAdj(e.getPAtk(), p.getPDef(), e.getRange());
					mDam = atkAdj(e.getMAtk(), p.getMDef(), e.getRange());
					dam = pDam + mDam;
					p.adjHP(-1 * dam);
					System.out.println("Dealt " + dam + " damage.");
				} else {
					System.out.println("Missed.");
				}
				turn++;
			}
		}
		if(p.getHP() <= 0) {
			System.out.println("Player Loses!");
		} else if(e.getHP() <= 0) {
			System.out.println("Player Wins!");
		}
		p.fullHeal();
		e.fullHeal();
	}

	// Called when player activates a skill
	// Modifies player and enemy stats based on skill values
	// Stores increase or decrease values within that skill for use when the skill resets
	public void useSkill(Player p, Enemy e, Skill skill, int turn) {
		int pAtk;
		int pDef;
		int mAtk;
		int mDef;
		int eva;
		int accMod;
		int dPAtk;
		int dPDef;
		int dMAtk;
		int dMDef;
		int dAcc;
		int dEva;

		// If skill costs mana, subtract that mana now
		if(skill.getManaCost() > 0) {
			p.adjMana(-1 * skill.getManaCost());
		} 
		// If skill sacrifices health, sacrifice that health now
		if(skill.getHeal() < 0) {
			int selfDam = (int) Math.ceil(p.getMaxHP() * skill.getHeal());
			p.adjHP(selfDam);
		}
		// Determine if skill hits
		boolean hit = calcHit(p.getAcc() + skill.getAcc(), e.getEva());
		if(!skill.getHitToBuff() || (skill.getHitToBuff() && hit)) {
			// If skill does not have to hit, or if skill has to hit and hits successfully
			// Adjust PAtk and store that value
			pAtk = Math.round(p.getBasePAtk() * skill.getPAtk());
			p.adjPAtk(pAtk);
			skill.storeValue("pAtk", pAtk);
			// Adjust PDef and store that value
			pDef = Math.round(p.getBasePDef() * skill.getPDef());
			p.adjPDef(pDef);
			skill.storeValue("pDef", pDef);
			// Adjust MAtk and store that value
			mAtk = Math.round(p.getBaseMAtk() * skill.getMAtk());
			p.adjMAtk(mAtk);
			skill.storeValue("mAtk", mAtk);
			// Adjust MDef and store that value
			mDef = Math.round(p.getBaseMDef() * skill.getMDef());
			p.adjMDef(mDef);
			skill.storeValue("mDef", mDef);
			// Adjust Eva and store that value
			eva = Math.round(p.getBaseEva() * skill.getEva());
			p.adjEva(eva);
			skill.storeValue("eva", eva);
			// Adjust Acc and store that value
			accMod = Math.round(p.getBaseAcc() * skill.getAccMod());
			p.adjAcc(accMod);
			skill.storeValue("accMod", accMod);
			// If skill has a heal affect, heal that much hp
			if(skill.getHeal() > 0) {
				int healed = Math.round(skill.getHeal() * p.getMaxHP());
				p.adjHP(healed);
				if(p.getHP() > p.getMaxHP()) {
					p.setHP(p.getMaxHP());
				}
			}
			// If skill recovers mana, regain that much mana
			if(skill.getManaCost() < 0) {
				p.adjMana(-1 * skill.getManaCost());
			}
			// Adjust enemy PAtk and store that value
			dPAtk = Math.round(e.getBasePAtk() * skill.getDPAtk());
			e.adjPAtk(dPAtk);
			skill.storeValue("dPAtk", dPAtk);
			// Adjust enemy PDef and store that value
			dPDef = Math.round(e.getBasePDef() * skill.getDPDef());
			e.adjPDef(dPDef);
			skill.storeValue("dPDef", dPDef);
			// Adjust enemy MAtk and store that value
			dMAtk = Math.round(e.getBaseMAtk() * skill.getDMAtk());
			e.adjMAtk(dMAtk);
			skill.storeValue("dMAtk", dMAtk);
			// Adjust enemy MDef and store that value
			dMDef = Math.round(e.getBaseMDef() * skill.getDMDef());
			e.adjMDef(dMDef);
			skill.storeValue("dMDef", dMDef);
			// Adjust enemy Acc and store that value
			dAcc = Math.round(e.getBaseAcc() * skill.getDAcc());
			e.adjAcc(dAcc);
			skill.storeValue("dAcc", dAcc);
			// Adjust enemy Eva and store that value
			dEva = Math.round(e.getBaseEva() * skill.getDEva());
			e.adjEva(dEva);
			skill.storeValue("dEva", dEva);

			if((skill.getPAtk() > -1 || skill.getMAtk() > -1) && hit) {
				// If skill hit and has a PAtk or MAtk value, deal damage
				int pDam = atkAdj(p.getPAtk(), e.getPDef(), skill.getRange());
				int mDam = atkAdj(p.getMAtk(), e.getMDef(), skill.getRange());
				int dam = pDam + mDam;
				e.adjHP(-1 * dam);
			}
			// Set BuffEnd and AtkBuffEnd equal to durations plus current turn value
			skill.setBuffEnd(turn + skill.getDuration());
			skill.setAtkBuffEnd(turn + skill.getAtkDuration());
		}
	}

	// Uses skill with text print
	public void useWText(Player p, Enemy e, Skill skill, int turn) {
		int pAtk;
		int pDef;
		int mAtk;
		int mDef;
		int eva;
		int accMod;
		int dPAtk;
		int dPDef;
		int dMAtk;
		int dMDef;
		int dAcc;
		int dEva;
		System.out.println(p.getName() + " uses " + skill.getName() + "!");
		if(skill.getManaCost() > 0) {	
			p.adjMana(-1 * skill.getManaCost());
		}
		if(skill.getHeal() < 0) {
			int selfDam = (int) Math.ceil(p.getMaxHP() * skill.getHeal());
			p.adjHP(selfDam);
			System.out.println("Sacrificed " + (-1 * selfDam) + " HP!");
		}
		boolean hit = calcHit(p.getAcc() + skill.getAcc(), e.getEva());
		if(!skill.getHitToBuff() || (skill.getHitToBuff() && hit)) {
			if(skill.getAtkDuration() > 1) {
				if(skill.getPAtk() > 0) {
					System.out.println("Physical Attack Up!");
				} else if(skill.getPAtk() < 0) {
					System.out.println("Physical Defense Down!");
				}
			}
			pAtk = Math.round(p.getBasePAtk() * skill.getPAtk());
			p.adjPAtk(pAtk);
			skill.storeValue("pAtk", pAtk);
			if(skill.getPDef() > 0) {
				System.out.println("Physical Defense Up!");
			} else if(skill.getPDef() < 0) {
				System.out.println("Physical Defense Down!");
			}
			pDef = Math.round(p.getBasePDef() * skill.getPDef());
			p.adjPDef(pDef);
			skill.storeValue("pDef", pDef);
			if(skill.getAtkDuration() > 1) {
				if(skill.getMAtk() > 0) {
					System.out.println("Magic Attack Up!");
				} else if(skill.getMAtk() < 0) {
					System.out.println("Magic Attack Down!");
				}
			}
			mAtk = Math.round(p.getBaseMAtk() * skill.getMAtk());
			p.adjMAtk(mAtk);
			skill.storeValue("mAtk", mAtk);
			if(skill.getMDef() > 0) {
				System.out.println("Magic Defense Up!");
			} else if(skill.getMDef() < 0) {
				System.out.println("Magic Defense Down!");
			}
			mDef = Math.round(p.getBaseMDef() * skill.getMDef());
			p.adjMDef(mDef);
			skill.storeValue("mDef", mDef);
			if(skill.getEva() > 0) {
				System.out.println("Evasion Up!");
			} else if(skill.getEva() < 0) {
				System.out.println("Evasion Down!");
			}
			eva = Math.round(p.getBaseEva() * skill.getEva());
			p.adjEva(eva);
			skill.storeValue("eva", eva);
			if(skill.getAccMod() > 0) {
				System.out.println("Accuracy Up!");
			} else if(skill.getAccMod() < 0) {
				System.out.println("Accuracy Down!");
			}
			accMod = Math.round(p.getBaseAcc() * skill.getAccMod());
			p.adjAcc(accMod);
			skill.storeValue("accMod", accMod);
			if(skill.getHeal() > 0) {
				int healed = Math.round(skill.getHeal() * p.getMaxHP());
				if(p.getHP() + healed > p.getMaxHP()) {
					healed = p.getMaxHP() - p.getHP();
				}
				p.adjHP(healed);
				System.out.println("Healed " + healed + " HP!");
			}
			if(skill.getManaCost() < 0) {
				int manaRecovered = -1 * skill.getManaCost();
				if(p.getMana() + manaRecovered > p.getMaxMana()) {
					manaRecovered = p.getMaxMana() - p.getMana();
				}
				p.adjMana(manaRecovered);
				System.out.println("Recovered " + manaRecovered + " mana!");
			}
			if(skill.getDPAtk() < 0) {
				System.out.println(e.getName() + " Physical Attack Down!");
			} else if(skill.getDPAtk() > 0) {
				System.out.println(e.getName() + " Physical Attack Up!");
			}
			dPAtk = Math.round(e.getBasePAtk() * skill.getDPAtk());
			e.adjPAtk(dPAtk);
			skill.storeValue("dPAtk", dPAtk);
			if(skill.getDPDef() < 0) {
				System.out.println(e.getName() + " Physical Defense Down!");
			} else if(skill.getDPDef() > 0) {
				System.out.println(e.getName() + " Physical Defense Up!");
			}
			dPDef = Math.round(e.getBasePDef() * skill.getDPDef());
			e.adjPDef(dPDef);
			skill.storeValue("dPDef", dPDef);
			if(skill.getDMAtk() < 0) {
				System.out.println(e.getName() + " Magic Attack Down!");
			} else if(skill.getDMAtk() > 0) {
				System.out.println(e.getName() + " Magic Attack Up!");
			}
			dMAtk = Math.round(e.getBaseMAtk() * skill.getDMAtk());
			e.adjMAtk(dMAtk);
			skill.storeValue("dMAtk", dMAtk);
			if(skill.getDMDef() < 0) {
				System.out.println(e.getName() + " Magic Defense Down!");
			} else if(skill.getDMDef() > 0) {
				System.out.println(e.getName() + " Magic Defense Up!");
			}
			dMDef = Math.round(e.getBaseMDef() * skill.getDMDef());
			e.adjMDef(dMDef);
			skill.storeValue("dMDef", dMDef);
			if(skill.getDAcc() < 0) {
				System.out.println(e.getName() + " Accuracy Down!");
			} else if(skill.getDAcc() > 0) {
				System.out.println(e.getName() + " Accuracy Up!");
			}
			dAcc = Math.round(e.getBaseAcc() * skill.getDAcc());
			e.adjAcc(dAcc);
			skill.storeValue("dAcc", dAcc);
			if(skill.getDEva() < 0) {
				System.out.println(e.getName() + " Evasion Down!");
			} else if(skill.getDEva() > 0) {
				System.out.println(e.getName() + " Evasion Up!");
			}
			dEva = Math.round(e.getBaseEva() * skill.getDEva());
			e.adjEva(dEva);
			skill.storeValue("dEva", dEva);
			if((skill.getPAtk() > -1 || skill.getMAtk() > -1) && hit) {
				int pDam = atkAdj(p.getPAtk(), e.getPDef(), skill.getRange());
				int mDam = atkAdj(p.getMAtk(), e.getMDef(), skill.getRange());
				int dam = pDam + mDam;
				System.out.println(p.getName() + " dealt " + dam + " damage!");
				e.adjHP(-1 * dam);
			}
			skill.setBuffEnd(turn + skill.getDuration());
			skill.setAtkBuffEnd(turn + skill.getAtkDuration());
		}
	}

	// Get all stored values and adjust player/enemy stats
	public void resetSkill(Player p, Enemy e, Skill skill, boolean wText) {
		int pDef = skill.getStoredValue("pDef");
		int mDef = skill.getStoredValue("mDef");
		int eva = skill.getStoredValue("eva");
		int acc = skill.getStoredValue("accMod");
		int dPAtk = skill.getStoredValue("dPAtk");
		int dPDef = skill.getStoredValue("dPDef");
		int dMAtk = skill.getStoredValue("dMAtk");
		int dMDef = skill.getStoredValue("dMDef");
		int dAcc = skill.getStoredValue("dAcc");
		int dEva = skill.getStoredValue("dEva");
		p.adjPDef(-1 * pDef);
		p.adjMDef(-1 * mDef);
		p.adjEva(-1 * eva);
		p.adjAcc(-1 * acc);
		e.adjPAtk(-1 * dPAtk);
		e.adjPDef(-1 * dPDef);
		e.adjMAtk(-1 * dMAtk);
		e.adjMDef(-1 * dMDef);
		e.adjAcc(-1 * dAcc);
		e.adjEva(-1 * dEva);
		if(wText) {
			if(skill.getDuration() > 1) {
				System.out.println(skill.getName() + " wears off!");
			}
		}
		skill.setBuffEnd(0);
	}

	// Get stored pAtk and mAtk values, adjust player stats
	public void atkEnd(Player p, Skill skill) {
		int pAtk = skill.getStoredValue("pAtk");
		int mAtk = skill.getStoredValue("mAtk");
		p.adjPAtk(-1 * pAtk);
		p.adjMAtk(-1 * mAtk);
		skill.setAtkBuffEnd(0);
	}

	// Determines if an attack hits
	// Accuracy is chance to hit out of 100
	// Evasion reduces accuracy
	// Hit chance is acc - eva
	// Miss chance is 100 - hit chance
	// Hit roll is random number between 1 and 100
	// If hit roll is less than miss chance, attack misses
	// Otherwise attack hits
	private boolean calcHit(int acc, int eva) {
		int hitChance = acc - eva;
		int missChance = 100 - hitChance;
		int hit = rand.nextInt(100) + 1;
		if(hit < missChance) {
			return false;
		} else {
			return true;
		}
	}

	// Adjusts damage based on attack, defense, and range of attack
	//
	// Range * 10 is percentage by which attack can spread, so Range of 2 can spread damage +/- 20%
	//
	// Find lower bound by 10 - range
	// Find range of random numbers by (range * 2) + 1
	// Find a random integer within random range, add lower bound to get modifier int
	// Get attackModFloat by dividing attack modifier int by 10
	// Get modified damage value by multiplying attack by attackModFloat
	//
	// Defense reduces damage by that percentage, so Defense of 40 would reduce damage by 40%
	// Find modified defense value by (100 - def) / 100
	//
	// Find final damage output by multiplying modifiedAttack by modifiedDefense, then rounding to the next highest integer
	//
	// EXAMPLE
	//
	// Attack 40, Defense 20, Range 2
	//
	// lowerBound = 10 - range = 10 - 2 = 8
	// randomRange = (range * 2) + 1 = (2 * 2) + 1 = 5
	// attackModInt = rand.nextInt(randomRange) + lowerBound = rand.nextInt(5) + 8 = 8 - 12
	// attackModInt = 9
	// attackModFloat = attackModInt / 10 = 9 / 10 = 0.9
	// modifiedAttack = atk * attackModFloat = 40 * 0.9 = 36
	// modifiedDefense = (100 - def) / 100 = (100 - 20) / 100 = 0.8
	// dam = Math.ceil(modifiedAttack * modifiedDefense) = Math.ceil(36 * 0.8) = 29
	// Attack 40, Defense 20, Range 2, Dam 29
	private int atkAdj(int atk, int def, int range) {
		int lowerBound = 10 - range;
		int randomRange = (range * 2) + 1;
		int attackModInt = rand.nextInt(randomRange) + lowerBound;
		float attackModFloat = (attackModInt / 10f);
		float modifiedAttack = atk * attackModFloat;

		float modifiedDefense = (100 - def) / 100f;
		
		int dam = (int) Math.ceil(modifiedAttack * modifiedDefense);

		if(dam <= 0) {
			return 0;
		} else {
			return dam;
		}
	}
	
	// Debug code printing attack adj logic
	private int atkAdjDebug(int atk, int def, int range) {
		System.out.println("atkAdj");
		System.out.println("atk: " + atk);
		System.out.println("def: " + def);
		System.out.println("range: " + range);
		int lowerBound = 10 - range;
		System.out.println("lowerBound: " + lowerBound);
		int randomRange = (range * 2) + 1;
		System.out.println("randomRange: " + randomRange);
		System.out.println("Lowest Possible: " + lowerBound);
		System.out.println("Highest Possible: " + (randomRange - 1 + lowerBound));
		int attackModInt = rand.nextInt(randomRange) + lowerBound;
		System.out.println("attackModInt: " + attackModInt);
		float attackModFloat = (attackModInt / 10f);
		System.out.println("attackModFloat: " + attackModFloat);
		float modifiedAttack = atk * attackModFloat;
		System.out.println("modifiedAttack: " + modifiedAttack);

		float modifiedDefense = (100 - def) / 100f;
		System.out.println("modifiedDefense: " + modifiedDefense);
		
		System.out.println("modifiedAttack * modifiedDefense: " + (modifiedAttack * modifiedDefense));
		int dam = (int) Math.ceil(modifiedAttack * modifiedDefense);
		System.out.println("(int) Math.ceil(modifiedAttack * modifiedDefense) " + dam);

		if(dam <= 0) {
			System.out.println("dam <= 0\nReturning 0");
			return 0;
		} else {
			System.out.println("Returning " + dam);
			return dam;
		}
	}

}
