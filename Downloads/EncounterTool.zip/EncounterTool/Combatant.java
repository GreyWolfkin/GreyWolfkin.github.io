/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

/*
 * Superclass for Player and Enemy objects
 * Handles get/set/adj for all shared stats
 * Stats can be modified above or below their Base value
 * HP cannot be greater than Max
 */

public class Combatant {

	protected String name;
	protected int maxHP;
	protected int hp;
	protected int basePAtk;
	protected int pAtk;
	protected int basePDef;
	protected int pDef;
	protected int baseMAtk;
	protected int mAtk;
	protected int baseMDef;
	protected int mDef;
	protected int baseAcc;
	protected int acc;
	protected int baseEva;
	protected int eva;
	protected int range;

	public Combatant(String name, int maxHP, int basePAtk, int basePDef, int baseMAtk, int baseMDef, int baseAcc, int baseEva, int range) {
		this.name = name;
		this.maxHP = maxHP;
		this.hp = maxHP;
		this.basePAtk = basePAtk;
		this.pAtk = basePAtk;
		this.basePDef = basePDef;
		if(basePDef > 100) {
			// PDef cannot be greater than 100
			basePDef = 100;
		}
		this.pDef = basePDef;
		this.baseMAtk = baseMAtk;
		this.mAtk = baseMAtk;
		this.baseMDef = baseMDef;
		if(baseMDef > 100) {
			// MDef cannot be greater than 100
			baseMDef = 100;
		}
		this.mDef = baseMDef;
		this.baseAcc = baseAcc;
		this.acc = baseAcc;
		this.baseEva = baseEva;
		this.eva = baseEva;
		this.range = range;
	}

	public String getName() {
		return name;
	}
	public void setName(String set) {
		name = set;
	}
	
	public int getMaxHP() {
		return maxHP;
	}
	public void setMaxHP(int set) {
		maxHP = set;
	}
	public void adjMaxHP(int adj) {
		maxHP += adj;
	}

	public int getHP() {
		return hp;
	}
	public void setHP(int set) {
		hp = set;
		if(hp > maxHP) {
			hp = maxHP;
		}
	}
	public void adjHP(int adj) {
		hp += adj;
		if(hp > maxHP) {
			hp = maxHP;
		}
	}

	public int getBasePAtk() {
		return basePAtk;
	}
	public void setBasePAtk(int set) {
		basePAtk = set;
		if(basePAtk < 0) {
			basePAtk = 0;
		}
	}
	public void adjBasePAtk(int adj) {
		basePAtk += adj;
		if(basePAtk < 0) {
			basePAtk = 0;
		}
	}

	public int getPAtk() {
		return pAtk;
	}
	public void setPAtk(int set) {
		pAtk = set;
		if(pAtk < 0) {
			pAtk = 0;
		}
	}
	public void adjPAtk(int adj) {
		pAtk += adj;
		if(pAtk < 0) {
			pAtk = 0;
		}
	}

	public int getBasePDef() {
		return basePDef;
	}
	public void setBasePDef(int set) {
		basePDef = set;
		if(basePDef < 0) {
			basePDef = 0;
		} else if(basePDef > 100) {
			basePDef = 100;
		}
	}
	public void adjBasePDef(int adj) {
		basePDef += adj;
		if(basePDef < 0) {
			basePDef = 0;
		} else if(basePDef > 100) {
			basePDef = 100;
		}
	}

	public int getPDef() {
		return pDef;
	}
	public void setPDef(int set) {
		pDef = set;
		if(pDef < 0) {
			pDef = 0;
		}
	}
	public void adjPDef(int adj) {
		pDef += adj;
		if(pDef < 0) {
			pDef = 0;
		}
	}

	public int getBaseMAtk() {
		return baseMAtk;
	}
	public void setBaseMAtk(int set) {
		baseMAtk = set;
		if(baseMAtk < 0) {
			baseMAtk = 0;
		}
	}
	public void adjBaseMAtk(int adj) {
		baseMAtk += adj;
		if(baseMAtk < 0) {
			baseMAtk = 0;
		}
	}

	public int getMAtk() {
		return mAtk;
	}
	public void setMAtk(int set) {
		mAtk = set;
		if(mAtk < 0) {
			mAtk = 0;
		}
	}
	public void adjMAtk(int adj) {
		mAtk += adj;
		if(mAtk < 0) {
			mAtk = 0;
		}
	}

	public int getBaseMDef() {
		return baseMDef;
	}
	public void setBaseMDef(int set) {
		baseMDef = set;
		if(baseMDef < 0) {
			baseMDef = 0;
		} else if(baseMDef > 100) {
			baseMDef = 100;
		}
	}
	public void adjBaseMDef(int adj) {
		baseMDef += adj;
		if(baseMDef < 0) {
			baseMDef = 0;
		} else if(baseMDef > 100) {
			baseMDef = 100;
		}
	}

	public int getMDef() {
		return mDef;
	}
	public void setMDef(int set) {
		mDef = set;
		if(mDef < 0) {
			mDef = 0;
		}
	}
	public void adjMDef(int adj) {
		mDef += adj;
		if(mDef < 0) {
			mDef = 0;
		}
	}

	public int getBaseAcc() {
		return baseAcc;
	}
	public void setBaseAcc(int set) {
		baseAcc = set;
		if(baseAcc > 100) {
			baseAcc = 100;
		} else if(baseAcc < 0) {
			baseAcc = 0;
		}
	}
	public void adjBaseAcc(int adj) {
		baseAcc += adj;
		if(baseAcc > 100) {
			baseAcc = 100;
		} else if(baseAcc < 0) {
			baseAcc = 0;
		}
	}

	public int getAcc() {
		return acc;
	}
	public void setAcc(int set) {
		acc = set;
		if(acc > 100) {
			acc = 100;
		} else if(acc < 0) {
			acc = 0;
		}
	}
	public void adjAcc(int adj) {
		acc += adj;
		if(acc > 100) {
			acc = 100;
		} else if(acc < 0) {
			acc = 0;
		}
	}

	public int getBaseEva() {
		return baseEva;
	}
	public void setBaseEva(int set) {
		baseEva = set;
		if(baseEva > 100) {
			baseEva = 100;
		} else if(baseEva < 0) {
			baseEva = 0;
		}
	}
	public void adjBaseEva(int adj) {
		baseEva += adj;
		if(baseEva > 100) {
			baseEva = 100;
		} else if(baseEva < 0) {
			baseEva = 0;
		}
	}

	public int getEva() {
		return eva;
	}
	public void setEva(int set) {
		eva = set;
		if(eva > 100) {
			eva = 100;
		} else if(eva < 0) {
			eva = 0;
		}
	}
	public void adjEva(int adj) {
		eva += adj;
		if(eva > 100) {
			eva = 100;
		} else if(eva < 0) {
			eva = 0;
		}
	}
	
	public int getRange() {
		return range;
	}
	public void setRange(int set) {
		range = set;
		if(range < 0) {
			range = 0;
		}
	}
	public void adjRange(int adj) {
		range += adj;
		if(range < 0) {
			range = 0;
		}
	}
	
	public void fullHeal() {
		// Reset all stats to base/max
		hp = maxHP;
		pAtk = basePAtk;
		pDef = basePDef;
		mAtk = baseMAtk;
		mDef = baseMDef;
		acc = baseAcc;
		eva = baseEva;
	}
	
	public void printBaseStats() {
		System.out.println(name);
		System.out.println("HP: " + hp);
	}
	
	public void printAdtlStats() {
		System.out.println("PAtk: " + basePAtk + tabOut(basePAtk) + "PDef: " + basePDef);
		System.out.println("MAtk: " + baseMAtk + tabOut(baseMAtk) + "MDef: " + baseMDef);
		System.out.println("Acc: " + baseAcc + "\t\t\tEva: " + baseEva);
	}
	
	public void printAllStats() {
		printBaseStats();
		printAdtlStats();
	}
	
	protected String tabOut(int stat) {
		// Used to keep printed stats in line
		if(stat >= 10) {
			return "\t\t";
		} else {
			return "\t\t\t";
		}
	}

}
