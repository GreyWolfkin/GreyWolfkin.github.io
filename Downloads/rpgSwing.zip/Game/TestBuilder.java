import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TestBuilder extends JFrame {
	
	private JPanel name, job, hp, mana, gold, pots, townL, townB, innL, innB, shopL, shopB, forestL, forestB, stay, sword, armor, encounter;
	private JPanel null1, null2, null3, null4, null5, null6;
	private JLabel nameLabel, jobLabel, hpLabel, manaLabel, goldLabel, potsLabel, townLabel, innLabel, shopLabel, forestLabel;
	private JButton townButton, innButton, shopButton, forestButton, stayButton, swordButton, armorButton, encounterButton;
	
	public TestBuilder() {
		
		name = new JPanel();
		job = new JPanel();
		hp = new JPanel();
		mana = new JPanel();
		gold = new JPanel();
		pots = new JPanel();
		townL = new JPanel();
		townB = new JPanel();
		innL = new JPanel();
		innB = new JPanel();
		shopL = new JPanel();
		shopB = new JPanel();
		forestL = new JPanel();
		forestB = new JPanel();
		stay = new JPanel();
		sword = new JPanel();
		armor = new JPanel();
		encounter = new JPanel();
		
		null1 = new JPanel();
		null2 = new JPanel();
		null3 = new JPanel();
		null4 = new JPanel();
		null5 = new JPanel();
		null6 = new JPanel();
		
		nameLabel = new JLabel("Name");
		jobLabel = new JLabel("Class");
		hpLabel = new JLabel("HP");
		manaLabel = new JLabel("Mana");
		goldLabel = new JLabel("Gold");
		potsLabel = new JLabel("Potions");
		townLabel = new JLabel("Town");
		innLabel = new JLabel("Inn");
		shopLabel = new JLabel("Shop");
		forestLabel = new JLabel("Forest");
		
		townButton = new JButton("Town");
		innButton = new JButton("Inn");
		shopButton = new JButton("Shop");
		forestButton = new JButton("Forest");
		stayButton = new JButton("Stay");
		swordButton = new JButton("Sword");
		armorButton = new JButton("Armor");
		encounterButton = new JButton("Encounter");
		
		townButton.addActionListener(new MoveListener());
		innButton.addActionListener(new MoveListener());
		shopButton.addActionListener(new MoveListener());
		forestButton.addActionListener(new MoveListener());
		stayButton.addActionListener(new ButtonListener());
		swordButton.addActionListener(new ButtonListener());
		armorButton.addActionListener(new ButtonListener());
		encounterButton.addActionListener(new ButtonListener());
		
		name.add(nameLabel);
		job.add(jobLabel);
		hp.add(hpLabel);
		mana.add(manaLabel);
		gold.add(goldLabel);
		pots.add(potsLabel);
		townL.add(townLabel);
		townB.add(townButton);
		innL.add(innLabel);
		innB.add(innButton);
		shopL.add(shopLabel);
		shopB.add(shopButton);
		forestL.add(forestLabel);
		forestB.add(forestButton);
		stay.add(stayButton);
		sword.add(swordButton);
		armor.add(armorButton);
		encounter.add(encounterButton);
		
		setTitle("Town");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new GridLayout(5,3));
		add(name);
		add(null1);
		add(job);
		add(hp);
		add(null2);
		add(gold);
		add(mana);
		add(null3);
		add(pots);
		add(null4);
		add(townL);
		add(null5);
		add(innB);
		add(shopB);
		add(forestB);
		pack();
		setVisible(true);
	}
	
	private class MoveListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			reset();
			String input = e.getActionCommand();
			switch(input) {
				case "Town":
					add(null4);
					add(townL);
					add(null5);
					add(innB);
					add(shopB);
					add(forestB);
					pack();
					setVisible(true);
					break;
				case "Inn":
					add(null4);
					add(innL);
					add(null5);
					add(stay);
					add(null6);
					add(townB);
					pack();
					setVisible(true);
					break;
				case "Shop":
					add(null4);
					add(shopL);
					add(null5);
					add(sword);
					add(armor);
					add(townB);
					pack();
					setVisible(true);
					break;
				case "Forest":
					add(null4);
					add(forestL);
					add(null5);
					add(encounter);
					add(null6);
					add(townB);
					pack();
					setVisible(true);
					break;
			}
		}
	}
	
	private class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(null, "You clicked " + e.getActionCommand());
		}
	}
	
	public void reset() {
		setVisible(false);
		getContentPane().removeAll();
		add(name);
		add(null1);
		add(job);
		add(hp);
		add(null2);
		add(gold);
		add(mana);
		add(null3);
		add(pots);
	}
	
	public static void main(String[] args) {
		new TestBuilder();
	}
}