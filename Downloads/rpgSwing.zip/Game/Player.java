public class Player extends Unit {
	
	private String name, job, skill1, skill1Cost, skill2, skill2Cost;
	private int maxHP, hp, atk, def, maxMana, mana, gold, pots, swordIndex, armorIndex;
	
	Player(String name, String job) {
		setName(name);
		this.job = job;
		gold = 0;
		pots = 0;
		swordIndex = 0;
		armorIndex = 0;
		
		switch(this.job) {
			case "Fighter":
				setMaxHP(100);
				setHP(100);
				setMaxAtk(20);
				setAtk(20);
				setMaxDef(20);
				setDef(20);
				maxMana = 100;
				mana = 100;
				skill1 = "Slash";
				skill1Cost = "20";
				skill2 = "Shield Bash";
				skill2Cost = "10";
				break;
			case "Wizard":
				setMaxHP(70);
				setHP(70);
				setMaxAtk(10);
				setAtk(10);
				setMaxDef(0);
				setDef(0);
				maxMana = 200;
				mana = 200;
				skill1 = "Magic Missile";
				skill1Cost = "20";
				skill2 = "Frost Bolt";
				skill2Cost = "40";
				break;
			case "Rogue":
				setMaxHP(85);
				setHP(85);
				setMaxAtk(30);
				setAtk(30);
				setMaxDef(10);
				setDef(10);
				maxMana = 100;
				mana = 100;
				skill1 = "Backstab";
				skill1Cost = "20";
				skill2 = "Smoke Cloud";
				skill2Cost = "20";
				break;
		}
	}
	
	public String getJob() {
		return job;
	}
	public void setJob(String set) {
		job = set;
	}
	
	public int getMaxMana() {
		return maxMana;
	}
	public void setMaxMana(int set) {
		maxMana = set;
	}
	public void incMaxMana(int inc) {
		maxMana += inc;
	}
	public void decMaxMana(int dec) {
		maxMana -= dec;
	}
	
	public int getMana() {
		return mana;
	}
	public void setMana(int set) {
		mana = set;
	}
	public void incMana(int inc) {
		if ((mana+inc) > maxMana) {
			mana = maxMana;
		} else {
			mana += inc;
		}
	}
	public void decMana(int dec) {
		if ((mana-dec) < 0) {
			mana = 0;
		} else {
			mana -= dec;
		}
	}
	public void fullMana() {
		mana = maxMana;
	}
	
	public int getGold() {
		return gold;
	}
	public void setGold(int set) {
		gold = set;
	}
	public void incGold(int inc) {
		gold += inc;
	}
	public void decGold(int dec) {
		gold -= dec;
	}
	
	public int getSwordIndex() {
		return swordIndex;
	}
	public void setSwordIndex(int set) {
		swordIndex = set;
	}
	public void incSwordIndex(int inc) {
		swordIndex += inc;
	}
	public void decSwordIndex(int dec) {
		swordIndex -= dec;
	}
	
	public int getArmorIndex() {
		return armorIndex;
	}
	public void setArmorIndex(int set) {
		armorIndex = set;
	}
	public void incArmorIndex(int inc) {
		armorIndex += inc;
	}
	public void decArmorIndex(int dec) {
		armorIndex -= dec;
	}
	
	public String getSkill1() {
		return skill1;
	}
	public void setSkill1(String set) {
		skill1 = set;
	}
	
	public String getSkill1Cost() {
		return skill1Cost;
	}
	
	public String getSkill2Cost() {
		return skill2Cost;
	}
	
	public String getSkill2() {
		return skill2;
	}
	public void setSkill2(String set) {
		skill2 = set;
	}
	
	public int getPots() {
		return pots;
	}
	public void setPots(int set) {
		pots = set;
	}
	public void incPots(int inc) {
		pots += inc;
	}
	public void decPots(int dec) {
		pots -= dec;
	}
	
	public int skillCost(String skill) {
		int i = 0;
		switch(skill) {
			case "Slash":
				i = 20;
				break;
			case "Shield Bash":
				i = 10;
				break;
			case "Magic Missile":
				i = 20;
				break;
			case "Frost Bolt":
				i = 40;
				break;
			case "Backstab":
				i = 20;
				break;
			case "Smoke Cloud":
				i = 20;
		}
		return i;
	}
	
	public int useSkill(String skill) {
		int dam = 0;
		switch(skill) {
			case "Slash":
				dam = getAtk()*2;
				break;
			case "Shield Bash":
				dam = getDef();
				setDef(getDef()*2);
				break;
			case "Magic Missile":
				dam = getAtk()*5;
				break;
			case "Smoke Cloud":
				dam = getAtk()/3;
				setDef(100);
				break;
		}
		return dam;
	}
	
	public int useSkill(String skill, Enemy e) {
		int dam = 0;
		switch(skill) {
			case "Frost Bolt":
				dam = getAtk()*3;
				e.decAtk(e.getAtk()/2);
				break;
			case "Backstab":
				dam = getAtk();
				e.setDef(0);
				break;
		}
		return dam;
	}
}