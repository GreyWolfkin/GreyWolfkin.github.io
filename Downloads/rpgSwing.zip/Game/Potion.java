public class Potion extends Item {
	
	private String name;
	private int cost, hp;
	
	Potion() {
		name = "Potion";
		cost = 75;
		hp = 50;
	}
	
	public int getHP() {
		return hp;
	}
	public void setHP(int set) {
		hp = set;
	}
}