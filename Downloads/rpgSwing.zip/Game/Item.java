public class Item {
	
	private String name;
	private int cost;
	
	Item(String name) {
		this.name = name;
	}
	
	Item() {
		name = "";
	}
	
	public String getName() {
		return name;
	}
	public void setName(String set) {
		name = set;
	}
	
	public int getCost() {
		return cost;
	}
	public void setCost(int set) {
		cost = set;
	}
}