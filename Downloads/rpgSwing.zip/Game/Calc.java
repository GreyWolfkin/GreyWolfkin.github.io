import java.util.Random;

public class Calc {
	
	public Calc() {
		
	}
	
	static int atkAdj(int atk) {
		Random rand = new Random();
		int i = rand.nextInt(5);
		int j = 12-i;
		float k = (float) j/10.0f;
		int l = (int) Math.ceil(atk*k);
		return l;
	}
	
	static int damAdj(int atk, int def) {
		Random rand = new Random();
		int perc = rand.nextInt(5);
		int mult = 12 - perc;
		float multF = (float) mult/10.0f;
		int adjAtk = (int) Math.ceil(atk * multF);
		int defPerc = 100 - def;
		float defMult = (float) defPerc/100.0f;
		int dam = (int) Math.ceil(adjAtk * defMult);
		return dam;		
	}
	
	
	// 0 = Enemy goes first
	// 1 = Player goes first
	static int turn() {
		Random rand = new Random();
		int i = rand.nextInt(4);
		int turn = 0;;
		switch(i) {
			case 0:
				turn = 0;
				break;
			case 1:
			case 2:
			case 3:
				turn = 1;
				break;
		}
		return turn;
	}
}