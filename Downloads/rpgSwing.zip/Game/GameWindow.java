import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class GameWindow extends JFrame {
	
	private Calc calc = new Calc();
	private boolean run = true;
	private boolean debug = false;
	private int turn, dam;
	private String input;
	private Player p;
	private Enemy e, bat, gob, orc;
	private String nameIn, jobIn;
	
	private Potion potion;
	private Sword woodenSword, ironSword;
	private Armor leatherArmor, chainArmor;
	private ArrayList<Sword> swordList;
	private ArrayList<Armor> armorList;
	
	private JFrame nameFrame, jobFrame, exploreFrame, combatFrame, shopFrame;
	
	private JPanel namePanel;
	private JTextField nameField;
	
	private JPanel jobPanel;
	private JButton fighterB;
	private JButton wizardB;
	private JButton rogueB;
	
	private JPanel name, job, hp, gold, mana, pots;
	private JPanel eName, eHP;
	private JPanel town, inn, shop, forest, stay, sword, armor, encounter;
	private JPanel attackPanel, skill1Panel, skill2Panel, potPanel;
	private JPanel null1, null2, null3, null4, null5, null6, null7, null8, null9;
	
	private JLabel nameL, jobL, hpL, goldL, manaL, potsL;
	private JLabel eNameL, eHPL;
	
	private JLabel skill1L, skill2L;
	private JPanel skill1CostPanel, skill2CostPanel;
	
	private JButton townB, innB, shopB, forestB, stayB, swordB, armorB, encounterB;
	private JButton attackB, skill1B, skill2B, potB;
	
	private JPanel purchasePanel;
	private JLabel purchaseL;
	private JButton purchaseB, exitB;
	
	public GameWindow() {
		bat = new Enemy("Bat");
		gob = new Enemy("Goblin");
		orc = new Enemy("Orc");
		
		potion = new Potion();
		woodenSword = new Sword("Wooden Sword", 0, 0);
		ironSword = new Sword("Iron Sword", 200, 20);
		leatherArmor = new Armor("Leather Armor", 0, 0);
		chainArmor = new Armor("Chain Armor", 200, 15);
		
		swordList = new ArrayList<Sword>();
		swordList.add(woodenSword);
		swordList.add(ironSword);
		
		armorList = new ArrayList<Armor>();
		armorList.add(leatherArmor);
		armorList.add(chainArmor);
		
		nameFrame = new JFrame();
		jobFrame = new JFrame();
		exploreFrame = new JFrame();
		combatFrame = new JFrame();
		
		namePanel = new JPanel();
		nameField = new JTextField(10);
		nameField.addActionListener(new NameListener());
		
		jobPanel = new JPanel();
		fighterB = new JButton("Fighter");
		fighterB.addActionListener(new JobListener());
		wizardB = new JButton("Wizard");
		wizardB.addActionListener(new JobListener());
		rogueB = new JButton("Rogue");
		rogueB.addActionListener(new JobListener());
		
		name = new JPanel();
		job = new JPanel();
		hp = new JPanel();
		gold = new JPanel();
		mana = new JPanel();
		pots = new JPanel();
		
		eName = new JPanel();
		eHP = new JPanel();
		
		town = new JPanel();
		inn = new JPanel();
		shop = new JPanel();
		forest = new JPanel();
		stay = new JPanel();
		sword = new JPanel();
		armor = new JPanel();
		encounter = new JPanel();
		attackPanel = new JPanel();
		skill1Panel = new JPanel();
		skill2Panel = new JPanel();
		potPanel = new JPanel();
		
		null1 = new JPanel();
		null2 = new JPanel();
		null3 = new JPanel();
		null4 = new JPanel();
		null5 = new JPanel();
		null6 = new JPanel();
		null7 = new JPanel();
		null8 = new JPanel();
		null9 = new JPanel();
		
		eNameL = new JLabel("");
		eHPL = new JLabel("");
		
		townB = new JButton("Town");
		innB = new JButton("Inn");
		shopB = new JButton("Shop");
		forestB = new JButton("Forest");
		
		townB.addActionListener(new MoveListener());
		innB.addActionListener(new MoveListener());
		shopB.addActionListener(new MoveListener());
		forestB.addActionListener(new MoveListener());
		
		stayB = new JButton("Stay - 100g");
		swordB = new JButton("Sword");
		armorB = new JButton("Armor");
		encounterB = new JButton("Encounter");
		
		stayB.addActionListener(new ActListener());
		swordB.addActionListener(new ActListener());
		armorB.addActionListener(new ActListener());
		encounterB.addActionListener(new ActListener());
		
		attackB = new JButton("Attack");
		potB = new JButton("Potion");
		
		attackB.addActionListener(new SkillListener());
		potB.addActionListener(new SkillListener());
		
		namePanel.add(nameField);
		
		jobPanel.add(fighterB);
		jobPanel.add(wizardB);
		jobPanel.add(rogueB);
		
		eName.add(eNameL);
		eHP.add(eHPL);
		
		town.add(townB);
		inn.add(innB);
		shop.add(shopB);
		forest.add(forestB);
		stay.add(stayB);
		sword.add(swordB);
		armor.add(armorB);
		encounter.add(encounterB);
		attackPanel.add(attackB);
		potPanel.add(potB);
		
		nameFrame.setTitle("What is your name?");
		nameFrame.setSize(600,200);
		nameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		nameFrame.add(namePanel);
		nameFrame.setVisible(true);
		
		jobFrame.setTitle("Choose your Class");
		jobFrame.setSize(400,400);
		jobFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jobFrame.add(jobPanel);
		
		exploreFrame.setTitle("Town");
		exploreFrame.setLayout(new GridLayout(5,3));
		exploreFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		combatFrame.setLayout(new GridLayout(7,3));
		combatFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void getRandomEnemy() {
		Random rand = new Random();
		e = bat;
		int i = rand.nextInt(10) + 1;
		switch(i) {
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
				e = bat;
				break;
			case 6:
			case 7:
			case 8:
				e = gob;
				break;
			case 9:
			case 10:
				e = orc;
				break;
		}
		switch(e.getName()) {
			case "Bat":
				JOptionPane.showMessageDialog(null, "A bat comes swooping from out of the trees!");
				break;
			case "Goblin":
				JOptionPane.showMessageDialog(null, "Hideous laughter alerts you to the presence of a goblin!");
				break;
			case "Orc":
				JOptionPane.showMessageDialog(null, "A towering orc lumbers towards you!");
				break;
		}
	}
	
	public void combatFirstTurn() {
		turn = calc.turn();
		if(turn == 0) {
			JOptionPane.showMessageDialog(null, e.getName() + " strikes first!");
		} else {
			JOptionPane.showMessageDialog(null, p.getName() + " strikes first!");
		}
		dam = 0;
		setLabels();
		switch(turn) {
			case 0:
				e.defaultDef();
				dam = calc.damAdj(e.getAtk(),p.getDef());
				JOptionPane.showMessageDialog(null, e.getName() + " dealt " + dam + " damage!");
				p.decHP(dam);
				if (p.getHP() <= 0) {
					JOptionPane.showMessageDialog(null, "Overcome by your wounds, your vision fades... slowly... to black...");
					run = false;
				} else {
					turn = 1;
					combat();
				}
				e.defaultAtk();
				break;
			case 1:
				p.defaultDef();
				startTurn();
				break;
		}
		if (p.getHP() <= 0) {
			JOptionPane.showMessageDialog(null, "Overcome by your wounds, your vision fades... slowly... to black...");
			run = false;
		} else if (e.getHP() <= 0) {
			combatWin();
		} else {
			combat();
		}
	}
	
	public void combat() {
		dam = 0;
		setLabels();
		if (p.getHP() > 0 && e.getHP() > 0) {
			switch(turn) {
				case 0:
					e.defaultDef();
					dam = calc.damAdj(e.getAtk(),p.getDef());
					JOptionPane.showMessageDialog(null, e.getName() + " dealt " + dam + " damage!");
					p.decHP(dam);
					if (p.getHP() <= 0) {
						JOptionPane.showMessageDialog(null, "Overcome by your wounds, your vision fades... slowly... to black...");
						System.exit(0);
					} else {
						turn = 1;
						combat();
					}
					e.defaultAtk();
					break;
				case 1:
					p.defaultDef();
					startTurn();
					break;
			}
		}
	}
	
	public void exploreStats() {
		exploreFrame.getContentPane().removeAll();
		exploreFrame.add(name);
		exploreFrame.add(null1);
		exploreFrame.add(job);
		exploreFrame.add(hp);
		exploreFrame.add(null2);
		exploreFrame.add(gold);
		exploreFrame.add(mana);
		exploreFrame.add(null3);
		exploreFrame.add(pots);
		exploreFrame.add(null4);
		exploreFrame.add(null5);
		exploreFrame.add(null6);
	}
	
	public void combatStats() {
		combatFrame.setTitle("Combat");
		combatFrame.add(name);
		combatFrame.add(null1);
		combatFrame.add(eName);
		combatFrame.add(hp);
		combatFrame.add(null2);
		combatFrame.add(eHP);
		combatFrame.add(mana);
		combatFrame.add(null3);
		combatFrame.add(null4);
		combatFrame.add(pots);
		combatFrame.add(null5);
		combatFrame.add(null6);
		combatFrame.add(null7);
		attackPanel.add(attackB);
		combatFrame.add(attackPanel);
		combatFrame.add(null8);
		combatFrame.add(skill1CostPanel);
		combatFrame.add(skill2CostPanel);
		combatFrame.add(null9);
		skill1Panel.add(skill1B);
		combatFrame.add(skill1Panel);
		skill2Panel.add(skill2B);
		combatFrame.add(skill2Panel);
		potPanel.add(potB);
		combatFrame.add(potPanel);
	}
	
	public void goToCombat() {
		exploreFrame.setVisible(false);
		getRandomEnemy();
		e.fullHeal();
		combatStats();
		combatFrame.pack();
		setLabels();
		combatFrame.setVisible(true);
		combatFirstTurn();
	}
	
	public void goToExplore() {
		combatFrame.setVisible(false);
		exploreStats();
		exploreFrame.add(encounter);
		exploreFrame.add(null7);
		exploreFrame.add(town);
		setLabels();
		exploreFrame.pack();
		exploreFrame.setVisible(true);
		
	}
	
	public void setLabels() {
		hpL.setText("HP: " + p.getHP());
		goldL.setText("Gold: " + p.getGold());
		manaL.setText("Mana: " + p.getMana());
		potsL.setText("Potions: " + p.getPots());
		eNameL.setText(e.getName());
		eHPL.setText("HP: " + e.getHP());
	}
	
	public void startTurn() {
		input = "";
	}
	
	public void endTurn() {
		input = "";
		p.defaultAtk();
		turn = 0;
		if (e.getHP() <= 0) {
			combatWin();
		} else {
			combat();
		}
	}
	
	public void combatWin() {
		JOptionPane.showMessageDialog(null, "You are victorious! You collect " + e.getGoldVal() + " gold coins!");
		p.incGold(e.getGoldVal());
		goToExplore();
	}
	
	private class NameListener implements ActionListener {
		public void actionPerformed(ActionEvent a) {
			nameIn = nameField.getText();
			if (nameIn == "debug") {
				debug = true;
			}
			nameFrame.setVisible(false);
			jobFrame.setVisible(true);
		}
	}
	
	private class JobListener implements ActionListener {
		public void actionPerformed(ActionEvent a) {
			jobIn = a.getActionCommand();
			p = new Player(nameIn, jobIn);
			nameL = new JLabel(p.getName());
			jobL = new JLabel(p.getJob());
			hpL = new JLabel("HP: " + p.getHP());
			goldL = new JLabel("Gold: " + p.getGold());
			manaL = new JLabel("Mana: " + p.getMana());
			potsL = new JLabel("Potions: " + p.getPots());
			name.add(nameL);
			job.add(jobL);
			hp.add(hpL);
			gold.add(goldL);
			mana.add(manaL);
			pots.add(potsL);
			skill1B = new JButton(p.getSkill1());
			skill2B = new JButton(p.getSkill2());
			skill1B.addActionListener(new SkillListener());
			skill2B.addActionListener(new SkillListener());
			skill1L = new JLabel(p.getSkill1Cost() + " mana");
			skill2L = new JLabel(p.getSkill2Cost() + " mana");
			skill1CostPanel = new JPanel();
			skill2CostPanel = new JPanel();
			skill1CostPanel.add(skill1L);
			skill2CostPanel.add(skill2L);
			skill1Panel.add(skill1L);
			skill2Panel.add(skill2L);
			skill1Panel.add(skill1B);
			skill2Panel.add(skill2B);
			exploreFrame.setTitle("Town");
			exploreFrame.add(name);
			exploreFrame.add(null1);
			exploreFrame.add(job);
			exploreFrame.add(hp);
			exploreFrame.add(null2);
			exploreFrame.add(gold);
			exploreFrame.add(mana);
			exploreFrame.add(null3);
			exploreFrame.add(pots);
			exploreFrame.add(null4);
			exploreFrame.add(null5);
			exploreFrame.add(null6);
			exploreFrame.add(inn);
			exploreFrame.add(shop);
			exploreFrame.add(forest);
			exploreFrame.pack();
			jobFrame.setVisible(false);
			JOptionPane.showMessageDialog(null, "You arrive in Town, eager to begin your adventure.");
			exploreFrame.setVisible(true);
		}
	}
	
	private class MoveListener implements ActionListener {
		public void actionPerformed(ActionEvent a) {
			input = a.getActionCommand();
			switch(input) {
				case "Town":
					JOptionPane.showMessageDialog(null, "You step back into the hustle and bustle of the Town.");
					exploreFrame.setVisible(false);
					exploreFrame.setTitle("Town");
					exploreFrame.getContentPane().removeAll();
					exploreStats();
					exploreFrame.add(inn);
					exploreFrame.add(shop);
					exploreFrame.add(forest);
					exploreFrame.setVisible(true);
					break;
				case "Inn":
					JOptionPane.showMessageDialog(null, "\"Good ta see ya! Will ye be stayin' the night with us?\"");
					exploreFrame.setVisible(false);
					exploreFrame.setTitle("Inn");
					exploreFrame.getContentPane().removeAll();
					exploreStats();
					exploreFrame.add(stay);
					exploreFrame.add(null7);
					exploreFrame.add(town);
					exploreFrame.setVisible(true);
					break;
				case "Shop":
					JOptionPane.showMessageDialog(null, "\"Like, we're closed, yeah? All of our buttons are like, broken and stuff.\"");
					exploreFrame.setVisible(false);
					exploreFrame.setTitle("Shop");
					exploreFrame.getContentPane().removeAll();
					exploreStats();
					exploreFrame.add(sword);
					exploreFrame.add(armor);
					exploreFrame.add(town);
					exploreFrame.setVisible(true);
					break;
				case "Forest":
					JOptionPane.showMessageDialog(null, "The Forest is damp, and full of monsters.");
					exploreFrame.setVisible(false);
					exploreFrame.setTitle("Forest");
					exploreFrame.getContentPane().removeAll();
					exploreStats();
					exploreFrame.add(encounter);
					exploreFrame.add(null7);
					exploreFrame.add(town);
					exploreFrame.setVisible(true);
					break;
			}
		}
	}
	
	private class ActListener implements ActionListener {
		public void actionPerformed(ActionEvent a) {
			String input = a.getActionCommand();
			switch(input) {
				case "Stay - 100g":
					if (p.getGold() >= 100) {
						if (p.getHP() < p.getMaxHP() || p.getMana() < p.getMaxMana()) {
							p.decGold(100);
							p.fullHeal();
							p.fullMana();
							JOptionPane.showMessageDialog(null, "You stay the night, healing your wounds and refreshing your mind.");
						} else {
							JOptionPane.showMessageDialog(null, "You feel fine, and have no need of resting.");
						}
					} else {
						JOptionPane.showMessageDialog(null, "\"Ya cannay stay here if ye haven't any money!\"");
					}
					setLabels();
					break;
				case "Sword":
					JOptionPane.showMessageDialog(null, "\"I just said, like, all of our buttons are broken. Come back in the full game or whatever.");
					setLabels();
					break;
				case "Dagger":
					JOptionPane.showMessageDialog(null, "\"I just said, like, all of our buttons are broken. Come back in the full game or whatever.");
					setLabels();
				case "Staff":
					JOptionPane.showMessageDialog(null, "\"I just said, like, all of our buttons are broken. Come back in the full game or whatever.");
					setLabels();
				case "Armor":
					JOptionPane.showMessageDialog(null, "\"I just said, like, all of our buttons are broken. Come back in the full game or whatever.");
					setLabels();
					break;
				case "Encounter":
					goToCombat();
					break;
			}
		}
	}
	
	private class SkillListener implements ActionListener {
		public void actionPerformed(ActionEvent a) {
			input = a.getActionCommand();
			switch(input) {
				case "Potion":
					if (p.getPots() > 0) {
						if (p.getHP() < p.getMaxHP()) {
							JOptionPane.showMessageDialog(null, "You hastily drink a potion and it rejuvinates your fighting spirit!");
							//Heal an amount
							p.decPots(1);
							setLabels();
							endTurn();
						} else {
							JOptionPane.showMessageDialog(null, "You don't need a potion right now!");
						}
					} else {
						JOptionPane.showMessageDialog(null, "You reach for a potion, only to find that your bag is empty!");
					}
					break;
				case "Attack":
					dam = calc.damAdj(p.getAtk(),e.getDef());
					JOptionPane.showMessageDialog(null, "You attack, dealing " + dam + " damage.");
					e.decHP(dam);
					setLabels();
					endTurn();
					break;
				case "Slash":
					if(p.getMana() >= 20) {
						p.decMana(20);
						dam = calc.damAdj(p.getAtk()*2,e.getDef());
						JOptionPane.showMessageDialog(null, "You slash viciously, dealing " + dam + " damage.");
						e.decHP(dam);
						setLabels();
						endTurn();
					} else {
						JOptionPane.showMessageDialog(null, "Not enough mana!");
					}
					break;
				case "Shield Bash":
					if(p.getMana() >= 10) {
						p.decMana(10);
						dam = calc.damAdj(p.getDef(),e.getDef());
						p.incDef(p.getDef());
						JOptionPane.showMessageDialog(null, "You bash with your shield, dealing " + dam + " damage, while protecting yourself from the next attack.");
						e.decHP(dam);
						setLabels();
						endTurn();
					} else {
						JOptionPane.showMessageDialog(null, "Not enough mana!");
					}
					break;
				case "Magic Missile":
					if(p.getMana() >= 20) {
						p.decMana(20);
						dam = calc.damAdj(p.getAtk()*5, e.getDef());
						JOptionPane.showMessageDialog(null, "Five bolts of pure energy rocket from your fingertips, dealing " + dam + " damage.");
						e.decHP(dam);
						setLabels();
						endTurn();
					} else {
						JOptionPane.showMessageDialog(null, "Not enough mana!");
					}
					break;
				case "Frost Bolt":
					if (p.getMana() >= 40) {
						p.decMana(40);
						dam = calc.damAdj(p.getAtk()*3, e.getDef());
						e.setAtk(e.getAtk()/2);
						JOptionPane.showMessageDialog(null, "A blast of freezing energy strikes your target, dealing " + dam + " damage and reducing the damage of the next attack.");
						e.decHP(dam);
						setLabels();
						endTurn();
					} else {
						JOptionPane.showMessageDialog(null, "Not enough mana!");
					}
					break;
				case "Backstab":
					if (p.getMana() >= 20) {
						p.decMana(20);
						dam = calc.damAdj(p.getAtk(),0);
						JOptionPane.showMessageDialog(null, "You stab, avoiding your target's armor and dealing " + dam + " damage.");
						e.decHP(dam);
						setLabels();
						endTurn();
					} else {
						JOptionPane.showMessageDialog(null, "Not enough mana!");
					}
					break;
				case "Smoke Cloud":
					if (p.getMana() >= 20) {
						p.decMana(20);
						dam = calc.damAdj(p.getAtk()/3, e.getDef());
						p.setDef(100);
						JOptionPane.showMessageDialog(null, "You deploy a cloud of stinging gas, dealing " + dam + " damage and obscuring yourself for one turn.");
						e.decHP(dam);
						setLabels();
						endTurn();
					} else {
						JOptionPane.showMessageDialog(null, "Not enough mana!");
					}
					break;
			}
		}
	}
	
	public static void main(String[] args) {
		new GameWindow();
	}
}