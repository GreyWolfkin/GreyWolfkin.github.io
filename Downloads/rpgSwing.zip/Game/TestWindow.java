import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TestWindow extends JFrame {
	
	private boolean clicked = false;
	
	private JPanel panel1;
	private JPanel panel2;
	private JPanel panel3;
	private JPanel panel4;
	private JPanel panel5;
	private JPanel panel6;
	private JPanel null1;
	private JPanel null2;
	
	private JLabel label1;
	private JLabel label2;
	private JLabel label3;
	private JLabel label4;
	private JLabel label5;
	private JLabel label6;
	
	private JButton button1;
	private JButton button2;
	private JButton button3;
	private JButton button4;
	private JButton button5;
	private JButton button6;
	
	public TestWindow() {
		
		panel1 = new JPanel();
		panel2 = new JPanel();
		panel3 = new JPanel();
		panel4 = new JPanel();
		panel5 = new JPanel();
		panel6 = new JPanel();
		null1 = new JPanel();
		null2 = new JPanel();
		
		label1 = new JLabel("Label 1");
		label2 = new JLabel("Label 2");
		label3 = new JLabel("Label 3");
		label4 = new JLabel("Label 4");
		label5 = new JLabel("Label 5");
		label6 = new JLabel("Label 6");
		
		button1 = new JButton("Button 1");
		button2 = new JButton("Button 2");
		button3 = new JButton("Button 3");
		button4 = new JButton("Button 4");
		button5 = new JButton("Button 5");
		button6 = new JButton("Button 6");
		
		button1.addActionListener(new ButtonListener());
		button2.addActionListener(new ButtonListener());
		button3.addActionListener(new ButtonListener());
		button4.addActionListener(new ButtonListener());
		button5.addActionListener(new ButtonListener());
		button6.addActionListener(new ButtonListener());
		
		panel1.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 7));
		panel2.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 7));
		panel3.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 7));
		panel4.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 7));
		panel5.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 7));
		panel6.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 7));
		
		panel1.add(label1);
		panel1.add(button1);
		panel2.add(label2);
		panel2.add(button2);
		panel3.add(label3);
		panel3.add(button3);
		panel4.add(label4);
		panel4.add(button4);
		panel5.add(label5);
		panel5.add(button5);
		panel6.add(label6);
		panel6.add(button6);
		
		setTitle("Test Window");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new GridLayout(2,3));
		add(panel1);
		add(panel2);
		add(panel3);
		add(panel4);
		add(panel5);
		add(panel6);
		pack();
		setVisible(true);
	}
	
	private class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(null, "You clicked " + e.getActionCommand());
			if (!clicked) {
				clicked = true;
				setVisible(false);
				remove(panel4);
				remove(panel5);
				remove(panel6);
				add(null1);
				add(panel4);
				add(null2);
				setVisible(true);
			} else {
				clicked = false;
				setVisible(false);
				getContentPane().removeAll();
				add(panel4);
				add(panel5);
				add(panel6);
				add(panel1);
				add(panel2);
				add(panel3);
				setVisible(true);
			}
		}
	}
	
	public static void main(String[] args) {
		new TestWindow();
	}
}