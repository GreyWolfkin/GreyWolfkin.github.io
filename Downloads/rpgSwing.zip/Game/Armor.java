public class Armor extends Item {
	
	private String name;
	private int cost, def;
	private boolean purchased;
	
	Armor(String name, int cost, int def) {
		this.name = name;
		this.cost = cost;
		this.def = def;
	}
	
	public int getDef() {
		return def;
	}
	public void setDef(int set) {
		def = set;
	}
	
	public boolean getPurchased() {
		return purchased;
	}
	public void setPurchased(boolean set) {
		purchased = set;
	}
}