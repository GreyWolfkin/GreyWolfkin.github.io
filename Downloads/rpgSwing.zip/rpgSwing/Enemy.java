/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Enemy extends Unit {
	
	private String name;
	private int maxHP, hp, maxAtk, atk, maxDef, def, goldVal;
	
	Enemy(String name) {
		setName(name);
		
		switch(name) {
			case "Bat":
				setMaxHP(40);
				setHP(40);
				setMaxAtk(6);
				setAtk(6);
				setMaxDef(0);
				setDef(0);
				goldVal = 25;
				break;
			case "Goblin":
				setMaxHP(60);
				setHP(60);
				setMaxAtk(13);
				setAtk(13);
				setMaxDef(10);
				setDef(10);
				goldVal = 60;
				break;
			case "Orc":
				setMaxHP(90);
				setHP(90);
				setMaxAtk(25);
				setAtk(25);
				setMaxDef(30);
				setDef(30);
				goldVal = 150;
				break;
		}
	}
	
	public int getGoldVal() {
		return goldVal;
	}
}