/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Unit {
	
	private String name;
	private int maxHP, hp, maxAtk, atk, maxDef, def;
	
	public String getName() {
		return name;
	}
	public void setName(String set) {
		name = set;
	}
	
	public int getMaxHP() {
		return maxHP;
	}
	public void setMaxHP(int set) {
		maxHP = set;
	}
	public void incMaxHP(int inc) {
		maxHP += inc;
	}
	public void decMaxHP(int dec) {
		maxHP -= dec;
	}
	
	public int getHP() {
		return hp;
	}
	public void setHP(int set) {
		hp = set;
	}
	public void incHP(int inc) {
		if ((hp+inc) > maxHP) {
			hp = maxHP;
		} else {
			hp += inc;
		}
	}
	public void decHP(int dec) {
		if ((hp-dec) < 0) {
			hp = 0;
		} else {
			hp -= dec;
		}
	}
	public void fullHeal() {
		hp = maxHP;
	}
	
	public int getMaxAtk() {
		return maxAtk;
	}
	public void setMaxAtk(int set) {
		maxAtk = set;
	}
	public void incMaxAtk(int inc) {
		maxAtk += inc;
	}
	public void decMaxAtk(int dec) {
		maxAtk -= dec;
	}
	
	public int getAtk() {
		return atk;
	}
	public void setAtk(int set) {
		atk = set;
	}
	public void incAtk(int inc) {
		atk += inc;
	}
	public void decAtk(int dec) {
		atk -= dec;
	}
	public void defaultAtk() {
		atk = maxAtk;
	}
	
	public int getMaxDef() {
		return maxDef;
	}
	public void setMaxDef(int set) {
		maxDef = set;
	}
	public void incMaxDef(int inc) {
		maxDef += inc;
	}
	public void decMaxDef(int dec) {
		maxDef -= dec;
	}
	
	public int getDef() {
		return def;
	}
	public void setDef(int set) {
		def = set;
	}
	public void incDef(int inc) {
		def += inc;
	}
	public void decDef(int dec) {
		def -= dec;
	}
	public void defaultDef() {
		def = maxDef;
	}
}