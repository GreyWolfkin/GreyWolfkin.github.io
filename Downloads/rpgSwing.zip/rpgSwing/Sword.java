/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Sword extends Item {
	
	private String name;
	private int cost, atk;
	private boolean purchased;
	
	Sword(String name, int cost, int atk) {
		this.name = name;
		this.cost = cost;
		this.atk = atk;
	}
	
	public int getAtk() {
		return atk;
	}
	public void setAtk(int set) {
		atk = set;
	}
	
	public boolean getPurchased() {
		return purchased;
	}
	public void setPurchased(boolean set) {
		purchased = set;
	}
}