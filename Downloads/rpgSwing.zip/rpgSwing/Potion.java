/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Potion extends Item {
	
	private String name;
	private int cost, hp;
	
	Potion() {
		name = "Potion";
		cost = 75;
		hp = 50;
	}
	
	public int getHP() {
		return hp;
	}
	public void setHP(int set) {
		hp = set;
	}
}