/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Item {
	
	private String name;
	private int cost;
	
	Item(String name) {
		this.name = name;
	}
	
	Item() {
		name = "";
	}
	
	public String getName() {
		return name;
	}
	public void setName(String set) {
		name = set;
	}
	
	public int getCost() {
		return cost;
	}
	public void setCost(int set) {
		cost = set;
	}
}