/*****
 * COPYRIGHT Joshua Supelana-Mix 11/15/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 *****/

class Product extends Table {
	
	private String linkIDProject, linkIDRoom;
	
	public Product(String name, String linkID, String linkIDProject, String linkIDRoom) {
		super(name, linkID);
		this.linkIDProject = linkIDProject;
		this.linkIDRoom = linkIDRoom;
	}
	
	public String getLinkIDProject() {
		return linkIDProject;
	}
	public void setLinkIDProject(String set) {
		linkIDProject = set;
	}
	
	public String getLinkIDRoom() {
		return linkIDRoom;
	}
	public void setLinkIDRoom(String set) {
		linkIDRoom = set;
	}
}