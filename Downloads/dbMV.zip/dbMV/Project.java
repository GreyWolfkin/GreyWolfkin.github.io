/*****
 * COPYRIGHT Joshua Supelana-Mix 11/15/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 *****/
 
 class Project extends Table {
	
	private String linkIDLibrary;
	
	public Project(String name, String linkID, String linkIDLibrary) {
		super(name, linkID);
		this.linkIDLibrary = linkIDLibrary;
	}
	
	public String getLinkIDLibrary() {
		return linkIDLibrary;
	}
	public void setLinkIDLibrary(String set) {
		linkIDLibrary = set;
	}
}