/*****
 * COPYRIGHT Joshua Supelana-Mix 11/15/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 *****/
 
 class Library extends Table {
	
	public Library(String name, String linkID) {
		super(name, linkID);
	}
}