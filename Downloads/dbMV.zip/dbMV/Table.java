/*****
 * COPYRIGHT Joshua Supelana-Mix 11/15/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 *****/
 
 class Table {
	
	private String name, linkID;
	
	public Table(String name, String linkID) {
		this.name = name;
		this.linkID = linkID;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String set) {
		name = set;
	}
	
	public String getLinkID() {
		return linkID;
	}
	public void setLinkID(String set) {
		linkID = set;
	}
}