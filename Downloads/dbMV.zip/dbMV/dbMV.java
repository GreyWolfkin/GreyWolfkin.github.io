/*****
 * dbMV v1.0
 * Simulates a database, linking "tables" with LinkID Strings.
 * Organizational Flowchart:
 *	Library > Project > Room > Product
 * Library.LinkID = Project.LinkIDLibrary
 *	Project.LinkID = Room.LinkIDProject
 *		Room.LinkID = Product.LinkIDRoom
 * Libraries, Projects, and Rooms can be cycled through by changing
 *	"Active" object. When Active, any lower-level objects created are
 *	assigned to that upper-level object.
 * Reads and Writes to "dbMV.txt"
 *****/

/*****
 * COPYRIGHT Joshua Supelana-Mix 11/15/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 *****/

import java.util.*;
import java.io.*;

public class dbMV {
	
	// Using "dbMV.txt", populates ArrayLists which make up the "database"
	static void setupDatabase(ArrayList<Library> libraries, ArrayList<Project> projects, ArrayList<Room> rooms, ArrayList<Product> products) throws IOException {
		FileReader fr = new FileReader("dbMV.txt");
		String baseString = "";
		int i;
		while((i=fr.read()) != -1) {
			baseString += (char)i;
		}
		fr.close();
		String[] splitString = baseString.split("\\|");
		
		// The below code calls addTo...() methods.
		//	These methods take an integer to determine where to start reading
		//	the splitString, and return an integer when they stop.
		int libraryStartCount = 1;
		int projectStartCount = addToLibraries(splitString, libraryStartCount, libraries);
		int roomStartCount = addToProjects(splitString, projectStartCount, projects);
		int productStartCount = addToRooms(splitString, roomStartCount, rooms);
		addToProducts(splitString, productStartCount, products);
	}
	
	// Reads data between strings LIBRARIES and PROJECTS
	static int addToLibraries(String[] splitString, int startCount, ArrayList<Library> libraries) {
		String name, linkID;
		for(int stringCount = startCount; stringCount < splitString.length; stringCount += 2) {
			if(splitString[stringCount].equals("PROJECTS")) {
				// When splitString.equals("PROJECTS"), need to start at the
				//	next String of the array. Therefore return the current integer + 1.
				return stringCount + 1;
			}
			name = splitString[stringCount];
			linkID = splitString[stringCount + 1];
			Library l = new Library(name, linkID);
			libraries.add(l);
		}
		return -1;
	}
	
	// Reads data between strings PROJECTS and ROOMS
	static int addToProjects(String[] splitString, int startCount, ArrayList<Project> projects) {
		String name, linkID, linkIDLibrary;
		for(int stringCount = startCount; stringCount < splitString.length; stringCount += 3) {
			if(splitString[stringCount].equals("ROOMS")) {
				return stringCount + 1;
			}
			name = splitString[stringCount];
			linkID = splitString[stringCount + 1];
			linkIDLibrary = splitString[stringCount + 2];
			Project proj = new Project(name, linkID, linkIDLibrary);
			projects.add(proj);
		}
		return -1;
	}
	
	// Reads data between strings ROOMS and PRODUCTS
	static int addToRooms(String[] splitString, int startCount, ArrayList<Room> rooms) {
		String name, linkID, linkIDProject;
		for(int stringCount = startCount; stringCount < splitString.length; stringCount += 3) {
			if(splitString[stringCount].equals("PRODUCTS")) {
				return stringCount + 1;
			}
			name = splitString[stringCount];
			linkID = splitString[stringCount + 1];
			linkIDProject = splitString[stringCount + 2];
			Room r = new Room(name, linkID, linkIDProject);
			rooms.add(r);
		}
		return -1;
	}
	
	// Reads all data after PRODUCTS
	static void addToProducts(String[] splitString, int startCount, ArrayList<Product> products) {
		String name, linkID, linkIDProject, linkIDRoom;
		for(int stringCount = startCount; stringCount < splitString.length; stringCount += 4) {
			name = splitString[stringCount];
			linkID = splitString[stringCount + 1];
			linkIDProject = splitString[stringCount + 2];
			linkIDRoom = splitString[stringCount + 3];
			Product prod = new Product(name, linkID, linkIDProject, linkIDRoom);
			products.add(prod);
		}
	}
	
	// Called at the beginning of each core loop.
	static void showActive(Library activeLibrary, Project activeProject, Room activeRoom) {
		System.out.print("Active Library: ");
		if(activeLibrary != null) {
			System.out.print(activeLibrary.getName());
		}
		System.out.println();
		System.out.print("Active Project: ");
		if(activeProject != null) {
			System.out.print(activeProject.getName());
		}
		System.out.println();
		System.out.print("Active Room: ");
		if(activeRoom != null) {
			System.out.print(activeRoom.getName());
		}
		System.out.println("\n");
	}
	
	/*****
	 * Displays the database in the following order:
	 *	Library
	 *		associated Project
	 *			associated Room
	 *				associated Product
	 *			associated Room
	 *				associated Product
	 *		associated Project
	 * ... etc
	 *
	 * Only returns Products associated with Room and Project, Rooms associated
	 *	with Project, and Projects associated with Library. Accomplishes this via
	 *	linkID and linkIDObject calls.
	 *****/
	static void displayDatabase(ArrayList<Library> libraries, ArrayList<Project> projects, ArrayList<Room> rooms, ArrayList<Product> products) {
		for(Library l:libraries) {
			// Calls all Libraries
			System.out.println("Library: " + l.getName());
			for(Project proj:projects) {
				if(proj.getLinkIDLibrary().equals(l.getLinkID())) {
					// Calls only projects where LinkIDLibrary equals library's LinkID
					System.out.println("Project: " + proj.getName());
					for(Room r:rooms) {
						if(r.getLinkIDProject().equals(proj.getLinkID())) {
							// Calls only rooms where LinkIDProject equals project's LinkID
							System.out.println("Room: " + r.getName());
							for(Product prod:products) {
								if(prod.getLinkIDProject().equals(proj.getLinkID()) && prod.getLinkIDRoom().equals(r.getLinkID())) {
									// Calls only products where LinkIDProject equals project's LinkID
									//	and LinkIDRoom equals room's LinkID
									System.out.println("Product: " + prod.getName());
								}
							}
							System.out.println();
						}
					}
					System.out.println();
				}
			}
			System.out.println();
		}
	}
	
	// Returns database in a different format. Allows double-checking of all imported data
	static void debugDatabase(ArrayList<Library> libraries, ArrayList<Project> projects, ArrayList<Room> rooms, ArrayList<Product> products) {
		if(libraries.size() > 0) {
			System.out.println("LIBRARIES");
			for(Library l:libraries) {
				System.out.println("Name: " + l.getName());
				System.out.println("LinkID: " + l.getLinkID());
				System.out.println();
			}
			System.out.println();
		}
		if(projects.size() > 0) {
			System.out.println("PROJECTS");
			for(Project proj:projects) {
				System.out.println("Name: " + proj.getName());
				System.out.println("LinkID: " + proj.getLinkID());
				System.out.println("LinkIDLibrary: " + proj.getLinkIDLibrary());
				System.out.print("Linked Library: ");
				for(Library l:libraries) {
					if(proj.getLinkIDLibrary().equals(l.getLinkID())) {
						System.out.println(l.getName());
					}
				}
				System.out.println();
			}
			System.out.println();
		}
		if(rooms.size() > 0) {
			System.out.println("ROOMS");
			for(Room r:rooms) {
				System.out.println("Name: " + r.getName());
				System.out.println("LinkID: " + r.getLinkID());
				System.out.println("LinkIDProject: " + r.getLinkIDProject());
				System.out.print("Linked Project: ");
				for(Project proj:projects) {
					if(r.getLinkIDProject().equals(proj.getLinkID())) {
						System.out.println(proj.getName());
					}
				}
				System.out.println();
			}
			System.out.println();
		}
		if(products.size() > 0) {
			System.out.println("PRODUCTS");
			for(Product prod:products) {
				System.out.println("Name: " + prod.getName());
				System.out.println("LinkID: " + prod.getLinkID());
				System.out.println("LinkIDProject: " + prod.getLinkIDProject());
				System.out.print("Linked Project: ");
				for(Project proj:projects) {
					if(prod.getLinkIDProject().equals(proj.getLinkID())) {
						System.out.println(proj.getName());
					}
				}
				System.out.println("LinkIDRoom: " + prod.getLinkIDRoom());
				System.out.print("Linked Room: ");
				for(Room r:rooms) {
					if(prod.getLinkIDRoom().equals(r.getLinkID()) && prod.getLinkIDProject().equals(r.getLinkIDProject())) {
						System.out.println(r.getName());
					}
				}
				System.out.println();
			}
		}
	}
	
	/*****
	 * Adds a library to ArrayList<Library>, as long as it has a unique name and
	 *	LinkID.
	 * Returns activeLibrary. If activeLibrary is null, sets activeLibrary to new
	 *	Library. Otherwise, returns the already activeLibrary.
	 *****/
	static Library addLibrary(input_utils in, Library activeLibrary, ArrayList<Library> libraries) {
		String name, linkID;
		name = in.get("Library Name: ");
		for(Library l:libraries) {
			if(name.equals(l.getName())) {
				System.out.println("Library " + name + " already exists.");
				return activeLibrary;
			}
		}
		linkID = in.get("Library LinkID: ");
		for(Library l:libraries) {
			if(linkID.equals(l.getLinkID())) {
				System.out.println("Library with LinkID " + linkID + " already exists.");
				return activeLibrary;
			}
		}
		Library l = new Library(name, linkID);
		libraries.add(l);
		if(activeLibrary == null) {
			activeLibrary = l;
		}
		return activeLibrary;
	}
	
	// Changes which Library new Projects will be created "inside"
	static Library changeActiveLibrary(input_utils in, Library activeLibrary, Project activeProject, Room activeRoom, ArrayList<Library> libraries) {
		int opt = 1;
		System.out.println("Select Active Library");
		for(Library l:libraries) {
			System.out.println(opt + " - " + l.getName());
			opt++;
		}
		int userIn = in.getInt("", 1, opt);
		Library chosenLibrary = libraries.get(userIn - 1);
		activeLibrary = chosenLibrary;
		return activeLibrary;
	}
	
	/*****
	 * All of the remove...() methods are complicated.
	 * They have to iterate upon a list and remove that element
	 *	if certain conditions are met.
	 * In this case, a Library is being removed. All Projects associated
	 *	with that Library, all Rooms associated with those Projects, and all
	 *	Products associated with those Rooms must be removed.
	 * If the removed Library is the currently Active Library, activeLibrary
	 *	must return null.
	 *****/
	static Library removeLibrary(input_utils in, Library activeLibrary, ArrayList<Library> libraries, ArrayList<Project> projects, ArrayList<Room> rooms, ArrayList<Product> products) {
		System.out.println("Delete which Library?");
		int opt = 1;
		for(Library l:libraries) {
			System.out.println(opt + " - " + l.getName());
			opt++;
		}
		int userIn = in.getInt("", 1, opt);
		Library libraryToDelete = libraries.get(userIn - 1);
		System.out.println("Are you sure you want to delete library " + libraryToDelete.getName() + "? This will delete all Projects, Rooms, and Products attached to this library.");
		int confirm = in.getInt("1 - Yes\n2 - No\n", 1, 2);
		if(confirm == 1) {
			/*****
			 * Initializes an Iterator<Project>, iterates upon ArrayList<Project>,
			 *	and focuses on each Project in the ArrayList as it is being
			 *	iterated upon.
			 * Within the Project iteration, initializes an Iterator<Room>,
			 *	iterates upon ArrayList<Room>, then initializes an Iterator<Product>
			 *****/
			for(Iterator<Project> projectIterator = projects.iterator(); projectIterator.hasNext();) {
				Project p = projectIterator.next();
				if(p.getLinkIDLibrary().equals(libraryToDelete.getLinkID())) {
					for(Iterator<Room> roomIterator = rooms.iterator(); roomIterator.hasNext();) {
						Room r = roomIterator.next();
						if(r.getLinkIDProject().equals(p.getLinkID())) {
							for(Iterator<Product> productIterator = products.iterator(); productIterator.hasNext();) {
								Product prod = productIterator.next();
								if(prod.getLinkIDProject().equals(p.getLinkID()) && prod.getLinkIDRoom().equals(r.getLinkID())) {
									productIterator.remove();
								}
							}
							roomIterator.remove();
						}
					}
					projectIterator.remove();
				}
			}
			libraries.remove(libraryToDelete);
			System.out.println("Removed Library");
			if(activeLibrary == libraryToDelete) {
				activeLibrary = null;
			}
		}
		return activeLibrary;
	}
	
	static Project addProject(input_utils in, Library activeLibrary, Project activeProject, ArrayList<Project> projects) {
		String name, linkID, linkIDLibrary;
		name = in.get("Project Name: ");
		for(Project p:projects) {
			if(p.getLinkIDLibrary().equals(activeLibrary.getLinkID()) && name.equals(p.getName())) {
				System.out.println("Project " + name + " already exists in Active Library");
				return activeProject;
			}
		}
		linkID = in.get("Project LinkID: ");
		for(Project p:projects) {
			if(p.getLinkIDLibrary().equals(activeLibrary.getLinkID()) && linkID.equals(p.getLinkID())) {
				System.out.println("Project with LinkID " + linkID + " already exists in Active Library.");
				return activeProject;
			}
		}
		linkIDLibrary = activeLibrary.getLinkID();
		Project p = new Project(name, linkID, linkIDLibrary);
		projects.add(p);
		if(activeProject == null) {
			activeProject = p;
		}
		return activeProject;
	}
	
	static Project changeActiveProject(input_utils in, Library activeLibrary, Project activeProject, Room activeRoom, ArrayList<Project> projects) {
		ArrayList<Project> tempList = new ArrayList<Project>();
		for(Project p:projects) {
			if(p.getLinkIDLibrary().equals(activeLibrary.getLinkID())) {
				tempList.add(p);
			}
		}
		System.out.println("Select Active Project");
		int opt = 1;
		for(Project p:tempList) {
			System.out.println(opt + " - " + p.getName());
			opt++;
		}
		int userIn = in.getInt("", 1, opt);
		Project chosenProject = projects.get(projects.indexOf(tempList.get(userIn - 1)));
		activeProject = chosenProject;
		return activeProject;
	}
	
	static Project removeProject(input_utils in, Library activeLibrary, Project activeProject, ArrayList<Project> projects, ArrayList<Room> rooms, ArrayList<Product> products) {
		
		ArrayList<Project> tempList = new ArrayList<Project>();
		for(Project p:projects) {
			if(p.getLinkIDLibrary().equals(activeLibrary.getLinkID())) {
				tempList.add(p);
			}
		}
		System.out.println("Delete which Project?");
		int opt = 1;
		for(Project p:tempList) {
			System.out.println(opt + " - " + p.getName());
			opt++;
		}
		int userIn = in.getInt("", 1, opt);
		Project projectToDelete = projects.get(projects.indexOf(tempList.get(userIn - 1)));
		System.out.println("Are you sure you want to delete project " + projectToDelete.getName() + "? This will delete all Rooms and Products attached to this project.");
		int confirm = in.getInt("1 - Yes\n2 - No\n", 1, 2);
		if(confirm == 1) {
			for(Iterator<Room> roomIterator = rooms.iterator(); roomIterator.hasNext();) {
				Room r = roomIterator.next();
				if(r.getLinkIDProject().equals(projectToDelete.getLinkID())) {
					for(Iterator<Product> productIterator = products.iterator(); productIterator.hasNext();) {
						Product prod = productIterator.next();
						if(prod.getLinkIDProject().equals(projectToDelete.getLinkID()) && prod.getLinkIDRoom().equals(r.getLinkID())) {
							productIterator.remove();
						}
					}
					roomIterator.remove();
				}
			}
			projects.remove(projectToDelete);
			System.out.println("Removed Project");
			if(activeProject == projectToDelete) {
				activeProject = null;
			}
		}
		return activeProject;
	}
	
	static Room addRoom(input_utils in, Project activeProject, Room activeRoom, ArrayList<Room> rooms) {
		
		String name, linkID, linkIDProject;
		name = in.get("Room Name: ");
		for(Room r:rooms) {
			if(r.getLinkIDProject().equals(activeProject.getLinkID()) && name.equals(r.getName())) {
				System.out.println("Room " + name + " already exists in Active Project.");
				return activeRoom;
			}
		}
		linkID = in.get("Room LinkID: ");
		for(Room r:rooms) {
			if(r.getLinkIDProject().equals(activeProject.getLinkID()) && linkID.equals(r.getLinkID())) {
				System.out.println("Room with LinkID " + linkID + " already exists in Active Project");
				return activeRoom;
			}
		}
		linkIDProject = activeProject.getLinkID();
		Room r = new Room(name, linkID, linkIDProject);
		rooms.add(r);
		if(activeRoom == null) {
			activeRoom = r;
		}
		return activeRoom;
	}
	
	static Room changeActiveRoom(input_utils in, Project activeProject, Room activeRoom, ArrayList<Room> rooms) {
		
		ArrayList<Room> tempList = new ArrayList<Room>();
		for(Room r:rooms) {
			if(r.getLinkIDProject().equals(activeProject.getLinkID())) {
				tempList.add(r);
			}
		}
		System.out.println("Select Active Room");
		int opt = 1;
		for(Room r:tempList) {
			System.out.println(opt + " - " + r.getName());
			opt++;
		}
		int userIn = in.getInt("", 1, opt);
		Room chosenRoom = rooms.get(rooms.indexOf(tempList.get(userIn - 1)));
		activeRoom = chosenRoom;
		return activeRoom;
	}
	
	static Room removeRoom(input_utils in, Project activeProject, Room activeRoom, ArrayList<Room> rooms, ArrayList<Product> products) {
		
		ArrayList<Room> tempList = new ArrayList<Room>();
		for(Room r:rooms) {
			if(r.getLinkIDProject().equals(activeProject.getLinkID())) {
				tempList.add(r);
			}
		}
		System.out.println("Delete which Room?");
		int opt = 1;
		for(Room r:tempList) {
			System.out.println(opt + " - " + r.getName());
			opt++;
		}
		int userIn = in.getInt("", 1, opt);
		Room roomToDelete = rooms.get(rooms.indexOf(tempList.get(userIn - 1)));
		System.out.println("Are you sure you want to delete room " + roomToDelete.getName() + "? This will delete all Products attached to this room.");
		int confirm = in.getInt("1 - Yes\n2 - No\n", 1, 2);
		if(confirm == 1) {
			for(Iterator<Product> productIterator = products.iterator(); productIterator.hasNext();) {
				Product p = productIterator.next();
				if(p.getLinkIDProject().equals(activeProject.getLinkID()) && p.getLinkIDRoom().equals(roomToDelete.getLinkID())) {
					productIterator.remove();
				}
			}
			rooms.remove(roomToDelete);
			System.out.println("Removed Room");
			if(roomToDelete == activeRoom) {
				activeRoom = null;
			}
		}
		return activeRoom;
	}
	
	static void addProduct(input_utils in, Project activeProject, Room activeRoom, ArrayList<Product> products) {
		
		String name, linkID, linkIDProject, linkIDRoom;
		name = in.get("Product Name: ");
		for(Product prod:products) {
			if(prod.getLinkIDProject().equals(activeProject.getLinkID()) && prod.getLinkIDRoom().equals(activeRoom.getLinkID()) && name.equals(prod.getName())) {
				System.out.println("Product " + name + " already exists in Active Room.");
				return;
			}
		}
		linkID = in.get("Product LinkID: ");
		for(Product prod:products) {
			if(prod.getLinkIDProject().equals(activeProject.getLinkID()) && prod.getLinkIDRoom().equals(activeRoom.getLinkID()) && linkID.equals(prod.getLinkID())) {
				System.out.println("Product with LinkID " + linkID + " already exists in Active Room.");
				return;
			}
		}
		linkIDProject = activeProject.getLinkID();
		linkIDRoom = activeRoom.getLinkID();
		Product p = new Product(name, linkID, linkIDProject, linkIDRoom);
		products.add(p);
	}
	
	static void removeProduct(input_utils in, Project activeProject, Room activeRoom, ArrayList<Product> products) {
		
		System.out.println("Delete which Product?");
		int opt = 1;
		for(Product prod:products) {
			if(prod.getLinkIDProject().equals(activeProject.getLinkID()) && prod.getLinkIDRoom().equals(activeRoom.getLinkID())) {
				System.out.println(opt + " - " + prod.getName());
				opt++;
			}
		}
		int userIn = in.getInt("", 1, opt);
		Product productToDelete = products.get(userIn - 1);
		System.out.println("Are you sure you want to delete product " + productToDelete.getName() + "?");
		int confirm = in.getInt("1 - Yes\n2 - No\n", 1, 2);
		if(confirm == 1) {
			products.remove(productToDelete);
		}
	}
	
	static int projectsInLibrary(Library activeLibrary, ArrayList<Project> projects) {
		int num = 0;
		for(Project p:projects) {
			if(p.getLinkIDLibrary().equals(activeLibrary.getLinkID())) {
				num++;
			}
		}
		return num;
	}
	
	static int roomsInProject(Project activeProject, ArrayList<Room> rooms) {
		int num = 0;
		for(Room r:rooms) {
			if(r.getLinkIDProject().equals(activeProject.getLinkID())) {
				num++;
			}
		}
		return num;
	}
	
	static int productsInRoom(Project activeProject, Room activeRoom, ArrayList<Product> products) {
		int num = 0;
		for(Product p:products) {
			if(p.getLinkIDProject().equals(activeProject.getLinkID()) && p.getLinkIDRoom().equals(activeRoom.getLinkID())) {
				num++;
			}
		}
		return num;
	}
	
	static boolean saveChanges(input_utils in) {
		int userIn = in.getInt("Save changes to database?\n1 - Yes\n2 - No\n", 1, 2);
		if(userIn == 1) {
			return true;
		} else {
			return false;
		}
	}
	
	static void writeFile(ArrayList<Library> libraries, ArrayList<Project> projects, ArrayList<Room> rooms, ArrayList<Product> products) throws IOException {
		File f = new File("dbMV.txt");
		f.delete();
		FileWriter fw = new FileWriter("dbMV.txt");
		fw.write("LIBRARIES|");
		for(Library l:libraries) {
			fw.write(l.getName() + "|" + l.getLinkID() + "|");
		}
		fw.write("PROJECTS|");
		for(Project p:projects) {
			fw.write(p.getName() + "|" + p.getLinkID() + "|" + p.getLinkIDLibrary() + "|");
		}
		fw.write("ROOMS|");
		for(Room r:rooms) {
			fw.write(r.getName() + "|" + r.getLinkID() + "|" + r.getLinkIDProject() + "|");
		}
		fw.write("PRODUCTS|");
		for(Product p:products) {
			fw.write(p.getName() + "|" + p.getLinkID() + "|" + p.getLinkIDProject() + "|" + p.getLinkIDRoom() + "|");
		}
		fw.close();
	}
	
	public static void main(String[] args) {
		input_utils in = new input_utils(); //input_utils v1.0
		
		ArrayList<Library> libraries = new ArrayList<Library>();
		ArrayList<Project> projects = new ArrayList<Project>();
		ArrayList<Room> rooms = new ArrayList<Room>();
		ArrayList<Product> products = new ArrayList<Product>();
		
		Library activeLibrary = null;
		Project activeProject = null;
		Room activeRoom = null;
		
		try {
			setupDatabase(libraries, projects, rooms, products);
		} catch(IOException ex) {
			System.out.println(ex);
		}
		
		int userIn;
		String[] commands = new String[14];
		int opt;
		// pIL = Projects In Library
		// rIP = Rooms in Project
		// pIR = Products in Room
		int pIL, rIP, pIR;
		int i;
		String command;
		
		while(true) {
			for(String string:commands) {
				string = null;
			}
			showActive(activeLibrary, activeProject, activeRoom);
			
			/*****
			 * I know this section of code is confusing. Let me explain:
			 *	User is going to input a number between 1 and something.
			 *	The list of options needs to change based on several factors,
			 *		such as how many libraries there are, how many projects
			 *		are in the active library, whether there is an active project,
			 *		etc.
			 *	In addition to changing the list of options, the result of user
			 *		input needs to change. 
			 *	For example, if the user inputs "2" when there are no libraries 
			 * 		in the database, the program terminates.
			 *	But if the user inputs "2" when there is at least one library
			 *		in the database, the program calls addLibrary() method.
			 *	String[] "commands" resolves these issues. Elements in the array
			 *		are assigned different Strings based on nested if statements.
			 *	If libraries.size() == 0, commands[1] is "Add Library" and
			 *		commands[2] is "Exit". If libraries.size() > 0,
			 *		commands[1] is "Display Database", [2] is "Add Library", etc.
			 *	The variable "opt" also changes depending on these if statements.
			 *		"opt" determines the maximum valid integer input, preventing
			 *		the user from accessing a method call they shouldn't.
			 *	Once the array is fully set and an integer assigned to opt,
			 *		the program prints all non-null elements in the array, with
			 *		their associated input number.
			 *	userIn gets an integer between 1 and opt, and the String command
			 *		gets the String located at that index of the array.
			 *	Then we run a switch statement on that String, calling different
			 *		methods based on what that String is.
			 *
			 * EXAMPLE
			 *
			 *		There are 2 Libraries in the database. The active Library
			 *			"contains" 3 projects. The active project contains
			 *			no rooms. The nested if statements determine that
			 *			commands[1] = "Display Database", [2] = "Add Library",
			 *			[3] = "Change Active Library", [4] = "Remove Library",
			 *			[5] = "Add Project", [6] = "Change Active Project",
			 *			[7] = "Remove Project", [8] = "Add Room", and
			 *			[9] = "Exit".
			 *		The user inputs "6". This is a valid input, since it is between
			 *			1 and 9 inclusive. The String command gets assigned variable
			 *			"Change Active Project", since that's the String at index
			 *			[6] of array "commands".
			 *		The switch statement looks at String command, finds that it is
			 *			equal to String "Change Active Project", and calls
			 *			changeActiveProject() method.
			 *
			 * Simple, right?
			 *****/
			if(libraries.size() > 0) {
				commands[1] = "Display Database";
				commands[2] = "Add Library";
				commands[3] = "Change Active Library";
				commands[4] = "Remove Library";
				if(activeLibrary != null) {
					pIL = projectsInLibrary(activeLibrary, projects);
					commands[5] = "Add Project";
					if(pIL > 0) {
						commands[6] = "Change Active Project";
						commands[7] = "Remove Project";
						if(activeProject != null) {
							rIP = roomsInProject(activeProject, rooms);
							commands[8] = "Add Room";
							if(rIP > 0) {
								commands[9] = "Change Active Room";
								commands[10] = "Remove Room";
								if(activeRoom != null) {
									pIR = productsInRoom(activeProject, activeRoom, products);
									commands[11] = "Add Product";
									if(pIR > 0) {
										opt = 13;
										commands[12] = "Remove Product";
										commands[13] = "Exit";
									} else {
										opt = 12;
										commands[12] = "Exit";
									}
								} else {
									opt = 11;
									commands[11] = "Exit";
								}
							} else {
								opt = 9;
								commands[9] = "Exit";
							}
						} else {
							opt = 8;
							commands[8] = "Exit";
						}
					} else {
						opt = 6;
						commands[6] = "Exit";
					}
				} else {
					opt = 5;
					commands[5] = "Exit";
				}
			} else {
				opt = 2;
				commands[1] = "Add Library";
				commands[2] = "Exit";
			}
			i = 1;
			while(i <= opt) {
				if(commands[i] != null) {
					System.out.println(i + " - " + commands[i]);
					i++;
				}
			}
			userIn = in.getInt("", 1, opt);
			command = commands[userIn];
			switch(command) {
				case "Display Database":
					displayDatabase(libraries, projects, rooms, products);
					break;
				case "Add Library":
					activeLibrary = addLibrary(in, activeLibrary, libraries);
					break;
				case "Change Active Library":
					activeLibrary = changeActiveLibrary(in, activeLibrary, activeProject, activeRoom, libraries);
					activeProject = null;
					activeRoom = null;
					break;
				case "Remove Library":
					activeLibrary = removeLibrary(in, activeLibrary, libraries, projects, rooms, products);
					if(activeLibrary == null) {
						activeProject = null;
						activeRoom = null;
					}
					break;
				case "Add Project":
					activeProject = addProject(in, activeLibrary, activeProject, projects);
					break;
				case "Change Active Project":
					activeProject = changeActiveProject(in, activeLibrary, activeProject, activeRoom, projects);
					activeRoom = null;
					break;
				case "Remove Project":
					activeProject = removeProject(in, activeLibrary, activeProject, projects, rooms, products);
					if(activeProject == null) {
						activeRoom = null;
					}
					break;
				case "Add Room":
					activeRoom = addRoom(in, activeProject, activeRoom, rooms);
					break;
				case "Change Active Room":
					activeRoom = changeActiveRoom(in, activeProject, activeRoom, rooms);
					break;
				case "Remove Room":
					removeRoom(in, activeProject, activeRoom, rooms, products);
					break;
				case "Add Product":
					addProduct(in, activeProject, activeRoom, products);
					break;
				case "Remove Product":
					removeProduct(in, activeProject, activeRoom, products);
					break;
				case "Exit":
					if(saveChanges(in)) {
						try {
							writeFile(libraries, projects, rooms, products);
						} catch(IOException ex) {
							System.out.println(ex);
						}
					}
					System.exit(0);
					break;
			}
		}
	}
}