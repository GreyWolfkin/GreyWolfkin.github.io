class Key extends Item {
	Key(String name, String desc, boolean isVis, boolean canMove) {
		super(name, desc, isVis, canMove);
		this.canTake = true;
		this.canUse = true;
		this.canMove = false;
	}
}