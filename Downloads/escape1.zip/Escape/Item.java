class Item {
	String name, desc;
	boolean isVis, canTake, inInv, canUse, canUseWith, canOpen, isOpen, isLocked, canMove, isMoved;
	
	Item(String name, String desc, boolean isVis, boolean canMove) {
		this.name = name;
		this.desc = desc;
		this.isVis = isVis;
		this.canTake = false;
		this.inInv = false;
		this.canUse = false;
		this.canUseWith = false;
		this.canOpen = false;
		this.isOpen = false;
		this.isLocked = false;
		this.canMove = canMove;
		this.isMoved = false;
	}
}