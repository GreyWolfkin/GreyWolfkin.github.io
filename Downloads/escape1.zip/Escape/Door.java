class Door extends Item {
	
	Door(String name, String desc, boolean isVis, boolean canMove, boolean isLocked) {
		super(name, desc, isVis, canMove);
		this.canOpen = true;
		this.isLocked = isLocked;
	}
}