/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/
 
 /*****
  * WORK IN PROGRESS
  * MULTIPLE BUGS STILL PRESENT
  *****/

import java.util.Scanner;

public class Game {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Listener l = new Listener(scan);
		Builder build = new Builder();
		Board board = build.getBoard();
		Rules rules = new Rules(l);
		Piece king = board.getSquare("e", "8").getOccupyingPiece();
		rules.movePiece(king, board.getSquare("e", "4"));
		int winner = rules.playGame(board);
		if(winner == 0) {
			System.out.println("White wins");
		} else if(winner == 1) {
			System.out.println("Black wins");
		} else if(winner == -1) {
			System.out.println("Error at Rules.playGame()");
		}
	}

}
