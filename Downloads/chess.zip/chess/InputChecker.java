/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class InputChecker {

	protected boolean isString(String input) {
		if(input.length() > 0) {
			return true;
		} else {
			return false;
		}
	}

	protected boolean inputMatches(String input, String inputType) {
		try {
			switch(inputType) {
			case "int":
				Integer.parseInt(input);
				break;
			case "float":
				Float.parseFloat(input);
				break;
			case "double":
				Double.parseDouble(input);
				break;
			}
			return true;
		} catch(NumberFormatException ex) {
			switch(inputType) {
			case "int":
				System.out.println("Unexpected Input. Expected Integer.");
				break;
			case "float":
				System.out.println("Unexpected Input. Expected Float.");
				break;
			case "double":
				System.out.println("Unexpected Input. Expected Double.");
				break;
			}
			return false;
		}
	}

	protected boolean isInRange(int input, int min) {
		if(min <= input) {
			return true;
		} else {
			rangeError(Integer.toString(min));
			return false;
		}
	}

	protected boolean isInRange(int input, int min, int max) {
		if(min <= input && input <= max) {
			return true;
		} else {
			rangeError(Integer.toString(min), Integer.toString(max));
			return false;
		}
	}

	protected boolean isInRange(float input, float min) {
		if(min <= input) {
			return true;
		} else {
			rangeError(Float.toString(min));
			return false;
		}
	}

	protected boolean isInRange(float input, float min, float max) {
		if(min <= input && input <= max) {
			return true;
		} else {
			rangeError(Float.toString(min), Float.toString(max));
			return false;
		}
	}

	protected boolean isInRange(double input, double min) {
		if(min <= input) {
			return true;
		} else {
			rangeError(Double.toString(min));
			return false;
		}
	}

	protected boolean isInRange(double input, double min, double max) {
		if(min <= input && input <= max) {
			return true;
		} else {
			rangeError(Double.toString(min), Double.toString(max));
			return false;
		}
	}

	private void rangeError(String min) {
		System.out.println("Invalid Input. Input must be at least " + min + ".");
	}

	private void rangeError(String min, String max) {
		System.out.println("Invalid Input. Input must be between " + min + " and " + max + ".");
	}

}
