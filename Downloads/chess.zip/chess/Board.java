/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/
 
public class Board {
	
	private Square[][] layout;
	private Piece[] pieces;
	
	public Board(Square[][] layout, Piece[] pieces) {
		this.layout = layout;
		this.pieces = pieces;
	}
	
	public Square[][] getLayout() {
		return layout;
	}
	
	public Square getSquare(String horizPos, String vertPos) {
		for(Square[] row:layout) {
			for(Square square:row) {
				if(square.getColumn().equals(horizPos) && square.getRow().equals(vertPos)) {
					return square;
				}
			}
		}
		return null;
	}
	
	public Square getSquare(int colVal, int rowVal) {
		for(Square[] row:layout) {
			for(Square square:row) {
				if(square.getColVal() == colVal && square.getRowVal() == rowVal) {
					return square;
				}
			}
		}
		return null;
	}
	
	public Piece[] getPieces() {
		return pieces;
	}
	
	public void drawBoard() {
		System.out.print("  ");
		drawHoriz();
		String color = "white";
		for(Square[] row:layout) {
			System.out.print("  ");
			drawVert(color);
			System.out.print(row[0].getRow() + " ");
			System.out.print("|");
			for(Square square:row) {
				square.printSelf();
				System.out.print("|");
			}
			System.out.println();
			System.out.print("  ");
			drawVert(color);
			System.out.print("  ");
			drawHoriz();
			if(color.equals("white")) {
				color = "black";
			} else {
				color = "white";
			}
		}
		for(Square square:layout[0]) {
			System.out.print("    ");
			System.out.print(square.getColumn());
		}
		System.out.println("\n");
	}
	
	private void drawHoriz() {
		for(int i = 0; i < 41; i++) {
			if(i % 5 == 0) {
				System.out.print(" ");
			} else {
				System.out.print("-");
			}
		}
		System.out.println();
	}
	
	private void drawVert(String color) {
		System.out.print("|");
		for(int i = 0; i < 8; i++) {
			if(color.equals("white")) {
				System.out.print("    ");
				color = "black";
			} else {
				System.out.print("////");
				color = "white";
			}
			System.out.print("|");
		}
		System.out.println();
	}
	
	private void drawSquare(Square square) {
		System.out.print("| ");
		square.printSelf();
		System.out.print(" |");
	}
	
	public void debugPieces() {
		Piece piece;
		for(Square[] row:layout) {
			for(Square square:row) {
				if(square.getOccupied()) {
					piece = square.getOccupyingPiece();
					piece.printSelf();
					System.out.print("\tRow: " + piece.getRow() + "\tColumn: " + piece.getColumn() + "\n");
				}
			}
		}
	}
	
	public void clearThreat() {
		for(Square[] row:layout) {
			for(Square square:row) {
				square.setThreatened(false);
			}
		}
	}
	
	/*
	 * private Square[][] layout;
	private Piece[] pieces;
	
	public Board(Square[][] layout, Piece[] pieces) {
		this.layout = layout;
		this.pieces = pieces;
	}
	 */
	
	public Board duplicateSelf() {
		Square[][] duplicateLayout = new Square[layout.length][layout[0].length];
		Piece[] duplicatePieces = new Piece[pieces.length];
		
		for(int i = 0; i < layout.length; i++) {
			for(int j = 0; j < layout[i].length; j++) {
				duplicateLayout[i][j] = layout[i][j].duplicateSelf();
//				duplicateLayout[i][j].printSelf();
			}
		}
		
		for(int i = 0; i < pieces.length; i++) {
			duplicatePieces[i] = pieces[i].duplicateSelf();
		}
		
		return new Board(duplicateLayout, duplicatePieces);
	}
	
	/*
	
	public Board copyBoard(Board newBoard) {
		
		Piece tempBoardPiece;
		Piece boardPiece;
		Square tempBoardSquare;
		Square boardSquare;
		System.out.println("Pieces");
		
		for(int i = 0; i < getPieces().length; i++) {
			System.out.println("i = " + i);
			tempBoardPiece = newBoard.getPieces()[i];
			boardPiece = getPieces()[i];
			tempBoardPiece.setCaptured(boardPiece.getCaptured());
			tempBoardPiece.setOccupiedSquare(boardPiece.getOccupiedSquare());
		}
		System.out.println("Squares");
		for(int i = 0; i < getLayout().length; i++) {
			for(int j = 0; j < getLayout()[i].length; j++) {
				System.out.println("i = " + i);
				System.out.println("j = " + j);
				tempBoardSquare = newBoard.getSquare(i + 1, j + 1);
				boardSquare = getSquare(i + 1, j + 1);
				if(boardSquare.getOccupied()) {
					tempBoardSquare.setOccupied(true);
					tempBoardSquare.setOccupyingPiece(boardSquare.getOccupyingPiece());
				} else {
					tempBoardSquare.removePiece();
				}
				tempBoardSquare.setOccupied(boardSquare.getOccupied());
				tempBoardSquare.setOccupyingPiece(boardSquare.getOccupyingPiece());
			}
		}
		
		return newBoard;
	}
	
	*/

}
