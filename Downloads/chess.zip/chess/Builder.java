/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Builder {
		
	public Board getBoard() {
		
		Square[][] squares = new Square[8][8];

		String[] rows = new String[] {"8", "7", "6", "5", "4", "3", "2", "1"};
		String[] columns = new String[] {"a", "b", "c", "d", "e", "f", "g", "h"};

		String row;
		String column;
		String color = "white";
		for(int i = 0; i < 8; i++) {
			row = rows[i];
			for(int j = 0; j < 8; j++) {
				column = columns[j];
				squares[i][j] = new Square(row, column, color);
				if(color.equals("white")) {
					color = "black";
				} else {
					color = "white";
				}
			}
			if(color.equals("white")) {
				color = "black";
			} else {
				color = "white";
			}
		}
		
		Piece[] piecesOnEight = new Piece[] {
				new Piece("Rook", "black", squares[0][0]),
				new Piece("Knight", "black", squares[0][1]),
				new Piece("Bishop", "black", squares[0][2]),
				new Piece("Queen", "black", squares[0][3]),
				new Piece("King", "black", squares[0][4]),
				new Piece("Bishop", "black", squares[0][5]),
				new Piece("Knight", "black", squares[0][6]),
				new Piece("Rook", "black", squares[0][7])
		};
		Piece[] piecesOnSeven = new Piece[8];
		for(int i = 0; i < 8; i++) {
			piecesOnSeven[i] = new Piece("Pawn", "black", squares[1][i]);
		}
		Piece[] piecesOnTwo = new Piece[8];
		for(int i = 0; i < 8; i++) {
			piecesOnTwo[i] = new Piece("Pawn", "white", squares[6][i]);
		}
		Piece[] piecesOnOne = new Piece[] {
				new Piece("Rook", "white", squares[7][0]),
				new Piece("Knight", "white", squares[7][1]),
				new Piece("Bishop", "white", squares[7][2]),
				new Piece("Queen", "white", squares[7][3]),
				new Piece("King", "white", squares[7][4]),
				new Piece("Bishop", "white", squares[7][5]),
				new Piece("Knight", "white", squares[7][6]),
				new Piece("Rook", "white", squares[7][7])
		};
		
		Piece[] pieces = new Piece[32];
		System.arraycopy(piecesOnEight, 0, pieces, 0, 8);
		System.arraycopy(piecesOnSeven, 0, pieces, 8, 8);
		System.arraycopy(piecesOnTwo, 0, pieces, 16, 8);
		System.arraycopy(piecesOnOne, 0, pieces, 24, 8);
		
		Piece piece;
		for(int i = 0; i < 32; i++) {
			piece = pieces[i];
			if(i < 8) {
				squares[0][i].setOccupyingPiece(piece);
			} else if(i < 16) {
				squares[1][i - 8].setOccupyingPiece(piece);
			} else if(i < 24) {
				squares[6][i - 16].setOccupyingPiece(piece);
			} else {
				squares[7][i - 24].setOccupyingPiece(piece);
			}
		}
		
		return new Board(squares, pieces);
	}

}
