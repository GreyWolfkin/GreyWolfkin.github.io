/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Rules {

	private Listener l;
//	private Board board;
	
	public Rules(Listener l) {
		this.l = l;
	}

//	public Rules(Listener l, Builder build, Board board) {
//		this.l = l;
//		this.build = build;
//		this.board = board;
//	}
	
//	private Rules(Board board) {
//		this.l = null;
//		this.build = null;
//		this.board = board;
//	}
	
	public int playGame(Board board) {
		int turn = 0;
		String input;
		String[] inputArr;
		Square curr;
		Square dest;
		Piece piece;
		while(true) {
			board.drawBoard();
			if(turn == 0) {
				if(isInCheck(board, "white")) {
					System.out.println("White King is in check");
				}
			} else if(turn == 1) {
				if(isInCheck(board, "black")) {
					System.out.println("Black King is in check");
				}
			}
			input = l.getString("", 3);
			if(input.equals("concede")) {
				if(turn == 0) {
					return 1;
				} else if(turn == 1) {
					return 0;
				}
			}
			inputArr = input.split("");
			if(inputArr.length == 4) {
				curr = board.getSquare(inputArr[0], inputArr[1]);
				dest = board.getSquare(inputArr[2], inputArr[3]);
				if(curr != null && dest != null) {
					if(curr.getOccupied()) {
						piece = curr.getOccupyingPiece();
						if(turn == 0) {
							if(piece.getColor().equals("white")) {
								if(canMove(board, piece, dest)) {
									if(!isInCheck(board, "white")) {
										movePiece(piece, dest);
										turn = 1;
									} else {
										if(moveOutOfCheck(board, "white", piece, dest)) {
											movePiece(piece, dest);
											turn = 1;
										} else {
											System.out.println("Must move out of check");
											continue;
										}
									}
								} else {
									continue;
								}
							} else {
								System.out.println("Cannot move that piece");
								continue;
							}
						} else if(turn == 1) {
							if(piece.getColor().equals("black")) {
								if(canMove(board, piece, dest)) {
									if(!isInCheck(board, "black")) {
										movePiece(piece, dest);
										turn = 0;
									} else {
										if(moveOutOfCheck(board, "black", piece, dest)) {
											movePiece(piece, dest);
											turn = 0;
										} else {
											System.out.println("Must move out of check");
											continue;
										}
									}
								} else {
									continue;
								}
							} else {
								System.out.println("Cannot move that piece");
								continue;
							}
						}
					} else {
						System.out.print("No piece at ");
						curr.printLoc();
						System.out.println();
						continue;
					}
				} else {
					System.out.println("Invalid input");
					continue;
				}
			} else {
				System.out.println("Invalid input");
				continue;
			}
		}
	}

	public void movePiece(Piece piece, Square dest) {
		if(dest.getOccupied()) {
			dest.getOccupyingPiece().setCaptured(true);
			dest.removePiece();
		}
		piece.getOccupiedSquare().removePiece();
		dest.setOccupyingPiece(piece);
		piece.setOccupiedSquare(dest);
	}
	
	public void movePieceDebug(Piece piece, Square dest) {
		System.out.println("Moving piece: " + piece);
		System.out.println("\t" + piece.getAbv() + "\t" + piece.getLoc());
		System.out.println("Curr square: " + piece.getOccupiedSquare());
		System.out.println("\t" + piece.getOccupiedSquare().getLoc());
		System.out.println("Dest square: " + dest);
		System.out.println("\t" + dest.getLoc());
		if(dest.getOccupied()) {
			Piece capturedPiece = dest.getOccupyingPiece();
			System.out.println("Destination is occupied");
			capturedPiece.setCaptured(true);
			System.out.println(capturedPiece.getAbv() + " captured");
			dest.removePiece();
			System.out.println("Removed piece " + capturedPiece + " from square " + dest);
		}
		Square oldSquare = piece.getOccupiedSquare();
		piece.getOccupiedSquare().removePiece();
		System.out.println("Removed piece " + piece + " from square " + oldSquare);
		dest.setOccupyingPiece(piece);
		System.out.println("Placed piece " + piece + " in square " + dest);
		piece.setOccupiedSquare(dest);
		System.out.println("Set piece " + piece + " occupied square to " + dest);
	}

	public boolean canMove(Board board, Piece piece, Square dest) {

		String type = piece.getType();
		String color = piece.getColor();
		int currRow = piece.getRowVal();
		int currCol = piece.getColVal();
		int destRow = dest.getRowVal();
		int destCol = dest.getColVal();
		int deltaX = destCol - currCol;
		int deltaY = destRow - currRow;

		switch(type) {
		case "Rook":
			if((deltaX != 0 && deltaY == 0) || (deltaX == 0 && deltaY != 0)) {
				if(pathClear(board, piece, dest)) {
					if(dest.getOccupied()) {
						if(!dest.getOccupyingPiece().getColor().equals(color)) {
							return true;
						} else {
							System.out.println("Cannot capture a like-colored piece");
							return false;
						}
					} else {
						return true;
					}
				} else {
					System.out.println("Rook's path is blocked");
					return false;
				}
			} else {
				System.out.println("Illegal move for Rook");
				return false;
			}
		case "Knight":
			if((Math.abs(deltaX) == 2 && Math.abs(deltaY) == 1) ||
					(Math.abs(deltaX) == 1 && Math.abs(deltaY) == 2)) {
				if(dest.getOccupied()) {
					if(!dest.getOccupyingPiece().getColor().equals(color)) {
						return true;
					} else {
						System.out.println("Cannot capture a like-colored piece");
						return false;
					}
				} else {
					return true;
				}
			} else {
				System.out.println("Illegal move for Knight");
				return false;
			}
		case "Bishop":
			if(Math.abs(deltaX) == Math.abs(deltaY)) {
				if(pathClear(board, piece, dest)) {
					if(dest.getOccupied()) {
						if(!dest.getOccupyingPiece().getColor().equals(color)) {
							return true;
						} else {
							System.out.println("Cannot capture a like-colored piece");
							return false;
						}
					} else {
						return true;
					}
				} else {
					System.out.println("Bishop's path is blocked");
					return false;
				}
			} else {
				System.out.println("Illegal move for Bishop");
				return false;
			}
		case "Queen":
			if((deltaX != 0 && deltaY == 0) ||
					(deltaX == 0 && deltaY != 0) ||
					(Math.abs(deltaX) == Math.abs(deltaY))) {
				if(pathClear(board, piece, dest)) {
					if(dest.getOccupied()) {
						if(!dest.getOccupyingPiece().getColor().equals(color)) {
							return true;
						} else {
							System.out.println("Cannot capture a like-colored piece");
							return false;
						}
					} else {
						return true;
					}
				} else {
					System.out.println("Queen's path is blocked");
					return false;
				}
			} else {
				System.out.println("Illegal move for Queen");
				return false;
			}
		case "King":
			if(destRow > currRow + 1 || destRow < currRow - 1 || destCol > currCol + 1 || destCol < currCol - 1) {
				System.out.println("Illegal move for King");
				return false;
			} else {
				if(dest.getOccupied()) {
					if(!dest.getOccupyingPiece().getColor().equals(color)) {
						if(!isThreatened(board, piece, dest)) {
							return true;
						} else {
							System.out.println("King may not move into a threatened square");
							return false;
						}
					} else {
						System.out.println("Cannot capture a like-colored piece");
						return false;
					}
				} else {
					if(!isThreatened(board, piece, dest)) {
						return true;
					} else {
						System.out.println("King may not move into a threatened square");
						return false;
					}
				}
			}
		case "Pawn":
			if((color.equals("white") && ((destRow == currRow + 1) ||
					(currRow == 2 && destRow == 4))) || 
					(color.equals("black") && ((destRow == currRow - 1) ||
							(currRow == 7 && destRow == 5)))) {
				if(destCol == currCol) {
					if(!dest.getOccupied()) {
						return true;
					} else {
						System.out.println("Cannot advance pawn. Destination is occupied");
						return false;
					}
				} else {
					if(destCol == currCol + 1 || destCol == currCol - 1) {
						if(dest.getOccupied()) {
							if(!dest.getOccupyingPiece().getColor().equals(color)) {
								return true;
							} else {
								System.out.println("Cannot capture a like-colored piece");
								return false;
							}
						} else {
							System.out.println("Illegal move for Pawn");
							System.out.println("TODO: Set legal passing move");
							return false;
						}
					} else if(destCol > currCol + 1 || destCol < currCol - 1) {
						System.out.println("Illegal move for Pawn");
						return false;
					} else {
						System.out.println("Error at Rules.canMove(Pawn). Unhandled move");
						System.exit(0);
					}
				}
			} else if((color.equals("white") && (destRow > currRow + 1 || destRow < currRow)) ||
					(color.equals("black") && (destRow < currRow - 1 || destRow > currRow))) {
				System.out.println("Illegal move for Pawn");
				return false;
			} else if(destRow == currRow) {
				System.out.println("Illegal move for Pawn");
				return false;
			} else {
				System.out.println("Error at Rules.canMove(Pawn). Unhandled move");
				System.exit(0);
			}
		default:
			System.out.println("Bad piece passed to Rules.canMove. Received " + type);
			System.exit(0);
		}
		return false;
	}
	
	public boolean isThreatened(Board board, Piece piece, Square dest) {
		String color = piece.getColor();
		board.clearThreat();
		for(Piece checkPiece:board.getPieces()) {
			if(!checkPiece.getCaptured() && !checkPiece.getColor().equals(color)) {
				threatenSquares(board, checkPiece);
				if(dest.getThreatened()) {
					return true;
				}
			}
		}
		return false;
	}
	
	private void threatenSquares(Board board, Piece piece) {
		Square maximumMove;
		int rowVal = piece.getRowVal();
		int colVal = piece.getColVal();
		switch(piece.getType()) {
		case "Rook":
			maximumMove = board.getSquare(1, rowVal);
			threatenLine(board, piece, maximumMove, 0, -1);
			maximumMove = board.getSquare(8, rowVal);
			threatenLine(board, piece, maximumMove, 0, 1);
			maximumMove = board.getSquare(colVal, 1);
			threatenLine(board, piece, maximumMove, -1, 0);
			maximumMove = board.getSquare(colVal, 8);
			threatenLine(board, piece, maximumMove, 1, 0);
			break;
		case "Knight":
			threatenKnight(board, piece);
			break;
		case "Bishop":
			maximumMove = getDiagMax(board, piece, -1, -1);
			threatenLine(board, piece, maximumMove, -1, -1);
			maximumMove = getDiagMax(board, piece, -1, 1);
			threatenLine(board, piece, maximumMove, -1, 1);
			maximumMove = getDiagMax(board, piece, 1, -1);
			threatenLine(board, piece, maximumMove, 1, -1);
			maximumMove = getDiagMax(board, piece, 1, 1);
			threatenLine(board, piece, maximumMove, 1, 1);
			break;
		case "Queen":
			maximumMove = board.getSquare(1, rowVal);
			threatenLine(board, piece, maximumMove, 0, -1);
			maximumMove = board.getSquare(8, rowVal);
			threatenLine(board, piece, maximumMove, 0, 1);
			maximumMove = board.getSquare(colVal, 1);
			threatenLine(board, piece, maximumMove, -1, 0);
			maximumMove = board.getSquare(colVal, 8);
			threatenLine(board, piece, maximumMove, 1, 0);
			maximumMove = getDiagMax(board, piece, -1, -1);
			threatenLine(board, piece, maximumMove, -1, -1);
			maximumMove = getDiagMax(board, piece, -1, 1);
			threatenLine(board, piece, maximumMove, -1, 1);
			maximumMove = getDiagMax(board, piece, 1, -1);
			threatenLine(board, piece, maximumMove, 1, -1);
			maximumMove = getDiagMax(board, piece, 1, 1);
			threatenLine(board, piece, maximumMove, 1, 1);
			break;
		case "King":
			threatenKing(board, piece);
			break;
		case "Pawn":
			threatenPawn(board, piece);
			break;
		}
	}
	
	private Square getDiagMax(Board board, Piece piece, int r, int c) {
		Square maximumMove = piece.getOccupiedSquare();
		Square tempSquare;
		int rowVal = piece.getRowVal();
		int colVal = piece.getColVal();
		int changeRow = r;
		int changeCol = c;
		while(true) {
			tempSquare = board.getSquare(colVal + changeCol, rowVal + changeRow);
			if(tempSquare == null) {
				return maximumMove;
			}
			maximumMove = tempSquare;
			changeRow += r;
			changeCol += c;
		}
	}
	
	 private void threatenLine(Board board, Piece piece, Square maximumMove, int r, int c) {
//		 System.out.println("Threatening Line");
		 Square tempSquare;
		 int rowVal = piece.getRowVal();
		 int colVal = piece.getColVal();
		 int changeRow = r;
		 int changeCol = c;
		 if(piece.getOccupiedSquare() != maximumMove) {
			 do {
				 tempSquare = board.getSquare(colVal + changeCol, rowVal + changeRow);
				 tempSquare.setThreatened(true);
				 changeRow += r;
				 changeCol += c;
			 } while(!tempSquare.getOccupied() && tempSquare != maximumMove);
			 return;
		 }
	 }
	 
	 private void threatenKnight(Board board, Piece knight) {
		 int kr = knight.getRowVal();
		 int kc = knight.getColVal();
		 int deltaX;
		 int deltaY;
		 for(Square[] row:board.getLayout()) {
			 for(Square square:row) {
				 deltaX = square.getColVal() - kc;
				 deltaY = square.getRowVal() - kr;
				 if((Math.abs(deltaX) == 1 && Math.abs(deltaY) == 2) ||
						 (Math.abs(deltaX) == 2 && Math.abs(deltaY) == 1)) {
					 square.setThreatened(true);
				 }
			 }
		 }
	 }
	 
	 private void threatenKing(Board board, Piece king) {
		 int kr = king.getRowVal();
		 int kc = king.getColVal();
		 int rv;
		 int cv;
		 for(Square[] row:board.getLayout()) {
			 for(Square square:row) {
				 rv = square.getRowVal();
				 cv = square.getColVal();
				 if((rv == kr && (cv == kc + 1 || cv == kc - 1)) ||
						 (rv == kr + 1 && (cv == kc + 1 || cv == kc || cv == kc - 1)) ||
						 (rv == kr - 1 && (cv == kc + 1 || cv == kc || cv == kc - 1))) {
					 square.setThreatened(true);
				 }
			 }
		 }
	 }
	 
	 private void threatenPawn(Board board, Piece pawn) {
		 int pr = pawn.getRowVal();
		 int pc = pawn.getColVal();
		 int rv;
		 int cv;
		 for(Square[] row:board.getLayout()) {
			 for(Square square:row) {
				 rv = square.getRowVal();
				 cv = square.getColVal();
				 if((cv == pc + 1 || cv == pc - 1) &&
						 ((pawn.getColor().equals("white") && rv == pr + 1) ||
								 (pawn.getColor().equals("black") && rv == pr - 1))) {
					 square.setThreatened(true);
				 }
			 }
		 }
	 }
	 

	private boolean pathClear(Board board, Piece piece, Square dest) {
		int currRow = piece.getRowVal();
		int currCol = piece.getColVal();
		int destRow = dest.getRowVal();
		int destCol = dest.getColVal();

		Square checkSquare;
		int deltaX = destCol - currCol;
		int checkX;
		int deltaY = destRow - currRow;
		int checkY;
		if(deltaX > 0) {
			checkX = 1; 
		} else if(deltaX < 0) {
			checkX = -1;
		} else {
			checkX = 0;
		}
		if(deltaY > 0) {
			checkY = 1;
		} else if(deltaY < 0) {
			checkY = -1;
		} else {
			checkY = 0;
		}
		checkSquare = board.getSquare(currCol + checkX, currRow + checkY);
		while(checkSquare != dest) {
			if(checkSquare.getOccupied()) {
				return false;
			}
			if(deltaX > 0) {
				checkX++;
			} else if(deltaX < 0) {
				checkX--;
			}
			if(deltaY > 0) {
				checkY++;
			} else if(deltaY < 0) {
				checkY--;
			}
			checkSquare = board.getSquare(currCol + checkX, currRow + checkY);
		}
		return true;
	}
	
	private boolean isInCheck(Board board, String color) {
		if(color.equals("white")) {
			if(isThreatened(board, board.getPieces()[28], board.getPieces()[28].getOccupiedSquare())) {
				return true;
			}
		} else if(color.equals("black")) {
			if(isThreatened(board, board.getPieces()[4], board.getPieces()[4].getOccupiedSquare())) {
				return true;
			}
		}
		return false;
	}
	
	private boolean moveOutOfCheck(Board board, String color, Piece movingPiece, Square dest) {
		Board tempBoard = board.duplicateSelf();
		Square[][] tempLayout = tempBoard.getLayout();
		Piece[] tempPieces = tempBoard.getPieces();
		
		Piece tempPiece = null;
		Square tempSquare = null;
		
		int indexOfPiece = -1;
		int indexOfSquareRow = -1;
		int indexOfSquareCol = -1;
		
		Piece piece;
		for(int i = 0; i < tempPieces.length; i++) {
			piece = tempPieces[i];
			if(piece.getLoc().equals(movingPiece.getLoc())) {
				tempPiece = piece.duplicateSelf();
				indexOfPiece = i;
				break;
			}
		}
		Square square;
		for(int i = 0; i < tempLayout.length; i++) {
			for(int j = 0; j < tempLayout[i].length; j++) {
				square = tempLayout[i][j];
				if(square.getLoc().equals(dest.getLoc())) {
					tempSquare = square.duplicateSelf();
					indexOfSquareRow = i;
					indexOfSquareCol = j;
					break;
				}
			}
			if(tempSquare != null) {
				break;
			} else {
				continue;
			}
		}
		
//		System.out.println("Board: " + board);
//		System.out.println("TempBoard: " + tempBoard);
//		System.out.println("Layout: " + board.getLayout());
//		System.out.println("TempLayout: " + tempLayout);
//		System.out.println("Pieces: " + board.getPieces());
//		System.out.println("TempPieces: " + tempPieces);
		
//		for(Piece piece:tempPieces) {
//			if(piece.getLoc().equals(movingPiece.getLoc())) {
//				tempPiece = piece.duplicateSelf();
//			}
//		}
//		for(Square[] row:tempLayout) {
//			for(Square square:row) {
//				if(square.getLoc().equals(dest.getLoc())) {
//					tempSquare = square.duplicateSelf();
//				}
//			}
//		}
		
		movePieceDebug(tempPiece, tempSquare);
		System.out.println("BOARD");
		board.drawBoard();
		System.out.println("TEMPBOARD");
		tempBoard.drawBoard();
		
		System.out.println("NEWBOARD");
		Board newBoard = new Board(tempLayout, tempPieces);
		newBoard.drawBoard();

		
		if(color.equals("white")) {
			if(!isThreatened(newBoard, tempPieces[28], tempPieces[28].getOccupiedSquare())) {
				return true;
			} else {
				return false;
			}
		} else if(color.equals("black")) {
			if(!isThreatened(newBoard, tempPieces[4], tempPieces[4].getOccupiedSquare())) {
				return true;
			} else {
				return false;
			}
		}
		
		return false;
	}
	
	public void clearBoard(Board board) {
		for(Square[] row:board.getLayout()) {
			for(Square square:row) {
				if(square.getOccupied()) {
					square.removePiece();
				}
			}
		}
	}
	
	public void clearBoard(Board board, Piece keep) {
		for(Square[] row:board.getLayout()) {
			for(Square square:row) {
				if(square.getOccupied()) {
					if(square.getOccupyingPiece() != keep) {
						square.removePiece();
					}
				}
			}
		}
	}

}
