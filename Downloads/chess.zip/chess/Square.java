/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Square {

	private String row;
	private String column;
	private int rowVal;
	private int colVal;
	private String color;
	private boolean occupied;
	private Piece occupyingPiece;
	private boolean threatened;

	public Square(String row, String column, String color) {
		this.row = row;
		this.column = column;
		switch(row) {
		case "1":
			rowVal = 1;
			break;
		case "2":
			rowVal = 2;
			break;
		case "3":
			rowVal = 3;
			break;
		case "4":
			rowVal = 4;
			break;
		case "5":
			rowVal = 5;
			break;
		case "6":
			rowVal = 6;
			break;
		case "7":
			rowVal = 7;
			break;
		case "8":
			rowVal = 8;
			break;
		default:
			System.out.println("Bad row passed to Square. Received " + row);
			System.exit(0);
		}
		switch(column) {
		case "a":
			colVal = 1;
			break;
		case "b":
			colVal = 2;
			break;
		case "c":
			colVal = 3;
			break;
		case "d":
			colVal = 4;
			break;
		case "e":
			colVal = 5;
			break;
		case "f":
			colVal = 6;
			break;
		case "g":
			colVal = 7;
			break;
		case "h":
			colVal = 8;
			break;
		default:
			System.out.println("Bad column passed to Square. Received " + column);
			System.exit(0);
		}
		this.color = color;
		occupied = false;
		occupyingPiece = null;
		threatened = false;
	}

	public String getRow() {
		return row;
	}

	public String getColumn() {
		return column;
	}
	
	public int getRowVal() {
		return rowVal;
	}
	
	public int getColVal() {
		return colVal;
	}

	public String getColor() {
		return color;
	}

	public boolean getOccupied() {
		return occupied;
	}
	public void setOccupied(boolean set) {
		occupied = set;
	}

	public Piece getOccupyingPiece() {
		return occupyingPiece;
	}
	public void setOccupyingPiece(Piece set) {
		occupyingPiece = set;
		occupied = true;
	}
	public void removePiece() {
		occupyingPiece = null;
		occupied = false;
	}
	
	public boolean getThreatened() {
		return threatened;
	}
	public void setThreatened(boolean set) {
		threatened = set;
	}

	public void printSelf() {
		if(occupied) {
			System.out.print(" ");
			occupyingPiece.printSelf();
			System.out.print(" ");
		} else {
			if(color.equals("white")) {
				System.out.print("    ");
			} else {
				System.out.print("////");
			}
		}
	}
	
	public void printLoc() {
		System.out.print(column + row);
	}
	
	public String getLoc() {
		return column+row;
	}
	
	public Square duplicateSelf() {
		Square duplicateSquare = new Square(row, column, color);
		if(occupied) {
			duplicateSquare.setOccupied(true);
			duplicateSquare.setOccupyingPiece(occupyingPiece);
		}
//		duplicateSquare.setOccupied(occupied);
//		duplicateSquare.setOccupyingPiece(occupyingPiece);
		duplicateSquare.setThreatened(threatened);
		return duplicateSquare;
	}

}
