/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Piece {

	private String type;
	private String color;
	private String typeAbv;
	private String colorAbv;
	private Square occupiedSquare;
	private String row;
	private String column;
	private int rowVal;
	private int colVal;
	private boolean captured;

	public Piece(String type, String color, Square occupiedSquare) {
		this.type = type;
		this.color = color;
		switch(type) {
		case "King":
			typeAbv = "K";
			break;
		case "Queen":
			typeAbv = "Q";
			break;
		case "Bishop":
			typeAbv = "B";
			break;
		case "Knight":
			typeAbv = "N";
			break;
		case "Rook":
			typeAbv = "R";
			break;
		case "Pawn":
			typeAbv = "P";
			break;
		default:
			System.out.println("Bad type given to Piece. Type = " + type);
			System.exit(0);
		}
		switch(color) {
		case "white":
			colorAbv = "w";
			break;
		case "black":
			colorAbv = "b";
			break;
		default:
			System.out.println("Bad color given to Piece. Color = " + color);
			System.exit(0);
		}
		this.occupiedSquare = occupiedSquare;
		row = occupiedSquare.getRow();
		column = occupiedSquare.getColumn();
		rowVal = occupiedSquare.getRowVal();
		colVal = occupiedSquare.getColVal();
		captured = false;
	}

	public String getType() {
		return type;
	}

	public String getColor() {
		return color;
	}
	
	public String getAbv() {
		return typeAbv + colorAbv;
	}

	public Square getOccupiedSquare() {
		return occupiedSquare;
	}
	public void setOccupiedSquare(Square set) {
		occupiedSquare = set;
		row = set.getRow();
		column = set.getColumn();
		rowVal = set.getRowVal();
		colVal = set.getColVal();
	}
	
	public String getRow() {
		return row;
	}
	
	public String getColumn() {
		return column;
	}
	
	public int getRowVal() {
		return rowVal;
	}
	
	public int getColVal() {
		return colVal;
	}

	public boolean getCaptured() {
		return captured;
	}
	public void setCaptured(boolean set) {
		captured = set;
	}

	public void printSelf() {
		System.out.print(typeAbv + colorAbv);
	}
	
	public void printLoc() {
		System.out.print(column + row);
	}
	
	public String getLoc() {
		return column + row;
	}
	
	public Piece duplicateSelf() {
		Piece duplicatePiece = new Piece(type, color, occupiedSquare.duplicateSelf());
		duplicatePiece.setCaptured(captured);
		return duplicatePiece;
	}

}