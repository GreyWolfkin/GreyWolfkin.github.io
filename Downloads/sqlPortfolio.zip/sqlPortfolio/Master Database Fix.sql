/*
 * COPYRIGHT Joshua 12/27/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 */

/*
 * MASTER DATABASE FIX
 *	For Use With SQL Server
 *	Fixes many common issues in Microvellum Databases.
 *	Queries are ordered to run in correct sequence,
 *	preventing unintentional deletion or modification
 *	of Template-Level code.
 *	For example: Template-Level Projects and Components
 *	are changed to Type 6, then Projects and Components
 *	with NULL Name and Type 6 are changed to 'CHECKME',
 *	then remaining NULL Name Projects and Components
 *	are deleted. This prevents Template-Level
 *	Projects and Components from being deleted.
 *	Additional non-running code included at the bottom.
 */
 
-- Set schema to dbo for all tables
--	NOTE: May throw "Cannot find table 0" exception.
--	This is not a problem, will still set schema for all
--	found tables
EXECUTE sp_MSforeachtable 'ALTER SCHEMA dbo TRANSFER ?'

-- Update all Template Level Projects to Type 6
UPDATE Projects
SET Type = 6
WHERE LinkID IN (SELECT LinkIDTemplate
	FROM Libraries)
	
-- Update all Template Level Components to Type 6
UPDATE CutPartsFiles
SET Type = 6
WHERE LinkIDProject IN (SELECT LinkIDTemplate
	FROM Libraries)
UPDATE DoorWizardFiles
SET Type = 6
WHERE LinkIDProject IN (SELECT LinkIDTemplate
	FROM Libraries)
UPDATE EdgebandFiles
SET Type = 6
WHERE LinkIDProject IN (SELECT LinkIDTemplate
	FROM Libraries)
UPDATE GlobalFiles
SET Type = 6
WHERE LinkIDProject IN (SELECT LinkIDTemplate
	FROM Libraries)
UPDATE HardwareFiles
SET Type = 6
WHERE LinkIDProject IN (SELECT LinkIDTemplate
	FROM Libraries)
UPDATE ProjectWizardFiles
SET Type = 6
WHERE LinkIDProject IN (SELECT LinkIDTemplate
	FROM Libraries)
	
-- Update all Type 6 Projects with NULL Name to 'CHECKME'
UPDATE Projects
SET Name = 'CHECKME'
WHERE Name IS NULL AND LinkID IN (
	SELECT LinkIDTemplate
	FROM Libraries)

-- Update all Type 6 Components with NULL Name to 'CHECKME'
UPDATE CutPartsFiles
SET Name = 'CHECKME'
WHERE Name IS NULL AND LinkIDProject IN (
	SELECT LinkIDTemplate
	FROM Libraries)
UPDATE DoorWizardFiles
SET Name = 'CHECKME'
WHERE Name IS NULL AND LinkIDProject IN (
	SELECT LinkIDTemplate
	FROM Libraries)
UPDATE EdgebandFiles
SET Name = 'CHECKME'
WHERE Name IS NULL AND LinkIDProject IN (
	SELECT LinkIDTemplate
	FROM Libraries)
UPDATE GlobalFiles
SET Name = 'CHECKME'
WHERE Name IS NULL AND LinkIDProject IN (
	SELECT LinkIDTemplate
	FROM Libraries)
UPDATE HardwareFiles
SET Name = 'CHECKME'
WHERE Name IS NULL AND LinkIDProject IN (
	SELECT LinkIDTemplate
	FROM Libraries)
UPDATE ProjectWizardFiles
SET Name = 'CHECKME'
WHERE Name IS NULL AND LinkIDProject IN (
	SELECT LinkIDTemplate
	FROM Libraries)

-- Delete Projects with NULL Name or Type = 0
DELETE FROM Projects
WHERE Name IS NULL OR Type = 0

-- Delete Componenets with NULL Name or Type = 0
DELETE FROM CutPartsFiles
WHERE Name IS NULL OR Type = 0
DELETE FROM DoorWizardFiles
WHERE Name IS NULL OR Type = 0
DELETE FROM EdgebandFiles
WHERE Name IS NULL OR Type = 0
DELETE FROM GlobalFiles
WHERE Name IS NULL OR Type = 0
DELETE FROM HardwareFiles
WHERE Name IS NULL OR Type = 0
DELETE FROM ProjectWizardFiles
WHERE Name IS NULL OR Type = 0

-- Set Non-Template Projects to Type 5
UPDATE Projects
SET Type = 5
WHERE LinkID NOT IN (
	SELECT LinkIDTemplate
	FROM Libraries)
AND Type = 6

-- Set Non-Template Components to Type 5
UPDATE CutPartsFiles
SET Type = 5
WHERE LinkIDProject NOT IN (
	SELECT LinkIDTemplate
	FROM Libraries)
AND Type = 6
UPDATE DoorWizardFiles
SET Type = 5
WHERE LinkIDProject NOT IN (
	SELECT LinkIDTemplate
	FROM Libraries)
AND Type = 6
UPDATE EdgebandFiles
SET Type = 5
WHERE LinkIDProject NOT IN (
	SELECT LinkIDTemplate
	FROM Libraries)
AND Type = 6
UPDATE GlobalFiles
SET Type = 5
WHERE LinkIDProject NOT IN (
	SELECT LinkIDTemplate
	FROM Libraries)
AND Type = 6
UPDATE HardwareFiles
SET Type = 5
WHERE LinkIDProject NOT IN (
	SELECT LinkIDTemplate
	FROM Libraries)
AND Type = 6
UPDATE ProjectWizardFiles
SET Type = 5
WHERE LinkIDProject NOT IN (
	SELECT LinkIDTemplate
	FROM Libraries)
AND Type = 6

-- Delete Categories with NULL Name
DELETE FROM Categories
WHERE Name IS NULL

-- Delete from Categories where Name = 'Projects' and
--	LinkIDLibrary != 'ROOM COMPONENTS'
DELETE FROM Categories
WHERE Name LIKE 'Projects' AND LinkIDLibrary NOT LIKE 'ROOM COMPONENTS'

-- Delete Materials with NULL Name
DELETE FROM Materials
WHERE Name IS NULL

-- Change ItemNumber for all illegally numbered Products
UPDATE Products
SET ItemNumber = 'CHECKME.99'
WHERE LinkID IN (SELECT LinkID
	FROM Products
	WHERE ItemNumber LIKE '%.%' AND ItemNumber NOT LIKE '%0%' AND ItemNumber NOT LIKE '%1%' AND ItemNumber NOT LIKE '%2%' AND ItemNumber NOT LIKE '%3%' AND ItemNumber NOT LIKE '%4%' AND ItemNumber NOT LIKE '%5%' AND ItemNumber NOT LIKE '%6%' AND ItemNumber NOT LIKE '%7%' AND ItemNumber NOT LIKE '%8%' AND ItemNumber NOT LIKE '%9%')
	
-- Delete Products with NULL Name or NULL LinkID
DELETE FROM Products
WHERE Name IS NULL OR LinkID IS NULL


/* SYS TABLES
INFORMATION_SCHEMA.TABLE_CONSTRAINTS
INFORMATION_SCHEMA.KEY_COLUMN_USAGE
sys.tables
*/

/* UTILITY CODE
-- Find existing constraint
SELECT CONSTRAINT_NAME
FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
WHERE TABLE_NAME = [Table]

-- Find Primary Key
SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE OBJECTPROPERTY(
	OBJECT_ID(
		CONSTRAINT_SCHEMA + '.' + QUOTENAME(
			CONSTRAINT_NAME)), 'IsPrimaryKey') = 1
AND TABLE_NAME = [Table]

-- Find table with no Primary Key
SELECT tab.[name] as table_name
FROM sys.tables tab
LEFT OUTER JOIN sys.indexes pk
ON tab.object_id = pk.object_id
AND pk.is_primary_key = 1
WHERE pk.object_id IS NULL
ORDER BY tab.[name]

-- Add Schema to valid Schemas
IF (NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'schema')) 
BEGIN
    EXEC ('CREATE SCHEMA [schema] AUTHORIZATION [dbo]')
END

-- Allow xp_cmdshell commands
EXEC sp_configure 'show advanced options', 1
RECONFIGURE WITH OVERRIDE
EXEC sp_configure 'xp_cmdshell', 1
RECONFIGURE WITH OVERRIDE

-- Disallow xp_cmdshell commands
EXEC sp_configure 'xp_cmdshell', 0
RECONFIGURE WITH OVERRIDE
EXEC sp_configure 'show advanced options', 0
RECONFIGURE WITH OVERRIDE
*/

/*
WORK IN PROGRESS CODE
-- Check and set Primary Key constraints for
--	all tables
ALTER TABLE [Table]
DROP CONSTRAINT [Constraint]
ALTER TABLE [Table]
ADD CONSTRAINT [Constraint]
PRIMARY KEY [pk]

-- NON WORKING CODE
EXECUTE sp_MSforeachtable 'ALTER TABLE ? DROP CONSTRAINT ' + SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_NAME = ?

*/