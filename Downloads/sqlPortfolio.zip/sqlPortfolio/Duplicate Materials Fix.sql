/*
 * COPYRIGHT Joshua Supelana-Mix 12/27/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 */

/*
 * DUPLICATE MATERIALS FIX
 *	For Use With SQL Server
 *	Deletes duplicate Library-
 *	Level materials. Leaves one
 *	instance of each Library-Level
 *	material in the database
 */
 
DECLARE @matName VARCHAR(MAX) -- Name of Material to delete
DECLARE @loop INT = 0 -- Increments when unique instance is deleted
DECLARE @maxLoop INT -- Loops through each unique instance
DECLARE @dupNum INT -- Determines how many instances to delete

-- Sets maxLoop to loop a number of times equal to the number
--	of unique instances of material names with duplicates.
--	i.e. 250 Duplicates of 0.75 Cherry Solid Stock would
--	count as 1 outer loop.
SET @maxLoop = (
	SELECT COUNT(m.num)
	FROM (
		SELECT COUNT(m1.Name) as num
		FROM Materials m1
		LEFT JOIN Materials m2
		ON m1.Name = m2.Name -- Duplicate Name
		WHERE m1.ID != m2.ID -- Non-Duplicate ID
		AND m1.LinkIDProject IS NULL -- Library Level
		AND m2.LinkIDProject IS NULL -- Library Level
		GROUP BY m1.Name) m)
		

WHILE @loop <= @maxLoop
	BEGIN
	SET @dupNum = 0 -- Reset dupNum
	
	-- Get name of next material with duplicates
	SET @matName = (
		SELECT TOP 1 m1.Name
		FROM Materials m1
		LEFT JOIN Materials m2
		ON m1.Name = m2.Name
		WHERE m1.ID != m2.ID
		AND m1.LinkIDProject IS NULL
		AND m2.LinkIDProject IS NULL)
		
	-- Sets dupNum equal to the number of occurances of material
	--	matching matName
	SET @dupNum = (
		SELECT COUNT(m.Name)
		FROM (
			SELECT Name
			FROM Materials
			WHERE (Name = @matName
			AND LinkIDProject IS NULL)) m)
	-- Decrements dupNum to delete all but one occurance
	SET @dupNum = @dupNum - 1
	
	-- Deletes all but one occurance of material
	DELETE TOP(@dupNum) 
	FROM Materials
	WHERE (Name LIKE @matName
	AND LinkIDProject IS NULL)
	
	SET @loop = @loop + 1
	END