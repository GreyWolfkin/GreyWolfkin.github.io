/*
 * COPYRIGHT Joshua Supelana-Mix 12/27/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 */

/*
 * MASTER DATABASE QUERY
 *	For Use With SQL Server
 *	Searches for common Database issues
 *	such as Projects or Spec Groups
 *	with incorrect Types.
 *	Groups issues into one returned row
 *	for ease of diagnosis/documentation.
 */

-- Looks for tables with schema != 'dbo'
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '01_Tables with Incorrect Schema' as Problem
	FROM sys.tables
	WHERE SCHEMA_NAME(schema_id) NOT LIKE 'dbo') s1
GROUP BY s1.Problem

-- Looks for Template Projects with Type != 6
UNION
SELECT p1.Problem, COUNT(p1.Problem) as Count
FROM (
	SELECT '02_Template Project Incorrect Type' as Problem
	FROM Projects
	WHERE LinkID IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type != 6) p1
GROUP BY p1.Problem

-- Looks for Template Spec Components with Type != 6
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '03_Template CutPartsFiles Incorrect Type' as Problem
	FROM CutPartsFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type != 6) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '03_Template DoorWizardFiles Incorrect Type' as Problem
	FROM DoorWizardFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type != 6) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '03_Template EdgebandFiles Incorrect Type' as Problem
	FROM EdgebandFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type != 6) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '03_Template GlobalFiles Incorrect Type' as Problem
	FROM GlobalFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type != 6) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '03_Template HardwareFiles Incorrect Type' as Problem
	FROM HardwareFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type != 6) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '03_Template ProjectWizardFiles Incorrect Type' as Problem
	FROM ProjectWizardFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type != 6) s1
GROUP BY s1.Problem

-- Looks for Template Projects where Name IS NULL
UNION
SELECT p1.Problem, COUNT(p1.Problem) as Count
FROM (
	SELECT '04_Template Project with NULL Name' as Problem
	FROM Projects
	WHERE LinkID IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Name IS NULL) p1
GROUP BY p1.Problem

-- Looks for Template Componenets where Name IS NULL
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '05_Template CutPartsFiles with NULL Name' as Problem
	FROM CutPartsFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Name IS NULL) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '05_Template DoorWizardFiles with NULL Name' as Problem
	FROM DoorWizardFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Name IS NULL) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '05_Template EdgebandFiles with NULL Name' as Problem
	FROM EdgebandFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Name IS NULL) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '05_Template GlobalFiles with NULL Name' as Problem
	FROM GlobalFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Name IS NULL) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '05_Template HardwareFiles with NULL Name' as Problem
	FROM HardwareFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Name IS NULL) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '05_Template ProjectWizardFiles with NULL Name' as Problem
	FROM ProjectWizardFiles
	WHERE LinkIDProject IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Name IS NULL) s1
GROUP BY s1.Problem

-- Looks for Non-Template Projects where Name IS NULL
UNION
SELECT p1.Problem, COUNT(p1.Problem) as Count
FROM (
	SELECT '06_Non-Template Project with NULL Name' as Problem
	FROM Projects
	WHERE LinkID NOT IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Name IS NULL) p1
GROUP BY p1.Problem

-- Looks for Non-Template Components where Name IS NULL
--	or Type = 0
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '07_Non-Template CutPartsFiles with NULL Name or Type = 0' as Problem
	FROM CutPartsFiles
	WHERE LinkIDProject NOT IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND (Name IS NULL OR Type = 0)) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '07_Non-Template DoorWizardFiles with NULL Name or Type = 0' as Problem
	FROM DoorWizardFiles
	WHERE LinkIDProject NOT IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND (Name IS NULL OR Type = 0)) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '07_Non-Template EdgebandFiles with NULL Name or Type = 0' as Problem
	FROM EdgebandFiles
	WHERE LinkIDProject NOT IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND (Name IS NULL OR Type = 0)) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '07_Non-Template GlobalFiles with NULL Name or Type = 0' as Problem
	FROM GlobalFiles
	WHERE LinkIDProject NOT IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND (Name IS NULL OR Type = 0)) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '07_Non-Template HardwareFiles with NULL Name or Type = 0' as Problem
	FROM HardwareFiles
	WHERE LinkIDProject NOT IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND (Name IS NULL OR Type = 0)) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '07_Non-Template ProjectWizardFiles with NULL Name or Type = 0' as Problem
	FROM ProjectWizardFiles
	WHERE LinkIDProject NOT IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND (Name IS NULL OR Type = 0)) s1
GROUP BY s1.Problem

-- Looks for Non-Template Projects with Type = 6
UNION
SELECT p1.Problem, COUNT(p1.Problem) as Count
FROM (
	SELECT '08_Non-Template Project with Type = 6' as Problem
	FROM Projects
	WHERE LinkID NOT IN (
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type = 6) p1
GROUP BY p1.Problem

-- Looks for Non-Template Componenets with Type = 6
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '09_Non-Template CutPartsFiles with Type = 6' as Problem
	FROM CutPartsFiles
	WHERE LinkIDProject NOT IN(
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type = 6) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '09_Non-Template DoorWizardFiles with Type = 6' as Problem
	FROM DoorWizardFiles
	WHERE LinkIDProject NOT IN(
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type = 6) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '09_Non-Template EdgebandFiles with Type = 6' as Problem
	FROM EdgebandFiles
	WHERE LinkIDProject NOT IN(
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type = 6) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '09_Non-Template GlobalFiles with Type = 6' as Problem
	FROM GlobalFiles
	WHERE LinkIDProject NOT IN(
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type = 6) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '09_Non-Template HardwareFiles with Type = 6' as Problem
	FROM HardwareFiles
	WHERE LinkIDProject NOT IN(
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type = 6) s1
GROUP BY s1.Problem
UNION
SELECT s1.Problem, COUNT(s1.Problem) as Count
FROM (
	SELECT '09_Non-Template ProjectWizardFiles with Type = 6' as Problem
	FROM ProjectWizardFiles
	WHERE LinkIDProject NOT IN(
		SELECT LinkIDTemplate
		FROM Libraries)
	AND Type = 6) s1
GROUP BY s1.Problem

-- Looks for Categories with NULL Name
UNION
SELECT c1.Problem, COUNT(c1.Problem) as Count
FROM (
	SELECT '10_NULL Name Categories' as Problem
	FROM Categories c
	WHERE c.Name IS NULL) c1
GROUP BY c1.Problem

-- Looks for Categories with Name = 'Projects'
--	and LinkIDLibrary != 'ROOM COMPONENTS'
UNION
SELECT c1.Problem, COUNT(c1.Problem) as Count
FROM (
	SELECT '11_Duplicate ''Projects'' Categories' as Problem
	FROM Categories c
	WHERE c.Name = 'Projects' AND c.LinkIDLibrary != 'ROOM COMPONENTS') c1
GROUP BY c1.Problem

-- Looks for Materials with NULL Name
UNION
SELECT m1.Problem, COUNT(m1.Problem) as Count
FROM (
	SELECT '12_NULL Name Materials' as Problem
	FROM Materials m
	WHERE m.Name IS NULL) m1
GROUP BY m1.Problem

-- Looks for illegally numbered Products
UNION
SELECT p1.Problem, COUNT(p1.Problem) as Count
FROM (
	SELECT '13_Illegally Numbered Products' as Problem
	FROM Products p
	WHERE ItemNumber LIKE '%.%' AND ItemNumber NOT LIKE '%0%' AND ItemNumber NOT LIKE '%1%' AND ItemNumber NOT LIKE '%2%' AND ItemNumber NOT LIKE '%3%' AND ItemNumber NOT LIKE '%4%' AND ItemNumber NOT LIKE '%5%' AND ItemNumber NOT LIKE '%6%' AND ItemNumber NOT LIKE '%7%' AND ItemNumber NOT LIKE '%8%' AND ItemNumber NOT LIKE '%9%') p1
GROUP BY p1.Problem

-- Looks for Products with NULL Name or NULL LinkID
UNION
SELECT p1.Problem, COUNT(p1.Problem) as Count
FROM (
	SELECT '13_Products with NULL Name or NULL LinkID' as Problem
	FROM Products p
	WHERE p.Name IS NULL OR p.LinkID IS NULL) p1
GROUP BY p1.Problem