from tkinter import *
from PIL import ImageTk,Image

root = Tk()
canvas = Canvas(root, width = 500, height = 500)
canvas.pack()
img1 = ImageTk.PhotoImage(Image.open("map r1.png"))
img2 = ImageTk.PhotoImage(Image.open("map r2.png"))
img3 = ImageTk.PhotoImage(Image.open("map r3.png"))
img4 = ImageTk.PhotoImage(Image.open("map r4.png"))
img5 = ImageTk.PhotoImage(Image.open("map r5.png"))
img6 = ImageTk.PhotoImage(Image.open("map r6.png"))
img7 = ImageTk.PhotoImage(Image.open("map r7.png"))
img8 = ImageTk.PhotoImage(Image.open("map r8.png"))
img9 = ImageTk.PhotoImage(Image.open("map r9.png"))
img10 = ImageTk.PhotoImage(Image.open("map r10.png"))
img11 = ImageTk.PhotoImage(Image.open("map r11.png"))
img12 = ImageTk.PhotoImage(Image.open("map r12.png"))

imageOnCanvas = canvas.create_image(20, 20, anchor=NW, image=img1)

class Room:
	def __init__(self, valN, valE, valS, valW):
		self.valN = valN
		self.valE = valE
		self.valS = valS
		self.valW = valW

r1 = Room(True, False, False, False)
r2 = Room(True, True, True, True)
r3 = Room(False, True, False, True)
r4 = Room(True, True, True, False)
r5 = Room(True, False, False, False)
r6 = Room(False, False, True, False)
r7 = Room(False, False, False, True)
r8 = Room(True, False, True, False)
r9 = Room(False, True, True, True)
r10 = Room(False, True, False, False)
r11 = Room(False, False, True, True)
r12 = Room(True, False, False, False)

dungeon = [ [r5, r4, r6, None], [None, r3, None, r10], [r1, r2, r8, r9], [None, r7, r12, r11] ]

x = 2
y = 0

def getRoom():
	global x
	global y
	r = dungeon[x][y]
	return r

def upKey(event):
	r = getRoom()
	global y
	if r.valN:
		y += 1
	setImg()

def rightKey(event):
	r = getRoom()
	global x
	if r.valE:
		x += 1
	setImg()
	
def downKey(event):
	r = getRoom()
	global y
	if r.valS:
		y -= 1
	setImg()
	
def leftKey(event):
	r = getRoom()
	global x
	if r.valW:
		x -= 1
	setImg()
	
def setImg():
	r = getRoom()
	if r == r1:
		canvas.itemconfig(imageOnCanvas, image = img1)
	if r == r2:
		canvas.itemconfig(imageOnCanvas, image = img2)
	if r == r3:
		canvas.itemconfig(imageOnCanvas, image = img3)
	if r == r4:
		canvas.itemconfig(imageOnCanvas, image = img4)
	if r == r5:
		canvas.itemconfig(imageOnCanvas, image = img5)
	if r == r6:
		canvas.itemconfig(imageOnCanvas, image = img6)
	if r == r7:
		canvas.itemconfig(imageOnCanvas, image = img7)
	if r == r8:
		canvas.itemconfig(imageOnCanvas, image = img8)
	if r == r9:
		canvas.itemconfig(imageOnCanvas, image = img9)
	if r == r10:
		canvas.itemconfig(imageOnCanvas, image = img10)
	if r == r11:
		canvas.itemconfig(imageOnCanvas, image = img11)
	if r == r12:
		canvas.itemconfig(imageOnCanvas, image = img12)
	
root.bind('<Up>', upKey)
root.bind('<Right>', rightKey)
root.bind('<Down>', downKey)
root.bind('<Left>', leftKey)

root.mainloop()