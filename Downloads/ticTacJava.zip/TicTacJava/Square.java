/*****
 * COPYRIGHT Joshua Supelana-Mix 11/12/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 *****/

class Square {
	
	/*****
	 * loc = Location. Integer value representing square's position on the board.
	 * 
	 * own = Owner. Represents whether square is owned by X, O, or neither.
	 *	-1 means empty, 0 means owned by X, 1 means owned by O.
	 * 
	 * possWins = Possible Wins. Used to calculate how many ways the computer
	 *	could possibly win if it claimed this square.
	 * 
	 * pos = Position. Old code used in v0.1 to determine relative location of
	 *	square. Kept in Square class as method placeO() still references it.
	 *****/
	 
	private int loc, own, possWins;
	private String pos;
	
	public Square(int loc) {
		this.loc = loc;
		this.own = -1;
		this.possWins = 0;
		
		switch(loc) {
			case 1:
			case 3:
			case 7:
			case 9:
				this.pos = "corner";
				break;
			case 5:
				this.pos = "center";
				break;
			case 2:
			case 4:
			case 6:
			case 8:
				this.pos = "edge";
				break;
		}
	}
	
	public int getLoc() {
		return loc;
	}
	
	public int getOwn() {
		return own;
	}
	public void setOwn(int set) {
		this.own = set;
	}
	public String owner() {
		// Returns x, o, or " " depending on ownership of square.
		if(own == -1) {
			return " ";
		} else if(own == 0) {
			return "x";
		} else if(own == 1) {
			return "o";
		} else {
			return "ERROR";
		}
	}
	
	public int getPossWins() {
		return possWins;
	}
	public void setPossWins(int set) {
		possWins = set;
	}
	public void adjPossWins(int adj) {
		possWins += adj;
	}
	
	public String getPos() {
		return pos;
	}
}