/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/
 
 /*****
 * TicTacJava v2.1
 * Features three modules: Playing against the computer, playing against another user, 
 * 	and running 1000 games for testing and debugging.
 * Computer is designed to never lose, regardless of whether it is playing X or O.
 * When a human is playing against the computer, takes input 1-9 to place user's mark in 
 * 	an unoccupied space.
 * User is randomly assigned to play X or O.
 * Computer's strategy changes depending on if it is playing X or O
 * Computer plays based on prioritization of winning moves. Roughly, this looks like:
 *	1) Can the computer win? If so, play there.
 *	2) Can the computer block the user? If so, play there.
 *	3) Can the computer trap the user? If so, play there.
 *	4) Can the computer prevent an upcoming trap? If so, play there.
 *	5) Can the computer prevent a possible mistake? If so, play there.
 *	6) If all other priorities fail, place in a random square
 * Algorithms were tested using repeatGame() method to run 1000 games and
 *	return the total wins or ties. Once repeatGame() repeatedly returned
 *	ties 1000 out of 1000 times, computer was ready to play the user.
 * The computer cannot lose, regardless of whether user plays X or O. 
 * Test it for yourself!
 *****/

/*****
 * TO DO (v2.0)
 *	DONE - Standardize arguments passed to methods
 *			- Arguments should be passed (as needed) in order:
 *				- input, random, computer, human, square, squares, board, winStates
 *	DONE - Correct all method calls to reflect standardized argument passing
 *	DONE - Organize method declaration for ease of reading
 *	DONE - Finish cleaning up comments
 *	DONE - Clean up for{} calls. Use for(Square sq:) instead of for(int i = 0) 
 *	 		whenever possible
 *			- Addition of indexOfSquare() method allows for more efficient use of for{} calls.
 *				USE IT!
 *	DONE - Improve variable names. Cut out as many instances of "i" as possible and
 *			replace with more specifics.
 *			- Remember, good code is self-explanatory
 *	DONE - Add playWithHuman() module
 *****/

import java.util.Random;

public class TicTacJava {
	
	static Square[] buildSquares() {
		Square[] squares = new Square[9];
		for(int i = 1; i < 10; i++) {
			Square sq = new Square(i);
			squares[i - 1] = sq;
		}
		return squares;
	}
	
	// Returns a multidimensional array replicating layout of the TicTacToe board.
	static Square[][] buildBoard(Square[] squares) {
		Square[][] board = {{squares[0], squares[1], squares[2]},
							{squares[3], squares[4], squares[5]},
							{squares[6], squares[7], squares[8]}};
		return board;
	}
	
	// Returns a multidimensional array of all possible win conditions for the board.
	static Square[][] buildWinStates(Square[] squares) {
		Square[][] winStates = {{squares[0], squares[1], squares[2]},
								{squares[3], squares[4], squares[5]},
								{squares[6], squares[7], squares[8]},
								{squares[0], squares[3], squares[6]},
								{squares[1], squares[4], squares[7]},
								{squares[2], squares[5], squares[8]},
								{squares[0], squares[4], squares[8]},
								{squares[2], squares[4], squares[6]}};
		return winStates;
	}
	
	// For user reference. Printed every time board is displayed.
	static void basicBoard() {
		System.out.println(" 1 | 2 | 3");
		System.out.println("-----------");
		System.out.println(" 4 | 5 | 6");
		System.out.println("-----------");
		System.out.println(" 7 | 8 | 9\n");
	}
	
	static void printBoard(Square[] squares) {
		basicBoard();
		// Calls sq.owner() to get String "x", "o", or " " representing
		//	ownership of that square.
		System.out.println(" " + squares[0].owner() + " | " + squares[1].owner() + " | " + squares[2].owner());
		System.out.println("-----------");
		System.out.println(" " + squares[3].owner() + " | " + squares[4].owner() + " | " + squares[5].owner());
		System.out.println("-----------");
		System.out.println(" " + squares[6].owner() + " | " + squares[7].owner() + " | " + squares[8].owner() + "\n");
	}
	
	// Allows user to play against the computer.
	static void playWithComputer(input_utils in, Random rand, Square[] squares, Square[][] board, Square[][] winStates) {
		// Resets ownership of all squares.
		for(Square sq:squares) {
			sq.setOwn(-1);
		}
		// Randomly assigns player X or O.
		int human = rand.nextInt(2);
		int computer = -1;
		int turn = 0;
		int winner = -1;
		if(human == 0) {
			System.out.println("You are playing X! You will go first.");
			computer = 1;
		} else if(human == 1) {
			System.out.println("You are playing O! You will go second.");
			computer = 0;
		}
		in.get(); // Waits for input.
		printBoard(squares);
		while(winner == -1) {
			if(turn == computer) {
				if(computer == 0) {
					placeX(rand, squares, board, winStates);
				} else if(computer == 1) {
					placeO(rand, squares, board, winStates);
				}
				turn = human;
			} else if(turn == human) {
				getSquareIn(in, human, squares);
				turn = computer;
			}
			printBoard(squares);
			winner = checkWin(squares, winStates);
			if(winner == computer) {
				System.out.println("Computer wins!");
				return;
			} else if(winner == human) {
				// This should never come up. Computer should always win or tie.
				System.out.println("Human wins!");
				System.out.println("An Error has occurred in the game-playing algorithm. Computer should always win or tie.");
				return;
			} else if(winner == 2) {
				System.out.println("No winner.");
				return;
			}
		}
	}
	
	// Allows two users to play against each other.
	static void playWithHuman(input_utils in, Square[] squares, Square[][] board, Square[][] winStates) {
		// Resets ownership of all squares.
		for(Square sq:squares) {
			sq.setOwn(-1);
		}
		int turn = 0;
		int winner = -1;
		while(winner == -1) {
			if(turn == 0) {
				System.out.println("X's turn!");
				printBoard(squares);
				getSquareIn(in, 0, squares);
				turn = 1;
			} else if(turn == 1) {
				System.out.println("O's turn!");
				printBoard(squares);
				getSquareIn(in, 1, squares);
				turn = 0;
			}
			winner = checkWin(squares, winStates);
			if(winner == 0) {
				printBoard(squares);
				System.out.println("X wins!");
				return;
			} else if(winner == 1) {
				printBoard(squares);
				System.out.println("O wins!");
				return;
			} else if(winner == 2) {
				printBoard(squares);
				System.out.println("No winner.");
				return;
			}
		}
	}
	
	// Runs 1000 games and returns number of wins and ties.
	static void repeatGame(Random rand, Square[] squares, Square[][] board, Square[][] winStates) {
		int winsX = 0;
		int winsO = 0;
		int ties = 0;
		for(int repeat = 0; repeat < 1000; repeat++) {
			// Resets ownership of all squares.
			for(Square sq:squares) {
				sq.setOwn(-1);
			}
			int turn = 0;
			int winner = -1;
			while(winner == -1) {
				if(turn == 0) {
					placeX(rand, squares, board, winStates);
					turn = 1;
				} else if(turn == 1) {
					placeO(rand, squares, board, winStates);
					turn = 0;
				}
				winner = checkWin(squares, winStates);
				if(winner == 0) {
					winsX++;
				} else if(winner == 1) {
					winsO++;
				} else if(winner == 2) {
					ties++;
				}
			}
		}
		System.out.println("X Wins: " + winsX + "\nO Wins: " + winsO + "\nTies: " + ties);
		return;
	}
	
	// Utilizes input_utils v1.0 to retrieve user input.
	//	Tests if user has input an empty square and repeats until input is valid.
	static void getSquareIn(input_utils in, int human, Square[] squares) {
		while(true) {
			int userIn = in.getInt("", 1, 9);
			Square selectedSquare = squares[userIn - 1];
			if(selectedSquare.getOwn() == -1) {
				selectedSquare.setOwn(human);
				return;
			} else {
				System.out.println("Cannot place there.");
			}
		}
	}
	
	// Computer strategy for playing X.
	static void placeX(Random rand, Square[] squares, Square[][] board, Square[][] winStates) {
		// Looks for an immediate win or imminent threat.
		int winningSquare = checkForWinOrBlock(0, 1, squares, winStates);
		if(winningSquare != -1) {
			// winningSquare != -1 means a win or block is available.
			//	X takes the win or block.
			squares[winningSquare].setOwn(0);
			return;
		} // winningSquare == -1 means no win or block is available.
		
		// If no win or block is available, X's strategy depends on how many squares have been claimed.
		int filledSquares = checkFilled(squares);
		switch(filledSquares) {
			case 0:
				/*****
				 * If filledSquares == 0, X takes a random corner.
				 * Though taking the center square is also a valid
				 *	opening play, taking a corner provides more
				 *	opportunities for the user to make a mistake
				 *	resulting in a win for X.
				 *****/
				int randomCorner = rand.nextInt(4);
				switch(randomCorner) {
					case 0:
						squares[0].setOwn(0);
						break;
					case 1:
						squares[2].setOwn(0);
						break;
					case 2:
						squares[6].setOwn(0);
						break;
					case 3:
						squares[8].setOwn(0);
						break;
				}
				break;
				
			case 2:
				/*****
				 * If filledSquares == 2, checks which corner is owned
				 *	and whether or not O has taken the center.
				 * Strategy changes based on these factors.
				 *****/
				Square ownedCorner = null;
				for(Square sq:squares) {
					// Determines which corner X claimed in the first move.
					if(sq.getOwn() == 0) {
						ownedCorner = sq;
					}
				}
				if(squares[4].getOwn() != 1) { 
					/*****
					 * If O has not taken the center, look for an adjacent corner with
					 *	an empty square between them, setting up a future trap.
					 * option1 and option2 represent the two possible squares.
					 *****/
					Square option1 = null;
					Square option2 = null;
					
					for(int looking = 0; looking < board.length; looking++) {
						// Looking for corner left or right from owned.
						if(board[looking][0] == ownedCorner && board[looking][1].getOwn() == -1 && board[looking][2].getOwn() == -1) {
							// If left-most corner is owned, adjacent edge is empty, and right-most corner is empty, option1 is right-most corner.
							option1 = board[looking][2];
						} else if(board[looking][2] == ownedCorner && board[looking][0].getOwn() == -1 && board[looking][1].getOwn() == -1) {
							// If right-most corner is owned, adjacent edge is empty, and left-most corner is empty, option1 is left-most corner.
							option1 = board[looking][0];
						}
						
						// Looking for corner above or below from owned.
						try {
							if(board[looking][0] == ownedCorner && board[looking + 1][0].getOwn() == -1 && board[looking + 2][0].getOwn() == -1) {
								// If bottom-left corner is owned, left edge is empty, and top-left corner is empty, option2 is top-left corner.
								option2 = board[looking + 2][0];
							} else if(board[looking][2] == ownedCorner && board[looking + 1][2].getOwn() == -1 && board[looking + 2][2].getOwn() == -1) {
								// If bottom-right corner is owned, right edge is empty, and top-right corner is empty, option2 is top-right corner.
								option2 = board[looking + 2][2];
							}
							
						// For top-most corners, [looking + x] will throw IndexOutOfBoundsException. Catch statement takes
						//	top-most corners and searches for [looking - x] indead.
						} catch(IndexOutOfBoundsException ex) {
							if(board[looking][0] == ownedCorner && board[looking - 1][0].getOwn() == -1 && board[looking - 2][0].getOwn() == -1) {
								// If top-left corner is owned, left edge is empty, and bottom-left corner is empty, option2 is bottom-left corner.
								option2 = board[looking - 2][0];
							} else if(board[looking][2] == ownedCorner && board[looking - 1][2].getOwn() == -1 && board[looking - 2][2].getOwn() == -1) {
								// If top-right corner is owned, right edge is empty, and bottom-right corner is empty, option2 is bottom-right corner.
								option2 = board[looking - 2][2];
							}
						}
					}
					
					// If there are two valid options, chooses one of the options at random.
					if(option1 != null && option2 != null) {
						int randomOption = rand.nextInt(2);
						if(randomOption == 0) {
							option1.setOwn(0);
							return;
						} else if(randomOption == 1) {
							option2.setOwn(0);
							return;
						}
					} else if (option1 != null && option2 == null) {
						// If there is only one valid option.
						option1.setOwn(0);
						return;
					} else if (option1 == null && option2 != null) {
						option2.setOwn(0);
						return;
					}
					
				} else if(squares[4].getOwn() == 1) {
					// If O has taken the center.
					// randomChoice determines if X will play to a corner or an edge.
					int randomChoice = rand.nextInt(2);
					if(randomChoice == 0) {
						// Place X on opposite corner from ownedCorner.
						if(ownedCorner == squares[0]) {
							squares[8].setOwn(0);
							return;
						} else if(ownedCorner == squares[2]) {
							squares[6].setOwn(0);
							return;
						} else if(ownedCorner == squares[6]) {
							squares[2].setOwn(0);
							return;
						} else if(ownedCorner == squares[8]) {
							squares[0].setOwn(0);
							return;
						}
					}
					else if(randomChoice == 1) {
						// Place X on edge not touching ownedCorner.
						//	Randomly determines on which edge to play.
						int randomEdge = rand.nextInt(2);
						if(ownedCorner == squares[0]) {
							if(randomEdge == 0) {
								squares[5].setOwn(0);
								return;
							} else if(randomEdge == 1) {
								squares[7].setOwn(0);
								return;
							}
						} else if(ownedCorner == squares[2]) {
							if(randomEdge == 0) {
								squares[3].setOwn(0);
								return;
							} else if(randomEdge == 1) {
								squares[7].setOwn(0);
								return;
							}
						} else if(ownedCorner == squares[6]) {
							if(randomEdge == 0) {
								squares[1].setOwn(0);
								return;
							} else if(randomEdge == 1) {
								squares[5].setOwn(0);
								return;
							}
						} else if(ownedCorner == squares[8]) {
							if(randomEdge == 0) {
								squares[1].setOwn(0);
								return;
							} else if(randomEdge == 1) {
								squares[3].setOwn(0);
								return;
							}
						}
					}
				}
				break;
				
			default:
				/*****
				 * If filledSquares >= 4, looks for best play. Looks for plays in this order:
				 *	1) Trap user
				 *	2) Prevent user trap
				 *	3) Play to set up a win
				 *****/
				int best = findBest(0, 1, squares, board, winStates);
				if(best != -1) {
					// best != -1 means a best play was found.
					squares[best].setOwn(0);
					return;
				} else if(best == -1) {
					// best == -1 means no best play found. Playing to random square.
					while(true) {
						int randomSquare = rand.nextInt(9);
						if(squares[randomSquare].getOwn() == -1) {
							squares[randomSquare].setOwn(0);
							return;
						}
					}
				}
				break;
		}
	}
	
	// Computer strategy for playing O.
	// O's strategy is more complicated than X's, as O must play more reactively while
	//	still looking for mistakes in X's play.
	static void placeO(Random rand, Square[] squares, Square[][] board, Square[][] winStates) {
		// Looks for an immediate win or imminent threat.
		int winningSquare = checkForWinOrBlock(1, 0, squares, winStates);
		if(winningSquare != -1) {
			// winningSquare != -1 means a win or block is available.
			//	O takes the win or block.
			squares[winningSquare].setOwn(1);
			return;
		} // winningSquare == -1 means no win or block available.
		
		// If no win or block available, O's strategy depends on how many squares have been
		//	claimed.
		int randomCorner = rand.nextInt(4);
		int filledSquares = checkFilled(squares);
		switch(filledSquares) {
			case 1:
				if(squares[4].getOwn() == -1) {
					// If opponent has not taken the center, taking the center is the best first play for O.
					squares[4].setOwn(1);
					return;
				} else if(squares[4].getOwn() == 0) {
					// If opponent has taken the center, taking a random corner is the best first play for O.
					switch(randomCorner) {
						case 0:
							squares[0].setOwn(1);
							return;
						case 1:
							squares[2].setOwn(1);
							return;
						case 2:
							squares[6].setOwn(1);
							return;
						case 3:
							squares[8].setOwn(1);
							return;
					}
				}
				break;
			case 3:
				// If filledSquares == 3, O's strategy is dependant on how many corners X has claimed.
				int cornersOwned = 0;
				for(Square sq:squares) {
					if(sq.getOwn() == 0 && sq.getPos().equals("corner")) {
						cornersOwned++;
					}
				}
				if(cornersOwned == 0) {
					// If X has taken no corners, it may be possible to win. If X has taken two adjacent edges, O can find a trap and guarantee a win.
					int best = findBest(1, 0, squares, board, winStates);
					if(best != -1) {
						squares[best].setOwn(1);
						return;
					} else {
						// If X has taken no corners and taken two non-adjacent edges, O's best play is to play to an empty edge.
						int randomEdge = rand.nextInt(2);
						if(randomEdge == 0) {
							if(squares[1].getOwn() == -1) {
								squares[1].setOwn(1);
								return;
							} else if(squares[3].getOwn() == -1){
								squares[3].setOwn(1);
								return;
							}
						} else if(randomEdge == 1) {
							if(squares[5].getOwn() == -1) {
								squares[5].setOwn(1);
								return;
							} else if(squares[7].getOwn() == -1) {
								squares[7].setOwn(1);
								return;
							}
						}
					}
				} else if(cornersOwned == 1) {
					// If X has taken one corner and is not threatening a win, then X has played to a non-adjacent edge. Look for best play.
					int best = findBest(1, 0, squares, board, winStates);
					if(best != -1) {
						squares[best].setOwn(1);
						return;
					}
				} else if(cornersOwned == 2) {
					// If X has taken two corners and is not threatening a win, then X has played to the distant corner. The only way to avoid X's trap is to play to a random edge.
					int randomEdge = rand.nextInt(4);
					switch(randomEdge) {
						case 0:
							squares[1].setOwn(1);
							return;
						case 1:
							squares[3].setOwn(1);
							return;
						case 2:
							squares[5].setOwn(1);
							return;
						case 3:
							squares[7].setOwn(1);
							return;
					}
				}
				break;
			default:
				// Once filledSquares > 3, looks for best play and if no best play available, takes a random square.
				int best = findBest(1, 0, squares, board, winStates);
				if(best != -1) {
					squares[best].setOwn(1);
					return;
				} else {
					while(true) {
						int randomSquare = rand.nextInt(9);
						if(squares[randomSquare].getOwn() == -1) {
							squares[randomSquare].setOwn(1);
							return;
						}
					}
				}
		}
	}

	static int checkForWinOrBlock(int computer, int human, Square[] squares, Square[][] winStates) {
		int index = -1;
		for(Square[] winState:winStates) {
			// Looks for an immediate win and returns index of winning play
			if(winState[0].getOwn() == -1 && winState[1].getOwn() == computer && winState[2].getOwn() == computer) {
				index = indexOfSquare(winState[0], squares);
				return index;
			} else if(winState[1].getOwn() == -1 && winState[0].getOwn() == computer && winState[2].getOwn() == computer) {
				index = indexOfSquare(winState[1], squares);
				return index;
			} else if(winState[2].getOwn() == -1 && winState[0].getOwn() == computer && winState[1].getOwn() == computer) {
				index = indexOfSquare(winState[2], squares);
				return index;
			}
		}
		for(Square[] winState:winStates) {
			// If no winning play found, looks for an imminent threat and returns index of blocking play
			if(winState[0].getOwn() == -1 && winState[1].getOwn() == human && winState[2].getOwn() == human) {
				index = indexOfSquare(winState[0], squares);
				return index;
			} else if(winState[1].getOwn() == -1 && winState[0].getOwn() == human && winState[2].getOwn() == human) {
				index = indexOfSquare(winState[1], squares);
				return index;
			} else if(winState[2].getOwn() == -1 && winState[0].getOwn() == human && winState[1].getOwn() == human) {
				index = indexOfSquare(winState[2], squares);
				return index;
			}
		}
		return index;
	}
	
	// Returns the index of a given square.
	static int indexOfSquare(Square sq, Square[] squares) {
		for(int i = 0; i < squares.length; i++) {
			if(sq == squares[i]) {
				return i;
			}
		}
		return -1;
	}
	
	static int checkFilled(Square[] squares) {
		int filledSquares = 0;
		for(Square sq:squares) {
			if(sq.getOwn() != -1) {
				// If a square is owned by -1, it is empty. Otherwise, it is owned by either X or O.
				filledSquares++;
			}
		}
		return filledSquares;
	}
	
	static int findBest(int computer, int human, Square[] squares, Square[][] board, Square[][] winStates) {
		// Looks for a trap first (possWins > 1), then for upcoming
		//	opponent traps (findTrap != -1),
		//	then for best possible play (possWins == 1).
		//	If none found, returns -1.
		
		for(Square sq:squares) {
			// Resets possible wins for square to 0
			sq.setPossWins(0);
			if(sq.getOwn() == -1) {
				for(Square[] winState:winStates) {
					/*****
					 * Okay, this if statement is complicated, so let's break it down.
					 * The previous if(sq.getOwn() == -1) statement ensures that this square is empty.
					 * For each set of Squares which represent a Win State,
					 *	if the square being tested is empty, and is part of the
					 *	given set of Squares,
					 *	and the computer owns any of the squares in the set,
					 *	and the user does not own any square in the set,
					 *	then the number of possible wins represented by that square
					 *	is increased by 1.
					 *****/
					 
					if((sq == winState[0] || sq == winState[1] || sq == winState[2]) && (winState[0].getOwn() == computer || winState[1].getOwn() == computer || winState[2].getOwn() == computer) && (winState[0].getOwn() != human && winState[1].getOwn() != human && winState[2].getOwn() != human)) {
						sq.adjPossWins(1);
					}
				}
			}
			if(sq.getPossWins() > 1) {
				// If the given square represents more than one possible win, then it is a "trap" 
				//	which will guarantee a win for the computer. Returns index of given square.
				int index = indexOfSquare(sq, squares);
				return index;
			}
		}
		// If no trap is found, looks for and prevents an upcoming trap.
		int upcomingTraps = findTrap(computer, human, squares, winStates);
		if(upcomingTraps != -1) {
			// upcomingTraps != -1 means that there is a square where the user could set up a trap.
			// Returns the index of the upcoming trap.
			return upcomingTraps;
		}
		// If no upcoming trap is found, checks all Squares for possible wins
		//	(determined above when looking for traps).
		// For any square that creates a possible win, returns the index of that square.
		for(Square sq:squares) {
			if(sq.getPossWins() == 1) {
				int index = indexOfSquare(sq, squares);
				return index;
			}
		}
		// If no square has at least one possible win, returns -1.
		return -1;
	}
	
	static int findTrap(int computer, int human, Square[] squares, Square[][] winStates) {
		// Called by findBest to find and prevent possible upcoming traps.
		for(Square sq:squares) {
			if(sq.getOwn() == -1) {
				// Temporarily sets square ownership to opponent.
				sq.setOwn(human);
				// Checks for all possible winning moves if square is owned by opponent.
				int createsWins = checkPossWins(computer, human, winStates);
				// Resets square to empty.
				sq.setOwn(-1);
				if(createsWins > 1) {
					// If more than one possible winning move is generated by the given square, then it is a source of a possible trap.
					// Returns index of possible trap so that computer can take the square and prevent the trap.
					int index = indexOfSquare(sq, squares);
					return index;
				}
			}
		}
		// If no square generates more than one possible winning move, returns -1.
		return -1;
	}
	
	static int checkPossWins(int computer, int human, Square[][] winStates) {
		// Checks a given square for how many possible wins it could generate if taken.
		int createsWins = 0;
		for(Square[] winState:winStates) {
			if(winState[0].getOwn() == -1 && winState[1].getOwn() == human && winState[2].getOwn() == human) {
				createsWins++;
			}
			if(winState[1].getOwn() == -1 && winState[0].getOwn() == human && winState[2].getOwn() == human) {
				createsWins++;
			}
			if(winState[2].getOwn() == -1 && winState[0].getOwn() == human && winState[1].getOwn() == human) {
				createsWins++;
			}
		}
		return createsWins;
	}
	
	static int checkWin(Square[] squares, Square[][] winStates) {
		// Checks all win states for a winning pattern.
		for(Square[] winState:winStates) {
			if(winState[0].getOwn() == 0 && winState[1].getOwn() == 0 && winState[2].getOwn() == 0) {
				// If all three sets of squares in the given winState are owned by 0, X wins.
				return 0;
			} else if(winState[0].getOwn() == 1 && winState[1].getOwn() == 1 && winState[2].getOwn() == 1) {
				// If all three sets of squares in the given winState are owned by 1, O wins.
				return 1;
			}
		}
		// If no winning pattern is found, checks how many squares are filled.
		int filledSquares = checkFilled(squares);
		if(filledSquares == 9) {
			// If all squares are filled and no winning pattern is found, a tie has been reached.
			return 2;
		} else {
			// If filledSquares < 9 and no winning pattern is found, game continues.
			return -1;
		}
	}
	
	public static void main(String[] args) {
		Random rand = new Random();
		input_utils in = new input_utils(); // input_utils v1.0
		
		Square[] squares = buildSquares();
		Square[][] board = buildBoard(squares);
		Square[][] winStates = buildWinStates(squares);
									
		System.out.println("Welcome to TicTacJava v2.1!");
		in.get(); // Waits for input.
		
		// Core loop.
		while(true) {
			System.out.println("1 - Play With Computer\nPlay TicTacToe against the computer!\nYou will be randomly assigned to play X or O.\nInput 1 - 9 to place your mark in an unoccupied space.\nWarning! The computer CANNOT LOSE!\n");
			System.out.println("2 - Play With Human\nPlay TicTacToe against a human partner.\nInput 1 - 9 to place your mark in an unoccupied space.\nX plays first.\n");
			System.out.println("3 - Test\nThe computer plays 1000 games of TicTacToe against itself and returns the number of wins and ties. The computer should tie 1000 out of 1000 times.\n");
			System.out.println("4 - End program\n");
			
			int userIn = in.getInt("", 1, 4);
			if(userIn == 1) {
				while(true) {
					playWithComputer(in, rand, squares, board, winStates);
					int playAgain = in.getInt("Play again?\n1 - Yes\n2 - No\n", 1, 2);
					if(playAgain == 2) {
						break;
					}
				}
			} else if(userIn == 2) {
				while(true) {
					playWithHuman(in, squares, board, winStates);
					int playAgain = in.getInt("Play again?\n1 - Yes\n2 - No\n", 1, 2);
					if(playAgain == 2) {
						break;
					}
				}
			} else if(userIn == 3) {
				while(true) {
					repeatGame(rand, squares, board, winStates);
					int runAgain = in.getInt("Run again?\n1 - Yes\n2 - No\n", 1, 2);
					if(runAgain == 2) {
						break;
					}
				}
			} else if(userIn == 4) {
				System.exit(0);
			}
		}
	}
}