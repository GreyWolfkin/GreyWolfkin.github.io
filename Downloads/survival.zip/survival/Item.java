/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Item {

	private String name;
	private int weight;
	private String desc;
	private int qtyInInv;
	private int qtyInChest;
	private int qtyInCache;
	private boolean isFood;
	private int foodVal;
	private boolean isWater;
	private int waterVal;
	private boolean isTemp;
	private int tempVal;

	public Item(String name, int weight, String desc, int qtyInInv, int qtyInChest, int qtyInCache, boolean isFood, int foodVal, boolean isWater, int waterVal, boolean isTemp, int tempVal) {
		this.name = name;
		this.weight = weight;
		this.desc = desc;
		this.qtyInInv = qtyInInv;
		this.qtyInChest = qtyInChest;
		this.qtyInCache = qtyInCache;
		this.isFood = isFood;
		this.foodVal = foodVal;
		this.isWater = isWater;
		this.waterVal = waterVal;
		this.isTemp = isTemp;
		this.tempVal = tempVal;
	}
	
	public Item(String name, int weight, String desc) {
		this.name = name;
		this.weight = weight;
		this.desc = desc;
		this.qtyInInv = 0;
		this.qtyInChest = 0;
		this.qtyInCache = 0;
		this.isFood = false;
		this.foodVal = 0;
		this.isWater = false;
		this.waterVal = 0;
		this.isTemp = false;
		this.tempVal = 0;
	}

	public String getName() {
		return name;
	}
	public void setName(String set) {
		name = set;
	}

	public int getWeight() {
		return weight;
	}
	public void setWeight(int set) {
		weight = set;
	}

	public String getDesc() {
		return desc;
	}
	public void setDesc(String set) {
		desc = set;
	}

	public int getQtyInInv() {
		return qtyInInv;
	}
	public void setQtyInInv(int set) {
		qtyInInv = set;
	}
	public void adjQtyInInv(int adj) {
		qtyInInv += adj;
	}

	public int getQtyInChest() {
		return qtyInChest;
	}
	public void setQtyInChest(int set) {
		qtyInChest = set;
	}
	public void adjQtyInChest(int adj) {
		qtyInChest += adj;
	}

	public int getQtyInCache() {
		return qtyInCache;
	}
	public void setQtyInCache(int set) {
		qtyInCache = set;
	}
	public void adjQtyInCache(int adj) {
		qtyInCache += adj;
	}

	public boolean getIsFood() {
		return isFood;
	}
	public void setIsFood(boolean set) {
		isFood = set;
	}

	public int getFoodVal() {
		return foodVal;
	}
	public void setFoodVal(int set) {
		foodVal = set;
		isFood = true;
	}

	public boolean getIsWater() {
		return isWater;
	}
	public void setIsWater(boolean set) {
		isWater = set;
	}

	public int getWaterVal() {
		return waterVal;
	}
	public void setWaterVal(int set) {
		waterVal = set;
		isWater = true;
	}

	public boolean getIsTemp() {
		return isTemp;
	}
	public void setIsTemp(boolean set) {
		isTemp = set;
	}

	public int getTempVal() {
		return tempVal;
	}
	public void setTempVal(int set) {
		tempVal = set;
		isTemp = true;
	}
	
	public void printSelf(int opt) {
		System.out.print(name + " ");
		if(opt == 0) {
			System.out.println(qtyInInv);
		} else if(opt == 1) {
			System.out.println(qtyInChest);
		} else if(opt == 2) {
			System.out.println(qtyInCache);
		}
		System.out.println(desc);
	}

}
