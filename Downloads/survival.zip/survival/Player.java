/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

import java.util.ArrayList;

public class Player {

	private int food;
	private int foodLoss;
	private int water;
	private int waterLoss;
	private int temp;
	private int tempLoss;
	private int carry;
	private int carryCap;
	private String loc;
	private int x;
	private int y;
	private ArrayList<Item> inv;
	private ArrayList<Item> chestInv;
	private ArrayList<Item> cacheInv;
	private String status;

	public Player(int food, int foodLoss, int water, int waterLoss, int temp, int tempLoss, int carry, int carryCap, String loc, int x, int y, ArrayList<Item> inv, ArrayList<Item> chestInv, ArrayList<Item> cacheInv, String status) {
		this.food = food;
		this.foodLoss = foodLoss;
		this.water = water;
		this.waterLoss = waterLoss;
		this.temp = temp;
		this.tempLoss = tempLoss;
		this.carry = carry;
		this.carryCap = carryCap;
		this.loc = loc;
		this.x = x;
		this.y = y;
		this.inv = inv;
		this.chestInv = chestInv;
		this.cacheInv = cacheInv;
		this.status = status;
	}
	
	public Player() {
		this.food = 100;
		this.foodLoss = 2;
		this.water = 100;
		this.waterLoss = 2;
		this.temp = 100;
		this.tempLoss = 2;
		this.carry = 0;
		this.carryCap = 10;
		this.loc = "Forest";
		this.x = 3;
		this.y = 3;
		this.inv = new ArrayList<Item>();
		this.chestInv = new ArrayList<Item>();
		this.cacheInv = new ArrayList<Item>();
		this.status = "Awake";
	}

	public int getFood() {
		return food;
	}
	public void setFood(int set) {
		food = set;
	}
	public void adjFood(int adj) {
		food += adj;
		if(food > 100) {
			food = 100;
		}
	}

	public int getFoodLoss() {
		return foodLoss;
	}
	public void setFoodLoss(int set) {
		foodLoss = set;
	}
	public void adjFoodLoss(int adj) {
		foodLoss += adj;
	}

	public int getWater() {
		return water;
	}
	public void setWater(int set) {
		water = set;
	}
	public void adjWater(int adj) {
		water += adj;
		if(water > 100) {
			water = 100;
		}
	}

	public int getWaterLoss() {
		return waterLoss;
	}
	public void setWaterLoss(int set) {
		waterLoss = set;
	}
	public void adjWaterLoss(int adj) {
		waterLoss += adj;
	}

	public int getTemp() {
		return temp;
	}
	public void setTemp(int set) {
		temp = set;
	}
	public void adjTemp(int adj) {
		temp += adj;
		if(temp > 100) {
			temp = 100;
		}
	}

	public int getTempLoss() {
		return tempLoss;
	}
	public void setTempLoss(int set) {
		tempLoss = set;
	}
	public void adjTempLoss(int adj) {
		tempLoss += adj;
	}

	public int getCarry() {
		return carry;
	}
	public void setCarry(int set) {
		carry = set;
	}
	public void adjCarry(int adj) {
		carry += adj;
	}
	public boolean canCarry(int weight) {
		if(carry + weight <= carryCap) {
			return true;
		} else {
			return false;
		}
	}

	public int getCarryCap() {
		return carryCap;
	}
	public void setCarryCap(int set) {
		carryCap = set;
	}
	public void adjCarryCap(int adj) {
		carryCap += adj;
	}

	public String getLoc() {
		return loc;
	}
	public void setLoc(String set) {
		loc = set;
	}

	public int getX() {
		return x;
	}
	public void setX(int set) {
		x = set;
	}
	public void adjX(int adj) {
		x += adj;
		if(x > 5) {
			x -= 5;
		} else if(x < 1) {
			x += 5;
		}
	}

	public int getY() {
		return y;
	}
	public void setY(int set) {
		y = set;
	}
	public void adjY(int adj) {
		y += adj;
		if(y > 5) {
			y -= 5;
		} else if(y < 1) {
			y += 5;
		}
	}

	public ArrayList<Item> getInv() {
		return inv;
	}
	public void setInv(ArrayList<Item> set) {
		inv = set;
	}
	public void printInv() {
		System.out.println("INVENTORY\n---------");
		for(Item item:inv) {
			item.printSelf(0);
			System.out.println();
		}
	}
	public void addToInv(Item item, int qty) {
		if(inv.contains(item)) {
			item.adjQtyInInv(qty);
		} else {
			inv.add(item);
			item.setQtyInInv(qty);
		}
		carry += item.getWeight() * qty;
	}
	public void removeFromInv(Item item, int qty) {
		item.adjQtyInInv(-1 * qty);
		if(item.getQtyInInv() == 0) {
			inv.remove(item);
		}
		carry -= item.getWeight() * qty;
	}
	public void clearInv() {
		inv.clear();
		carry = 0;
	}

	public ArrayList<Item> getChestInv() {
		return chestInv;
	}
	public void setChestInv(ArrayList<Item> set) {
		chestInv = set;
	}
	public void printChest() {
		System.out.println("CHEST\n-----");
		for(Item item:chestInv) {
			item.printSelf(1);
			System.out.println();
		}
	}
	public void addToChest(Item item, int qty) {
		if(chestInv.contains(item)) {
			item.adjQtyInChest(qty);
		} else {
			chestInv.add(item);
			item.setQtyInChest(qty);
		}
	}
	public void removeFromChest(Item item, int qty) {
		item.adjQtyInChest(-1 * qty);
		if(item.getQtyInChest() == 0) {
			chestInv.remove(item);
		}
	}
	public void clearChest() {
		chestInv.clear();
	}

	public ArrayList<Item> getCacheInv() {
		return cacheInv;
	}
	public void setCacheInv(ArrayList<Item> set) {
		cacheInv = set;
	}
	public void printCache() {
		System.out.println("CACHE\n-----");
		for(Item item:cacheInv) {
			item.printSelf(2);
			System.out.println();
		}
	}
	public void addToCache(Item item, int qty) {
		if(cacheInv.contains(item)) {
			item.adjQtyInCache(qty);
		} else {
			cacheInv.add(item);
			item.setQtyInCache(qty);
		}
	}
	public void removeFromCache(Item item, int qty) {
		item.adjQtyInCache(-1 * qty);
		if(item.getQtyInCache() == 0) {
			cacheInv.remove(item);
		}
	}
	public void clearCache() {
		cacheInv.clear();
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String set) {
		status = set;
	}

}
