/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/
 
/*****
 * WORK IN PROGRESS
 * MULTIPLE BUGS STILL PRESENT
 *****/

import java.io.IOException;
import java.util.Scanner;

public class Survival {
	
	private static Scanner scan = new Scanner(System.in);
	private static Listener l = new Listener(scan);
	private static Player p;
	private static World world;
	private static FileUtils fileUtils;
	private static Utils utils;
	
	public static void newGame() {
		String diff = l.getString("\nSet Difficulty\nEASY\nNORMAL\nHARD\n", 1);
		if(diff.equals("Easy") || diff.equals("Normal") || diff.equals("Hard") || diff.equals("Debug") || diff.equals("Wolf")) {
			world.setDiff(diff);
		} else {
			System.out.println("\nUnrecognized Input");
		}
		fileUtils.addItemsToWorld(true);
	}
	
	public static void main(String[] args) {
		p = new Player();
		world = new World();
		fileUtils = new FileUtils(p, world);
		utils = new Utils(fileUtils, l, p, world);
//		utils.buildItems();
		System.out.println("Survival Game\nWORK IN PROGRESS\nA text-based game in which you must survive the Winter in a strange, never-ending forest.\nContextual actions are listed in all-caps. For a list of additional actions, input 'HELP'.\nPress Enter to begin.");
		l.pause();
		
		String input = l.getString("Load a Save File?\nYES\nNO\n", 1);
		if(input.equals("Yes")) {
			String file_name = l.getString("Load Save File: ", 1);
			try {
				fileUtils.addItemsToWorld(false);
				fileUtils.readSaveFile(file_name);
			} catch(IOException | IllegalArgumentException | LoadException ex) {
				ex.printStackTrace();
				System.out.println("Error Reading From File");
				newGame();
			}
		} else {
			newGame();
		}
		while(true) {
			int check = utils.winCheck();
			if(check == 1) {
				System.out.println("You have survived");
			} else if(check == -1) {
				System.out.println("You have died");
				System.exit(0);
			}
			utils.printStats();
			utils.storyReader();
			utils.locationReader();
			utils.primaryLoop();
		}
	}

}
