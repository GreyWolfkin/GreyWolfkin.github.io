/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

public class Location {
	
	private int x;
	private int y;
	private String text;
	private String contextual;
	private String reqItem;
	private String secondContextual;
	
	public Location(int x, int y, String text, String contextual, String reqItem, String secondContextual) {
		this.x = x;
		this.y = y;
		this.text = text;
		this.contextual = contextual;
		this.reqItem = reqItem;
		this.secondContextual = secondContextual;
	}
	
	public int getX() {
		return x;
	}
	public void setX(int set) {
		x = set;
	}
	
	public int getY() {
		return y;
	}
	public void setY(int set) {
		y = set;
	}
	
	public String getText() {
		return text;
	}
	public void setText(String set) {
		text = set;
	}
	
	public boolean hasContextual() {
		if(!contextual.equals("NONE")) {
			return true;
		} else {
			return false;
		}
	}
	
	public String getContextual() {
		return contextual;
	}
	public void setContextual(String set) {
		contextual = set;
	}
	
	public boolean hasReqItem() {
		if(!reqItem.equals("NONE")) {
			return true;
		} else {
			return false;
		}
	}
	
	public String getReqItem() {
		return reqItem;
	}
	public void setReqItem(String set) {
		reqItem = set;
	}
	
	public boolean hasSecond() {
		if(!secondContextual.equals("NONE")) {
			return true;
		} else {
			return false;
		}
	}
	
	public String getSecond() {
		return secondContextual;
	}
	public void setSecond(String set) {
		secondContextual = set;
	}

}
