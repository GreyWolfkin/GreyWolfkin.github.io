/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

import java.util.ArrayList;
import java.util.Random;

public class Utils {
	
	private Random rand = new Random();

	private FileUtils fileUtils;
	private Listener l;
	private Player p;
	private World world;

	private boolean running;

	public Utils(FileUtils fileUtils, Listener l, Player p, World world) {
		this.fileUtils = fileUtils;
		this.l = l;
		this.p = p;
		this.world = world;
		this.running = true;
	}
	
	public boolean getRunning() {
		return running;
	}
	public void setRunning(boolean set) {
		running = set;
	}

	public void primaryLoop() {
		actionListener();
		updater();
	}

	private int findIndex(String itemName, ArrayList<Item> itemList) {
		for(int i = 0; i < itemList.size(); i++) {
			if(itemList.get(i).getName().equals(itemName)) {
				return i;
			}
		}
		return -1;
	}

	public void storyReader() {
		boolean inCabin = (p.getLoc().equals("Cabin"));
		boolean fireBurning = (world.getFire() > 0);
		boolean coatInInv = (findIndex("Coat", p.getInv()) != -1);

		if(world.getRead() == 1) {
			System.out.println();
			System.out.println("\nYou shiver in the cold as the first snow begins to fall. Night will be here soon.");
			if(world.getDiff().equals("Easy")) {
				System.out.println("\nSurvive until Day 4 and use the Radio to win!");
			}
		} else if(world.getRead() == 2) {
			if(inCabin) {
				System.out.println("\nOutside, night falls. The chill seeps through the walls of your small cabin.");
			} else if(coatInInv) {
				System.out.println("\nNight falls. You tug your coat tighter around you, but it does little to keep out the cold.");
			} else {
				System.out.println("\nNight falls. Without shelter or warmer clothing, you will not last long.");
			}
		} else if(world.getRead() == 3) {
			if(inCabin) {
				if(fireBurning) {
					System.out.println("\nOutside, the storm rages. You shudder and shift closer to the fire.");
				} else {
					System.out.println("\nOutside, the storm rages. Even in the cabin, you will not last long without a fire.");
				}
			} else {
				if(coatInInv) {
					System.out.println("\nThe storm arrives, blinding you with snow and ice. Your coat does nothing to keep out Nature's wrath. Find shelter before you perish.");
				} else {
					System.out.println("\nThe storm arrives, blinding you with snow and ice. Without shelter or warm clothing, you soon will die.");
				}
			}
		} else if(world.getRead() == 4) {
			System.out.println("\nThe storm passes as quickly as it arrived, and the winter silence is deafening.");
		}
		l.pause();
		world.setRead(0);
	}

	public void locationReader() {
		String text = "";
		if(p.getLoc().equals("Forest")) {
			int x = p.getX();
			int y = p.getY();
			text += world.getLocationText(x, y);
//			if(x == 1) {
//				if(y == 1 || y == 2) {
//					text += "You are in the Stone Fields.\nTo the West, the forest grows dense.";
//				} else if(y == 3) {
//					text += "You are in the Forest.\nA lonely Watchtower looms to the North.\nTo the West is a small, ramshackle Cabin.\nTo the South, the ground is hard and rocky.";
//				} else if(y == 4) {
//					text += "You stand outside an abandoned Watchtower.\nBerry bushes grow to the West.";
//				} else if(y == 5) {
//					text += "You are in the Forest.\nA lonely Watchtower looms to the South.\nTo the North, the ground is hard and rocky.\nBerry bushes grow to the West.";
//				}
//			} else if(x == 2) {
//				if(y == 1) {
//					text += "You are in the Stone Fields.\nA frigid lake sits to the East.";
//				} else if(y == 2) {
//					text += "You are in the Stone Fields.";
//				} else if(y == 3) {
//					text += "You are West of the Crossroads.\nTo the South, the ground is hard and rocky.";
//				} else if(y == 4) {
//					text += "You are in the Forest.\nA lonely Watchtower looms to the West.";
//				} else if(y == 5) {
//					text += "You are in the Forest.\nTo the North, the ground is hard and rocky.";
//				}
//			} else if(x == 3) {
//				if(y == 1) {
//					text += "You stand at the shores of a frigid lake.\nTo the East, the forest grows dense.\nTo the West, the ground is hard and rocky.";
//				} else if(y == 2) {
//					text += "You are South of the Crossroads.\nTo the East, the forest grows dense.\nA frigid lake sits to the South.\nTo the West, the ground is hard and rocky.";
//				} else if(y == 3) {
//					text += "You stand at a Crossroads.";
//				} else if(y == 4) {
//					text += "You are north of the Crossroads.\nBerry bushes grow to the East.";
//				} else if(y == 5) {
//					text += "You are in the Forest.\nA frigid lake sits to the North.\nBerry bushes grow to the East.";
//				}
//			} else if(x == 4) {
//				if(y == 1) {
//					text += "You are in a dense part of the Forest.\nBerry bushes grow to the South.\nA frigid lake sits to the West.";
//				} else if(y == 2) {
//					text += "You are in a dense part of the Forest.";
//				} else if(y == 3) {
//					text += "You are East of the Crossroads.\nTo the East is a small, ramshackle Cabin.\nBerry bushes grow to the North.\nTo the South, the forest grows dense.";
//				} else if(y == 4) {
//					text += "You are in a field of berry bushes.";
//				} else if(y == 5) {
//					text += "You are in a field of berry bushes.\nTo the North, the forest grows dense.";
//				}
//			} else if(x == 5) {
//				if(y == 1) {
//					text += "You are in a dense part of the Forest.\nTo the East, the ground is hard and rocky.\nBerry bushes grow to the South.";
//				} else if(y == 2) {
//					text += "You are in a dense part of the Forest.\nTo the North is a small, ramshackle Cabin.\nTo the East, the ground is hard and rocky.";
//				} else if(y == 3) {
//					text += "You stand outside a drafty Cabin. Maybe it could provide some shelter from the cold.\nBerry bushes grow to the North.\nTo the South, the forest grows dense.";
//				} else if(y == 4) {
//					text += "You are in a field of berry bushes.\nA lonely Watchtower looms to the East.\nTo the South is a small, ramshackle Cabin.";
//				} else if(y == 5) {
//					text += "You are in a field of berry bushes.\nTo the North, the forest grows dense.";
//				}
//			}
		} else if(p.getLoc().equals("Cabin")) {
			text += "You are in a small Cabin. The wind whistles through cracks in the walls.";
		} else if(p.getLoc().equals("Watchtower")) {
			text += "You are in an abandoned Watchtower.";
			if(world.getCache()) {
				text += " A small cache of supplies sits against one wall.";
			}
		}
		if(world.getWolf()) {
			checkWolves();
		}
		System.out.println(text);
	}

	private void updater() {
		if(!world.getDiff().equals("Wolf")) {
			p.setFoodLoss(2);
			p.setWaterLoss(2);
			p.setTempLoss(0);
			p.setCarryCap(10);
			boolean inCabin = (p.getLoc().equals("Cabin"));
			boolean fireBurning = (world.getFire() > 0);
			boolean inWatchtower = (p.getLoc().equals("Watchtower"));
			boolean coatInInv = (findIndex("Coat", p.getInv()) != -1);
			boolean backpack = (findIndex("Backpack", p.getInv()) != -1);
			int time = world.getTime();
			boolean night = (5 >= time || time >= 16);
			boolean storm = (world.getWeather().equals("Storm"));
			if(inCabin) {
				p.adjTempLoss(-15);
				if(fireBurning) {
					p.adjTempLoss(-10);
				}
			}
			if(inWatchtower) {
				p.adjTempLoss(-5);
			}
			if(coatInInv) {
				p.adjTempLoss(-5);
			}
			if(night) {
				p.adjTempLoss(5);
			}
			if(storm) {
				p.adjTempLoss(20);
			}
			if(backpack) {
				p.adjCarryCap(10);
			}
		} else {
			p.setFoodLoss(0);
			p.setWaterLoss(0);
			p.setTempLoss(0);
			p.setCarryCap(100);
		}
	}

	private void updateWorld() {
		int time = world.getTime();
		if(time > 23) {
			world.adjDay(1);
			world.setTime(time - 24);
		}
		int day = world.getDay();
		if(day == 1 && time == 16) {
			world.setRead(2);
			storyReader();
		} else if(day == 2 && time == 16) {
			world.setWeather("Storm");
			world.setRead(3);
			storyReader();
		} else if(day == 3 && time == 6) {
			world.setWeather("Clear");
			world.setRead(4);
			storyReader();
		} else if(day == 5 && time == 16) {
			world.setWolf(true);
		} else if(day == 7 && time == 6) {
			world.setWolf(false);
		}
	}
	
	private void wolves() {
		if(world.getWolf()) {
			if(world.getWolfCount() == world.getWolfMove()) {
				
				moveWolves();
				
				if(5 >= world.getTime() || world.getTime() >= 16) {
					int move = rand.nextInt(2) + 1;
					world.setWolfMove(move);
				} else {
					int move = rand.nextInt(3) + 1;
					world.setWolfMove(move);
				}
				world.setWolfCount(1);
			} else {
				world.adjWolfCount(1);
			}
		}
	}
	
	private void moveWolves() {
		int[] dist = getWolfDistance();
		int deltaX = dist[0];
		int deltaY = dist[1];
		
		if(deltaX == 0 && deltaY == 0) {
			return;
		}
		
		if(Math.abs(deltaX) > Math.abs(deltaY) || Math.abs(deltaX) == Math.abs(deltaY)) {
			if(deltaX > 0) {
				world.adjWolfX(1);
			} else {
				world.adjWolfX(-1);
			}
		} else if(Math.abs(deltaX) < Math.abs(deltaY)) {
			if(deltaY > 0) {
				world.adjWolfY(1);
			} else {
				world.adjWolfY(-1);
			}
		}
	}
	
	private void checkWolves() {
		int[] distArr = getWolfDistance();
		int deltaX = distArr[0];
		int deltaY = distArr[1];
		int dist = Math.abs(distArr[0]) + Math.abs(distArr[1]);
		if(p.getLoc().equals("Forest")) {
			if(dist == 2) {
				System.out.println("You hear their howls in the distance. They are hunting you.");
			} else if(dist == 1) {
				System.out.println("They are right on your heels. You need to move, now.");
			}
			if(dist <= 2) {
				boolean north = false;
				boolean east = false;
				boolean south = false;
				boolean west = false;
				if(deltaX > 0) {
					west = true;
				} else if(deltaX < 0) {
					east = true;
				}
				if(deltaY > 0) {
					south = true;
				} else if(deltaY < 0) {
					north = true;
				}
				if(north && east) {
					System.out.println("They are coming from the North-East.");
				} else if(north && west) {
					System.out.println("They are coming from the North-West.");
				} else if(north) {
					System.out.println("They are coming from the North.");
				} else if(south && east) {
					System.out.println("They are coming from the South-East.");
				} else if(south && west) {
					System.out.println("They are coming from the South-West.");
				} else if(south) {
					System.out.println("They are coming from the South.");
				} else if(east) {
					System.out.println("They are coming from the East.");
				} else if(west) {
					System.out.println("They are coming from the West.");
				}
			}
		} else {
			if(dist == 1) {
				System.out.println("You can hear their howls in the forest. They are very nearby.");
			} else if(dist == 0) {
				if(p.getLoc().equals("Cabin")) {
					System.out.println("They are right outside the flimsy walls of the cabin. They smell you. You are not safe.");
				} else if(p.getLoc().equals("Watchtower")) {
					System.out.println("They are circling the base of the Watchtower. You are not safe.");
				}
			}
		}
	}
	
	private int[] getWolfDistance() {
		int pX = p.getX();
		int pY = p.getY();
		int wX = world.getWolfX();
		int wY = world.getWolfY();
		int deltaX = 0;
		int deltaY = 0;
		if(pX > wX) {
			if(pX - wX < wX + 5 - pX) {
				deltaX = pX - wX;
			} else if(wX + 5 - pX < pX - wX) {
				deltaX = -1 * (wX + 5 - pX);
			}
		} else if(wX > pX) {
			if(wX - pX < pX + 5 - wX) {
				deltaX = -1 * (wX - pX);
			} else if(pX + 5 - wX < wX - pX) {
				deltaX = pX + 5 - wX;
			}
		} else {
			deltaX = 0;
		}
		if(pY > wY) {
			if(pY - wY < wY + 5 - pY) {
				deltaY = pY - wY;
			} else if(wY + 5 - pY < pY - wY) {
				deltaY = -1 * (wY + 5 - pY);
			}
		} else if(wY > pY) {
			if(wY - pY < pY + 5 - wY) {
				deltaY = -1 * (wY - pY);
			} else if(pY + 5 - wY < wY - pY) {
				deltaY = pY + 5 - wY;
			}
		} else {
			deltaY = 0;
		}
		return new int[] {deltaX, deltaY};
	}

	private void timer(int hours) {
		for(int i = 0; i < hours; i++) {
			updater();
			p.adjFood(-1 * p.getFoodLoss());
			p.adjWater(-1 * p.getWaterLoss());
			p.adjTemp(-1 * p.getTempLoss());
			world.adjTime(1);
			world.adjFire(-1);
			wolves();
			updateWorld();
		}
	}
	
	

	private String contextualActions() {
		String text = "";
		if(p.getLoc().equals("Forest")) {
			int x = p.getX();
			int y = p.getY();
			text += "Walk NORTH\nWalk EAST\nWalk SOUTH\nWalk WEST\nCUT Grass\nPICK UP Sticks\n";
			text += world.getLocationContextual(x, y, p.getInv());
		} else if(p.getLoc().equals("Cabin")) {
			text += "Use CHEST\n";
			if(world.getFire() > 0) {
				text += "Stoke FIRE\n";
			} else {
				text += "Start FIRE\n";
			}
			text += "CRAFT at Workbench\n";
			text += "LEAVE Cabin\n";
		} else if(p.getLoc().equals("Watchtower")) {
			text += "Check WEATHER\n";
			text += "Use RADIO\n";
			if(world.getCache()) {
				text += "Open CACHE\n";
			}
			text += "LEAVE Watchtower\n";
		}
		return text;
	}

	private void actionListener() {
		String text = contextualActions();
		String input = l.getString(text, 1);
		if(!isBaseOption(input)) {
			if(!isWalkOption(input)) {
				if(!isInvOption(input)) {
					if(!isContextualOption(input)) {
						System.out.println("Unrecognized Input");
					}
				}
			}
		}
	}

	private boolean isBaseOption(String input) {
		switch(input) {
		case "L":
		case "Look":
			look();
			return true;
		case "I":
		case "Inv":
		case "Inventory":
			p.printInv();
			invUse();
			return true;
		case "Wait":
			int waitInput = l.getInt("Wait how many hours?\n", 0, 24);
			timer(waitInput);
			return true;
		case "Options":
			options();
			return true;
		case "Save":
			String file_name = l.getString("Name your Save File: ", 3);
			fileUtils.saveAndQuit(file_name);
		case "Quit":
			System.exit(0);
		case "Help":
			help();
			return true;
		case "F":
			System.out.println("\nYou pay your respects.");
			return true;
		default:
			return false;
		}
	}

	private boolean isWalkOption(String input) {
		if(p.getLoc().equals("Forest")) {
			switch(input) {
			case "N":
			case "North":
				System.out.println("\nYou walk North.");
				p.adjY(1);
				timer(1);
				return true;
			case "E":
			case "East":
				System.out.println("\nYou walk East.");
				p.adjX(1);
				timer(1);
				return true;
			case "S":
			case "South":
				System.out.println("\nYou walk South.");
				p.adjY(-1);
				timer(1);
				return true;
			case "W":
			case "West":
				System.out.println("\nYou walk West.");
				p.adjX(-1);
				timer(1);
				return true;
			default:
				return false;
			}
		}
		return false;
	}

	private boolean isInvOption(String input) {
		int index = findIndex(input, world.getAllItems());
		if(index != -1) {
			Item item = world.getAllItems().get(index);
			if(item.getQtyInInv() > 0) {
				directUse(item);
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	private boolean isContextualOption(String input) {
		if(p.getLoc().equals("Forest")) {
			switch(input) {
			case "Enter":
				if(p.getX() == 1 && p.getY() == 4) {
					System.out.println("\nYou enter the Watchtower.");
					p.setLoc("Watchtower");
					return true;
				} else if(p.getX() == 5 && p.getY() == 3) {
					System.out.println("\nYou enter the Cabin.");
					p.setLoc("Cabin");
					return true;
				} else {
					return false;
				}
			case "Cut":
				System.out.println("\nYou cut some grass.");
				Item grass = world.findItem("Grass");
				if(p.canCarry(grass.getWeight())) {
					p.addToInv(grass, 1);
					timer(1);
				} else {
					System.out.println("But you can't carry any more!");
				}
				return true;
			case "Pick up":
				System.out.println("\nYou pick up sticks.");
				Item stick = world.findItem("Stick");
				if(p.canCarry(stick.getWeight())) {
					p.addToInv(stick, 1);
					timer(1);
				} else {
					System.out.println("But you can't carry any more!");
				}
				return true;
			case "Collect":
				if((p.getX() == 1 || p.getX() == 2) && (p.getY() == 1 || p.getY() == 2)) {
					System.out.println("\nYou collect some stone.");
					Item stone = world.findItem("Stone");
					if(p.canCarry(stone.getWeight())) {
						p.addToInv(stone, 1);
						timer(1);
					} else {
						System.out.println("But you can't carry any more!");
					}
					return true;
				} else {
					return false;
				}
			case "Mine":
				if((p.getX() == 1 || p.getX() == 2) && (p.getY() == 1 || p.getY() == 2)) {
					if(world.findItem("Pick").getQtyInInv() == 1) {
						System.out.println("\nYou mine some flint.");
						Item flint = world.findItem("Flint");
						if(p.canCarry(flint.getWeight())) {
							p.addToInv(flint, 1);
							timer(1);
						} else {
							System.out.println("But you can't carry anymore!");
						}
					} else {
						System.out.println("\nCannot mine flint without a pick!");
					}
					return true;
				} else {
					return false;
				}
			case "Chop":
				if((p.getX() == 4 || p.getX() == 5) && (p.getY() == 1 || p.getY() == 2)) {
					if(world.findItem("Axe").getQtyInInv() == 1) {
						System.out.println("\nYou chop some firewood");
						Item wood = world.findItem("Wood");
						if(p.canCarry(wood.getWeight())) {
							p.addToInv(wood, 1);
							timer(1);
						} else {
							System.out.println("But you can't carry anymore!");
						}
					} else {
						System.out.println("\nCan't chop wood without an axe!");
					}
					return true;
				} else {
					return false;
				}
			case "Gather":
				if((p.getX() == 4 || p.getX() == 5) && (p.getY() == 4 || p.getY() == 5)) {
					System.out.println("\nYou gather a handful of berries");
					Item berry = world.findItem("Berries");
					if(p.canCarry(berry.getWeight())) {
						p.addToInv(berry, 1);
						timer(1);
					} else {
						System.out.println("But you can't carry any more!");
					}
					return true;
				} else {
					return false;
				}
			default:
				return false;
			}
		} else if(p.getLoc().equals("Cabin")) {
			switch(input) {
			case "Chest":
				useChest();
				return true;
			case "Deposit":
				deposit();
				return true;
			case "Withdraw":
				withdraw();
				return true;
			case "Fire":
				useFire();
				return true;
			case "Craft":
				useWorkbench();
				return true;
			case "Leave":
				System.out.println("\nYou leave the Cabin");
				p.setLoc("Forest");
				return true;
			default:
				return false;
			}
		} else if(p.getLoc().equals("Watchtower")) {
			switch(input) {
			case "Weather":
				//TODO
				System.out.println("\nYou look worryingly at the approaching storm.");
				return true;
			case "Radio":
				useRadio();
				return true;
			case "Cache":
				withdrawFromCache();
				return true;
			case "Leave":
				System.out.println("\nYou leave the Watchtower");
				p.setLoc("Forest");
				return true;
			default:
				return false;
			}
		} else {
			return false;
		}
	}

	private void look() {
		//TODO
		String text = "";
		if(p.getLoc().equals("Forest")) {
			text += "Something";
		} else if(p.getLoc().equals("Cabin")) {
			text += "Something";
		} else if(p.getLoc().equals("Watchtower")) {
			text += "You are in the Watchtower";
		}
		System.out.println(text);
		l.pause();
	}

	private void invUse() {
		String input = l.getString("Use Item?\n", 1);
		int index = findIndex(input, p.getInv());
		if(index != -1) {
			Item item = p.getInv().get(index);
			if(item.getIsFood() || item.getIsWater() || item.getIsTemp()) {
				int qtyIn = l.getInt("Use how many?\n", 0, item.getQtyInInv());
				if(qtyIn == 0) {
					System.out.println(item.getDesc());
					return;
				} else {
					while(qtyIn > 0) {
						p.adjFood(item.getFoodVal());
						p.adjWater(item.getWaterVal());
						p.adjTemp(item.getTempVal());
						p.removeFromInv(item, 1);
						qtyIn--;
					}
				}
			} else {
				System.out.println(item.getDesc());
			}
		} else {
			System.out.println("Unrecognized Input");
		}
	}
	
	private void directUse(Item item) {
		if(item.getIsFood() || item.getIsWater() || item.getIsTemp()) {
			int qtyIn = l.getInt("Use how many?\n", 0, item.getQtyInInv());
			if(qtyIn > 0) {
				while(qtyIn > 0) {
					p.adjFood(item.getFoodVal());
					p.adjWater(item.getWaterVal());
					p.adjTemp(item.getTempVal());
					p.removeFromInv(item, 1);
					qtyIn--;
				}
			} else {
				item.printSelf(0);
			}
		} else {
			item.printSelf(0);
		}
	}

	private void options() {
		String input = l.getString("SAVE and Quit\nQUIT\n", 1);
		switch(input) {
		case "Save":
			String file_name = l.getString("Name your Save File: ", 3);
			fileUtils.saveAndQuit(file_name);
		case "Quit":
			System.exit(0);
		}
	}

	private void help() {
		//TODO
		System.out.println("Something helpful");
	}

	private void deposit() {
		if(p.getInv().size() > 0) {
			System.out.println("\nDeposit what?");
			for(Item item:p.getInv()) {
				item.printSelf(0);
			}
			String input = l.getString("", 1);
			int index = findIndex(input, p.getInv());
			if(index != -1) {
				Item item = p.getInv().get(index);
				if(item.getName().equals("Backpack") && p.getCarry() > 10) {
					System.out.println("\nYou are carrying too much to put the Backpack away!");
					return;
				}
				int qtyIn;
				if(item.getQtyInInv() > 1) {
					qtyIn = l.getInt("Deposit how many?\n", 1, item.getQtyInInv());
				} else {
					qtyIn = 1;
				}
				System.out.println("You store " + qtyIn + " " + item.getName() + " in the chest.");
				p.removeFromInv(item, qtyIn);
				p.addToChest(item, qtyIn);
			} else {
				System.out.println("\nUnrecognized Input");
			}
		} else {
			System.out.println("\nNothing to Deposit!");
		}
	}

	private void withdraw() {
		if(p.getChestInv().size() > 0) {
			System.out.println("\nWithdraw what?");
			for(Item item:p.getChestInv()) {
				item.printSelf(1);
			}
			String input = l.getString("",1);
			int index = findIndex(input, p.getChestInv());
			if(index != -1) {
				Item item = p.getChestInv().get(index);
				int qtyIn;
				if(item.getQtyInChest() > 1) {
					qtyIn = l.getInt("Withdraw how many?\n", 1, item.getQtyInChest());
				} else {
					qtyIn = 1;
				}
				if(p.canCarry(item.getWeight() * qtyIn)) {
					System.out.println("\nYou take " + qtyIn + " " + item.getName() + " out of the chest.");
					p.removeFromChest(item, qtyIn);
					p.addToInv(item, qtyIn);
				} else {
					System.out.println("\nYou cannot carry that much!");
				}
			} else {
				System.out.println("Unrecognized Input");
			}

		} else {
			System.out.println("\nNothing to Withdraw!");
		}
	}

	private void withdrawFromCache() {
		if(p.getCacheInv().size() > 0) {
			System.out.println("\nWithdraw what?");
			for(Item item:p.getCacheInv()) {
				item.printSelf(2);
			}
			String input = l.getString("",1);
			int index = findIndex(input, p.getCacheInv());
			if(index != -1) {
				Item item = p.getCacheInv().get(index);
				int qtyIn;
				if(item.getQtyInCache() > 1) {
					qtyIn = l.getInt("Withdraw how many?\n", 1, item.getQtyInCache());
				} else {
					qtyIn = 1;
				}
				if(p.canCarry(item.getWeight() * qtyIn)) {
					System.out.println("\nYou take " + qtyIn + " " + item.getName() + " out of the chest.");
					p.removeFromCache(item, qtyIn);
					p.addToInv(item, qtyIn);
					if(p.getCacheInv().size() == 0) {
						world.setCache(false);
					}
				} else {
					System.out.println("\nYou cannot carry that much!");
				}
			} else {
				System.out.println("Unrecognized Input");
			}

		} else {
			System.out.println("\nNothing to Withdraw!");
		}
	}

	private void useChest() {
		String input = l.getString("Do what?\nDEPOSIT\nWITHDRAW\n", 1);
		switch(input) {
		case "Deposit":
			deposit();
			break;
		case "Withdraw":
			withdraw();
			break;
		default:
			System.out.println("\nUnrecognized Input");
		}
	}
	
	private void useFire() {
		if(world.getFire() == 0) {
			System.out.println("\nThe fire is bone cold.");
		} else {
			System.out.println("\nThe fire is burning. It will last another " + world.getFire() + " hours.");
		}
		int index = findIndex("Wood", p.getInv());
		if(index != -1) {
			Item wood = p.getInv().get(index);
			int qtyIn = l.getInt("Add wood to the fire?\n0 - " + wood.getQtyInInv() + "\n", 0, wood.getQtyInInv());
			if(qtyIn > 0) {
				System.out.println("You add " + qtyIn + " wood to the fire.");
				world.adjFire(qtyIn);
				p.removeFromInv(wood, qtyIn);
			}
		}
	}
	
	private void useWorkbench() {
		System.out.println("Craft what?\n");
		Item grass = world.findItem("Grass");
		Item stick = world.findItem("Stick");
		Item stone = world.findItem("Stone");
		Item flint = world.findItem("Flint");
		System.out.println("Backpack\nGrass " + grass.getQtyInInv() + "/2\nStick " + stick.getQtyInInv() + "/2\n");
		System.out.println("Pick\nStick " + stick.getQtyInInv() + "/2\nStone " + stone.getQtyInInv() + "/2\n");
		System.out.println("Axe\nStick " + stick.getQtyInInv() + "/2\nFlint " + flint.getQtyInInv() + "/3\n");
		String input = l.getString("", 1);
		switch(input) {
		case "Backpack":
			Item backpack = world.findItem("Backpack");
			if(backpack.getQtyInInv() == 0 && backpack.getQtyInChest() == 0) {
				if(grass.getQtyInInv() >= 2 && stick.getQtyInInv() >= 2) {
					p.removeFromInv(grass, 2);
					p.removeFromInv(stick, 2);
					p.addToInv(backpack, 1);
					System.out.println("You craft a Backpack!");
				} else {
					System.out.println("Not enough materials!");
				}
			} else {
				System.out.println("You don't need another backpack.");
			}
			break;
		case "Pick":
			Item pick = world.findItem("Pick");
			if(pick.getQtyInInv() == 0 && pick.getQtyInChest() == 0) {
				if(stick.getQtyInInv() >= 2 && stone.getQtyInInv() >= 2) {
					p.removeFromInv(stick, 2);
					p.removeFromInv(stone, 2);
					p.addToInv(pick, 1);
					System.out.println("You craft a Pick!");
				} else {
					System.out.println("Not enough materials!");
				}
			} else {
				System.out.println("You don't need another Pick.");
			}
			break;
		case "Axe":
			Item axe = world.findItem("Axe");
			if(axe.getQtyInInv() == 0 && axe.getQtyInChest() == 0) {
				if(stick.getQtyInInv() >= 2 && flint.getQtyInInv() >= 3) {
					p.removeFromInv(stick, 2);
					p.removeFromInv(flint, 3);
					p.addToInv(axe, 1);
					System.out.println("You craft an Axe!");
				} else {
					System.out.println("Not enough materials!");
				}
			} else {
				System.out.println("You don't need another Axe.");
			}
			break;
		default:
			System.out.println("Unrecognized Input");
		}
	}
	
	public void useRadio() {
		Item batteries = world.findItem("Batteries");
		if(world.getRadio()) {
			if(world.getDay() >= 4) {
				System.out.println("\nA miracle! You hear a voice! Someone is coming to rescue you!");
				System.out.println("\nYou win!");
				System.exit(0);
			} else {
				System.out.println("\nNothing but static.");
			}
		} else if(batteries.getQtyInInv() > 0) {
			world.setRadio(true);
			System.out.println("\nYou plug the batteries into the Radio. Now to see if anyone is listening.");
			p.removeFromInv(batteries, 1);
		} else {
			System.out.println("\nThe radio needs batteries.");
		}
	}

	public int winCheck() {
		if(p.getFood() <= 0 || 
				p.getWater() <= 0 || 
				p.getTemp() <= 0) {
			return -1;
		} else if(world.getWolf() && 
				world.getWolfX() == p.getX() && 
				world.getWolfY() == p.getY() && 
				!p.getLoc().equals("Cabin") && 
				!p.getLoc().equals("Watchtower")) {
			System.out.println("You are eaten by wolves");
			return -1;
		} else if(world.getDay() == 31) {
			return 1;
		} else {
			return 0;
		}
	}

	public void printStats() {
		
		System.out.println();
		System.out.println("Food: " + p.getFood() + "/100\tWater: " + p.getWater() + "/100");
		System.out.println("Temp: " + p.getTemp() + "/100\tInv: " + p.getCarry() + "/" + p.getCarryCap());
		String time = "";
		if(world.getTime() < 10) {
			time += "0";
		}
		time += world.getTime() + ":00";
		System.out.println("Time: " + time + "\tDay: " + world.getDay());
		System.out.println("Weather: " + world.getWeather());
		System.out.println();
	}

}
