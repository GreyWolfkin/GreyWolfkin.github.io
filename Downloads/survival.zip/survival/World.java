/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

import java.util.ArrayList;

public class World {

	private ArrayList<Item> allItems;
	private ArrayList<Location> allLocations;
	private int time;
	private int day;
	private String weather;
	private int fire;
	private boolean radio;
	private boolean cache;
	private String diff;
	private int read;
	private int play;
	private boolean wolf;
	private int wolfX;
	private int wolfY;
	private int wolfMove;
	private int wolfCount;

	public World(ArrayList<Location> allLocations, ArrayList<Item> allItems, int time, int day, String weather, int fire, boolean radio, boolean cache, String diff, int read, int play, boolean wolf, int wolfX, int wolfY, int wolfMove, int wolfCount) {
		this.allLocations = allLocations;
		this.allItems = new ArrayList<Item>();
		this.time = time;
		this.day = day;
		this.weather = weather;
		this.fire = fire;
		this.radio = radio;
		this.cache = cache;
		this.diff = diff;
		this.read = read;
		this.play = play;
		this.wolf = wolf;
		this.wolfX = wolfX;
		this.wolfY = wolfY;
		this.wolfMove = wolfMove;
		this.wolfCount = wolfCount;
	}
	
	public World() {
		this.allLocations = new ArrayList<Location>();
		this.allItems = new ArrayList<Item>();
		this.time = 6;
		this.day = 1;
		this.weather = "Clear";
		this.fire = 0;
		this.radio = false;
		this.cache = true;
		this.diff = "Normal";
		this.read = 1;
		this.play = 1;
		this.wolf = false;
		this.wolfX = -1;
		this.wolfY = -1;
		this.wolfMove = 3;
		this.wolfCount = 1;
	}
	
	public ArrayList<Location> getAllLocations() {
		return allLocations;
	}
	public void setAllLocations(ArrayList<Location> set) {
		allLocations = set;
	}
	public void addToLocations(Location location) {
		allLocations.add(location);
	}
	public void removeFromLocations(Location location) {
		allLocations.remove(location);
	}
	
	public Location findLocation(int x, int y) {
		for(Location location:allLocations) {
			if(location.getX() == x && location.getY() == y) {
				return location;
			}
		}
		return null;
	}
	
	public String getLocationText(int x, int y) {
		for(Location location:allLocations) {
			if(location.getX() == x && location.getY() == y) {
				return location.getText();
			}
		}
		return null;
	}
	public String getLocationContextual(int x, int y, ArrayList<Item> inv) {
		String text = "";
		for(Location location:allLocations) {
			if(location.getX() == x && location.getY() == y) {
				if(location.hasContextual()) {
					text += location.getContextual() + "\n";
				}
				if(location.hasSecond()) {
					if(location.hasReqItem()) {
						for(Item item:inv) {
							if(item.getName().equals(location.getReqItem())) {
								text +=location.getSecond() + "\n";
							}
						}
					} else {
						text += location.getSecond() + "\n";
					}
				}
			}
		}
		return text;
	}

	public ArrayList<Item> getAllItems() {
		return allItems;
	}
	public void setAllItems(ArrayList<Item> set) {
		allItems = set;
	}
	public void addToItems(Item item) {
		allItems.add(item);
	}
	public void removeFromItems(Item item) {
		allItems.remove(item);
	}
	
	public Item findItem(String itemName) {
		for(Item item:allItems) {
			if(item.getName().equals(itemName)) {
				return item;
			}
		}
		return null;
	}

	public int getTime() {
		return time;
	}
	public void setTime(int set) {
		time = set;
	}
	public void adjTime(int adj) {
		time += adj;
	}

	public int getDay() {
		return day;
	}
	public void setDay(int set) {
		day = set;
	}
	public void adjDay(int adj) {
		day += adj;
	}

	public String getWeather() {
		return weather;
	}
	public void setWeather(String set) {
		weather = set;
	}

	public int getFire() {
		return fire;
	}
	public void setFire(int set) {
		fire = set;
	}
	public void adjFire(int adj) {
		fire += adj;
		if(fire < 0) {
			fire = 0;
		}
	}

	public boolean getRadio() {
		return radio;
	}
	public void setRadio(boolean set) {
		radio = set;
	}

	public boolean getCache() {
		return cache;
	}
	public void setCache(boolean set) {
		cache = set;
	}
	
	public String getDiff() {
		return diff;
	}
	public void setDiff(String set) {
		diff = set;
		if(set.equals("Wolf")) {
			setWolf(true);
		}
	}
	
	public int getRead() {
		return read;
	}
	public void setRead(int set) {
		read = set;
	}
	public void adjRead(int adj) {
		read += adj;
	}
	
	public int getPlay() {
		return play;
	}
	public void setPlay(int set) {
		play = set;
	}
	public void adjPlay(int adj) {
		play += adj;
	}
	
	public boolean getWolf() {
		return wolf;
	}
	public void setWolf(boolean set) {
		wolf = set;
		if(set == true) {
			wolfX = 3;
			wolfY = 1;
		} else {
			wolfX = -1;
			wolfY = -1;
		}
	}
	
	public int getWolfX() {
		return wolfX;
	}
	public void setWolfX(int set) {
		wolfX = set;
	}
	public void adjWolfX(int adj) {
		wolfX += adj;
		if(wolfX > 5) {
			wolfX -= 5;
		} else if(wolfX < 1) {
			wolfX += 5;
		}
	}
	
	public int getWolfY() {
		return wolfY;
	}
	public void setWolfY(int set) {
		wolfY = set;
	}
	public void adjWolfY(int adj) {
		wolfY += adj;
		if(wolfY > 5) {
			wolfY -= 5;
		} else if(wolfY < 1) {
			wolfY += 5;
		}
	}
	
	public int getWolfMove() {
		return wolfMove;
	}
	public void setWolfMove(int set) {
		wolfMove = set;
	}
	public void adjWolfMove(int adj) {
		wolfMove += adj;
	}
	
	public int getWolfCount() {
		return wolfCount;
	}
	public void setWolfCount(int set) {
		wolfCount = set;
	}
	public void adjWolfCount(int adj) {
		wolfCount += adj;
	}

}

