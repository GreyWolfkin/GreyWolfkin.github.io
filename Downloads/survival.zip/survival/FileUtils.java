/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;

public class FileUtils {
	
	private Player p;
	private World world;
	
	private String currentWorkingDirectory;
	private String save_directory_path;
	private String data_directory_path;
	private String save_file_path;
	
	public FileUtils(Player p, World world) {
		this.p = p;
		this.world = world;
		currentWorkingDirectory = System.getProperty("user.dir");
		save_directory_path = currentWorkingDirectory + "\\save";
		data_directory_path = currentWorkingDirectory + "\\data";
		addLocationsToWorld();
	}
	
	private void addLocationsToWorld() {
		ArrayList<Location> locations = new ArrayList<Location>();
		String data_file_path = data_directory_path + "\\location.txt";
		try {
			FileReader fr = new FileReader(data_file_path);
			String str_enc = "";
			int c;
			while((c = fr.read()) != -1) {
				str_enc += (char) c;
			}
			fr.close();
			byte[] byte_dec = Base64.getDecoder().decode(str_enc);
			String str_dec = new String(byte_dec);
			str_dec = str_dec.replace("\\n", "\n");
			String[] split_str = str_dec.split("\\|");
			int x;
			int y;
			String text;
			String contextual;
			String reqItem;
			String secondContextual;
			for(int i = 0; i < split_str.length; i += 6) {
				x = Integer.parseInt(split_str[i]);
				y = Integer.parseInt(split_str[i + 1]);
				text = split_str[i + 2];
				contextual = split_str[i + 3];
				reqItem = split_str[i + 4];
				secondContextual = split_str[i + 5];
				Location newLocation = new Location(x, y, text, contextual, reqItem, secondContextual);
				locations.add(newLocation);
			}
			world.setAllLocations(locations);
		} catch(IOException | NumberFormatException ex) {
			ex.printStackTrace();
		}
	}
	
	public void addItemsToWorld(boolean newGame) {
		String item_file_path = data_directory_path + "\\item.txt";
		try {
			FileReader fr = new FileReader(item_file_path);
			String str_enc = "";
			int c;
			while((c = fr.read()) != -1) {
				str_enc += (char) c;
			}
			fr.close();
			byte[] byte_dec = Base64.getDecoder().decode(str_enc);
			String str_dec = new String(byte_dec);
			String[] split_str = str_dec.split("\\|");
			String name;
			int weight;
			String desc;
			int qtyInInv;
			int qtyInChest;
			int qtyInCache;
			boolean isFood;
			int foodVal;
			boolean isWater;
			int waterVal;
			boolean isTemp;
			int tempVal;
			for(int i = 0; i < split_str.length; i += 12) {
				name = split_str[i];
				weight = Integer.parseInt(split_str[i + 1]);
				desc = split_str[i + 2];
				qtyInInv = Integer.parseInt(split_str[i + 3]);
				qtyInChest = Integer.parseInt(split_str[i + 4]);
				qtyInCache = Integer.parseInt(split_str[i + 5]);
				if(split_str[i + 6].equals("true")) {
					isFood = true;
				} else {
					isFood = false;
				}
				foodVal = Integer.parseInt(split_str[i + 7]);
				if(split_str[i + 8].equals("true")) {
					isWater = true;
				} else {
					isWater = false;
				}
				waterVal = Integer.parseInt(split_str[i + 9]);
				if(split_str[i + 10].equals("true")) {
					isTemp = true;
				} else {
					isTemp = false;
				}
				tempVal = Integer.parseInt(split_str[i + 11]);
				Item newItem = new Item(name, weight, desc, 0, 0, 0, isFood, foodVal, isWater, waterVal, isTemp, tempVal);
				world.addToItems(newItem);
				if(newGame) {
					if(qtyInInv > 0) {
						p.addToInv(newItem, qtyInInv);
					}
					if(qtyInChest > 0) {
						p.addToChest(newItem, qtyInChest);
					}
					if(qtyInCache > 0) {
						p.addToCache(newItem, qtyInCache);
					}
				}
			}
		} catch(IOException | NumberFormatException ex) {
			ex.printStackTrace();
		}
	}
	
	public void saveAndQuit(String file_name) {
		save_file_path = save_directory_path + "\\" + file_name + ".txt";
		String str_dec = "Game|Exists";
		str_dec += "|Food|" + p.getFood();
		str_dec += "|Water|" + p.getWater();
		str_dec += "|Temp|" + p.getTemp();
		str_dec += "|Loc|" + p.getLoc();
		str_dec += "|X|" + p.getX();
		str_dec += "|Y|" + p.getY();
		str_dec += "|Items|";
		for(Item item:world.getAllItems()) {
			str_dec += item.getName() + "|";
			str_dec += item.getQtyInInv() + "|";
			str_dec += item.getQtyInChest() + "|";
			str_dec += item.getQtyInCache() + "|";
		}
		str_dec += "Status|" + p.getStatus();
		str_dec += "|Time|" + world.getTime();
		str_dec += "|Day|" + world.getDay();
		str_dec += "|Weather|" + world.getWeather();
		str_dec += "|Fire|" + world.getFire();
		str_dec += "|Radio|" + world.getRadio();
		str_dec += "|Cache|" + world.getCache();
		str_dec += "|Read|" + world.getRead();
		str_dec += "|Play|" + world.getPlay();
		str_dec += "|Diff|" + world.getDiff();
		str_dec += "|Wolf|" + world.getWolf();
		str_dec += "|WolfX|" + world.getWolfX();
		str_dec += "|WolfY|" + world.getWolfY();
		str_dec += "|WolfMove|" + world.getWolfMove();
		str_dec += "|WolfCount|" + world.getWolfCount();
		
		String str_enc = encodeString(str_dec);
		
		try {
			File directory = new File(save_directory_path);
			if(!directory.isDirectory()) {
				directory.mkdir();
			}
			FileWriter fw = new FileWriter(save_file_path);
			fw.write(str_enc);
			fw.flush();
			fw.close();
		} catch(IOException ex) {
			System.out.println("Error writing to file");
		}
		
		try {
			FileWriter fw = new FileWriter(save_directory_path + "\\raw.txt");
			fw.write(str_dec);
			fw.flush();
			fw.close();
		} catch(IOException ex) {
			ex.printStackTrace();
		}
	}
	
	public void readSaveFile(String name) throws IOException, IllegalArgumentException, NumberFormatException, LoadException {
		save_file_path = save_directory_path + "\\" + name + ".txt";
		FileReader fr = new FileReader(save_file_path);
		String str_enc = "";
		int c;
		while((c = fr.read()) != -1) {
			str_enc += (char) c;
		}
		fr.close();
		
		byte[] byte_dec = Base64.getDecoder().decode(str_enc);
		String str_dec = new String(byte_dec);
		String[] split_str = str_dec.split("\\|");
		p.setFood(getInt("Food", split_str));
		p.setWater(getInt("Water", split_str));
		p.setTemp(getInt("Temp", split_str));
		p.setLoc(getString("Loc", split_str));
		p.setX(getInt("X", split_str));
		p.setY(getInt("Y", split_str));
		getItems(split_str);
		p.setStatus(getString("Status", split_str));
		world.setTime(getInt("Time", split_str));
		world.setDay(getInt("Day", split_str));
		world.setWeather(getString("Weather", split_str));
		world.setFire(getInt("Fire", split_str));
		world.setRadio(getBool("Radio", split_str));
		world.setCache(getBool("Cache", split_str));
		world.setRead(getInt("Read", split_str));
		world.setPlay(getInt("Play", split_str));
		world.setDiff(getString("Diff", split_str));
		world.setWolf(getBool("Wolf", split_str));
		world.setWolfX(getInt("WolfX", split_str));
		world.setWolfY(getInt("WolfY", split_str));
		world.setWolfMove(getInt("WolfMove", split_str));
		world.setWolfCount(getInt("WolfCount", split_str));
	}
	
	private String encodeString(String str_dec) {
		return Base64.getEncoder().encodeToString(str_dec.getBytes());
	}
	
	private int getInt(String term, String[] split_str) throws NumberFormatException, LoadException {
		for(int i = 0; i < split_str.length; i++) {
			if(split_str[i].equals(term)) {
				int returnInt = Integer.parseInt(split_str[i + 1]);
				return returnInt;
			}
		}
		throw new LoadException("Load Exception Get Int");
	}
	
	private String getString(String term, String[] split_str) throws LoadException {
		for(int i = 0; i < split_str.length; i++) {
			if(split_str[i].equals(term)) {
				return split_str[i + 1];
			}
		}
		throw new LoadException("Load Exception Get String");
	}
	
	private boolean getBool(String term, String[] split_str) throws LoadException {
		for(int i = 0; i < split_str.length; i++) {
			if(split_str[i].equals(term)) {
				if(split_str[i + 1].equals("true")) {
					return true;
				} else {
					return false;
				}
			}
		}
		throw new LoadException("Load Exception Get Bool");
	}
	
	private void getItems(String[] split_str) throws NumberFormatException {
		int i = 0;
		int j = 0;
		while(i < split_str.length) {
			if(split_str[i].equals("Items")) {
				i++;
				break;
			}
			i++;;
		}
		while(j < split_str.length) {
			if(split_str[j].equals("Status")) {
				break;
			}
			j++;
		}
		while(i < j) {
			Item item = world.findItem(split_str[i]);
			int pQty = Integer.parseInt(split_str[i + 1]);
			int chestQty = Integer.parseInt(split_str[i + 2]);
			int cacheQty = Integer.parseInt(split_str[i + 3]);
			if(pQty > 0) {
				p.addToInv(item, pQty);
			}
			if(chestQty > 0) {
				p.addToChest(item, chestQty);
			}
			if(cacheQty > 0) {
				p.addToCache(item, cacheQty);
			}
			i += 4;
		}
	}

}
