import java.util.*;

public class Game {
	
	static boolean run = true;
	
	static Scanner scan = new Scanner(System.in);
	
	//Constructs Items with args (name, desc, isVis) or (name, desc, desc2, isVis). All other bools default to false
	static Item door1 = new Item("door", "A solid, wooden door. It is locked.", "A solid, wooden door. It is unlocked.", true);
	static Item key1 = new Item("key", "A small, brass key.", false);
	static Item rug1 = new Item("rug", "A beautiful rug.", "A beautiful rug. It has been shoved against the wall.", true);
	static Item flashlight1 = new Item("flashlight", "A powerful flashlight. It is missing batteries.", "A powerful flashlight", true);
	static Item cupboard1 = new Item("cupboard", "A small, dark cupboard", "A small cupboard. There is a small, brass key inside it", true);
	static Item batteries1 = new Item("batteries", "A pair of AA batteries", false);
	
	//Array of valid items
	static Item[] items = {door1, key1, rug1, flashlight1, cupboard1, batteries1};
	
	//printInv() iterates upon this List to print items in inventory
	static ArrayList<Item> inv = new ArrayList<Item>();
	
	//Sets individual Item bools to true as necessary
	static void itemBools() {
		door1.canOpen = true;
		door1.isLocked = true;
		key1.canTake = true;
		key1.canUseWith = true;
		rug1.canMove = true;
		flashlight1.inInv = true;
		flashlight1.canUse = true;
		flashlight1.needsPower = true;
		cupboard1.canOpen = true;
		batteries1.canTake = true;
		batteries1.canUseWith = true;
	}
	
	//Listens to input, sets to Lower Case, splits using " " delimiter, passes to
	// methods based on length of inputArr
	static void listen() {
		String input = scan.nextLine();
		input.toLowerCase();
		String[] inputArr = input.split(" ");
		switch (inputArr.length) {
			case 1:
			inputOne(input);
			break;
			case 2:
			inputTwo(inputArr);
			break;
			case 4:
			inputFour(inputArr);
			break;
			default:
			System.out.println("Unrecognized input");
			break;
		}
	}
	
	//Checks input against array of valid items, returns index of item if valid,
	// returns -1 if invalid
	static int checkItem(String input) {
		int index = -1;
		for (int i = 0; i < items.length; i++) {
			if (input.equals(items[i].name)) {
				index = i;
			}
		}
		return index;
	}
	
	//Takes input in the form of [command]
	static void inputOne(String input) {
		switch (input) {
			case "help":
				help();
				break;
			case "look":
				look();
				break;
			case "i":
			case "inv":
			case "inventory":
				printInv();
				break;
			case "end":
			case "quit":
				run = false;
				break;
			case "stats":
				itemStats();
				break;
			case "hint":
				hint();
				break;
			default:
				System.out.println("Unrecognized input");
				break;
		}
	}
	
	//Prints help text, valid commands, syntax
	static void help() {
		System.out.println("Valid commands:");
		System.out.println("help - Prints help text\nlook - Looks at room\ninv - Prints inventory\nend - Ends program");
		System.out.println("look/take/move/open/use [item] - Performs [action] on [item]");
		System.out.println("use [item1] on [item2] - Combines item1 with item2, if possible\n");
		System.out.println("Debugging commands:");
		System.out.println("hint - Prints walkthrough for win condition\nstats - Prints Strings and Booleans for all items");
	}
	
	//Prints what the player sees, based on certain flags
	static void look() {
		System.out.print("You are in a room.");
		if (door1.isLocked) {
			System.out.print(" There is a locked door.");
		} else {
			System.out.print(" There is an unlocked door.");
		}
		if (rug1.isMoved) {
			System.out.print(" A beautiful rug has been shoved against one wall.");
			if (!batteries1.inInv) {
				System.out.print(" There are a pair of AA batteries on the floor.");
			}
		} else {
			System.out.print(" There is a beautiful rug on the floor.");
		}
		if (cupboard1.isOpen) {
			if (flashlight1.isOn) {
				if (key1.inInv) {
					System.out.print(" There is a cupboard with an open door.");
				} else {
					System.out.print(" There is a cupboard with an open door. Inside the cupboard is a small, brass key.");
				}
			} else {
				System.out.print(" There is a cupboard with an open door, but it is too dark to see inside.");
			}
		} else {
			System.out.print(" There is a cupboard on the wall.");
		}
		System.out.println();
	}
	
	//Iterates upon inv List
	static void printInv() {
		if (inv.size() > 0) {
			System.out.println("Inventory:");
			for (int i = 0; i < inv.size(); i++) {
				if (inv.get(i).descNum == 1) {
					System.out.println(inv.get(i).desc);
				} else {
					System.out.println(inv.get(i).desc2);
				}
			}
		} else {
			System.out.println("You are not carrying anything.");
		}
	}
	
	//Takes input in the form of [command] [item]
	static void inputTwo(String[] inputArr) {
		String command = inputArr[0];
		switch(command) {
			case "look":
				lookAt(inputArr[1]);
				break;
			case "take":
				take(inputArr[1]);
				break;
			case "move":
				move(inputArr[1]);
				break;
			case "open":
				open(inputArr[1]);
				break;
			case "use":
				use(inputArr[1]);
				break;
			default:
				System.out.println("Unrecognized input");
				break;
		}
	}
	
	//Prints [item].desc if item is valid and isVis
	static void lookAt(String input) {
		//Checks that [item] is valid
		int i = checkItem(input);
		if (i == -1) {
			System.out.println("I don't see " + input);
		} else {
			if (items[i].isVis) {
				if (items[i].descNum == 1) {
					System.out.println(items[i].desc);
				} else {
					System.out.println(items[i].desc2);
				}
			} else {
				System.out.println("I don't see " + input);
			}
		}
	}
	
	//Takes [item] if item is valid, isVis, canTake, and !inInv
	static void take(String input) {
		//Checks that [item] is valid
		int i = checkItem(input);
		if (i == -1) {
			System.out.println("I don't see " + input);
		} else {
			if (items[i].isVis) {
				if (items[i].canTake) {
					if (!items[i].inInv) {
						itemTaken(i);
					} else {
						System.out.println(input + " is already in inventory");
					}
				} else {
					System.out.println("Cannot take " + input);
				}
			} else {
				System.out.println("I don't see " + input);
			}
		}
	}
	
	//When an item is taken, prints text, sets flags, and adds to inv based on what item is taken
	static void itemTaken(int i) {
		System.out.println("You pick up " + items[i].name);
		items[i].inInv = true;
		inv.add(items[i]);
		if (items[i] == key1) {
			cupboard1.descNum = 1;
		}
	}
	
	//Moves [item] if item is valid, isVis, canMove, and !isMoved
	static void move(String input) {
		//Checks that [item] is valid
		int i = checkItem(input);
		if (i == -1) {
			System.out.println("I don't see " + input);
		} else {
			if (items[i].isVis) {
				if (items[i].canMove) {
					if (!items[i].isMoved) {
						itemMoved(i);
					} else {
						System.out.println(input + " is already moved");
					}
				} else {
					System.out.println("Cannot move " + input);
				}
			} else {
				System.out.println("I don't see " + input);
			}
		}
	}
	
	//When an item is moved, prints text and sets flags based on what item is moved
	static void itemMoved(int i) {
		System.out.println("You move " + items[i].name);
		items[i].isMoved = true;
		if (items[i] == rug1) {
			rug1.descNum = 2;
			System.out.println("You see a pair of AA batteries under the rug.");
			batteries1.isVis = true;
		}
	}
	
	//Opens [item] if item is valid, isVis, canOpen, !isOpen, and !isLocked
	static void open(String input) {
		//Checks that [item] is valid
		int i = checkItem(input);
		if (i == -1) {
			System.out.println("I don't see " + input);
		} else {
			if (items[i].isVis) {
				if (items[i].canOpen) {
					if (!items[i].isOpen) {
						if (!items[i].isLocked) {
							itemOpened(i);
						} else {
							System.out.println(input + " is locked");
						}
					} else {
						System.out.println(input + " is already open");
					}
				} else {
					System.out.println("Cannot open " + input);
				}
			} else {
				System.out.println("I don't see " + input);
			}
		}
	}
	
	//When an item is opened, prints text and sets flags based on which item is opened
	static void itemOpened(int i) {
		System.out.println("You open " + items[i].name);
		items[i].isOpen = true;
		if (items[i] == door1) {
			System.out.println("You escaped! You win!");
			run = false;
		}
		if (items[i] == cupboard1) {
			if (flashlight1.isOn) {
				System.out.println("Inside is a small, brass key");
				key1.isVis = true;
				cupboard1.descNum = 2;
			} else {
				System.out.println("It is too dark to see inside.");
			}
		}
	}
	
	//Attempts to use [item] if item is valid, inInv, and canUse
	static void use(String input) {
		//Checks that [item] is valid
		int i = checkItem(input);
		if (i == -1) {
			System.out.println("No " + input + " in inventory");
		} else {
			if (items[i].inInv) {
				if (items[i].canUse) {
					itemUsed(i);
				} else {
					System.out.println("Cannot use " + input + " in that way");
				}
			} else {
				System.out.println("No " + input + " in inventory");
			}
		}
	}
	
	//When an item is used, checks if it needs power, then prints text and sets flags depending on which item was used
	static void itemUsed(int i) {
		if (!items[i].isOn) {
			if (items[i].needsPower) {
				if (items[i].isPowered) {
					System.out.println("You used " + items[i].name);
					items[i].isOn = true;
					if (items[i] == flashlight1) {
						if (cupboard1.isOpen) {
							key1.isVis = true;
							cupboard1.descNum = 2;
						}
					}
				} else {
					noPower(i);
				}
			} else {
				System.out.println("You used " + items[i].name);
				items[i].isOn = true;
			}
		} else {
			System.out.println(items[i].name + " is already on.");
		}
	}
	
	//If an item requires power and is not currently powered, prints text based on which item was used
	static void noPower(int i) {
		if (items[i] == flashlight1) {
			System.out.println("There are no batteries in the flashlight");
		}
	}
	
	//Takes input in the form of [command] [item] [conjunction] [item]
	static void inputFour(String[] inputArr) {
		String command = inputArr[0];
		String conjunction = inputArr[2];
		
		//Checks for conjunction == with/on
		boolean goodGrammar = false;
		switch(conjunction) {
			case "on":
			case "with":
				goodGrammar = true;
				break;
			default:
				break;
		}
		
		if (goodGrammar) {
			switch(command) {
				case "combine":
				case "use":
					use(inputArr);
					break;
				default:
					System.out.println("Unrecognized input");
			}
		} else {
			System.out.println("Unrecognized syntax");
		}
	}
	
	//Attempts to use [item1] on [item2] if both are valid
	//Overloaded version of use() which accepts String[] as arg
	static void use(String[] inputArr) {
		int i = checkItem(inputArr[1]);
		int j = checkItem(inputArr[3]);
		
		if (i == -1) {
			System.out.println("I don't see " + inputArr[1]);
		} else {
			if (j == -1) {
				System.out.println("I don't see " + inputArr[3]);
			} else {
				if (items[i].inInv) {
					checkCanUse(i, j);
				} else {
					System.out.println("I don't see " + inputArr[1]);
				}
			}
		}
	}
	
	//When an item is used on another item, checks if they are compatible, prints text, and sets flags
	static void checkCanUse(int i, int j) {
		switch (items[i].name) {
			case "key":
				switch(items[j].name) {
					case "door":
						System.out.println("You unlock " + items[j].name);
						items[j].isLocked = false;
						items[j].descNum = 2;
						break;
					default:
						System.out.println("Cannot use " + items[i].name + " on " + items[j].name);
						break;
					
				}
				break;
			case "batteries":
				switch(items[j].name) {
					case "flashlight":
						System.out.println("You put " + items[i].name + " into " + items[j].name);
						items[j].isPowered = true;
						batteries1.isVis = false;
						inv.remove(batteries1);
						items[j].descNum = 2;
						break;
					default:
						System.out.println("Cannot use " + items[i].name + " on " + items[j].name);
						break;
				}
				break;
			default:
				System.out.println("Cannot use " + items[i].name);
				break;
		}
	}
	
	//Debugging method. Prints a walkthrough
	static void hint() {
		System.out.println(">>move rug");
		System.out.println(">>take batteries");
		System.out.println(">>use batteries on flashlight");
		System.out.println(">>use flashlight");
		System.out.println(">>open cupboard");
		System.out.println(">>take key");
		System.out.println(">>use key on door");
		System.out.println(">>open door");
	}
	
	//Debugging method. Prints Strings and Booleans for all valid items
	static void itemStats() {
		for (Item i : items) {
			System.out.println("Name: " + i.name);
			System.out.println("Desc: " + i.desc);
			System.out.println("Desc2: " + i.desc2);
			System.out.println("isVis: " + i.isVis);
			System.out.println("canTake: " + i.canTake);
			System.out.println("inInv: " + i.inInv);
			System.out.println("canUse: " + i.canUse);
			System.out.println("needsPower: " + i.needsPower);
			System.out.println("isPowered: " + i.isPowered);
			System.out.println("isOn: " + i.isOn);
			System.out.println("canUseWith: " + i.canUseWith);
			System.out.println("canOpen: " + i.canOpen);
			System.out.println("isOpen: " + i.isOpen);
			System.out.println("isLocked: " + i.isLocked);
			System.out.println("canMove: " + i.canMove);
			System.out.println("isMoved: " + i.isMoved);
			System.out.println("descNum: " + i.descNum);
			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		
		//Sets Item bools to true as necessary
		itemBools();
		
		//Puts items with inInv = true into inventory
		for(Item i : items) {
			if (i.inInv) {
				inv.add(i);
			}
		}
		
		//Prints first instance of look()
		look();
		System.out.println();
		
		//Continually listens for user input until user inputs "end" or "quit"
		while(run) {
			listen();
			System.out.println();
		}
	}
}