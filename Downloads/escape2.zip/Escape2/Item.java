class Item {
	String name, desc, desc2;
	boolean isVis, canTake, inInv, canUse, needsPower, isPowered, isOn, canUseWith, canOpen, isOpen, isLocked, canMove, isMoved;
	int descNum;
	
	Item(String name, String desc, boolean isVis) {
		this.name = name;
		this.desc = desc;
		this.desc2 = desc;
		this.isVis = isVis;
		this.canTake = false;
		this.inInv = false;
		this.canUse = false;
		this.needsPower = false;
		this.isPowered = false;
		this.isOn = false;
		this.canUseWith = false;
		this.canOpen = false;
		this.isOpen = false;
		this.isLocked = false;
		this.canMove = false;
		this.isMoved = false;
		this.descNum = 1;
	}
	
	Item(String name, String desc, String desc2, boolean isVis) {
		this.name = name;
		this.desc = desc;
		this.desc2 = desc2;
		this.isVis = isVis;
		this.canTake = false;
		this.inInv = false;
		this.canUse = false;
		this.needsPower = false;
		this.isPowered = false;
		this.isOn = false;
		this.canUseWith = false;
		this.canOpen = false;
		this.isOpen = false;
		this.isLocked = false;
		this.canMove = false;
		this.isMoved = false;
		this.descNum = 1;
	}
}