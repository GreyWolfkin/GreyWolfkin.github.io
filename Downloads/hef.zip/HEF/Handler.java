/******
 * Handler does the "heavy lifting" for the Demo2 program.
 * Handler's p# methods print dialogue, narration, and player's options for input/choices.
 * Handler's c# methods take input as an integer, increase or decrease variables, and set g for where the 
 * player's choice takes them next.
 *
 * Not all p# methods are followed by a c# method. Some p# methods are called by listener() which then
 * go to a different c# method, such as c2() which is the most frequently called method in the program.
 ******/

import java.util.ArrayList;

class Handler {
	
	private Player p;
	private ALIM a;
	
	//Stores Strings which are referenced by c2().
	private ArrayList<String> opt2 = new ArrayList<String>();
	
	Handler(Player p, ALIM a) {
		this.p = p;
		this.a = a;
	}
	
	void p0() {
		System.out.println("You wake up groggy. Your head is throbbing and your throat feels dry.\nYour vision is blurry, but slowly your surroundings come into focus.\nYou are in a room lit by soft, comfortable light. The walls and consoles are hospital-white, and black screens cover most of every surface.\nWhere large, bay windows should be there are thick, segmented metal plates.\nYou groan softly. \"My head...\" you whisper.\nA large console on the right wall flashes to life and white, block letters apear on the screen.\nPLEASE BE CAUTIOUS. VITAL SIGNS INDICATE YOU HAVE BEEN UNCONSCIOUS FOR [15 HOURS]. HEAD TRAUMA IS HIGHLY PROBABLE_\n");
		System.out.println("1 - Speak into the console");
		System.out.println("2 - Look around some more");
	}
	
	/*
	 First choice player makes. Speak Into Console or Look Around.
	 For c0(), Speak Into Console sets g=1, which prints a sentence unique to that area.
	 Following c0(), options to speak into console set g=2.
	*/
	void c0(int input) {
		switch(input) {
			case 1:
				p.incT(1);
				p.setG(1);
				break;
			case 2:
				p.incT(1);
				p.incM(1);
				p.setLookAround(true);
				p.setG(3);
				break;
			default:
				System.out.println("Unrecognized input");
				break;
		}
	}
	
	void p1() {
		System.out.println("You clear your throat, wincing at the pain it causes.\nYou lean towards the console and speak clearly:\n");
		System.out.println("1 - \"Where am I?\"");
		System.out.println("2 - \"What are you?\"");
		if (p.getM() >= 1) {
			System.out.println("3 - \"Who am I?\"");
			System.out.println("4 - \"Where is everyone else?\"");
			System.out.println("5 - \"What happened here?\"");
		}
	}
	
	//If player chooses to speak into the console first, c1() is called. Otherwise c2() is called.
	void c1(int input) {
		if (input > 2) {
			if (p.getM() < 1) {
				input = 0;
			}
		}
		switch(input) {
			case 1:
				p.incM(1);
				p.setShuttle(true);
				p.setG(4);
				break;
			case 2:
				p.setAlim(true);
				p.setG(5);
				break;
			case 3:
				p.incM(1);
				p.setWhoAmI(true);
				p.setG(6);
				break;
			case 4:
				p.setWhereCrew(true);
				p.setAlimError(true);
				p.setG(7);
				break;
			case 5:
				p.incM(1);
				p.setWhatHap(true);
				p.setG(8);
				break;
			default:
				System.out.println("Unrecognized input");
				break;
		}
	}
	
	/******
	 * p2() and c2() are together the most frequently called methods in Demo2.
	 * First, p2() clears ArrayList<String> opt2. This ensures that when p2() is called more than once,
	 * opt2 is always clean and ready to be updated.
	 * p2() then adds Strings to opt2, depending on which booleans are true or false.
	 * For each boolean that is false, p2() adds that String to opt2.
	 * For certain choices, p2() also checks for memory value, and whether or not player has already
	 * chosen certain dialogue options.
	 *
	 * For example, the player cannot ask for a Damage Report until they have asked What Happened.
	 *
	 * After adding all valid options to opt1b, p2() prints the players options as
	 * 1 - [String at index 0]
	 * 2 - [String at index 1]
	 * etc. 
	 *
	 * c2() is then called, and takes an integer as its argument.
	 * c2() takes that input and subtracts 1. Sting h is then assigned the value of opt2.get(input), so if 
	 * player inputs 1, String h is the String at index 0.
	 * A switch method then checks String h against all possible Strings which could be in opt2.
	 * if {} else {"Unrecognized input"}; checks are not necessary in switch(h) because a try{}catch{} method
	 * checks int input against opt2, and catches IndexOutOfBoundsException. If a player inputs a value which is
	 * outside the bounds of the array, h = "". If a player inputs a valid integer, h takes the String at the correct index,
	 * preventing any unwanted inputs.
	 ******/
	
	void p2() {
		opt2.clear();
		if (!p.getLookAround()) {
			opt2.add("Look around some more");
		}
		if (!p.getShuttle()) {
			opt2.add("\"Where am I?\"");
		}
		if (!p.getAlim()) {
			opt2.add("\"What are you?\"");
		}
		if ((p.getM() >= 1) && (!p.getWhoAmI())) {
			opt2.add("\"Who am I?\"");
		}
		if ((p.getM() >=1) && (!p.getWhereCrew())) {
			opt2.add("\"Where is everyone else?\"");
		}
		if ((p.getM() >= 1) && (!p.getWhatHap())) {
			opt2.add("\"What happened here?\"");
		}
		if ((p.getM() >= 2) && (!p.getWhatMiss())) {
			opt2.add("\"What was the mission?\"");
		}
		if ((p.getWhatHap()) && (!p.getDamRep())) {
			opt2.add("\"Damage report.\"");
		}
		int i = 1;
		for (String j : opt2) {
			System.out.println(i + " - " + j);
			i++;
		}
	}
	
	void c2(int input) {
		String h = "";
		input--;
		try {
			h = opt2.get(input);
		} catch (IndexOutOfBoundsException ex) {
			h = "";
		}
		switch(h) {
			case "Look around some more":
				p.incT(1);
				p.incM(1);
				p.setLookAround(true);
				p.setG(3);
				break;
			case "\"Where am I?\"":
				p.incM(1);
				p.setShuttle(true);
				p.setG(4);
				break;
			case "\"What are you?\"":
				p.incM(1);
				p.setAlim(true);
				p.setG(5);
				break;
			case "\"Who am I?\"":
				p.incM(1);
				p.setWhoAmI(true);
				p.setG(6);
				break;
			case "\"Where is everyone else?\"":
				p.incM(1);
				p.setWhereCrew(true);
				p.setAlimError(true);
				p.setG(7);
				break;
			case "\"What happened here?\"":
				p.incM(1);
				p.setWhatHap(true);
				p.setG(8);
				break;
			case "\"What was the mission?\"":
				p.incM(1);
				p.setShuttle(true);
				p.setWhatMiss(true);
				p.setG(9);
				break;
			case "\"Damage report.\"":
				p.incM(1);
				p.setAlimError(true);
				p.setDamRep(true);
				p.setG(10);
				break;
			default:
				System.out.println("Unrecognized input");
				break;
		}
	}
	
	// When the player chooses "Look Around", p3(). p3() changes based on what the player has already seen or learned.
	// For example, if the player has already asked about what happened to the shuttle, looking around will reference
	// what the player learned about the solar flare. If the player has not asked about what happened, looking around
	// will suggest a technical failure, but not reference the flare.
	void p3() {
		System.out.println("You look around, still trying to clear your head.");
		if (p.getShuttle()) {
			System.out.println("The Command Module is deathly silent.");
		} else {
			System.out.println("This room looks right out of a textbook on Deep-Space travel. You are in what appears to be the Command Module.");
		}
		if (p.getAlim()) {
			System.out.println("ALIM sits on the wall, his output dash blinking as he dutifully waits for your next query.");
		} else {
			System.out.println("The screen, which previously told you about your probable head trauma, now sits blank except for an output dash that blinks slowly in the top-left corner.");
		}
		if (p.getWhereCrew()) {
			System.out.println("The empty chairs stare back at you, daring you to find the other three crew members.");
		} else {
			System.out.println("You realize this must have been a four-person crew, based on the number of chairs and consoles stationed on deck.");
		}
		if (p.getWhatHap()) {
			System.out.println("You look at the blast shields and dark consoles and shudder. ALIM said there had been a solar flare? What kind of flare could do this much damage?");
		} else {
			System.out.println("The blast shields and dark consoles make you think there must have been a technical failure at some point.");
		}
		System.out.println();
	}
	
	void p4() {
		System.out.println("You look around the unfamiliar room.\n\"Where am I?\"\nThe blinking line disappears for the briefest of moments before text begins to appear.\nYOU ARE IN THE COMMAND MODULE OF DEEP-SPACE EXPLORATION AND RECONNAISSANCE SHUTTLE CODENAME PROMETHEUS_\n");
	}
	
	void p5() {
		System.out.println("\"What are you? State your rank and designation.\"\nI AM THIS SHUTTLE'S ONBOARD ARTIFICIAL INTELLIGENCE: MKII AUTONOMOUS LEARNING INTEGRATED MODULE. PLEASE CALL ME ALIM.\nARTIFICIAL INTELLIGENCE ARE NOT ASSIGNED RANK IN THE SPACE DEFENSE CORPS, THOUGH MY PROGRAMMING REQUIRES THAT I OBEY THE ORDERS OF EVERY OFFICER ABOARD THE SHUTTLE, WHICH WOULD SUGGEST THAT MY RANK IS ENSIGN_\n");
	}
	
	void p6() {
		System.out.println("You decide to ask the most pressing question at hand.\n\"Who am I? Name, rank, and crew bio.\"\nNAME: JANE DAWTHORN\nRANK: COMMANDING OFFICER, DEEP-SPACE MISSION CODENAME \"STOLEN FIRE\"\nBIO: YOUNGEST FEMALE LIEUTENANT COMMANDER IN THE SDC. BORN 2301. DAUGHTER OF DISTINGUISHED [REDACTED - SPECIAL] AND [REDACTED]. GRADUATED 3RD IN CLASS, MOON-BASE FOXTROT NAVAL ACADEMY. GRADUATED WITH SPECIAL HONORS, JUPITER OFFICER TERTIARY TRAINING FACILITY. SERVED UNDER [REDACTED] DURING [REDACTED - SPECIAL]. PROMOTED TO LIEUTENANT COMMANDER IN 2326 FOR DISTINGUISHED AND SUPERIOR PERFORMANCE IN MULTIPLE THEATERS_\n");
	}
	
	// Similarly to p3(), p7() changes based on what the character has already seen/determined.
	void p7() {
		if (p.getLookAround()) {
			System.out.println("There were three other crew members aboard. You'll have to find out what happened to them.");
		} else {
			System.out.println("You can't have been the only person onboard.");
		}
		System.out.println("\"Where is everyone else?\"\nAPOLOGIES, BUT THE LOCATIONS OF [ERROR], [ERROR], AND [ERROR] ARE PRESENTLY UNKNOWN_\n");
	}
	
	void p8() {
		System.out.println("You don't like the look of the blast shields and all those dark consoles.\n\"What happened here?\"\nCATASTROPHIC EQUIPMENT FAILURE CAUSED BY SOLAR FLARE EXCEEDING [ERROR] [ERROR]_\n");
	}
	
	void p9() {
		System.out.println("\"What was the mission of this vessel?\"\nBRAVO-ALPHA SECURITY CLEARANCE REQUIRED. INITIATING SECURITY CHECK_\nSECURITY GREEN LIT. ACCESSING MISSION BRIEFING_\nMISSION BRIEFING \"STOLEN FIRE\": 12-YEAR DEEP-SPACE SCIENTIFIC MISSION. DESIG CRITICAL. DEEP-SPACE SHUTTLE PROMETHEUS TO REACH WHITE GIANT STAR HEF-3575 IN 5 YEARS, SUSPENDED ANIMATION FOR CREW NOT REQUIRED. SPEND 2 YEARS IN STABLE ORBIT AROUND HEF-3575. DURING ORBIT, RESEARCH ISOTOPE HE-14. PROMETHEUS TO RETURN TO SCIENTIFIC STATION ECHO-ECHO-CHARLIE TO REPORT FINDINGS_\n");
	}
	
	void p10() {
		System.out.println("\"Damage report.\"\nMULTIPLE LIFE SUPPORT FUNCTIONS DAMAGED.\nMULTIPLE LIFE SUPPORT FUNCTIONS INOPERABLE.\nMULTIPLE VITAL FUNCTIONS DAMAGED.\nMULTIPLE VITAL FUNCTIONS INOPERABLE\nMULTIPLE SECONDARY FUNCTIONS DAMAGED.\nMULTIPLE SECONDARY FUNCTIONS INOPERABLE.\nALL TERTIARY FUNCTIONS INOPERABLE_\n\n\"Give me more details.\"\nLIFE SUPPORT FUNCTIONS:\nPRIMARY O2 SCRUB (DAMAGED)\nSECONDARY O2 SCRUB (DAMAGED)\nPRIMARY H2O REPLICATION (OPERATIONAL)\nSECONDARY H20 REPLICATION (INOPERABLE)\nPRIMARY NUTRITION REPLICATION (INOPERABLE)\nSECONDARY NUTRITION REPLICATION (INOPERABLE)\nPRIMARY HEATER (DAMAGED)\nSECONDARY HEATER (INOPERABLE)\nPRIMARY WASTE DISPOSAL (OPERATIONAL)\nSECONDARY WASTE DISPOSAL (DAMAGED)\n\nVITAL FUNCTIONS:\nFTL THRUSTERS (INOPERABLE)\nPRIMARY RADIATION SHIELDS (DAMAGED)\nPRIMARY ELECTROMAGNETIC SHIELDS (DAMAGED)\nPRIMARY KINETIC SHIELDS (INOPERABLE)\nMULTI-PERSONNEL SUB-LIGHT ESCAPE UNIT (INOPERABLE)\n\nSECONDARY FUNCTIONS:\nSUB-LIGHT THRUSTERS (INOPERABLE)\nLIGHT-DISTANCE COMM SYS (INOPERABLE)\nARTIFICIAL LEARNING INTEGRATED MODULE (DAMAGED)\nSUSPENDED ANIMATION CONTAINMENT (DAMAGED)\nSECONDARY RADIATION SHIELDS (OPERATIONAL)\nSECONDARY ELECTROMAGNETIC SHIELDS (INOPERABLE)\nSECONDARY KINETIC SHIELDS (DAMAGED)\n\nTERTIARY FUNCTIONS:\nALL TERTIARY FUNCTIONS (INOPERABLE)_\n");
	}
	
	// p11() is effectively the win screen for the demo. Once the player's m value reaches 8, p11() is called and reveals more information about
	// the story, ending the demo.
	void p11() {
		System.out.println("It's starting to come back to you now. The energy crisis which drove you to join up with the Space Defense Corps in the first place. The discovery of HEF-3575 and its output of the impossible isotope, He-14. How they started calling the distant star Hephaestus, after the Greek god of Fire. The shuttle Prometheus and its mission Stolen Fire to take the secret of this untapped energy source from HEF. Your crew members, Hernandez, Emal, and Liu. Your high-orbit low-thrust escape from the Mars colony, the 5 years you spent together in FTL travel, Emal's careful, almost beautiful orchestration of your orbit around the White Giant. These things come back to you in the fuzzy way a dream comes back to you the next day, or the day after. Beyond that, everything is black. You have no recollection of the crisis, what happened to the crew, or even where the shuttle is now.\n\n\nWhat are you going to do next?\n");
	}
}