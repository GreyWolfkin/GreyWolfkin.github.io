class Player{
	
	//g = GoTo. Determines where the character is in the story.
	//t = Time. Must accomplish goals before t >= X or cannot achieve win condition.
	//m = Memory. Unlocks certain dialogue options.
	private int g, t, m;
	
	//Flags used to determine which dialogue options are available.
	private boolean lookAround, shuttle, alim, whoAmI, whereCrew, alimError, whatHap, whatMiss, damRep;
	
	Player() {
		this.g = 0;
		this.t = 0;
		this.m = 0;
		this.lookAround = false;
		this.shuttle = false;
		this.alim = false;
		this.whoAmI = false;
		this.whereCrew = false;
		this.alimError = false;
		this.whatHap = false;
		this.whatMiss = false;
		this.damRep = false;
	}
	
	public int getG() {
		return g;
	}
	public void setG(int g) {
		this.g = g;
	}
	
	public int getT() {
		return t;
	}
	public void setT(int set) {
		this.t = set;
	}
	public void incT(int inc) {
		this.t += inc;
	}
	public void decT(int dec) {
		this.t -= dec;
	}
	
	public int getM() {
		return m;
	}
	public void setM(int set) {
		this.m = set;
	}
	public void incM(int inc) {
		this.m += inc;
	}
	public void decM(int dec) {
		this.m -= dec;
	}
	
	public boolean getLookAround() {
		return lookAround;
	}
	public void setLookAround(boolean set) {
		this.lookAround = set;
	}
	
	public boolean getShuttle() {
		return shuttle;
	}
	public void setShuttle(boolean set) {
		this.shuttle = set;
	}
	
	public boolean getAlim() {
		return alim;
	}
	public void setAlim(boolean set) {
		this.alim = set;
	}
	
	public boolean getWhoAmI() {
		return whoAmI;
	}
	public void setWhoAmI(boolean set) {
		this.whoAmI = set;
	}
	
	public boolean getWhereCrew() {
		return whereCrew;
	}
	public void setWhereCrew(boolean set) {
		this.whereCrew = set;
	}
	
	public boolean getAlimError() {
		return alimError;
	}
	public void setAlimError(boolean set) {
		this.alimError = set;
	}
	
	public boolean getWhatHap() {
		return whatHap;
	}
	public void setWhatHap(boolean set) {
		this.whatHap = set;
	}
	
	public boolean getWhatMiss() {
		return whatMiss;
	}
	public void setWhatMiss(boolean set) {
		this.whatMiss = set;
	}
	
	public boolean getDamRep() {
		return damRep;
	}
	public void setDamRep(boolean set) {
		this.damRep = set;
	}
}