/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

class ALIM{
	
	//op = Opinion. Must be >= X for win condition. If it falls below Y, lose condition.
	private int op;
	
	ALIM() {
		this.op = 0;
	}
	
	public int getOp() {
		return op;
	}
	public void setOp(int set) {
		this.op = set;
	}
	public void incOp(int inc) {
		this.op += inc;
	}
	public void decOp(int dec) {
		this.op -= dec;
	}
}