class ALIM{
	
	//op = Opinion. Must be >= X for win condition. If it falls below Y, lose condition.
	private int op;
	
	ALIM() {
		this.op = 0;
	}
	
	public int getOp() {
		return op;
	}
	public void setOp(int set) {
		this.op = set;
	}
	public void incOp(int inc) {
		this.op += inc;
	}
	public void decOp(int dec) {
		this.op -= dec;
	}
}