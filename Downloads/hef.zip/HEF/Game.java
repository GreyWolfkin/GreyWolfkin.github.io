/*****
 * COPYRIGHT Joshua Caredig 2/1/2021
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose except by the copyright holder
 *****/

/******
 * This program is a demo / proof-of-concept for a Choose Your Own Adventure style sci-fi game.
 * The player wakes up alone and in the command module of a space shuttle, suffering from short-term memory loss.
 * It quickly becomes apparent that something has gone very wrong.
 * The player's only source of information is an AI called Alim.
 * Through asking Alim questions about who you are, the mission of your vessel, and the locations of the missing crew members,
 * the player must piece together what happened and what to do next.
 * 
 * In the demo, the player is forced to go through all of the dialogue options in order to progress.
 * In the final product, the player will have more agency about what to ask and when. The more questions the player asks,
 * the more information they have to work with, but an unseen clock is ticking down until it's too late to save yourself.
 *
 * The main drivers of the program are integer g and method listen().
 *
 * g is a variable of the Player class. g stands for GoTo, which is updated whenever the player makes a choice.
 * Say the player has a choice between A and B. In a Choose Your Own Adventure book, it would say something like
 * "If you choose A, go to page 101. If you choose B, go to page 29."
 * g functions much the same way, telling the program to "go" to a section based on player choice.
 * In the demo, most choices loop back to g=2 as that is the primary section for dialogue options.
 * In the finished product, there will be many more options for g, based on player choices.
 *
 * listen() uses g in a switch function. Based on the value of g, listen() calls a particular print method and calls a particular
 * choice method based on where the player is in the program.
 * The choice methods call inputInt() which takes an integer as input and passes it back to the choice method.
 * The choice method then uses that integer to determine what the player wants to do.
 *
 * The player's input for a given choice method affect variables, such as (t)ime, (m)emory, and (a)lim's opinion. Input also affects
 * g, which is then used by listen() to determine the next print and choice methods.
 ******/

import java.util.*;

public class Game{
	
	static Scanner scan = new Scanner(System.in);
	
	static boolean run = true;
	
	static Player p = new Player();
	static ALIM a = new ALIM();
	static Handler handle = new Handler(p, a);
	
	public static void main(String[] args) {
		
		while(run) {
			listen();
		}

	}
	
	//Tries to take an integer for player input. In case of InputMismatchException, clears the Scanner and returns 0.
	static int inputInt() {
		int i = 0;
		try {
			i = scan.nextInt();
		} catch(InputMismatchException ex) {
			scan.nextLine();
		}
		return i;
	}
	
	/******
	 * listen() is one of the primary drivers of the program.
	 * Using a switch statement for integer g, determines where the player is in the program
	 * and calls p#() and c#() accordingly.
	 * Also checks if m has reached a value of 8. Once m reaches or exceeds 8, immediately goes to
	 * win condition for demo.
	 ******/
	static void listen() {
		
		int input = 0;
		
		switch(p.getG()) {
			case 0:
				handle.p0();
				input = inputInt();
				handle.c0(input);
				break;
			case 1:
				handle.p1();
				input = inputInt();
				handle.c1(input);
				break;
			case 2:
				handle.p2();
				input = inputInt();
				handle.c2(input);
				break;
			case 3:
				handle.p3();
				if (p.getM() < 8) {
					p.setG(2);
				} else {
					p.setG(11);
				}
				break;
			case 4:
				handle.p4();
				if (p.getM() < 8) {
					p.setG(2);
				} else {
					p.setG(11);
				}
				break;
			case 5:
				handle.p5();
				if (p.getM() < 8) {
					p.setG(2);
				} else {
					p.setG(11);
				}
				break;
			case 6:
				handle.p6();
				if (p.getM() < 8) {
					p.setG(2);
				} else {
					p.setG(11);
				}
				break;
			case 7:
				handle.p7();
				if (p.getM() < 8) {
					p.setG(2);
				} else {
					p.setG(11);
				}
				break;
			case 8:
				handle.p8();
				if (p.getM() < 8) {
					p.setG(2);
				} else {
					p.setG(11);
				}
				break;
			case 9:
				handle.p9();
				if (p.getM() < 8) {
					p.setG(2);
				} else {
					p.setG(11);
				}
				break;
			case 10:
				handle.p10();
				if (p.getM() < 8) {
					p.setG(2);
				} else {
					p.setG(11);
				}
				break;
			case 11:
				handle.p11();
				run = false;
				break;
		}
	}
}