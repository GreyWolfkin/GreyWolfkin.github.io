/******
 * This program is a demo / proof-of-concept for a Choose Your Own Adventure style sci-fi game.
 * The player wakes up alone and in the command module of a space shuttle, suffering from short-term memory loss.
 * It quickly becomes apparent that something has gone very wrong.
 * The player's only source of information is an AI called Alim.
 * Through asking Alim questions about who you are, the mission of your vessel, and the locations of the missing crew members,
 * the player must piece together what happened and what to do next.
 * 
 * In the demo, the player is forced to go through most (but not all) of the dialogue options in order to progress.
 * In the final product, the player will have more agency about what to ask and when. The more questions the player asks,
 * the more information they have to work with, but an unseen clock is ticking down until it's too late to save yourself.
 *
 * The demo is entirely contained within class Demo. Demo2 will be the same chunk of the story, but updated with classes
 * for code reusability.
 *
 * The main drivers of the program are String g and method listen().
 *
 * g stands for GoTo, which is updated whenever the player makes a choice.
 * Say the player has a choice between A and B. In a Choose Your Own Adventure book, it would say something like
 * "If you choose A, go to page 101. If you choose B, go to page 29."
 * g functions much the same way, telling the program to "go" to a section based on player choice.
 * In the demo, most choices loop back to g="1b" as that is the primary section for dialogue options.
 * In the finished product, there will be many more options for g, based on player choices.
 *
 * listen() uses g in a switch function. Based on the value of g, listen() calls a particular print method and calls a particular
 * choice method based on where the player is in the program.
 * The choice methods call inputInt() which takes an integer as input and passes it back to the choice method.
 * The choice method then uses that integer to determine what the player wants to do.
 *
 * The player's input for a given choice method affect variables, such as (t)ime, (m)emory, and (a)lim's mood. Input also affects
 * g, which is then used by listen() to determine the next print and choice methods.
 ******/

import java.util.*;

public class Game{
	
	static Scanner scan = new Scanner(System.in);
	static boolean run = true;
	
	//Flags used to determine which dialogue options are available.
	static boolean lookAround, shuttle, alim, whoAmI, whereCrew, alimError, whatHap, whatMiss, damRep;
	
	//Time. Must accomplish goals before t >= X or the shuttle can't escape HEF's gravity.
	static int t = 0; 
	//Memory. Unlocks certain dialogue options.
	static int m = 0; 
	//ALIM's opinion. Must be >= X for win condition. If it falls below Y, lose condition.
	static int a = 0; 
	//GoTo. Determines where the character is in the story.
	static String g = "0"; 
	
	//Stores Strings which are referenced by choice1b().
	static ArrayList<String> opt1b = new ArrayList<String>();
	
	//Turns on and off certain displays. Turned on by entering "1009" for any input.
	static boolean debug = false; 
	
	static void pause() {
		scan.nextLine();
	}
	
	static void ln() {
		System.out.println();
	}
	
	//Tries to take an integer for player input. Catches InputMismatchException, clears the Scanner, and returns 0.
	static int inputInt() {
		if (debug) {
			System.out.println("inputInt()");
		}
		int i = 0;
			try {
				i = scan.nextInt();
			} catch (InputMismatchException ex) {
				scan.nextLine();
			}
			if (i == 1009) {
				if(debug) {
					debug = false;
				} else {
					debug = true;
				}
			}
		if (debug) {
			System.out.println("inputInt() returning " + i);
		}
		return i;
	}
	
	/******
	 * PRINT METHODS
	 * String "g" determines where player is in the story.
	 * Depending on where the player is and what choices are made,
	 * prints the necessary dialogue and/or narrative.
	 ******/
	
	static void print0() {
		if (debug) {
			System.out.println("print0()");
		}
		System.out.println("You wake up groggy. Your head is throbbing and your throat feels dry.\nYour vision is blurry, but slowly your surroundings come into focus.\nYou are in a room lit by soft, comfortable light. The walls and consoles are hospital-white, and black screens cover most of every surface.\nWhere large, bay windows should be there are thick, segmented metal plates.\nYou groan softly. \"My head...\" you whisper.\nA large console on the right wall flashes to life and white, block letters apear on the screen.\nPLEASE BE CAUTIOUS. VITAL SIGNS INDICATE YOU HAVE BEEN UNCONSCIOUS FOR [15 HOURS]. HEAD TRAUMA IS HIGHLY PROBABLE_\n");
	}
	
	static void print1a() {
		if (debug) {
			System.out.println("print1a()");
		}
		System.out.println("You clear your throat, wincing at the pain it causes.\nYou lean towards the console and speak clearly:\n");
	}
	
	// When the player chooses "Look Around", print2(). print2() changes based on what the player has already seen or learned.
	// For example, if the player has already asked about what happened to the shuttle, looking around will reference
	// what the player learned about the solar flare. If the player has not asked about what happened, looking around
	// will suggest a technical failure, but not reference the flare.
	static void print2() {
		if (debug) {
			System.out.println("print2()");
		}
		System.out.println("You look around, still trying to clear your head.");
		if (shuttle) {
			System.out.println("The Command Module is deathly silent.");
		} else {
			System.out.println("This room looks right out of a textbook on Deep-Space travel. You are in what appears to be the Command Module.");
		}
		if (alim) {
			System.out.println("ALIM sits on the wall, his output dash blinking as he dutifully waits for your next query.");
		} else {
			System.out.println("The screen, which previously told you about your probable head trauma, now sits blank except for an output dash that blinks slowly in the top-left corner.");
		}
		if (whereCrew) {
			System.out.println("The empty chairs stare back at you, daring you to find the other three crew members.");
		} else {
			System.out.println("You realize this must have been a four-person crew, based on the number of chairs and consoles stationed on deck.");
		}
		if (whatHap) {
			System.out.println("You look at the blast shields and dark consoles and shudder. ALIM said there had been a solar flare? What kind of flare could do this much damage?");
		} else {
			System.out.println("The blast shields and dark consoles make you think there must have been a technical failure at some point.");
		}
		System.out.println();
	}
	
	static void print3() {
		if (debug) {
			System.out.println("print3()");
		}
		System.out.println("You look around the unfamiliar room.\n\"Where am I?\"\nThe blinking line disappears for the briefest of moments before text begins to appear.\nYOU ARE IN THE COMMAND MODULE OF DEEP-SPACE EXPLORATION AND RECONNAISSANCE SHUTTLE CODENAME PROMETHEUS_\n");
	}
	
	static void print4() {
		if (debug) {
			System.out.println("print4()");
		}
		System.out.println("\"What are you? State your rank and designation.\"\nI AM THIS SHUTTLE'S ONBOARD ARTIFICIAL INTELLIGENCE: MKII AUTONOMOUS LEARNING INTEGRATED MODULE. PLEASE CALL ME ALIM.\nARTIFICIAL INTELLIGENCE ARE NOT ASSIGNED RANK IN THE SPACE DEFENSE CORPS, THOUGH MY PROGRAMMING REQUIRES THAT I OBEY THE ORDERS OF EVERY OFFICER ABOARD THE SHUTTLE, WHICH WOULD SUGGEST THAT MY RANK IS ENSIGN_\n");
	}
	
	static void print5() {
		if (debug) {
			System.out.println("print5()");
		}
		System.out.println("You decide to ask the most pressing question at hand.\n\"Who am I? Name, rank, and crew bio.\"\nNAME: JANE DAWTHORN\nRANK: COMMANDING OFFICER, DEEP-SPACE MISSION CODENAME \"STOLEN FIRE\"\nBIO: YOUNGEST FEMALE LIEUTENANT COMMANDER IN THE SDC. BORN 2301. DAUGHTER OF DISTINGUISHED [REDACTED - SPECIAL] AND [REDACTED]. GRADUATED 3RD IN CLASS, MOON-BASE FOXTROT NAVAL ACADEMY. GRADUATED WITH SPECIAL HONORS, JUPITER OFFICER TERTIARY TRAINING FACILITY. SERVED UNDER [REDACTED] DURING [REDACTED - SPECIAL]. PROMOTED TO LIEUTENANT COMMANDER IN 2326 FOR DISTINGUISHED AND SUPERIOR PERFORMANCE IN MULTIPLE THEATERS_\n");
	}
	
	// Similarly to print2(), print6() changes based on what the character has already seen/determined.
	static void print6() {
		if (debug) {
			System.out.println("print6()");
		}
		if (lookAround) {
			System.out.println("There were three other crew members aboard. You'll have to find out what happened to them.");
		} else {
			System.out.println("You can't have been the only person onboard.");
		}
		System.out.println("\"Where is everyone else?\"\nAPOLOGIES, BUT THE LOCATIONS OF [ERROR], [ERROR], AND [ERROR] ARE PRESENTLY UNKNOWN_\n");
	}
	
	static void print7() {
		if (debug) {
			System.out.println("print7()");
		}
		System.out.println("You don't like the look of the blast shields and all those dark consoles.\n\"What happened here?\"\nCATASTROPHIC EQUIPMENT FAILURE CAUSED BY SOLAR FLARE EXCEEDING [ERROR] [ERROR]_\n");
	}
	
	static void print8() {
		if (debug) {
			System.out.println("print8()");
		}
		System.out.println("\"What was the mission of this vessel?\"\nBRAVO-ALPHA SECURITY CLEARANCE REQUIRED. INITIATING SECURITY CHECK_\nSECURITY GREEN LIT. ACCESSING MISSION BRIEFING_\nMISSION BRIEFING \"STOLEN FIRE\": 12-YEAR DEEP-SPACE SCIENTIFIC MISSION. DESIG CRITICAL. DEEP-SPACE SHUTTLE PROMETHEUS TO REACH WHITE GIANT STAR HEF-3575 IN 5 YEARS, SUSPENDED ANIMATION FOR CREW NOT REQUIRED. SPEND 2 YEARS IN STABLE ORBIT AROUND HEF-3575. DURING ORBIT, RESEARCH ISOTOPE HE-14. PROMETHEUS TO RETURN TO SCIENTIFIC STATION ECHO-ECHO-CHARLIE TO REPORT FINDINGS_\n");
	}
	
	static void print9() {
		if (debug) {
			System.out.println("print9()");
		}
		System.out.println("\"Damage report.\"\nMULTIPLE LIFE SUPPORT FUNCTIONS DAMAGED.\nMULTIPLE LIFE SUPPORT FUNCTIONS INOPERABLE.\nMULTIPLE VITAL FUNCTIONS DAMAGED.\nMULTIPLE VITAL FUNCTIONS INOPERABLE\nMULTIPLE SECONDARY FUNCTIONS DAMAGED.\nMULTIPLE SECONDARY FUNCTIONS INOPERABLE.\nALL TERTIARY FUNCTIONS INOPERABLE_\n\n\"Give me more details.\"\nLIFE SUPPORT FUNCTIONS:\nPRIMARY O2 SCRUB (DAMAGED)\nSECONDARY O2 SCRUB (DAMAGED)\nPRIMARY H2O REPLICATION (OPERATIONAL)\nSECONDARY H20 REPLICATION (INOPERABLE)\nPRIMARY NUTRITION REPLICATION (INOPERABLE)\nSECONDARY NUTRITION REPLICATION (INOPERABLE)\nPRIMARY HEATER (DAMAGED)\nSECONDARY HEATER (INOPERABLE)\nPRIMARY WASTE DISPOSAL (OPERATIONAL)\nSECONDARY WASTE DISPOSAL (DAMAGED)\n\nVITAL FUNCTIONS:\nFTL THRUSTERS (INOPERABLE)\nPRIMARY RADIATION SHIELDS (DAMAGED)\nPRIMARY ELECTROMAGNETIC SHIELDS (DAMAGED)\nPRIMARY KINETIC SHIELDS (INOPERABLE)\nMULTI-PERSONNEL SUB-LIGHT ESCAPE UNIT (INOPERABLE)\n\nSECONDARY FUNCTIONS:\nSUB-LIGHT THRUSTERS (INOPERABLE)\nLIGHT-DISTANCE COMM SYS (INOPERABLE)\nARTIFICIAL LEARNING INTEGRATED MODULE (DAMAGED)\nSUSPENDED ANIMATION CONTAINMENT (DAMAGED)\nSECONDARY RADIATION SHIELDS (OPERATIONAL)\nSECONDARY ELECTROMAGNETIC SHIELDS (INOPERABLE)\nSECONDARY KINETIC SHIELDS (DAMAGED)\n\nTERTIARY FUNCTIONS:\nALL TERTIARY FUNCTIONS (INOPERABLE)_\n");
	}
	
	// print10() is effectively the win screen for the demo. Once the player's m value reaches 6, print10() reveals more information about
	// the story and ends the demo.
	static void print10() {
		if (debug) {
			System.out.println("print10()");
		}
		System.out.println("It's starting to come back to you now. The energy crisis which drove you to join up with the Space Defense Corps in the first place. The discovery of HEF-3575 and its output of the impossible isotope, He-14. How they started calling the distant star Hephaestus, after the Greek god of Fire. The shuttle Prometheus and its mission Stolen Fire to take the secret of this untapped energy source from HEF. Your crew members, Hernandez, Emal, and Liu. Your high-orbit low-thrust escape from the Mars colony, the 5 years you spent together in FTL travel, Emal's careful, almost beautiful orchestration of your orbit around the White Giant. These things come back to you in the fuzzy way a dream comes back to you the next day, or the day after. Beyond that, everything is black. You have no recollection of the crisis, what happened to the crew, or even where the shuttle is now.\n\n\nWhat are you going to do next?\n");
	}
	 
	/******
	 * CHOICE METHODS
	 * For Demo, only three choice methods exist.
	 * Each choice affects variables such as Time, Memory, and Alim.
	 * Each choice also changes g to a new value, which allows the correct print method to be called.
	 ******/
	
	/*
	 First choice player makes. Speak Into Console or Look Around.
	 For choice0, Speak Into Console sets g=1a, which prints a sentence unique to that area.
	 Following choice0, options to speak into console set g=1b.
	*/
	static void choice0() {
		if (debug) {
			System.out.println("choice0()");
		}
		System.out.println("1 - Speak into the console");
		System.out.println("2 - Look around some more");
		int input = inputInt(); //Get input as integer from player, return 0 if input is non-integer
		switch(input) {
			case 1:
				t++; //Time increases by 1
				g = "1a"; //GoTo 1a
				break;
			case 2:
				t++; //Time increases by 1
				m++; //Memory increases by 1
				lookAround = true; //Flags "lookAround", to prevent that option from appearing later
				g = "2"; //GoTo 2
				break;
			default:
				System.out.println("Unrecognized input");
				break;
		}
	}
	
	//If player chooses to speak into the console first, choice1a is called. Otherwise choice1b is called.
	static void choice1a() {
		if (debug) {
			System.out.println("choice1a()");
		}
		System.out.println("1 - \"Where am I?\"");
		System.out.println("2 - \"What are you?\"");
		if (m >= 1) {
			System.out.println("3 - \"Who am I?\"");
			System.out.println("4 - \"Where is everyone else?\"");
			System.out.println("5 - \"What happened here?\"");
		}
		int input = inputInt(); //Get input as integer from player, return 0 if input is non-integer
		switch(input) {
			case 1:
				m++; //Memory increases by 1
				shuttle = true; //Flags "shuttle"
				g = "3"; //GoTo 3
				break;
			case 2:
				alim = true; //Flags "alim"
				g = "4"; //GoTo 4
				break;
			case 3:
				//Checks if player has chosen LookAround and subsequently gained a point of memory
				if (m >= 1) {
					m++; //Memory increases by 1
					whoAmI = true; //Flags "whoAmI"
					g = "5"; //GoTo 5
				} else {
					//If player has not gained a point of memory, does not allow input = 3
					System.out.println("Unrecognized input");
				}
				break;
			case 4:
				//Checks if player has a point of memory
				if (m >= 1) {
					whereCrew = true; //Flags whereCrew
					alimError = true; //Flags alimError
					g = "6"; //GoTo 6
				} else {
					//If player does not have m >= 1, does not allow input = 4
					System.out.println("Unrecognized input");
				}
				break;
			case 5:
				if (m >= 1) {
					m++; //Memory increases by 1
					whatHap = true; //Flags whatHap
					g = "7"; //GoTo 7
				} else {
					//If player does not have m >= 1, does not allow input = 5
					System.out.println("Unrecognized input");
				}
				break;
			default:
				System.out.println("Unrecognized input");
				break;
		}
	}
	
	/******
	 * choice1b is the most frequently called method in Demo.
	 * First, choice1b clears ArrayList<String> opt1b. This ensures that when choice1b is called more than once,
	 * opt1b is always clean and ready to be updated.
	 * choice1b then adds Strings to opt1b, depending on which booleans are true or false.
	 * For each boolean that is false, choice1b adds that String to opt1b.
	 * For certain choices, choice1b also checks for memory value, and whether or not player has already
	 * chosen certain dialogue options.
	 *
	 * For example, the player cannot ask for a Damage Report until they have asked What Happened.
	 *
	 * After adding all valid options to opt1b, choice1b prints the players options as
	 * 1 - [String at index 0]
	 * 2 - [String at index 1]
	 * etc. 
	 *
	 * Integer input then takes the player's input and subtracts 1. String h is then assigned the value
	 * of opt1b.get(input), so if player inputs "1", String h is the String at index 0.
	 * A switch method then checks String h against all possible Strings which could be in opt1b.
	 * if {} else {"Unrecognized input"}; checks are not necessary in switch(h) because a try{}catch{} method
	 * checks int input against opt1b, and catches IndexOutOfBoundsException. If a player inputs a value which is
	 * outside the bounds of the array, h = "". If a player inputs a valid integer, h takes the String at the correct index,
	 * preventing any unwanted inputs.
	 ******/
	static void choice1b() {
		if (debug) {
			System.out.println("choice1b()");
		}
		if (debug) {
			System.out.println("opt1b.clear()");
		}
		opt1b.clear();
		if (debug) {
			System.out.println("opt1b.add()");
		}
		if (!lookAround) {
			opt1b.add("Look around some more");
		}
		if (!shuttle) {
			opt1b.add("\"Where am I?\"");
		}
		if (!alim) {
			opt1b.add("\"What are you?\"");
		}
		if ((m >= 1) && (!whoAmI)) {
			opt1b.add("\"Who am I?\"");
		}
		if ((m >= 1) && (!whereCrew)) {
			opt1b.add("\"Where is everyone else?\"");
		}
		if ((m >= 1) && (!whatHap)) {
			opt1b.add("\"What happened here?\"");
		}
		if ((m >= 2) && (!whatMiss)) {
			opt1b.add("\"What was the mission?\"");
		}
		if ((whatHap) && (!damRep)) {
			opt1b.add("\"Damage report.\"");
		}
		if (debug) {
			System.out.println("int i = 1");
		}
		int i = 1;
		if (debug) {
			System.out.println("String h = \"\"");
		}
		String h = "";
		if (debug) {
			System.out.println("for (String j : opt1b)");
		}
		for (String j : opt1b) {
			System.out.println(i + " - " + j);
			i++;
		}
		if (debug) {
			System.out.println("int input = inputInt() - 1");
		}
		
		// Get input as integer from player, return 0 if input is non-integer
		// Subtracts 1 from input so that input can be used to reference index of opt1b.
		// Thus input 1 will reference the first String, index 0, of opt1b.
		int input = inputInt() - 1;
		if (debug) {
			System.out.println("try {}");
		}
		try {
			if (debug) {
			System.out.println("try success. h = opt1b.get(input)");
			}
			h = opt1b.get(input);
		} catch (IndexOutOfBoundsException ex) {
			if (debug) {
			System.out.println("try fail. Catch IndexOutOfBoundsException. h = \"\"");
			}
			h = "";
		}
		if (debug) {
			System.out.println("switch(h)");
		}
		switch(h) {
			case "Look around some more":
				if (debug) {
					System.out.println("case; \"Look around some more\"");
				}
				t++;
				m++;
				lookAround = true;
				g = "2";
				break;
			case "\"Where am I?\"":
				if (debug) {
					System.out.println("case: \"Where am I?\"");
				}
				m++;
				shuttle = true;
				g = "3";
				break;
			case "\"What are you?\"":
				if (debug) {
					System.out.println("case: \"What are you?\"");
				}
				alim = true;
				g = "4";
				break;
			case "\"Who am I?\"":
				if (debug) {
					System.out.println("case: \"Who am I?\"");
				}
				m++;
				whoAmI = true;
				g = "5";
				break;
			case "\"Where is everyone else?\"":
				if (debug) {
					System.out.println("case: \"Where is everyone else?\"");
				}
				whereCrew = true;
				alimError = true;
				g = "6";
				break;
			case "\"What happened here?\"":
				if (debug) {
					System.out.println("case: \"What happened here?\"");
				}
				m++;
				whatHap = true;
				g = "7";
				break;
			case "\"What was the mission?\"":
				if (debug) {
					System.out.println("case: \"What was the mission?\"");
				}
				m += 2;
				shuttle = true;
				whatMiss = true;
				g = "8";
				break;
			case "\"Damage report.\"":
				if (debug) {
					System.out.println("case: \"Damage report.\"");
				}
				m++;
				alimError = true;
				damRep = true;
				g = "9";
				break;
			default:
				if (debug) {
					System.out.println("default:");
				}
				System.out.println("Unrecognized input");
				break;
		}
	}
	
	/******
	 * listen() is one of the primary drivers of the program.
	 * Using a switch statement for String g, determines where the player is in the program
	 * and calls printX() and choiceX() accordingly.
	 * Also checks if m has reached a value of 6. Once m reaches or exceeds 6, immediately goes to
	 * win condition for demo.
	 ******/
	static void listen() {
		if (debug) {
			System.out.println("listen()");
		}
		switch(g) {
			case "0":
				print0();
				choice0();
				break;
			case "1a":
				print1a();
				choice1a();
				break;
			case "1b":
				choice1b();
				break;
			case "2":
				print2();
				if (m < 6) {
					g = "1b";
				} else {
					g = "10";
				}
				break;
			case "3":
				print3();
				if (m < 6) {
					g = "1b";
				} else {
					g = "10";
				}
				break;
			case "4":
				print4();
				if (m < 6) {
					g = "1b";
				} else {
					g = "10";
				}
				break;
			case "5":
				print5();
				if (m < 6) {
					g = "1b";
				} else {
					g = "10";
				}
				break;
			case "6":
				print6();
				if (m < 6) {
					g = "1b";
				} else {
					g = "10";
				}
				break;
			case "7":
				print7();
				if (m < 6) {
					g = "1b";
				} else {
					g = "10";
				}
				break;
			case "8":
				print8();
				if (m < 6) {
					g = "1b";
				} else {
					g = "10";
				}
				break;
			case "9":
				print9();
				if (m < 6) {
					g = "1b";
				} else {
					g = "10";
				}
				break;
			case "10":
				print10();
				run = false;
				break;
		}
	}
	
	public static void main(String[] args) {
		
		while(run) {
			if (debug) {
			System.out.println("Current Memory value: " + m);
			}
			listen();
		}
		
	}
}