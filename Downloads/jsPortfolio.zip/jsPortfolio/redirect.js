function rpgTest() {
	window.location = "rpgTest.html";
}

function escapeTest() {
	window.location = "escapeTest.html";
}

function portfolio() {
	window.location = "portfolio.html";
}

function goToIndex() {
	window.location = "index.html";
}