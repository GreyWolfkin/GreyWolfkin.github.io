/*****
 * COPYRIGHT Joshua Supelana-Mix 11/8/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 *****/

/*****
 * dbEmployee v1.0
 * Keeps company records of Employees and Departments
 * Uses ArrayList<Obj> for flexibility
 * Creates txt files EmployeeDirectory and
 *	DepartmentDirectory for archiving and recovery
 *	of saved changes
 *****/

import java.util.*;
import java.io.*;

public class dbEmployee {
	
	// Uses input_utils v1.0 for all User Input
	static input_utils in = new input_utils();
	
	static void addEmployee(ArrayList<Employee> employees, ArrayList<Department> departments) {
		String userIn, nameIn, deptIn;
		double salaryIn;
		nameIn = in.get("Employee Name: ");
		deptIn = getAndConfirmDept(departments);
		salaryIn = getAndConfirmSalary(deptIn, departments);
		Employee e = new Employee(nameIn, deptIn, salaryIn);
		employees.add(e);
	}
	
	// Checks if department exists in ArrayList of departments
	//	and asks for confirmation if the department does not exist
	static String getAndConfirmDept(ArrayList<Department> departments) {
		String deptIn;
		int index, intIn;
		while(true) {
			deptIn = in.get("Employee Department: ");
			index = indexOfDept(deptIn, departments);
			if(index != -1) {
				// index != -1 means department exists in ArrayList of departments
				return deptIn;
			} else {
				System.out.println("Department " + deptIn + " does not exist in list of Departments.");
				intIn = in.getInt("Confirm Employee Department?\n1 - Yes\n2 - No\n", 1, 2);
				if(intIn == 1) {
					return deptIn;
				} // else: continue loop
			}
		}
	}
	
	// Returns index of department in ArrayList, or -1 if no match
	static int indexOfDept(String deptIn, ArrayList<Department> departments) {
		for(int i = 0; i < departments.size(); i++) {
			if(deptIn.equals(departments.get(i).getName())) {
				return i;
			}
		}
		return -1;
	}
	
	
	// If department exists, checks that salary is not less than base pay
	//	and asks for confirmation if it is
	static double getAndConfirmSalary(String deptIn, ArrayList<Department> departments) {
		double salaryIn;
		int index, intIn;
		while(true) {
			salaryIn = in.getDouble("Employee Salary: ");
			index = indexOfDept(deptIn, departments);
			if(index != -1) {
				// index != -1 means that department exists in ArrayList of departments
				if(salaryIn < departments.get(index).getBasePay()) {
					System.out.println("Employee Salary is less than " + deptIn + " base pay.");
					intIn = in.getInt("Confirm employee salary?\n1 - Yes\n2 - No\n", 1, 2);
					if(intIn == 1) {
						return salaryIn;
					} // else: continue loop
				} else {
					// Salary is equal-to or greater-than department base pay
					return salaryIn;
				}
			} else {
				// index == -1 means that department does not exist
				return salaryIn;
			}
		}
	}
	
	static void viewEmployees(ArrayList<Employee> employees) {
		System.out.println("EMPLOYEES");
		System.out.println("---------");
		for(Employee employee:employees) {
			System.out.println(employee.getName() + "\n" + employee.getDept() + "\n$" + employee.getSalary());
			System.out.println("---------");
		}
	}
	static void modifyEmployee(ArrayList<Employee> employees, ArrayList<Department> departments) {
		int intIn;
		System.out.println("Modify which employee?");
		for(int i = 1; i <= employees.size(); i++) {
			System.out.println(i + " - " + employees.get(i-1).getName());
		}
		// Accepts only input between 1 and size of ArrayList
		intIn = in.getInt("", 1, employees.size());
		// Turns user input into index of ArrayList
		Employee chosenEmployee = employees.get(intIn - 1);
		System.out.println(chosenEmployee.getName() + "\n" + chosenEmployee.getDept() + "\n" + chosenEmployee.getSalary() + "\n");
		intIn = in.getInt("Modify what?\n1 - Name\n2 - Department\n3 - Salary\n", 1, 3);
		switch(intIn) {
			case 1:
				String nameIn = in.get("Employee Name: ");
				chosenEmployee.setName(nameIn);
				break;
			case 2:
				String deptIn = getAndConfirmDept(departments);
				chosenEmployee.setDept(deptIn);
				break;
			case 3:
				double salaryIn = getAndConfirmSalary(chosenEmployee.getDept(), departments);
				chosenEmployee.setSalary(salaryIn);
				break;
		}
	}
	
	static void removeEmployee(ArrayList<Employee> employees) {
		int intIn;
		System.out.println("Remove which employee?");
		for(int i = 1; i <= employees.size(); i++) {
			System.out.println(i + " - " + employees.get(i-1).getName());
		}
		intIn = in.getInt("", 1, employees.size());
		Employee chosenEmployee = employees.get(intIn - 1);
		intIn = in.getInt("Remove Employee " + chosenEmployee.getName() + "?\n1 - Yes\n2 - No\n", 1, 2);
		if(intIn == 1) {
			employees.remove(chosenEmployee);
		}
	}
	
	static void addDepartment(ArrayList<Department> departments) {
		String nameIn, descIn;
		int index;
		double basePayIn;
		nameIn = in.get("Department Name: ");
		if(indexOfDept(nameIn, departments) == -1) {
			// Return of -1 means department does not exist in ArrayList
			descIn = in.get("Department Description: ");
			basePayIn = in.getDouble("Department Base Pay: ");
			Department d = new Department(nameIn, descIn, basePayIn);
			departments.add(d);
		} else {
			System.out.println("Department " + nameIn + " already exists.");
		}
	}
	static void viewDepartments(ArrayList<Department> departments) {
		System.out.println("DEPARTMENTS");
		System.out.println("-----------");
		for(Department department:departments) {
			System.out.println(department.getName());
			System.out.println(department.getDesc());
			System.out.println("Number of Employees: " + department.getNumEmployees());
			System.out.println("Department Base Pay: " + department.getBasePay());
			System.out.println("-----------");
		}
	}
	static void modifyDepartment(ArrayList<Department> departments) {
		int intIn;
		System.out.println("Modify which department?");
		for(int i = 1; i <= departments.size(); i++) {
			System.out.println(i + " - " + departments.get(i-1).getName());
		}
		// Accepts input between 1 and size of ArrayList
		intIn = in.getInt("", 1, departments.size());
		// Turns user input into index of ArrayList
		Department chosenDept = departments.get(intIn - 1);
		System.out.println(chosenDept.getName() + "\n" + chosenDept.getDesc() + "\nNumber of Employees: " + chosenDept.getNumEmployees() + "\n" + "Department Base Pay: " + chosenDept.getBasePay());
		intIn = in.getInt("Modify what?\n1 - Name\n2 - Description\n3 - Base Pay\n", 1, 3);
		switch(intIn) {
			case 1:
				String nameIn = in.get("Department Name: ");
				chosenDept.setName(nameIn);
				break;
			case 2:
				String descIn = in.get("Department Description: ");
				chosenDept.setDesc(descIn);
				break;
			case 3:
				double basePayIn = in.getDouble("Department Base Pay: ");
				chosenDept.setBasePay(basePayIn);
				break;
		}
	}
	static void removeDepartment(ArrayList<Department> departments) {
		int intIn;
		System.out.println("Remove which department?");
		for(int i = 1; i <= departments.size(); i++) {
			System.out.println(i + " - " + departments.get(i-1).getName());
		}
		intIn = in.getInt("", 1, departments.size());
		Department chosenDept = departments.get(intIn-1);
		intIn = in.getInt("Remove department " + chosenDept.getName() + "?\n1 - Yes\n2 - No\n", 1, 2);
		if(intIn == 1) {
			departments.remove(chosenDept);
		}
	}
	
	// Runs after every iteration of core loop. Checks and updates
	//	number of employees listed for each department
	static void updateNumEmployees(ArrayList<Employee> employees, ArrayList<Department> departments) {
		if(employees.size() > 0 && departments.size() > 0) {
			for(Department department:departments) {
				department.setNumEmployees(0);
				for(Employee employee:employees) {
					if(employee.getDept().equals(department.getName())) {
						department.adjNumEmployees(1);
					}
				}
			}
		}
	}
	
	// Loads data from EmployeeDirectory.txt and DepartmentDirectory.txt into
	//	ArrayLists
	static void readFiles(ArrayList<Employee> employees, ArrayList<Department> departments) throws IOException {
		FileReader employeeReader = new FileReader("EmployeeDirectory.txt");
		int i;
		String allFile = "";
		while((i = employeeReader.read()) != -1) {
			allFile += (char)i;
		}
		String[] splitFile = allFile.split("\\||\\n");
		for(int j = 0; j < splitFile.length; j += 3) {
			Employee e = new Employee(splitFile[j], splitFile[j+1], Double.parseDouble(splitFile[j+2]));
			employees.add(e);
		}
		employeeReader.close();
		FileReader deptReader = new FileReader("DepartmentDirectory.txt");
		allFile = "";
		while((i = deptReader.read()) != -1) {
			allFile += (char)i;
		}
		splitFile = allFile.split("\\||\\n");
		for(int j = 0; j < splitFile.length; j += 3) {
			Department d = new Department(splitFile[j], splitFile[j+1], Double.parseDouble(splitFile[j+2]));
			departments.add(d);
		}
		deptReader.close();
	}
	
	// Asks user to save changes
	static boolean saveChanges() {
		int intIn = in.getInt("Save changes to Directory?\n1 - Yes\n2 - No\n", 1, 2);
		if(intIn == 1) {
			return true;
		} else {
			return false;
		}
	}
	
	// Called if user confirms save changes.
	// Prevents ArrayIndexOutOfBoundsException by only creating Directory files if
	//	Employee or Department objects are present in ArrayLists
	static void writeFiles(ArrayList<Employee> employees, ArrayList<Department> departments) throws IOException {
		File employeeDirectory = new File("EmployeeDirectory.txt");
		employeeDirectory.delete(); // Deletes file if it exists, no return
		if(employees.size() > 0) {
			FileWriter employeeWriter = new FileWriter("EmployeeDirectory.txt");
			for(Employee employee:employees) {
				employeeWriter.write(employee.getName() + "|" + employee.getDept() + "|" + employee.getSalary() + "\n");
			}
			employeeWriter.close();
		}
		File deptDirectory = new File("DepartmentDirectory.txt");
		deptDirectory.delete(); // Deletes file if it exists, no return
		if(departments.size() > 0) {
			FileWriter deptWriter = new FileWriter("DepartmentDirectory.txt");
			for(Department department:departments) {
				deptWriter.write(department.getName() + "|" + department.getDesc() + "|" + department.getBasePay() + "\n");
			}
			deptWriter.close();
		}
	}
	
	public static void main(String[] args) {
		
		int intIn;
		
		ArrayList<Employee> employees = new ArrayList<Employee>();
		ArrayList<Department> departments = new ArrayList<Department>();
		
		// Title Screen
		System.out.println("dbEmployee v1.0\n\nAdd Employees and Departments, manipulate tables, and view or modify existing records.\nWrites to \"EmployeeDirectory.txt\" and \"DepartmentDirectory.txt\"\n\nPress <Enter> to begin.");
		// Wait for input
		in.get();
		
		// Checks for existing directories, writes to ArrayList if directories exist
		try {
			readFiles(employees, departments);
		} catch(IOException ex) {
			
		}
		// Core loop
		while(true) {
			updateNumEmployees(employees, departments);
			// Adjusts printed options based on whether any Employees or
			//	Departments are in given ArrayList
			if(employees.size() > 0 && departments.size() > 0) {
				intIn = in.getInt("1 - Add Employee\n2 - View Employees\n3 - Modify Employee\n4 - Remove Employee\n5 - Add Department\n6 - View Departments\n7 - Modify Department\n8 - Remove Department\n9 - Quit\n", 1, 9);
			} else if(employees.size() > 0) {
				intIn = in.getInt("1 - Add Employee\n2 - View Employees\n3 - Modify Employee\n4 - Remove Employee\n5 - Add Department\n6 - Quit\n", 1, 6);
			} else if(departments.size() > 0) {
				intIn = in.getInt("1 - Add Employee\n2 - Add Department\n3 - View Departments\n4 - Modify Department\n5 - Remove Department\n6 - Quit\n", 1, 6);
			} else {
				intIn = in.getInt("1 - Add Employee\n2 - Add Department\n3 - Quit\n", 1, 3);
			}
			// Changes which method is called based on which options are shown in previous screen
			switch(intIn) {
				case 1:
					addEmployee(employees, departments);
					break;
				case 2:
					if(employees.size() > 0) {
						viewEmployees(employees);
					} else {
						addDepartment(departments);
					}
					break;
				case 3:
					if(employees.size() > 0) {
						modifyEmployee(employees, departments);
					} else if(departments.size() > 0) {
						viewDepartments(departments);
					} else {
						if(saveChanges()) {
							try {
								writeFiles(employees, departments);
							} catch(IOException ex) {
								System.out.println("Error writing to file");
							}
							System.exit(0);
						} else {
							System.exit(0);
						}
					}
					break;
				case 4:
					if(employees.size() > 0) {
						removeEmployee(employees);
					} else {
						modifyDepartment(departments);
					}
					break;
				case 5:
					if(employees.size() > 0) {
						addDepartment(departments);
					} else {
						removeDepartment(departments);
					}
					break;
				case 6:
					if(employees.size() > 0 && departments.size() > 0) {
						viewDepartments(departments);
					} else {
						if(saveChanges()) {
							try {
								writeFiles(employees, departments);
							} catch(IOException ex) {
								System.out.println("Error writing to file");
							}
							System.exit(0);
						} else {
							System.exit(0);
						}
					}
					break;
				case 7:
					modifyDepartment(departments);
					break;
				case 8:
					removeDepartment(departments);
					break;
				case 9:
					if(saveChanges()) {
						try {
								writeFiles(employees, departments);
						} catch(IOException ex) {
							System.out.println("Error writing to file");
						}
						System.exit(0);
					} else {
						System.exit(0);
					}
					break;
			}
		}
	}
}