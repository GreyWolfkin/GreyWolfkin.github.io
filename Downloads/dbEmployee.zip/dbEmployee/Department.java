/*****
 * COPYRIGHT Joshua Supelana-Mix 11/7/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 *****/

class Department {
	
	private String name, desc;
	private int numEmployees;
	private double basePay;
	
	public Department(String name, String desc, double basePay) {
		this.name = name;
		this.desc = desc;
		this.basePay = basePay;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String set) {
		name = set;
	}
	
	public String getDesc() {
		return desc;
	}
	public void setDesc(String set) {
		desc = set;
	}
	
	public int getNumEmployees() {
		return numEmployees;
	}
	public void setNumEmployees(int set) {
		numEmployees = set;
	}
	public void adjNumEmployees(int adj) {
		numEmployees += adj;
	}
	
	public double getBasePay() {
		return basePay;
	}
	public void setBasePay(double set) {
		basePay = set;
	}
}