/*****
 * COPYRIGHT Joshua Supelana-Mix 11/7/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 *****/

class Employee {
	private String name, dept;
	private double salary;
	
	public Employee(String name, String dept, double salary) {
		this.name = name;
		this.dept = dept;
		this.salary = salary;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String set) {
		name = set;
	}
	
	public String getDept() {
		return dept;
	}
	public void setDept(String set) {
		dept = set;
	}
	
	public double getSalary() {
		return salary;
	}
	public void setSalary(double set) {
		salary = set;
	}
}