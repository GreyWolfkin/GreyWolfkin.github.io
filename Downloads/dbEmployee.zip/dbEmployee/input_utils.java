/*****
 * COPYRIGHT Joshua Supelana-Mix 11/7/2019
 * This product is for private use only
 * This product may not be modified, redistributed, sold, or used for any commercial purpose
 * except by the copyright holder
 *****/

/******
 * input_utils v1.0
 * Returns user input of required type
 * Catches NumberFormatException to prevent returning
 *	incorrect type. Loops until input is valid
 * Overloaded methods allow for minimum/maximum allowed
 *	inputs on int, double, and float returns
 *****/

import java.util.Scanner;

class input_utils {
	
	Scanner scan = new Scanner(System.in);
	
	public void get() {
		// Waits for any input
		scan.nextLine();
	}
	
	public String get(String string) {
		System.out.print(string);
		String userIn = scan.nextLine();
		return userIn;
	}
	
	public char[] getArr(String string) {
		System.out.print(string);
		String userIn = scan.nextLine().toUpperCase();
		char[] arr = userIn.toCharArray();
		return arr;
	}
	
	public String[] getSplit(String string, String delim) {
		System.out.print(string);
		String[] userIn = scan.nextLine().toUpperCase().split(delim);
		return userIn;
	}
	
	public int getInt(String string) {
		while(true) {
			System.out.print(string);
			try {
				int userIn = Integer.parseInt(scan.nextLine());
				return userIn;
			} catch(NumberFormatException ex) {
				System.out.println("Invalid input");
			}
		}
	}
	public int getInt(String string, int min, int max) {
		while(true) {
			System.out.print(string);
			try {
				int userIn = Integer.parseInt(scan.nextLine());
				if(max >= userIn && userIn >= min) {
					return userIn;
				} else {
					System.out.println("Input must be between " + min + " and " + max);
				}
			} catch(NumberFormatException ex) {
				System.out.println("Invalid input");
			}
		}
	}
	
	public double getDouble(String string) {
		while(true) {
			System.out.print(string);
			try {
				double userIn = Double.parseDouble(scan.nextLine());
				return userIn;
			} catch(NumberFormatException ex) {
				System.out.println("Invalid input");
			}
		}
	}
	public double getDouble(String string, double min, double max) {
		while(true) {
			System.out.print(string);
			try {
				double userIn = Double.parseDouble(scan.nextLine());
				if(max >= userIn && userIn >= min) {
					return userIn;
				} else {
					System.out.println("Input must be between " + min + " and " + max);
				}
			} catch(NumberFormatException ex) {
				System.out.println("Invalid input");
			}
		}
	}
	
	public float getFloat(String string) {
		while(true) {
			System.out.print(string);
			try {
				float userIn = Float.parseFloat(scan.nextLine());
				return userIn;
			} catch(NumberFormatException ex) {
				System.out.println("Invalid input");
			}
		}
	}
	public float getFloat(String string, float min, float max) {
		while(true) {
			System.out.print(string);
			try {
				float userIn = Float.parseFloat(scan.nextLine());
				if(max >= userIn && userIn >= min) {
					return userIn;
				} else {
					System.out.println("Input must be between " + min + " and " + max);
				}
			} catch(NumberFormatException ex) {
				System.out.println("Invalid input");
			}
		}
	}
}