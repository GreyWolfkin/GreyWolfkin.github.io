class Room {
	
	private String name, desc, doorColor;
	private boolean n, e, s, w, locked;
	private boolean[] exit = {n, e, s, w};
	private int exitNum;
	
	Room(String name, String desc, boolean n, boolean e, boolean s, boolean w, boolean locked, String doorColor) {
		this.name = name;
		this.desc = desc;
		this.n = n;
		this.e = e;
		this.s = s;
		this.w = w;
		this.locked = locked;
		this.doorColor = doorColor;
		this.exitNum = 0;
		
		if(n) {
			exitNum++;
		}
		if(e) {
			exitNum++;
		}
		if(s) {
			exitNum++;
		}
		if(w) {
			exitNum++;
		}
	}
	
	Room(String name, String desc, boolean n, boolean e, boolean s, boolean w, boolean locked) {
		this.name = name;
		this.desc = desc;
		this.n = n;
		this.e = e;
		this.s = s;
		this.w = w;
		this.locked = locked;
		this.doorColor = "None";
		this.exitNum = 0;
		
		if(n) {
			exitNum++;
		}
		if(e) {
			exitNum++;
		}
		if(s) {
			exitNum++;
		}
		if(w) {
			exitNum++;
		}
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public boolean getN() {
		return n;
	}
	public void setN(boolean n) {
		this.n = n;
	}
	
	public boolean getE() {
		return e;
	}
	public void setE(boolean e) {
		this.e = e;
	}
	
	public boolean getS() {
		return s;
	}
	public void setS(boolean s) {
		this.s = s;
	}
	
	public boolean getW() {
		return w;
	}
	public void setW(boolean w) {
		this.w = w;
	}
	
	public boolean getLocked() {
		return locked;
	}
	public void setLocked(boolean locked) {
		this.locked = locked;
	}
	
	public String getDoorColor() {
		return doorColor;
	}
	public void setDoorColor(String doorColor) {
		this.doorColor = doorColor;
	}
	
	public void printExits() {
		if (exitNum > 2) {
			System.out.print("There are exits to the ");
			int i = 0;
			boolean printN = false;
			boolean printE = false;
			boolean printS = false;
			while (i < exitNum-1) {
				if(!printN) {
					if(n) {
						System.out.print("North, ");
						i++;
						printN = true;
						continue;
					}
				}
				if(!printE) {
					if(e) {
						System.out.print("East, ");
						i++;
						printE = true;
						continue;
					}
				}
				if(!printS) {
					if(s) {
						System.out.print("South, ");
						i++;
						printS = true;
						continue;
					}
				}
			}
			int j = 0;
			while (j == 0) {
				if(w) {
					System.out.println("and West.");
					j++;
					break;
				}
				if(s) {
					System.out.println("and South.");
					j++;
					break;
				}
				if(e) {
					System.out.println("and East.");
					j++;
					break;
				}
			}
		} else if (exitNum == 2) {
			System.out.print("There are exits to the ");
			int i = 0;
			while(i == 0) {
				if(n) {
					System.out.print("North ");
					i++;
					break;
				}
				if(e) {
					System.out.print("East ");
					i++;
					break;
				}
				if(s) {
					System.out.print("South ");
					i++;
					break;
				}
			}
			int j = 0;
			while (j == 0) {
				if(w) {
					System.out.println("and West.");
					j++;
					break;
				}
				if(s) {
					System.out.println("and South.");
					j++;
					break;
				}
				if(e) {
					System.out.println("and East.");
					j++;
					break;
				}
			}
		} else {
			System.out.print("There is an exit to the ");
			if(n) {
				System.out.println("North.");
			}
			if(e) {
				System.out.println("East.");
			}
			if(s) {
				System.out.println("South.");
			}
			if(w) {
				System.out.println("West.");
			}
		}
	}
}