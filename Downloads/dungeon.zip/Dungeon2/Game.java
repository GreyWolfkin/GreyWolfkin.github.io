import java.util.*;

public class Game {
	
	static Scanner scan = new Scanner(System.in);
	static Random rand = new Random();
	
	static boolean run = true;
	
	static boolean keyPurple = false;
	static boolean keyRed = false;
	static boolean keyBlue = false;
	static boolean keyGreen = false;
	static boolean keyGray = false;
	static boolean keyBlack = false;
	
	static ArrayList<String> inv = new ArrayList<String>();
	
	//Room(name, desc, n, e, s, w, locked);
	//Room(name, desc, n, e, s, w, locked, doorColor);
	static Room r1 = new Room("R1", "Room 1", true, false, false, false, false);
	static Room r2 = new Room("R2", "Room 2", true, true, true, true, false);
	static Room r3 = new Room("R3", "Room 3", false, false, true, false, false);
	static Room r4 = new Room("R4", "Room 4", true, true, false, true, false);
	static Room r5 = new Room("R5", "Room 5", false, true, false, false, false);
	static Room r6 = new Room("R6", "Room 6", false, false, true, false, true, "Purple");
	static Room r7 = new Room("R7", "Room 7", false, true, false, true, false);
	static Room r8 = new Room("R8", "Room 8", true, false, false, true, true, "Red");
	static Room r9 = new Room("R9", "Room 9", true, true, true, false, true, "Blue");
	static Room r10 = new Room("R10", "Room 10", false, false, true, false, false);
	static Room r11 = new Room("R11", "Room 11", false, true, false, true, true, "Green");
	static Room r12 = new Room("R12", "Room 12", false, false, true, true, true, "Gray");
	static Room r13 = new Room("R13", "Room 13", true, false, false, false, true, "Black");
	
	static Room[] rooms = {r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13};
	//Room[x], [y]
	static Room[][] dungeon = {
		{null, null, null, null, null, null}, 
		{null, null, r5, null, null, null}, 
		{null, null, r4, r6, null, null}, 
		{null, r1, r2, r3, null, null}, 
		{null, null, r7, null, null, null}, 
		{null, null, r8, r9, r10, null}, 
		{null, null, null, r11, null, null}, 
		{null, null, r13, r12, null, null}, 
		{null, null, null, null, null, null}
	};
	
	//Sets start point
	static int x = 3;
	static int y = 1;
	
	static void listen() {
		String input = scan.nextLine();
		input.toLowerCase();
		switch(input) {
			case "n":
			case "e":
			case "s":
			case "w":
				listenMove(input);
				break;
			case "quit":
			case "end":
				run = false;
				break;
			default:
				System.out.println("Unrecognized input");
				break;
		}
	}
	
	static void listenMove(String input) {
		Room r = dungeon[x][y];
		Room rN = dungeon[x][y+1];
		Room rE = dungeon[x+1][y];
		Room rS = dungeon[x][y-1];
		Room rW = dungeon[x-1][y];
		
		switch(input) {
			case "n":
				if (r.getN()) {
					if (!rN.getLocked()) {
						y++;
					} else {
						System.out.println("That door is locked!");
					}
				} else {
					System.out.println("Cannot move North from here!");
				}
				break;
			case "e":
				if (r.getE()) {
					if (!rE.getLocked()) {
						x++;
					} else {
						System.out.println("That door is locked!");
					}
				} else {
					System.out.println("Cannot move East from here!");
				}
				break;
			case "s":
				if (r.getS()) {
					if (!rS.getLocked()) {
						y--;
					} else {
						System.out.println("That door is locked!");
					}
				} else {
					System.out.println("Cannot move South from here!");
				}
				break;
			case "w":
				if (r.getW()) {
					if (!rW.getLocked()) {
						x--;
					} else {
						System.out.println("Cannot move East from here!");
					}
				} else {
					System.out.println("Cannot move West from here!");
				}
				break;
		}
	}
	
	static void printLocked() {
		Room r = dungeon[x][y];
		Room rN = dungeon[x][y+1];
		Room rE = dungeon[x+1][y];
		Room rS = dungeon[x][y-1];
		Room rW = dungeon[x-1][y];
		
		if(rN != null) {
			if(r.getN()) {
				if(rN.getLocked()) {
					System.out.println("The door to the North is locked with a " + rN.getDoorColor() + " door.");
				}
			}
		}
		if(rE != null) {
			if(r.getE()) {
				if(rE.getLocked()) {
					System.out.println("The door to the East is locked with a " + rE.getDoorColor() + " door.");
				}
			}
		}
		if(rS != null) {
			if(r.getS()) {
				if(rS.getLocked()) {
					System.out.println("The door to the South is locked with a " + rS.getDoorColor() + " door.");
				}
			}
		}
		if(rW != null) {
			if(r.getW()) {
				if(rW.getLocked()) {
					System.out.println("The door to the West is locked with a " + rW.getDoorColor() + " door.");
				}
			}
		}
	}
	
	static void checkRoom() {
		Room r = dungeon[x][y];
		if (r == r13) {
			System.out.println("You win!");
		}
		if (r == r3) {
			System.out.println("Found a Blue Key!");
			keyBlue = true;
			inv.add("Blue Key");
		}
		if (r == r5) {
			System.out.println("Found a Red Key!");
			keyRed = true;
			inv.add("Red Key");
		}
		if (r == r6) {
			System.out.println("Found a Black Key!");
			keyBlack = true;
			inv.add("Black Key");
		}
		if (r == r7) {
			System.out.println("Found a Purple Key!");
			keyPurple = true;
			inv.add("Purple Key");
		}
		if (r == r8) {
			System.out.println("Found a Gray Key!");
			keyGray = true;
			inv.add("Gray Key");
		}
		if (r == r10) {
			System.out.println("Found a Green Key!");
			keyGreen = true;
			inv.add("Green Key");
		}
	}
	
	public void printInv() {
		System.out.println("Inventory:");
		for (String i : inv) {
			System.out.println(i);
		}
	}
	
	public boolean checkKey(String check) {
		boolean key = false;
		for (String i : inv) {
			if (check.equals(i)) {
				key = true;
			}
		}
		return key;
	}
	
	public static void main(String[] args) {
		
		while(run) {
			Room r = dungeon[x][y];
			System.out.println(r.getDesc());
			/*
			if (r == r5) {
				System.out.println("You win!");
				run = false;
				break;
			}
			*/
			r.printExits();
			printLocked();
			checkRoom();
			listen();
		}
		
		/*
		for (Room i : rooms) {
			System.out.println(i.getDesc());
			i.printExits();
		}
		*/
	}
}